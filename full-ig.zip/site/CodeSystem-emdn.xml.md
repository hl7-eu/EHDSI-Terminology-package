# EMDN CodeSystem - XML Representation - eHDSI Terminologies v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **EMDN CodeSystem**

## : EMDN CodeSystem - XML Representation

| |
| :--- |
| Active as of 2025-12-23 |

[Raw xml](CodeSystem-emdn.xml) | [Download](CodeSystem-emdn.xml)

content temporarily excluded                  

              

