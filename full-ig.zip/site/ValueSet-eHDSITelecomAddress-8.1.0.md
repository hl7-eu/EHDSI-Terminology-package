# eHDSI Telecom Address - eHDSI Terminologies v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **eHDSI Telecom Address**

## ValueSet: eHDSI Telecom Address 

| | |
| :--- | :--- |
| *Official URL*:http://terminology.ehdsi.eu/ValueSet/eHDSITelecomAddress | *Version*:0.2.0 |
| Active as of 2025-12-23 | *Computable Name*:eHDSITelecomAddress |
| *Other Identifiers:*OID:1.3.6.1.4.1.12559.11.10.1.3.1.42.40 | |

 
The Value Set is used (optionally) to code the usage of a phone number, email and all telecommunications. Can be used for all phone numbers mentioned in the three CDA-documents. 

 **References** 

This value set is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "eHDSITelecomAddress-8.1.0",
  "url" : "http://terminology.ehdsi.eu/ValueSet/eHDSITelecomAddress",
  "identifier" : [
    {
      "system" : "urn:ietf:rfc:3986",
      "value" : "urn:oid:1.3.6.1.4.1.12559.11.10.1.3.1.42.40"
    }
  ],
  "version" : "0.2.0",
  "name" : "eHDSITelecomAddress",
  "title" : "eHDSI Telecom Address",
  "status" : "active",
  "experimental" : false,
  "date" : "2025-12-23T10:21:27+00:00",
  "publisher" : "HL7 Europe",
  "contact" : [
    {
      "name" : "HL7 Europe",
      "telecom" : [
        {
          "system" : "url",
          "value" : "http://hl7europe.org"
        }
      ]
    }
  ],
  "description" : "The Value Set is used (optionally) to code the usage of a phone number, email and all telecommunications. Can be used for all phone numbers mentioned in the three CDA-documents.",
  "compose" : {
    "include" : [
      {
        "system" : "http://terminology.hl7.org/CodeSystem/v3-AddressUse",
        "concept" : [
          {
            "code" : "AS",
            "display" : "answering service"
          },
          {
            "code" : "EC",
            "display" : "emergency contact"
          },
          {
            "code" : "H",
            "display" : "home address"
          },
          {
            "code" : "HP",
            "display" : "primary home"
          },
          {
            "code" : "HV",
            "display" : "vacation home"
          },
          {
            "code" : "MC",
            "display" : "mobile contact"
          },
          {
            "code" : "PG",
            "display" : "pager"
          },
          {
            "code" : "WP",
            "display" : "work place"
          },
          {
            "code" : "TMP",
            "display" : "temporary address"
          },
          {
            "code" : "PHYS",
            "display" : "physical visit address"
          },
          {
            "code" : "PST",
            "display" : "postal address"
          }
        ]
      }
    ]
  }
}

```
