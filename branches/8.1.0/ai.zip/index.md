# Home - eHDSI Terminologies v8.1.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://hl7europe.org/fhir/terminology/ehdsi/ImplementationGuide/hl7.eu.terminology.ehdsi | *Version*:8.1.0 |
| Active as of 2025-11-18 | *Computable Name*:EHDSI |

This is a Terminology Package

