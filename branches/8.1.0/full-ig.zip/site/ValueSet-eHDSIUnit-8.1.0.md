# eHDSI Unit - eHDSI Terminologies v8.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **eHDSI Unit**

## ValueSet: eHDSI Unit 

| | |
| :--- | :--- |
| *Official URL*:http://terminology.ehdsi.eu/ValueSet/eHDSIUnit | *Version*:8.1.0 |
| Active as of 2025-11-18 | *Computable Name*:eHDSIUnit |
| *Other Identifiers:*OID:1.3.6.1.4.1.12559.11.10.1.3.1.42.16 | |

 **References** 

This value set is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

### Logical Definition (CLD)

 

### Expansion

No Expansion for this valueset (not supported by Publication Tooling)

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "eHDSIUnit-8.1.0",
  "url" : "http://terminology.ehdsi.eu/ValueSet/eHDSIUnit",
  "identifier" : [
    {
      "system" : "urn:ietf:rfc:3986",
      "value" : "urn:oid:1.3.6.1.4.1.12559.11.10.1.3.1.42.16"
    }
  ],
  "version" : "8.1.0",
  "name" : "eHDSIUnit",
  "title" : "eHDSI Unit",
  "status" : "active",
  "experimental" : false,
  "date" : "2025-11-18T20:02:38+00:00",
  "publisher" : "HL7 Europe",
  "contact" : [
    {
      "name" : "HL7 Europe",
      "telecom" : [
        {
          "system" : "url",
          "value" : "http://hl7europe.org"
        }
      ]
    }
  ],
  "compose" : {
    "include" : [
      {
        "system" : "http://unitsofmeasure.org/",
        "concept" : [
          {
            "code" : "1",
            "display" : "Unit"
          },
          {
            "code" : "%",
            "display" : "percent"
          },
          {
            "code" : "%{abnormal}",
            "display" : "percent abnormal"
          },
          {
            "code" : "%{activity}",
            "display" : "percent activity"
          },
          {
            "code" : "%{aggregation}",
            "display" : "percent aggregation"
          },
          {
            "code" : "%{at_60_min}",
            "display" : "percent at 60 minute"
          },
          {
            "code" : "%{bacteria}",
            "display" : "percent of bacteria"
          },
          {
            "code" : "%{basal_activity}",
            "display" : "percent basal activity"
          },
          {
            "code" : "%{baseline}",
            "display" : "percent of baseline"
          },
          {
            "code" : "%{binding}",
            "display" : "percent binding"
          },
          {
            "code" : "%{blockade}",
            "display" : "percent blockade"
          },
          {
            "code" : "%{blocked}",
            "display" : "percent blocked"
          },
          {
            "code" : "%{bound}",
            "display" : "percent bound"
          },
          {
            "code" : "%{breakdown}",
            "display" : "percent breakdown"
          },
          {
            "code" : "%{cells}",
            "display" : "percent of cells"
          },
          {
            "code" : "%{deficient}",
            "display" : "percent deficient"
          },
          {
            "code" : "%{dose}",
            "display" : "percent dose"
          },
          {
            "code" : "%{excretion}",
            "display" : "percent excretion"
          },
          {
            "code" : "%{Hb}",
            "display" : "percent hemoglobin"
          },
          {
            "code" : "%{hemolysis}",
            "display" : "percent hemolysis"
          },
          {
            "code" : "%{index}",
            "display" : "percent index"
          },
          {
            "code" : "%{inhibition}",
            "display" : "percent inhibition"
          },
          {
            "code" : "%{loss_AChR}",
            "display" : "percent loss of acetylcholine receptor"
          },
          {
            "code" : "%{loss}",
            "display" : "percent loss"
          },
          {
            "code" : "%{lysis}",
            "display" : "percent lysis"
          },
          {
            "code" : "%{normal}",
            "display" : "percent normal"
          },
          {
            "code" : "%{penetration}",
            "display" : "percent penetration"
          },
          {
            "code" : "%{pooled_plasma}",
            "display" : "percent normal pooled plasma"
          },
          {
            "code" : "%{positive}",
            "display" : "percent positive"
          },
          {
            "code" : "%{RBCs}",
            "display" : "percent of red blood cells"
          },
          {
            "code" : "%{reactive}",
            "display" : "percent reactive"
          },
          {
            "code" : "%{recovery}",
            "display" : "percent recovery"
          },
          {
            "code" : "%{reference}",
            "display" : "percent reference"
          },
          {
            "code" : "%{relative}",
            "display" : "relative percent"
          },
          {
            "code" : "%{residual}",
            "display" : "percent residual"
          },
          {
            "code" : "%{response}",
            "display" : "percent response"
          },
          {
            "code" : "%{saturation}",
            "display" : "percent saturation"
          },
          {
            "code" : "%{total}",
            "display" : "percent total"
          },
          {
            "code" : "%{uptake}",
            "display" : "percent uptake"
          },
          {
            "code" : "%{viable}",
            "display" : "percent viable"
          },
          {
            "code" : "%{vol}",
            "display" : "percent by volume"
          },
          {
            "code" : "%{WBCs}",
            "display" : "percent of white blood cells"
          },
          {
            "code" : "/(12.h)",
            "display" : "per twelve hour"
          },
          {
            "code" : "/[arb'U]",
            "display" : "per arbitrary unit"
          },
          {
            "code" : "/[HPF]",
            "display" : "per high power field"
          },
          {
            "code" : "/[IU]",
            "display" : "per international unit"
          },
          {
            "code" : "/[LPF]",
            "display" : "per low power field"
          },
          {
            "code" : "/{entity}",
            "display" : "per entity"
          },
          {
            "code" : "/{OIF}",
            "display" : "per oil immersion field"
          },
          {
            "code" : "/10*10",
            "display" : "per 10 billion"
          },
          {
            "code" : "/10*12",
            "display" : "per trillion"
          },
          {
            "code" : "/10*12{RBCs}",
            "display" : "per trillion red blood cells"
          },
          {
            "code" : "/10*3",
            "display" : "per thousand"
          },
          {
            "code" : "/10*3{RBCs}",
            "display" : "per thousand red blood cells"
          },
          {
            "code" : "/10*4{RBCs}",
            "display" : "per 10 thousand red blood cells"
          },
          {
            "code" : "/10*6",
            "display" : "per million"
          },
          {
            "code" : "/10*9",
            "display" : "per billion"
          },
          {
            "code" : "/100",
            "display" : "per 100"
          },
          {
            "code" : "/100{cells}",
            "display" : "per 100 cells"
          },
          {
            "code" : "/100{neutrophils}",
            "display" : "per 100 neutrophils"
          },
          {
            "code" : "/100{spermatozoa}",
            "display" : "per 100 spermatozoa"
          },
          {
            "code" : "/100{WBCs}",
            "display" : "per 100 white blood cells"
          },
          {
            "code" : "/a",
            "display" : "per year"
          },
          {
            "code" : "/cm[H2O]",
            "display" : "per centimeter of water"
          },
          {
            "code" : "/d",
            "display" : "per day"
          },
          {
            "code" : "/dL",
            "display" : "per deciliter"
          },
          {
            "code" : "/g",
            "display" : "per gram"
          },
          {
            "code" : "/g{creat}",
            "display" : "per gram of creatinine"
          },
          {
            "code" : "/g{Hb}",
            "display" : "per gram of hemoglobin"
          },
          {
            "code" : "/g{tot_nit}",
            "display" : "per gram of total nitrogen"
          },
          {
            "code" : "/g{tot_prot}",
            "display" : "per gram of total protein"
          },
          {
            "code" : "/g{wet_tis}",
            "display" : "per gram of wet tissue"
          },
          {
            "code" : "/h",
            "display" : "per hour"
          },
          {
            "code" : "/kg",
            "display" : "per kilogram"
          },
          {
            "code" : "/kg{body_wt}",
            "display" : "per kilogram of body weight"
          },
          {
            "code" : "/L",
            "display" : "per liter"
          },
          {
            "code" : "/m2",
            "display" : "per square meter"
          },
          {
            "code" : "/m3",
            "display" : "per cubic meter"
          },
          {
            "code" : "/mg",
            "display" : "per milligram"
          },
          {
            "code" : "/min",
            "display" : "per minute"
          },
          {
            "code" : "/mL",
            "display" : "per milliliter"
          },
          {
            "code" : "/mm",
            "display" : "per millimeter"
          },
          {
            "code" : "/mmol{creat}",
            "display" : "per millimole of creatinine"
          },
          {
            "code" : "/mo",
            "display" : "per month"
          },
          {
            "code" : "/s",
            "display" : "per second"
          },
          {
            "code" : "/U",
            "display" : "per enzyme unit"
          },
          {
            "code" : "/uL",
            "display" : "per microliter"
          },
          {
            "code" : "/wk",
            "display" : "per week"
          },
          {
            "code" : "[APL'U]",
            "display" : "IgA anticardiolipin unit**"
          },
          {
            "code" : "[APL'U]/mL",
            "display" : "IgA anticardiolipin unit per milliliter**"
          },
          {
            "code" : "[arb'U]",
            "display" : "arbitrary unit"
          },
          {
            "code" : "[arb'U]/mL",
            "display" : "arbitrary unit per milliliter"
          },
          {
            "code" : "[AU]",
            "display" : "allergy unit"
          },
          {
            "code" : "[bdsk'U]",
            "display" : "Bodansky unit"
          },
          {
            "code" : "[beth'U]",
            "display" : "Bethesda unit"
          },
          {
            "code" : "[CFU]",
            "display" : "colony forming unit"
          },
          {
            "code" : "[CFU]/L",
            "display" : "colony forming unit per liter"
          },
          {
            "code" : "[CFU]/mL",
            "display" : "colony forming unit per milliliter"
          },
          {
            "code" : "[Ch]",
            "display" : "French (catheter gauge)"
          },
          {
            "code" : "[cin_i]",
            "display" : "cubic inch (international)"
          },
          {
            "code" : "[degF]",
            "display" : "degree Fahrenheit"
          },
          {
            "code" : "[diop]",
            "display" : "diopter"
          },
          {
            "code" : "[dr_av]",
            "display" : "dram (US and British)"
          },
          {
            "code" : "[drp]",
            "display" : "drop (1/12 milliliter)"
          },
          {
            "code" : "[foz_us]",
            "display" : "fluid ounce (US)"
          },
          {
            "code" : "[ft_i]",
            "display" : "foot (international)"
          },
          {
            "code" : "[ft_us]/[ft_us]",
            "display" : "feet (US) per feet (US)"
          },
          {
            "code" : "[gal_us]",
            "display" : "gallon (US)"
          },
          {
            "code" : "[GPL'U]",
            "display" : "IgG anticardiolipin unit**"
          },
          {
            "code" : "[GPL'U]/mL",
            "display" : "IgG anticardiolipin unit per milliliter**"
          },
          {
            "code" : "[HPF]",
            "display" : "high power field"
          },
          {
            "code" : "[in_i]",
            "display" : "inch (international)"
          },
          {
            "code" : "[in_i'H2O]",
            "display" : "inch (international) of water"
          },
          {
            "code" : "[in_us]",
            "display" : "inches (US)"
          },
          {
            "code" : "[IU]",
            "display" : "international unit"
          },
          {
            "code" : "[IU]/(2.h)",
            "display" : "international unit per 2 hour"
          },
          {
            "code" : "[IU]/(24.h)",
            "display" : "international unit per 24 hour"
          },
          {
            "code" : "[IU]/10*9{RBCs}",
            "display" : "international unit per billion red blood cells"
          },
          {
            "code" : "[IU]/d",
            "display" : "international unit per day"
          },
          {
            "code" : "[IU]/dL",
            "display" : "international unit per deciliter"
          },
          {
            "code" : "[IU]/g",
            "display" : "international unit per gram"
          },
          {
            "code" : "[IU]/g{Hb}",
            "display" : "international unit per gram of hemoglobin"
          },
          {
            "code" : "[IU]/h",
            "display" : "international unit per hour"
          },
          {
            "code" : "[IU]/kg",
            "display" : "international unit per kilogram"
          },
          {
            "code" : "[IU]/kg/d",
            "display" : "international unit per kilogram per day"
          },
          {
            "code" : "[IU]/L",
            "display" : "international unit per liter"
          },
          {
            "code" : "[IU]/L{37Cel}",
            "display" : "international unit per liter at 37 degrees Celsius"
          },
          {
            "code" : "[IU]/mg{creat}",
            "display" : "international unit per milligram of creatinine"
          },
          {
            "code" : "[IU]/min",
            "display" : "international unit per minute"
          },
          {
            "code" : "[IU]/mL",
            "display" : "international unit per milliliter"
          },
          {
            "code" : "[ka'U]",
            "display" : "King Armstrong unit"
          },
          {
            "code" : "[knk'U]",
            "display" : "Kunkel unit"
          },
          {
            "code" : "[lb_av]",
            "display" : "pound (US and British)"
          },
          {
            "code" : "[LPF]",
            "display" : "low power field"
          },
          {
            "code" : "[mclg'U]",
            "display" : "Maclagan unit"
          },
          {
            "code" : "[MET].min/wk",
            "display" : "metabolic equivalent minute per week"
          },
          {
            "code" : "[mi_i]",
            "display" : "mile (international)"
          },
          {
            "code" : "[MPL'U]",
            "display" : "IgM anticardiolipin unit**"
          },
          {
            "code" : "[MPL'U]/mL",
            "display" : "IgM anticardiolipin unit per milliliter**"
          },
          {
            "code" : "[oz_av]",
            "display" : "ounce (US and British)"
          },
          {
            "code" : "[oz_tr]",
            "display" : "Troy ounce"
          },
          {
            "code" : "[pH]",
            "display" : "pH"
          },
          {
            "code" : "[ppb]",
            "display" : "part per billion"
          },
          {
            "code" : "[ppm]",
            "display" : "part per million"
          },
          {
            "code" : "[ppm]{v/v}",
            "display" : "part per million in volume per volume"
          },
          {
            "code" : "[ppth]",
            "display" : "part per thousand"
          },
          {
            "code" : "[pptr]",
            "display" : "part per trillion"
          },
          {
            "code" : "[psi]",
            "display" : "pound per square inch"
          },
          {
            "code" : "[pt_us]",
            "display" : "pint (US)"
          },
          {
            "code" : "[qt_us]",
            "display" : "quart (US)"
          },
          {
            "code" : "[sft_i]",
            "display" : "square foot (international)"
          },
          {
            "code" : "[sin_i]",
            "display" : "square inch (international)"
          },
          {
            "code" : "[syd_i]",
            "display" : "square yard (international)"
          },
          {
            "code" : "[tbs_us]",
            "display" : "tablespoon (US)"
          },
          {
            "code" : "[tb'U]",
            "display" : "tuberculin unit"
          },
          {
            "code" : "[todd'U]",
            "display" : "Todd unit"
          },
          {
            "code" : "[tsp_us]",
            "display" : "teaspoon (US)"
          },
          {
            "code" : "[yd_i]",
            "display" : "yard (international)"
          },
          {
            "code" : "{#}",
            "display" : "number"
          },
          {
            "code" : "{#}/[HPF]",
            "display" : "number per high power field"
          },
          {
            "code" : "{#}/[LPF]",
            "display" : "number per low power field"
          },
          {
            "code" : "{#}/{platelet}",
            "display" : "molecule per platelet"
          },
          {
            "code" : "{#}/a",
            "display" : "number per annum (year)"
          },
          {
            "code" : "{#}/d",
            "display" : "number per day"
          },
          {
            "code" : "{#}/g",
            "display" : "number per gram"
          },
          {
            "code" : "{#}/L",
            "display" : "number per liter"
          },
          {
            "code" : "{#}/min",
            "display" : "number per minute"
          },
          {
            "code" : "{#}/mL",
            "display" : "number per milliliter"
          },
          {
            "code" : "{#}/uL",
            "display" : "number per microliter"
          },
          {
            "code" : "{#}/wk",
            "display" : "number per week"
          },
          {
            "code" : "{absorbance}",
            "display" : "absorbance"
          },
          {
            "code" : "{activity}",
            "display" : "activity"
          },
          {
            "code" : "{AHF'U}",
            "display" : "American Hospital Formulary unit"
          },
          {
            "code" : "{APS'U}",
            "display" : "IgA antiphosphatidylserine unit"
          },
          {
            "code" : "{ARU}",
            "display" : "aspirin response unit"
          },
          {
            "code" : "{beats}/min",
            "display" : "heart beats per minute"
          },
          {
            "code" : "{binding_index}",
            "display" : "binding index"
          },
          {
            "code" : "{breaths}/min",
            "display" : "breaths per minute"
          },
          {
            "code" : "{CAE'U}",
            "display" : "complement activity enzyme unit"
          },
          {
            "code" : "{CAG_repeats}",
            "display" : "CAG trinucleotide repeats"
          },
          {
            "code" : "{cells}",
            "display" : "cells"
          },
          {
            "code" : "{cells}/[HPF]",
            "display" : "cells per high power field"
          },
          {
            "code" : "{cells}/uL",
            "display" : "cells per microliter"
          },
          {
            "code" : "{CH100'U}",
            "display" : "complement CH100 unit"
          },
          {
            "code" : "{clock_time}",
            "display" : "clock time e.g 12:30PM"
          },
          {
            "code" : "{copies}",
            "display" : "copies"
          },
          {
            "code" : "{copies}/mL",
            "display" : "copies per milliliter"
          },
          {
            "code" : "{copies}/ug",
            "display" : "copies per microgram"
          },
          {
            "code" : "{count}",
            "display" : "count"
          },
          {
            "code" : "{CPM}",
            "display" : "counts per minute"
          },
          {
            "code" : "{CPM}/10*3{cell}",
            "display" : "counts per minute per thousand cells"
          },
          {
            "code" : "{Ct_value}",
            "display" : "Cycle threshold value"
          },
          {
            "code" : "{delta_OD}",
            "display" : "change in (delta) optical density"
          },
          {
            "code" : "{dilution}",
            "display" : "dilution"
          },
          {
            "code" : "{Ehrlich'U}",
            "display" : "Ehrlich unit"
          },
          {
            "code" : "{Ehrlich'U}/(2.h)",
            "display" : "Ehrlich unit per 2 hour"
          },
          {
            "code" : "{Ehrlich'U}/100.g",
            "display" : "Ehrlich unit per 100 gram"
          },
          {
            "code" : "{Ehrlich'U}/d",
            "display" : "Ehrlich unit per day"
          },
          {
            "code" : "{Ehrlich'U}/dL",
            "display" : "Ehrlich unit per deciliter"
          },
          {
            "code" : "{EIA_index}",
            "display" : "EIA index"
          },
          {
            "code" : "{EIA_titer}",
            "display" : "EIA titer"
          },
          {
            "code" : "{EIA'U}",
            "display" : "EIA unit"
          },
          {
            "code" : "{EIA'U}/U",
            "display" : "EIA unit per enzyme unit"
          },
          {
            "code" : "{ELISA'U}",
            "display" : "ELISA unit"
          },
          {
            "code" : "{EV}",
            "display" : "EIA value"
          },
          {
            "code" : "{FIU}",
            "display" : "fluorescent intensity unit"
          },
          {
            "code" : "{fraction}",
            "display" : "fraction"
          },
          {
            "code" : "{GAA_repeats}",
            "display" : "GAA trinucleotide repeats"
          },
          {
            "code" : "{genomes}/mL",
            "display" : "genomes per milliliter"
          },
          {
            "code" : "{Globules}/[HPF]",
            "display" : "globules (drops) per high power field"
          },
          {
            "code" : "{GPS'U}",
            "display" : "IgG antiphosphatidylserine unit"
          },
          {
            "code" : "{HA_titer}",
            "display" : "influenza hemagglutination titer"
          },
          {
            "code" : "{IFA_index}",
            "display" : "immunofluorescence assay index"
          },
          {
            "code" : "{IFA_titer}",
            "display" : "Immunofluorescence assay titer"
          },
          {
            "code" : "{ImmuneComplex'U}",
            "display" : "immune complex unit"
          },
          {
            "code" : "{index_val}",
            "display" : "index value"
          },
          {
            "code" : "{index}",
            "display" : "index value"
          },
          {
            "code" : "{INR}",
            "display" : "international normalized ratio"
          },
          {
            "code" : "{ISR}",
            "display" : "immune status ratio"
          },
          {
            "code" : "{JDF'U}",
            "display" : "Juvenile Diabetes Foundation unit"
          },
          {
            "code" : "{JDF'U}/L",
            "display" : "Juvenile Diabetes Foundation unit per liter"
          },
          {
            "code" : "{KCT'U}",
            "display" : "kaolin clotting time"
          },
          {
            "code" : "{KRONU'U}/mL",
            "display" : "Kronus unit per milliliter"
          },
          {
            "code" : "{Log_copies}/mL",
            "display" : "log (base 10) copies per milliliter"
          },
          {
            "code" : "{Log_IU}",
            "display" : "log (base 10) international unit"
          },
          {
            "code" : "{Log_IU}/mL",
            "display" : "log (base 10) international unit per milliliter"
          },
          {
            "code" : "{Log}",
            "display" : "log base 10"
          },
          {
            "code" : "{Lyme_index_value}",
            "display" : "Lyme index value"
          },
          {
            "code" : "{M.o.M}",
            "display" : "multiple of the median"
          },
          {
            "code" : "{minidrop}/min",
            "display" : "minidrop per minute"
          },
          {
            "code" : "{minidrop}/s",
            "display" : "minidrop per second"
          },
          {
            "code" : "{mm/dd/yyyy}",
            "display" : "month-day-year"
          },
          {
            "code" : "{MPS'U}",
            "display" : "IgM antiphosphatidylserine unit"
          },
          {
            "code" : "{MPS'U}/mL",
            "display" : "IgM antiphosphatidylserine unit per milliliter"
          },
          {
            "code" : "{mutation}",
            "display" : "mutation"
          },
          {
            "code" : "{OD_unit}",
            "display" : "optical density unit"
          },
          {
            "code" : "{Pan_Bio'U}",
            "display" : "panbio unit"
          },
          {
            "code" : "{percentile}",
            "display" : "percentile"
          },
          {
            "code" : "{phenotype}",
            "display" : "phenotype"
          },
          {
            "code" : "{ratio}",
            "display" : "ratio"
          },
          {
            "code" : "{RBC}/uL",
            "display" : "red blood cell per microliter"
          },
          {
            "code" : "{rel_saturation}",
            "display" : "relative saturation"
          },
          {
            "code" : "{risk}",
            "display" : "risk"
          },
          {
            "code" : "{Rubella_virus}",
            "display" : "rubella virus"
          },
          {
            "code" : "{s_co_ratio}",
            "display" : "signal to cutoff ratio"
          },
          {
            "code" : "{saturation}",
            "display" : "saturation"
          },
          {
            "code" : "{score}",
            "display" : "score"
          },
          {
            "code" : "{shift}",
            "display" : "shift"
          },
          {
            "code" : "{spermatozoa}/mL",
            "display" : "spermatozoa per milliliter"
          },
          {
            "code" : "{STDV}",
            "display" : "standard deviation"
          },
          {
            "code" : "{titer}",
            "display" : "titer"
          },
          {
            "code" : "{TmStp}",
            "display" : "time stamp"
          },
          {
            "code" : "{Tscore}",
            "display" : "t score"
          },
          {
            "code" : "{TSI_index}",
            "display" : "thyroid-stimulating immunoglobulin index"
          },
          {
            "code" : "{WBCs}",
            "display" : "white blood cells"
          },
          {
            "code" : "{yyyy}",
            "display" : "year"
          },
          {
            "code" : "{Zscore}",
            "display" : "z score"
          },
          {
            "code" : "10*12/L",
            "display" : "trillion per liter"
          },
          {
            "code" : "10*3",
            "display" : "thousand"
          },
          {
            "code" : "10*3/L",
            "display" : "thousand per liter"
          },
          {
            "code" : "10*3/mL",
            "display" : "thousand per milliliter"
          },
          {
            "code" : "10*3/uL",
            "display" : "thousand per microliter"
          },
          {
            "code" : "10*3{copies}/mL",
            "display" : "thousand copies per milliliter"
          },
          {
            "code" : "10*3{RBCs}",
            "display" : "thousand red blood cells"
          },
          {
            "code" : "10*4/uL",
            "display" : "10 thousand per microliter"
          },
          {
            "code" : "10*5",
            "display" : "one hundred thousand"
          },
          {
            "code" : "10*6",
            "display" : "million"
          },
          {
            "code" : "10*6.[CFU]/L",
            "display" : "million colony forming unit per liter"
          },
          {
            "code" : "10*6.[IU]",
            "display" : "million international unit"
          },
          {
            "code" : "10*6/(24.h)",
            "display" : "million per 24 hour"
          },
          {
            "code" : "10*6/kg",
            "display" : "million per kilogram"
          },
          {
            "code" : "10*6/L",
            "display" : "million per liter"
          },
          {
            "code" : "10*6/mL",
            "display" : "million per milliliter"
          },
          {
            "code" : "10*6/uL",
            "display" : "million per microliter"
          },
          {
            "code" : "10*8",
            "display" : "100 million"
          },
          {
            "code" : "10*9/L",
            "display" : "billion per liter"
          },
          {
            "code" : "10*9/mL",
            "display" : "billion per milliliter"
          },
          {
            "code" : "10*9/uL",
            "display" : "billion per microliter"
          },
          {
            "code" : "10.L/(min.m2)",
            "display" : "10 liter per minute per square meter"
          },
          {
            "code" : "10.L/min",
            "display" : "10 liter per minute"
          },
          {
            "code" : "10.uN.s/(cm5.m2)",
            "display" : "10 micronewton second per centimeter to the fifth power per square meter"
          },
          {
            "code" : "24.h",
            "display" : "24 hour"
          },
          {
            "code" : "A",
            "display" : "ampere"
          },
          {
            "code" : "a",
            "display" : "year"
          },
          {
            "code" : "A/m",
            "display" : "ampere per meter"
          },
          {
            "code" : "ag/{cell}",
            "display" : "attogram per cell"
          },
          {
            "code" : "atm",
            "display" : "atmosphere"
          },
          {
            "code" : "bar",
            "display" : "bar"
          },
          {
            "code" : "Bq",
            "display" : "Becquerel"
          },
          {
            "code" : "cal",
            "display" : "calorie"
          },
          {
            "code" : "Cel",
            "display" : "degree Celsius"
          },
          {
            "code" : "cg",
            "display" : "centigram"
          },
          {
            "code" : "cL",
            "display" : "centiliter"
          },
          {
            "code" : "cm",
            "display" : "centimeter"
          },
          {
            "code" : "cm/s",
            "display" : "centimeter per second"
          },
          {
            "code" : "cm[H2O]",
            "display" : "centimeter of water"
          },
          {
            "code" : "cm[H2O]/L/s",
            "display" : "centimeter of water per liter per second"
          },
          {
            "code" : "cm[H2O]/s/m",
            "display" : "centimeter of water per second per meter"
          },
          {
            "code" : "cm[Hg]",
            "display" : "centimeter of mercury"
          },
          {
            "code" : "cm2",
            "display" : "square centimeter"
          },
          {
            "code" : "cm2/s",
            "display" : "square centimeter per second"
          },
          {
            "code" : "cm3",
            "display" : "cubic centimeter"
          },
          {
            "code" : "cP",
            "display" : "centipoise"
          },
          {
            "code" : "cSt",
            "display" : "centistoke"
          },
          {
            "code" : "d",
            "display" : "day"
          },
          {
            "code" : "d/(7.d)",
            "display" : "day per 7 day"
          },
          {
            "code" : "d/wk",
            "display" : "days per week"
          },
          {
            "code" : "daL/min",
            "display" : "dekaliter per minute"
          },
          {
            "code" : "daL/min/m2",
            "display" : "dekaliter per minute per square meter"
          },
          {
            "code" : "dB",
            "display" : "decibel"
          },
          {
            "code" : "deg",
            "display" : "degree (plane angle)"
          },
          {
            "code" : "deg/s",
            "display" : "degree per second"
          },
          {
            "code" : "dg",
            "display" : "decigram"
          },
          {
            "code" : "dL",
            "display" : "deciliter"
          },
          {
            "code" : "dm",
            "display" : "decimeter"
          },
          {
            "code" : "dm2/s2",
            "display" : "square decimeter per square second"
          },
          {
            "code" : "dyn.s/(cm.m2)",
            "display" : "dyne second per centimeter per square meter"
          },
          {
            "code" : "dyn.s/cm",
            "display" : "dyne second per centimeter"
          },
          {
            "code" : "eq",
            "display" : "equivalent"
          },
          {
            "code" : "eq/L",
            "display" : "equivalent per liter"
          },
          {
            "code" : "eq/mL",
            "display" : "equivalent per milliliter"
          },
          {
            "code" : "eq/mmol",
            "display" : "equivalent per millimole"
          },
          {
            "code" : "eq/umol",
            "display" : "equivalent per micromole"
          },
          {
            "code" : "erg",
            "display" : "erg"
          },
          {
            "code" : "eV",
            "display" : "electron Volt"
          },
          {
            "code" : "F",
            "display" : "Farad"
          },
          {
            "code" : "fg",
            "display" : "femtogram"
          },
          {
            "code" : "fL",
            "display" : "femtoliter"
          },
          {
            "code" : "fm",
            "display" : "femtometer"
          },
          {
            "code" : "fmol",
            "display" : "femtomole"
          },
          {
            "code" : "fmol/g",
            "display" : "femtomole per gram"
          },
          {
            "code" : "fmol/L",
            "display" : "femtomole per liter"
          },
          {
            "code" : "fmol/mg",
            "display" : "femtomole per milligram"
          },
          {
            "code" : "fmol/mg{cyt_prot}",
            "display" : "femtomole per milligram of cytosol protein"
          },
          {
            "code" : "fmol/mg{prot}",
            "display" : "femtomole per milligram of protein"
          },
          {
            "code" : "fmol/mL",
            "display" : "femtomole per milliliter"
          },
          {
            "code" : "g",
            "display" : "gram"
          },
          {
            "code" : "g.m",
            "display" : "gram meter"
          },
          {
            "code" : "g.m/{beat}",
            "display" : "gram meter per heart beat"
          },
          {
            "code" : "g/(100.g)",
            "display" : "gram per 100 gram"
          },
          {
            "code" : "g/(12.h)",
            "display" : "gram per 12 hour"
          },
          {
            "code" : "g/(24.h)",
            "display" : "gram per 24 hour"
          },
          {
            "code" : "g/(3.d)",
            "display" : "gram per 3 days"
          },
          {
            "code" : "g/(4.h)",
            "display" : "gram per 4 hour"
          },
          {
            "code" : "g/(48.h)",
            "display" : "gram per 48 hour"
          },
          {
            "code" : "g/(5.h)",
            "display" : "gram per 5 hour"
          },
          {
            "code" : "g/(6.h)",
            "display" : "gram per 6 hour"
          },
          {
            "code" : "g/(72.h)",
            "display" : "gram per 72 hour"
          },
          {
            "code" : "g/(8.h){shift}",
            "display" : "gram per 8 hour shift"
          },
          {
            "code" : "g/{specimen}",
            "display" : "gram per specimen"
          },
          {
            "code" : "g/{total_output}",
            "display" : "gram per total output"
          },
          {
            "code" : "g/{total_weight}",
            "display" : "gram per total weight"
          },
          {
            "code" : "g/cm2",
            "display" : "gram per square centimeter"
          },
          {
            "code" : "g/cm3",
            "display" : "gram per cubic centimeter"
          },
          {
            "code" : "g/d",
            "display" : "gram per day"
          },
          {
            "code" : "g/dL",
            "display" : "gram per deciliter"
          },
          {
            "code" : "g/g",
            "display" : "gram per gram"
          },
          {
            "code" : "g/g{creat}",
            "display" : "gram per gram of creatinine"
          },
          {
            "code" : "g/g{globulin}",
            "display" : "gram per gram of globulin"
          },
          {
            "code" : "g/g{tissue}",
            "display" : "gram per gram of tissue"
          },
          {
            "code" : "g/h",
            "display" : "gram per hour"
          },
          {
            "code" : "g/h/m2",
            "display" : "gram per hour per square meter"
          },
          {
            "code" : "g/kg",
            "display" : "gram per kilogram"
          },
          {
            "code" : "g/kg/(8.h)",
            "display" : "gram per kilogram per 8 hour"
          },
          {
            "code" : "g/kg/(8.h){shift}",
            "display" : "gram per kilogram per 8 hour shift"
          },
          {
            "code" : "g/kg/d",
            "display" : "gram per kilogram per day"
          },
          {
            "code" : "g/kg/h",
            "display" : "gram per kilogram per hour"
          },
          {
            "code" : "g/kg/min",
            "display" : "gram per kilogram per minute"
          },
          {
            "code" : "g/L",
            "display" : "gram per liter"
          },
          {
            "code" : "g/m2",
            "display" : "gram per square meter"
          },
          {
            "code" : "g/mg",
            "display" : "gram per milligram"
          },
          {
            "code" : "g/min",
            "display" : "gram per minute"
          },
          {
            "code" : "g/mL",
            "display" : "gram per milliliter"
          },
          {
            "code" : "g/mmol",
            "display" : "gram per millimole"
          },
          {
            "code" : "g/mol{creat}",
            "display" : "gram per mole of creatinine"
          },
          {
            "code" : "g{creat}",
            "display" : "gram of creatinine"
          },
          {
            "code" : "g{Hb}",
            "display" : "gram of hemoglobin"
          },
          {
            "code" : "g{total_nit}",
            "display" : "gram of total nitrogen"
          },
          {
            "code" : "g{total_prot}",
            "display" : "gram of total protein"
          },
          {
            "code" : "g{wet_tissue}",
            "display" : "gram of wet tissue"
          },
          {
            "code" : "Gy",
            "display" : "Gray"
          },
          {
            "code" : "H",
            "display" : "Henry"
          },
          {
            "code" : "h",
            "display" : "hour"
          },
          {
            "code" : "h/d",
            "display" : "hour per day"
          },
          {
            "code" : "h/wk",
            "display" : "hour per week"
          },
          {
            "code" : "Hz",
            "display" : "Hertz"
          },
          {
            "code" : "J",
            "display" : "joule"
          },
          {
            "code" : "J/L",
            "display" : "joule per liter"
          },
          {
            "code" : "K",
            "display" : "degree Kelvin"
          },
          {
            "code" : "K/W",
            "display" : "degree Kelvin per Watt"
          },
          {
            "code" : "k[IU]/L",
            "display" : "kilo international unit per liter"
          },
          {
            "code" : "k[IU]/mL",
            "display" : "kilo international unit per milliliter"
          },
          {
            "code" : "kat",
            "display" : "katal"
          },
          {
            "code" : "kat/kg",
            "display" : "katal per kilogram"
          },
          {
            "code" : "kat/L",
            "display" : "katal per liter"
          },
          {
            "code" : "kcal",
            "display" : "kilocalorie"
          },
          {
            "code" : "kcal/(24.h)",
            "display" : "kilocalorie per 24 hour"
          },
          {
            "code" : "kcal/[oz_av]",
            "display" : "kilocalorie per ounce (US & British)"
          },
          {
            "code" : "kcal/d",
            "display" : "kilocalorie per day"
          },
          {
            "code" : "kcal/h",
            "display" : "kilocalorie per hour"
          },
          {
            "code" : "kcal/kg/(24.h)",
            "display" : "kilocalorie per kilogram per 24 hour"
          },
          {
            "code" : "kg",
            "display" : "kilogram"
          },
          {
            "code" : "kg.m/s",
            "display" : "kilogram meter per second"
          },
          {
            "code" : "kg/(s.m2)",
            "display" : "kilogram per second per square meter"
          },
          {
            "code" : "kg/h",
            "display" : "kilogram per hour"
          },
          {
            "code" : "kg/L",
            "display" : "kilogram per liter"
          },
          {
            "code" : "kg/m2",
            "display" : "kilogram per square meter"
          },
          {
            "code" : "kg/m3",
            "display" : "kilogram per cubic meter"
          },
          {
            "code" : "kg/min",
            "display" : "kilogram per minute"
          },
          {
            "code" : "kg/mol",
            "display" : "kilogram per mole"
          },
          {
            "code" : "kg/s",
            "display" : "kilogram per second"
          },
          {
            "code" : "kL",
            "display" : "kiloliter"
          },
          {
            "code" : "km",
            "display" : "kilometer"
          },
          {
            "code" : "kPa",
            "display" : "kilopascal"
          },
          {
            "code" : "ks",
            "display" : "kilosecond"
          },
          {
            "code" : "kU",
            "display" : "kilo enzyme unit"
          },
          {
            "code" : "kU/g",
            "display" : "kilo enzyme unit per gram"
          },
          {
            "code" : "kU/L",
            "display" : "kilo enzyme unit per liter"
          },
          {
            "code" : "kU/L{class}",
            "display" : "kilo enzyme unit per liter class"
          },
          {
            "code" : "kU/mL",
            "display" : "kilo enzyme unit per milliliter"
          },
          {
            "code" : "L",
            "display" : "liter"
          },
          {
            "code" : "L/(24.h)",
            "display" : "liter per 24 hour"
          },
          {
            "code" : "L/(8.h)",
            "display" : "liter per 8 hour"
          },
          {
            "code" : "L/(min.m2)",
            "display" : "liter per minute per square meter"
          },
          {
            "code" : "L/d",
            "display" : "liter per day"
          },
          {
            "code" : "L/h",
            "display" : "liter per hour"
          },
          {
            "code" : "L/kg",
            "display" : "liter per kilogram"
          },
          {
            "code" : "L/L",
            "display" : "liter per liter"
          },
          {
            "code" : "L/min",
            "display" : "liter per minute"
          },
          {
            "code" : "L/min/m2",
            "display" : "liter per minute per sqaure meter"
          },
          {
            "code" : "L/s",
            "display" : "liter per second"
          },
          {
            "code" : "L/s/s2",
            "display" : "liter per second per square second"
          },
          {
            "code" : "lm",
            "display" : "lumen"
          },
          {
            "code" : "lm.m2",
            "display" : "lumen square meter"
          },
          {
            "code" : "m",
            "display" : "meter"
          },
          {
            "code" : "m/s",
            "display" : "meter per second"
          },
          {
            "code" : "m/s2",
            "display" : "meter per square second"
          },
          {
            "code" : "m[IU]/L",
            "display" : "milli international unit per liter"
          },
          {
            "code" : "m[IU]/mL",
            "display" : "milli international unit per milliliter"
          },
          {
            "code" : "m2",
            "display" : "square meter"
          },
          {
            "code" : "m2/s",
            "display" : "square meter per second"
          },
          {
            "code" : "m3/s",
            "display" : "cubic meter per second"
          },
          {
            "code" : "mA",
            "display" : "milliampere"
          },
          {
            "code" : "mbar",
            "display" : "millibar"
          },
          {
            "code" : "mbar.s/L",
            "display" : "millibar second per liter"
          },
          {
            "code" : "mbar/L/s",
            "display" : "millibar per liter per second"
          },
          {
            "code" : "meq",
            "display" : "milliequivalent"
          },
          {
            "code" : "meq/(2.h)",
            "display" : "milliequivalent per 2 hour"
          },
          {
            "code" : "meq/(24.h)",
            "display" : "milliequivalent per 24 hour"
          },
          {
            "code" : "meq/(8.h)",
            "display" : "milliequivalent per 8 hour"
          },
          {
            "code" : "meq/{specimen}",
            "display" : "milliequivalent per specimen"
          },
          {
            "code" : "meq/{total_volume}",
            "display" : "milliequivalent per total volume"
          },
          {
            "code" : "meq/d",
            "display" : "milliequivalent per day"
          },
          {
            "code" : "meq/dL",
            "display" : "milliequivalent per deciliter"
          },
          {
            "code" : "meq/g",
            "display" : "milliequivalent per gram"
          },
          {
            "code" : "meq/g{creat}",
            "display" : "milliequivalent per gram of creatinine"
          },
          {
            "code" : "meq/h",
            "display" : "milliequivalent per hour"
          },
          {
            "code" : "meq/kg",
            "display" : "milliequivalent per kilogram"
          },
          {
            "code" : "meq/kg/h",
            "display" : "milliequivalent per kilogram per hour"
          },
          {
            "code" : "meq/L",
            "display" : "milliequivalent per liter"
          },
          {
            "code" : "meq/m2",
            "display" : "milliequivalent per square meter"
          },
          {
            "code" : "meq/min",
            "display" : "milliequivalent per minute"
          },
          {
            "code" : "meq/mL",
            "display" : "milliequivalent per milliliter"
          },
          {
            "code" : "mg",
            "display" : "milligram"
          },
          {
            "code" : "mg/(10.h)",
            "display" : "milligram per 10 hour"
          },
          {
            "code" : "mg/(12.h)",
            "display" : "milligram per 12 hour"
          },
          {
            "code" : "mg/(2.h)",
            "display" : "milligram per 2 hour"
          },
          {
            "code" : "mg/(24.h)",
            "display" : "milligram per 24 hour"
          },
          {
            "code" : "mg/(6.h)",
            "display" : "milligram per 6 hour"
          },
          {
            "code" : "mg/(72.h)",
            "display" : "milligram per 72 hour"
          },
          {
            "code" : "mg/(8.h)",
            "display" : "milligram per 8 hour"
          },
          {
            "code" : "mg/{collection}",
            "display" : "milligram per collection"
          },
          {
            "code" : "mg/{specimen}",
            "display" : "milligram per specimen"
          },
          {
            "code" : "mg/{total_output}",
            "display" : "milligram per total output"
          },
          {
            "code" : "mg/{total_volume}",
            "display" : "milligram per total volume"
          },
          {
            "code" : "mg/d",
            "display" : "milligram per day"
          },
          {
            "code" : "mg/d/{1.73_m2}",
            "display" : "milligram per day per 1.73 square meter"
          },
          {
            "code" : "mg/dL",
            "display" : "milligram per deciliter"
          },
          {
            "code" : "mg/dL{RBCs}",
            "display" : "milligram per deciliter of red blood cells"
          },
          {
            "code" : "mg/g",
            "display" : "milligram per gram"
          },
          {
            "code" : "mg/g{creat}",
            "display" : "milligram per gram of creatinine"
          },
          {
            "code" : "mg/g{dry_tissue}",
            "display" : "milligram per gram of dry tissue"
          },
          {
            "code" : "mg/g{feces}",
            "display" : "milligram per gram of feces"
          },
          {
            "code" : "mg/g{tissue}",
            "display" : "milligram per gram of tissue"
          },
          {
            "code" : "mg/g{wet_tissue}",
            "display" : "milligram per gram of wet tissue"
          },
          {
            "code" : "mg/h",
            "display" : "milligram per hour"
          },
          {
            "code" : "mg/kg",
            "display" : "milligram per kilogram"
          },
          {
            "code" : "mg/kg/(8.h)",
            "display" : "milligram per kilogram per 8 hour"
          },
          {
            "code" : "mg/kg/d",
            "display" : "milligram per kilogram per day"
          },
          {
            "code" : "mg/kg/h",
            "display" : "milligram per kilogram per hour"
          },
          {
            "code" : "mg/kg/min",
            "display" : "milligram per kilogram per minute"
          },
          {
            "code" : "mg/L",
            "display" : "milligram per liter"
          },
          {
            "code" : "mg/L{RBCs}",
            "display" : "milligram per liter of red blood cells"
          },
          {
            "code" : "mg/m2",
            "display" : "milligram per square meter"
          },
          {
            "code" : "mg/m3",
            "display" : "milligram per cubic meter"
          },
          {
            "code" : "mg/mg",
            "display" : "milligram per milligram"
          },
          {
            "code" : "mg/mg{creat}",
            "display" : "milligram per milligram of creatinine"
          },
          {
            "code" : "mg/min",
            "display" : "milligram per minute"
          },
          {
            "code" : "mg/mL",
            "display" : "milligram per milliliter"
          },
          {
            "code" : "mg/mmol",
            "display" : "milligram per millimole"
          },
          {
            "code" : "mg/mmol{creat}",
            "display" : "milligram per millimole of creatinine"
          },
          {
            "code" : "mg/wk",
            "display" : "milligram per week"
          },
          {
            "code" : "mg{FEU}/L",
            "display" : "milligram fibrinogen equivalent unit per liter"
          },
          {
            "code" : "min",
            "display" : "minute"
          },
          {
            "code" : "min/d",
            "display" : "minute per day"
          },
          {
            "code" : "min/wk",
            "display" : "minute per week"
          },
          {
            "code" : "mL",
            "display" : "milliliter"
          },
          {
            "code" : "mL/(10.h)",
            "display" : "milliliter per 10 hour"
          },
          {
            "code" : "mL/(12.h)",
            "display" : "milliliter per 12 hour"
          },
          {
            "code" : "mL/(2.h)",
            "display" : "milliliter per 2 hour"
          },
          {
            "code" : "mL/(24.h)",
            "display" : "milliliter per 24 hour"
          },
          {
            "code" : "mL/(4.h)",
            "display" : "milliliter per 4 hour"
          },
          {
            "code" : "mL/(5.h)",
            "display" : "milliliter per 5 hour"
          },
          {
            "code" : "mL/(6.h)",
            "display" : "milliliter per 6 hour"
          },
          {
            "code" : "mL/(72.h)",
            "display" : "milliliter per 72 hour"
          },
          {
            "code" : "mL/(8.h)",
            "display" : "milliliter per 8 hour"
          },
          {
            "code" : "mL/(8.h)/kg",
            "display" : "milliliter per 8 hour per kilogram"
          },
          {
            "code" : "mL/[sin_i]",
            "display" : "milliliter per square inch (international)"
          },
          {
            "code" : "mL/{beat}",
            "display" : "milliliter per heart beat"
          },
          {
            "code" : "mL/{beat}/m2",
            "display" : "milliliter per heart beat per square meter"
          },
          {
            "code" : "mL/cm[H2O]",
            "display" : "milliliter per centimeter of water"
          },
          {
            "code" : "mL/d",
            "display" : "milliliter per day"
          },
          {
            "code" : "mL/dL",
            "display" : "milliliter per deciliter"
          },
          {
            "code" : "mL/h",
            "display" : "milliliter per hour"
          },
          {
            "code" : "mL/kg",
            "display" : "milliliter per kilogram"
          },
          {
            "code" : "mL/kg/(8.h)",
            "display" : "milliliter per kilogram per 8 hour"
          },
          {
            "code" : "mL/kg/d",
            "display" : "milliliter per kilogram per day"
          },
          {
            "code" : "mL/kg/h",
            "display" : "milliliter per kilogram per hour"
          },
          {
            "code" : "mL/kg/min",
            "display" : "milliliter per kilogram per minute"
          },
          {
            "code" : "mL/m2",
            "display" : "milliliter per square meter"
          },
          {
            "code" : "mL/mbar",
            "display" : "milliliter per millibar"
          },
          {
            "code" : "mL/min",
            "display" : "milliliter per minute"
          },
          {
            "code" : "mL/min/{1.73_m2}",
            "display" : "milliliter per minute per 1.73 square meter"
          },
          {
            "code" : "mL/min/m2",
            "display" : "milliliter per minute per square meter"
          },
          {
            "code" : "mL/mm",
            "display" : "milliliter per millimeter"
          },
          {
            "code" : "mL/s",
            "display" : "milliliter per second"
          },
          {
            "code" : "mL{fetal_RBCs}",
            "display" : "milliliter of fetal red blood cells"
          },
          {
            "code" : "mm",
            "display" : "millimeter"
          },
          {
            "code" : "mm/h",
            "display" : "millimeter per hour"
          },
          {
            "code" : "mm/min",
            "display" : "millimeter per minute"
          },
          {
            "code" : "mm[H2O]",
            "display" : "millimeter of water"
          },
          {
            "code" : "mm[Hg]",
            "display" : "millimeter of mercury"
          },
          {
            "code" : "mm2",
            "display" : "square millimeter"
          },
          {
            "code" : "mmol",
            "display" : "millimole"
          },
          {
            "code" : "mmol/(12.h)",
            "display" : "millimole per 12 hour"
          },
          {
            "code" : "mmol/(2.h)",
            "display" : "millimole per 2 hour"
          },
          {
            "code" : "mmol/(24.h)",
            "display" : "millimole per 24 hour"
          },
          {
            "code" : "mmol/(5.h)",
            "display" : "millimole per 5 hour"
          },
          {
            "code" : "mmol/(6.h)",
            "display" : "millimole per 6 hour"
          },
          {
            "code" : "mmol/(8.h)",
            "display" : "millimole per 8 hour"
          },
          {
            "code" : "mmol/{ejaculate}",
            "display" : "millimole per ejaculate"
          },
          {
            "code" : "mmol/{specimen}",
            "display" : "millimole per specimen"
          },
          {
            "code" : "mmol/{total_vol}",
            "display" : "millimole per total volume"
          },
          {
            "code" : "mmol/d",
            "display" : "millimole per day"
          },
          {
            "code" : "mmol/dL",
            "display" : "millimole per deciliter"
          },
          {
            "code" : "mmol/g",
            "display" : "millimole per gram"
          },
          {
            "code" : "mmol/g{creat}",
            "display" : "millimole per gram of creatinine"
          },
          {
            "code" : "mmol/h",
            "display" : "millimole per hour"
          },
          {
            "code" : "mmol/h/mg{Hb}",
            "display" : "millimole per hour per milligram of hemoglobin"
          },
          {
            "code" : "mmol/h/mg{prot}",
            "display" : "millimole per hour per milligram of protein"
          },
          {
            "code" : "mmol/kg",
            "display" : "millimole per kilogram"
          },
          {
            "code" : "mmol/kg/(8.h)",
            "display" : "millimole per kilogram per 8 hour"
          },
          {
            "code" : "mmol/kg/d",
            "display" : "millimole per kilogram per day"
          },
          {
            "code" : "mmol/kg/h",
            "display" : "millimole per kilogram per hour"
          },
          {
            "code" : "mmol/kg/min",
            "display" : "millimole per kilogram per minute"
          },
          {
            "code" : "mmol/L",
            "display" : "millimole per liter"
          },
          {
            "code" : "mmol/L{RBCs}",
            "display" : "millimole per liter of red blood cells"
          },
          {
            "code" : "mmol/m2",
            "display" : "millimole per square meter"
          },
          {
            "code" : "mmol/min",
            "display" : "millimole per minute"
          },
          {
            "code" : "mmol/mmol",
            "display" : "millimole per millimole"
          },
          {
            "code" : "mmol/mmol{creat}",
            "display" : "millimole per millmole of creatinine"
          },
          {
            "code" : "mmol/mmol{urea}",
            "display" : "millimole per millimole of urea"
          },
          {
            "code" : "mmol/mol",
            "display" : "millimole per mole"
          },
          {
            "code" : "mmol/mol{creat}",
            "display" : "millimole per mole of creatinine"
          },
          {
            "code" : "mmol/s/L",
            "display" : "millimole per second per liter"
          },
          {
            "code" : "mo",
            "display" : "month"
          },
          {
            "code" : "mol",
            "display" : "mole"
          },
          {
            "code" : "mol/kg",
            "display" : "mole per kilogram"
          },
          {
            "code" : "mol/kg/s",
            "display" : "mole per kilogram per second"
          },
          {
            "code" : "mol/L",
            "display" : "mole per liter"
          },
          {
            "code" : "mol/m3",
            "display" : "mole per cubic meter"
          },
          {
            "code" : "mol/mL",
            "display" : "mole per milliliter"
          },
          {
            "code" : "mol/mol",
            "display" : "mole per mole"
          },
          {
            "code" : "mol/s",
            "display" : "mole per second"
          },
          {
            "code" : "mosm",
            "display" : "milliosmole"
          },
          {
            "code" : "mosm/kg",
            "display" : "milliosmole per kilogram"
          },
          {
            "code" : "mosm/L",
            "display" : "milliosmole per liter"
          },
          {
            "code" : "mPa",
            "display" : "millipascal"
          },
          {
            "code" : "mPa.s",
            "display" : "millipascal second"
          },
          {
            "code" : "Ms",
            "display" : "megasecond"
          },
          {
            "code" : "ms",
            "display" : "millisecond"
          },
          {
            "code" : "mU/g",
            "display" : "milli enzyme unit per gram"
          },
          {
            "code" : "mU/g{Hb}",
            "display" : "milli enzyme unit per gram of hemoglobin"
          },
          {
            "code" : "mU/g{prot}",
            "display" : "milli enzyme unit per gram of protein"
          },
          {
            "code" : "mU/L",
            "display" : "milli enzyme unit per liter"
          },
          {
            "code" : "mU/mg",
            "display" : "milli enzyme unit per milligram"
          },
          {
            "code" : "mU/mg{creat}",
            "display" : "milli enzyme unit per milligram of creatinine"
          },
          {
            "code" : "mU/mL",
            "display" : "milli enzyme unit per milliliter"
          },
          {
            "code" : "mU/mL/min",
            "display" : "milli enzyme unit per milliliter per minute"
          },
          {
            "code" : "mU/mmol{creat}",
            "display" : "milli enzyme unit per millimole of creatinine"
          },
          {
            "code" : "mU/mmol{RBCs}",
            "display" : "milli enzyme unit per millimole of red blood cells"
          },
          {
            "code" : "mV",
            "display" : "millivolt"
          },
          {
            "code" : "mV/s",
            "display" : "millivolt per second"
          },
          {
            "code" : "N",
            "display" : "Newton"
          },
          {
            "code" : "N.cm",
            "display" : "Newton centimeter"
          },
          {
            "code" : "N.s",
            "display" : "Newton second"
          },
          {
            "code" : "ng",
            "display" : "nanogram"
          },
          {
            "code" : "ng/(24.h)",
            "display" : "nanogram per 24 hour"
          },
          {
            "code" : "ng/(8.h)",
            "display" : "nanogram per 8 hour"
          },
          {
            "code" : "ng/10*6",
            "display" : "nanogram per million"
          },
          {
            "code" : "ng/10*6{RBCs}",
            "display" : "nanogram per million red blood cells"
          },
          {
            "code" : "ng/d",
            "display" : "nanogram per day"
          },
          {
            "code" : "ng/dL",
            "display" : "nanogram per deciliter"
          },
          {
            "code" : "ng/g",
            "display" : "nanogram per gram"
          },
          {
            "code" : "ng/g{creat}",
            "display" : "nanogram per gram of creatinine"
          },
          {
            "code" : "ng/h",
            "display" : "nanogram per hour"
          },
          {
            "code" : "ng/kg",
            "display" : "nanogram per kilogram"
          },
          {
            "code" : "ng/kg/(8.h)",
            "display" : "nanogram per kilogram per 8 hour"
          },
          {
            "code" : "ng/kg/h",
            "display" : "nanogram per kilogram per hour"
          },
          {
            "code" : "ng/kg/min",
            "display" : "nanogram per kilogram per minute"
          },
          {
            "code" : "ng/L",
            "display" : "nanogram per liter"
          },
          {
            "code" : "ng/m2",
            "display" : "nanogram per square meter"
          },
          {
            "code" : "ng/mg",
            "display" : "nanogram per milligram"
          },
          {
            "code" : "ng/mg/h",
            "display" : "nanogram per milligram per hour"
          },
          {
            "code" : "ng/mg{creat}",
            "display" : "nanogram per milligram of creatinine"
          },
          {
            "code" : "ng/mg{prot}",
            "display" : "nanogram per milligram of protein"
          },
          {
            "code" : "ng/min",
            "display" : "nanogram per minute"
          },
          {
            "code" : "ng/mL",
            "display" : "nanogram per millliiter"
          },
          {
            "code" : "ng/mL/h",
            "display" : "nanogram per milliliter per hour"
          },
          {
            "code" : "ng/mL{RBCs}",
            "display" : "nanogram per milliliter of red blood cells"
          },
          {
            "code" : "ng/s",
            "display" : "nanogram per second"
          },
          {
            "code" : "ng/U",
            "display" : "nanogram per enzyme unit"
          },
          {
            "code" : "ng{FEU}/mL",
            "display" : "nanogram fibrinogen equivalent unit per milliliter"
          },
          {
            "code" : "nkat",
            "display" : "nanokatal"
          },
          {
            "code" : "nL",
            "display" : "nanoliter"
          },
          {
            "code" : "nm",
            "display" : "nanometer"
          },
          {
            "code" : "nm/s/L",
            "display" : "nanometer per second per liter"
          },
          {
            "code" : "nmol",
            "display" : "nanomole"
          },
          {
            "code" : "nmol/(24.h)",
            "display" : "nanomole per 24 hour"
          },
          {
            "code" : "nmol/d",
            "display" : "nanomole per day"
          },
          {
            "code" : "nmol/dL",
            "display" : "nanomole per deciliter"
          },
          {
            "code" : "nmol/dL{GF}",
            "display" : "nanomole per deciliter of glomerular filtrate"
          },
          {
            "code" : "nmol/g",
            "display" : "nanomole per gram"
          },
          {
            "code" : "nmol/g{creat}",
            "display" : "nanomole per gram of creatinine"
          },
          {
            "code" : "nmol/g{dry_wt}",
            "display" : "nanomole per gram of dry weight"
          },
          {
            "code" : "nmol/h/L",
            "display" : "nanomole per hour per liter"
          },
          {
            "code" : "nmol/h/mg{prot}",
            "display" : "nanomole per hour per milligram of protein"
          },
          {
            "code" : "nmol/h/mL",
            "display" : "nanomole per hour per milliliter"
          },
          {
            "code" : "nmol/L",
            "display" : "nanomole per liter"
          },
          {
            "code" : "nmol/L/mmol{creat}",
            "display" : "nanomole per liter per millimole of creatinine"
          },
          {
            "code" : "nmol/L{RBCs}",
            "display" : "nanomole per liter of red blood cells"
          },
          {
            "code" : "nmol/m/mg{prot}",
            "display" : "nanomole per meter per milligram of protein"
          },
          {
            "code" : "nmol/mg",
            "display" : "nanomole per milligram"
          },
          {
            "code" : "nmol/mg/h",
            "display" : "nanomole per milligram per hour"
          },
          {
            "code" : "nmol/mg{creat}",
            "display" : "nanomole per milligram of creatinine"
          },
          {
            "code" : "nmol/mg{prot}",
            "display" : "nanomole per milligram of protein"
          },
          {
            "code" : "nmol/mg{prot}/h",
            "display" : "nanomole per milligram of protein per hour"
          },
          {
            "code" : "nmol/min",
            "display" : "nanomole per minute"
          },
          {
            "code" : "nmol/min/10*6{cells}",
            "display" : "nanomole per minute per million cells"
          },
          {
            "code" : "nmol/min/mg{Hb}",
            "display" : "nanomole per minute per milligram of hemoglobin"
          },
          {
            "code" : "nmol/min/mg{prot}",
            "display" : "nanomole per minute per milligram of protein"
          },
          {
            "code" : "nmol/min/mg{protein}",
            "display" : "nanomole per minute per milligram protein"
          },
          {
            "code" : "nmol/min/mL",
            "display" : "nanomole per minute per milliliter"
          },
          {
            "code" : "nmol/mL",
            "display" : "nanomole per milliliter"
          },
          {
            "code" : "nmol/mL/h",
            "display" : "nanomole per milliliter per hour"
          },
          {
            "code" : "nmol/mL/min",
            "display" : "nanomole per milliliter per minute"
          },
          {
            "code" : "nmol/mmol",
            "display" : "nanomole per millimole"
          },
          {
            "code" : "nmol/mmol{creat}",
            "display" : "nanomole per millimole of creatinine"
          },
          {
            "code" : "nmol/mol",
            "display" : "nanomole per mole"
          },
          {
            "code" : "nmol/mol{creat}",
            "display" : "nanomole per mole creatinine"
          },
          {
            "code" : "nmol/nmol",
            "display" : "nanomole per nanomole"
          },
          {
            "code" : "nmol/s",
            "display" : "nanomole per second"
          },
          {
            "code" : "nmol/s/L",
            "display" : "nanomole per second per liter"
          },
          {
            "code" : "nmol/umol{creat}",
            "display" : "nanomole per micromole of creatinine"
          },
          {
            "code" : "nmol{ATP}",
            "display" : "nanomole of ATP"
          },
          {
            "code" : "nmol{BCE}",
            "display" : "nanomole bone collagen equivalent"
          },
          {
            "code" : "nmol{BCE}/L",
            "display" : "nanomole bone collagen equivalent per liter"
          },
          {
            "code" : "ns",
            "display" : "nanosecond"
          },
          {
            "code" : "nU/{RBC}",
            "display" : "nanoenzyme unit per red blood cell"
          },
          {
            "code" : "nU/mL",
            "display" : "nanoenzyme unit per milliliter"
          },
          {
            "code" : "Ohm",
            "display" : "Ohm"
          },
          {
            "code" : "Ohm.m",
            "display" : "Ohm meter"
          },
          {
            "code" : "osm",
            "display" : "osmole"
          },
          {
            "code" : "osm/kg",
            "display" : "osmole per kilogram"
          },
          {
            "code" : "osm/L",
            "display" : "osmole per liter"
          },
          {
            "code" : "Pa",
            "display" : "Pascal"
          },
          {
            "code" : "pA",
            "display" : "picoampere"
          },
          {
            "code" : "pg",
            "display" : "picogram"
          },
          {
            "code" : "pg/{cell}",
            "display" : "picogram per cell"
          },
          {
            "code" : "pg/{RBC}",
            "display" : "picogram per red blood cell"
          },
          {
            "code" : "pg/dL",
            "display" : "picogram per deciliter"
          },
          {
            "code" : "pg/L",
            "display" : "picogram per liter"
          },
          {
            "code" : "pg/mg",
            "display" : "picogram per milligram"
          },
          {
            "code" : "pg/mg{creat}",
            "display" : "picogram per milligram of creatinine"
          },
          {
            "code" : "pg/mL",
            "display" : "picogram per milliliter"
          },
          {
            "code" : "pg/mL{sLT}",
            "display" : "picogram per milliliter sulfidoleukotrienes"
          },
          {
            "code" : "pg/mm",
            "display" : "picogram per millimeter"
          },
          {
            "code" : "pkat",
            "display" : "picokatal"
          },
          {
            "code" : "pL",
            "display" : "picoliter"
          },
          {
            "code" : "pm",
            "display" : "picometer"
          },
          {
            "code" : "pmol",
            "display" : "picomole"
          },
          {
            "code" : "pmol/(24.h)",
            "display" : "picomole per 24 hour"
          },
          {
            "code" : "pmol/{RBC}",
            "display" : "picomole per red blood cell"
          },
          {
            "code" : "pmol/d",
            "display" : "picomole per day"
          },
          {
            "code" : "pmol/dL",
            "display" : "picomole per deciliter"
          },
          {
            "code" : "pmol/g",
            "display" : "picomole per gram"
          },
          {
            "code" : "pmol/h/mg{prot}",
            "display" : "picomole per hour per milligram of protein"
          },
          {
            "code" : "pmol/H/mg{protein}",
            "display" : "picomole per hour per milligram protein"
          },
          {
            "code" : "pmol/h/mL",
            "display" : "picomole per hour per milliliter"
          },
          {
            "code" : "pmol/L",
            "display" : "picomole per liter"
          },
          {
            "code" : "pmol/mg{prot}",
            "display" : "picomole per milligram of protein"
          },
          {
            "code" : "pmol/min",
            "display" : "picomole per minute"
          },
          {
            "code" : "pmol/min/mg{prot}",
            "display" : "picomole per minute per milligram of protein"
          },
          {
            "code" : "pmol/mL",
            "display" : "picomole per milliliter"
          },
          {
            "code" : "pmol/mmol{creat}",
            "display" : "picomole per millimole of creatinine"
          },
          {
            "code" : "pmol/umol",
            "display" : "picomole per micromole"
          },
          {
            "code" : "pmol/umol{creat}",
            "display" : "picomole per micromole of creatinine"
          },
          {
            "code" : "ps",
            "display" : "picosecond"
          },
          {
            "code" : "pT",
            "display" : "picotesla"
          },
          {
            "code" : "s",
            "display" : "second"
          },
          {
            "code" : "S",
            "display" : "Siemens"
          },
          {
            "code" : "s/{control}",
            "display" : "second per control"
          },
          {
            "code" : "Sv",
            "display" : "Sievert"
          },
          {
            "code" : "t",
            "display" : "metric ton"
          },
          {
            "code" : "T",
            "display" : "Tesla"
          },
          {
            "code" : "Torr",
            "display" : "Torr"
          },
          {
            "code" : "U",
            "display" : "enzyme unit"
          },
          {
            "code" : "U/(10.g){feces}",
            "display" : "enzyme unit per 10 gram of feces"
          },
          {
            "code" : "U/(12.h)",
            "display" : "enzyme unit per 12 hour"
          },
          {
            "code" : "U/(2.h)",
            "display" : "enzyme unit per 2 hour"
          },
          {
            "code" : "U/(24.h)",
            "display" : "enzyme unit per 24 hour"
          },
          {
            "code" : "U/10",
            "display" : "enzyme unit per 10"
          },
          {
            "code" : "U/10*10",
            "display" : "enzyme unit per 10 billion"
          },
          {
            "code" : "U/10*10{cells}",
            "display" : "enzyme unit per 10 billion cells"
          },
          {
            "code" : "U/10*12",
            "display" : "enzyme unit per trillion"
          },
          {
            "code" : "U/10*12{RBCs}",
            "display" : "enzyme unit per trillion red blood cells"
          },
          {
            "code" : "U/10*6",
            "display" : "enzyme unit per million"
          },
          {
            "code" : "U/10*9",
            "display" : "enzyme unit per billion"
          },
          {
            "code" : "U/d",
            "display" : "enzyme unit per day"
          },
          {
            "code" : "U/dL",
            "display" : "enzyme unit per deciliter"
          },
          {
            "code" : "U/g",
            "display" : "enzyme unit per gram"
          },
          {
            "code" : "U/g{creat}",
            "display" : "enzyme unit per gram of creatinine"
          },
          {
            "code" : "U/g{Hb}",
            "display" : "enzyme unit per gram of hemoglobin"
          },
          {
            "code" : "U/g{protein}",
            "display" : "enzyme unit per gram of protein"
          },
          {
            "code" : "U/h",
            "display" : "enzyme unit per hour"
          },
          {
            "code" : "U/kg{Hb}",
            "display" : "enzyme unit per kilogram of hemoglobin"
          },
          {
            "code" : "U/L",
            "display" : "enzyme unit per liter"
          },
          {
            "code" : "U/min",
            "display" : "enzyme unit per minute"
          },
          {
            "code" : "U/mL",
            "display" : "enzyme unit per milliliter"
          },
          {
            "code" : "U/mL{RBCs}",
            "display" : "enzyme unit per milliliter of red blood cells"
          },
          {
            "code" : "U/mmol{creat}",
            "display" : "enzyme unit per millimole of creatinine"
          },
          {
            "code" : "U/s",
            "display" : "enzyme unit per second"
          },
          {
            "code" : "u[IU]",
            "display" : "micro international unit"
          },
          {
            "code" : "u[IU]/L",
            "display" : "microinternational unit per liter"
          },
          {
            "code" : "u[IU]/mL",
            "display" : "micro international unit per milliliter"
          },
          {
            "code" : "U{25Cel}/L",
            "display" : "enzyme unit per liter at 25 deg Celsius"
          },
          {
            "code" : "U{37Cel}/L",
            "display" : "enzyme unit per liter at 37 deg Celsius"
          },
          {
            "code" : "ueq",
            "display" : "microequivalent"
          },
          {
            "code" : "ueq/L",
            "display" : "microequivalent per liter"
          },
          {
            "code" : "ueq/mL",
            "display" : "microequivalent per milliliter"
          },
          {
            "code" : "ug",
            "display" : "microgram"
          },
          {
            "code" : "ug/(100.g)",
            "display" : "microgram per 100 gram"
          },
          {
            "code" : "ug/(24.h)",
            "display" : "microgram per 24 hour"
          },
          {
            "code" : "ug/(8.h)",
            "display" : "microgram per 8 hour"
          },
          {
            "code" : "ug/[sft_i]",
            "display" : "microgram per square foot (international)"
          },
          {
            "code" : "ug/{specimen}",
            "display" : "microgram per specimen"
          },
          {
            "code" : "ug/d",
            "display" : "microgram per day"
          },
          {
            "code" : "ug/dL",
            "display" : "microgram per deciliter"
          },
          {
            "code" : "ug/dL{RBCs}",
            "display" : "microgram per deciliter of red blood cells"
          },
          {
            "code" : "ug/g",
            "display" : "microgram per gram"
          },
          {
            "code" : "ug/g{creat}",
            "display" : "microgram per gram of creatinine"
          },
          {
            "code" : "ug/g{dry_tissue}",
            "display" : "microgram per gram of dry tissue"
          },
          {
            "code" : "ug/g{dry_wt}",
            "display" : "microgram per gram of dry weight"
          },
          {
            "code" : "ug/g{feces}",
            "display" : "microgram per gram of feces"
          },
          {
            "code" : "ug/g{hair}",
            "display" : "microgram per gram of hair"
          },
          {
            "code" : "ug/g{Hb}",
            "display" : "microgram per gram of hemoglobin"
          },
          {
            "code" : "ug/g{tissue}",
            "display" : "microgram per gram of tissue"
          },
          {
            "code" : "ug/h",
            "display" : "microgram per hour"
          },
          {
            "code" : "ug/kg",
            "display" : "microgram per kilogram"
          },
          {
            "code" : "ug/kg/(8.h)",
            "display" : "microgram per kilogram per 8 hour"
          },
          {
            "code" : "ug/kg/d",
            "display" : "microgram per kilogram per day"
          },
          {
            "code" : "ug/kg/h",
            "display" : "microgram per kilogram per hour"
          },
          {
            "code" : "ug/kg/min",
            "display" : "microgram per kilogram per minute"
          },
          {
            "code" : "ug/L",
            "display" : "microgram per liter"
          },
          {
            "code" : "ug/L/(24.h)",
            "display" : "microgram per liter per 24 hour"
          },
          {
            "code" : "ug/L{RBCs}",
            "display" : "microgram per liter of red blood cells"
          },
          {
            "code" : "ug/m2",
            "display" : "microgram per square meter"
          },
          {
            "code" : "ug/m3",
            "display" : "microgram per cubic meter"
          },
          {
            "code" : "ug/mg",
            "display" : "microgram per milligram"
          },
          {
            "code" : "ug/mg{creat}",
            "display" : "microgram per milligram of creatinine"
          },
          {
            "code" : "ug/min",
            "display" : "microgram per minute"
          },
          {
            "code" : "ug/mL",
            "display" : "microgram per milliliter"
          },
          {
            "code" : "ug/mL{class}",
            "display" : "microgram per milliliter class"
          },
          {
            "code" : "ug/mL{eqv}",
            "display" : "microgram per milliliter equivalent"
          },
          {
            "code" : "ug/mmol",
            "display" : "microgram per millimole"
          },
          {
            "code" : "ug/mmol{creat}",
            "display" : "microgram per millimole of creatinine"
          },
          {
            "code" : "ug/ng",
            "display" : "microgram per nanogram"
          },
          {
            "code" : "ug{FEU}/mL",
            "display" : "microgram fibrinogen equivalent unit per milliliter"
          },
          {
            "code" : "ukat",
            "display" : "microkatal"
          },
          {
            "code" : "uL",
            "display" : "microliter"
          },
          {
            "code" : "uL/(2.h)",
            "display" : "microliter per 2 hour"
          },
          {
            "code" : "uL/h",
            "display" : "microliter per hour"
          },
          {
            "code" : "um",
            "display" : "micrometer"
          },
          {
            "code" : "um/s",
            "display" : "microns per second"
          },
          {
            "code" : "umol",
            "display" : "micromole"
          },
          {
            "code" : "umol/(2.h)",
            "display" : "micromole per 2 hour"
          },
          {
            "code" : "umol/(24.h)",
            "display" : "micromole per 24 hour"
          },
          {
            "code" : "umol/(8.h)",
            "display" : "micromole per 8 hour"
          },
          {
            "code" : "umol/10*6{RBC}",
            "display" : "micromole per million red blood cell"
          },
          {
            "code" : "umol/d",
            "display" : "micromole per day"
          },
          {
            "code" : "umol/dL",
            "display" : "micromole per deciliter"
          },
          {
            "code" : "umol/dL{GF}",
            "display" : "micromole per deciliter of glomerular filtrate"
          },
          {
            "code" : "umol/g",
            "display" : "micromole per gram"
          },
          {
            "code" : "umol/g{creat}",
            "display" : "micromole per gram of creatinine"
          },
          {
            "code" : "umol/g{Hb}",
            "display" : "micromole per gram of hemoglobin"
          },
          {
            "code" : "umol/h",
            "display" : "micromole per hour"
          },
          {
            "code" : "umol/kg",
            "display" : "micromole per kilogram"
          },
          {
            "code" : "umol/kg{feces}",
            "display" : "micromole per kilogram of feces"
          },
          {
            "code" : "umol/L",
            "display" : "micromole per liter"
          },
          {
            "code" : "umol/L/h",
            "display" : "micromole per liter per hour"
          },
          {
            "code" : "umol/L{RBCs}",
            "display" : "micromole per liter of red blood cells"
          },
          {
            "code" : "umol/mg",
            "display" : "micromole per milligram"
          },
          {
            "code" : "umol/mg{creat}",
            "display" : "micromole per milligram of creatinine"
          },
          {
            "code" : "umol/min",
            "display" : "micromole per minute"
          },
          {
            "code" : "umol/min/g",
            "display" : "micromole per minute per gram"
          },
          {
            "code" : "umol/min/g{mucosa}",
            "display" : "micromole per minute per gram of mucosa"
          },
          {
            "code" : "umol/min/g{prot}",
            "display" : "micromole per minute per gram of protein"
          },
          {
            "code" : "umol/min/L",
            "display" : "micromole per minute per liter"
          },
          {
            "code" : "umol/mL",
            "display" : "micromole per milliliter"
          },
          {
            "code" : "umol/mL/min",
            "display" : "micromole per milliliter per minute"
          },
          {
            "code" : "umol/mmol",
            "display" : "micromole per millimole"
          },
          {
            "code" : "umol/mmol{creat}",
            "display" : "micromole per millimole of creatinine"
          },
          {
            "code" : "umol/mol",
            "display" : "micromole per mole"
          },
          {
            "code" : "umol/mol{creat}",
            "display" : "micromole per mole of creatinine"
          },
          {
            "code" : "umol/mol{Hb}",
            "display" : "micromole per mole of hemoglobin"
          },
          {
            "code" : "umol/umol",
            "display" : "micromole per micromole"
          },
          {
            "code" : "umol/umol{creat}",
            "display" : "micromole per micromole of creatinine"
          },
          {
            "code" : "umol{BCE}/mol",
            "display" : "micromole bone collagen equivalent per mole"
          },
          {
            "code" : "uOhm",
            "display" : "microOhm"
          },
          {
            "code" : "us",
            "display" : "microsecond"
          },
          {
            "code" : "uU/g",
            "display" : "micro enzyme unit per gram"
          },
          {
            "code" : "uU/L",
            "display" : "micro enzyme unit per liter"
          },
          {
            "code" : "uU/mL",
            "display" : "micro enzyme unit per milliliter"
          },
          {
            "code" : "uV",
            "display" : "microvolt"
          },
          {
            "code" : "V",
            "display" : "volt"
          },
          {
            "code" : "Wb",
            "display" : "Weber"
          },
          {
            "code" : "wk",
            "display" : "week"
          },
          {
            "code" : "10*-3",
            "display" : "ten to the power of minus three"
          },
          {
            "code" : "10*-6",
            "display" : "ten to the power of minus six"
          },
          {
            "code" : "g/mol",
            "display" : "gram per mole"
          },
          {
            "code" : "mg/mol",
            "display" : "milligram per mole"
          },
          {
            "code" : "nmol/[IU]",
            "display" : "nanomole per international unit"
          },
          {
            "code" : "10*-9",
            "display" : "ten to the power of minus nine"
          },
          {
            "code" : "10*6.[IU]/L",
            "display" : "million international unit per liter"
          },
          {
            "code" : "10*9",
            "display" : "billion"
          },
          {
            "code" : "10*9/kg",
            "display" : "billion per kilogram"
          },
          {
            "code" : "10*3.[arb'U]/L",
            "display" : "thousand arbitrary unit per liter"
          },
          {
            "code" : "akat",
            "display" : "attokatal"
          },
          {
            "code" : "amol",
            "display" : "attomole"
          },
          {
            "code" : "[arb'U]/L",
            "display" : "arbitrary unit per liter"
          },
          {
            "code" : "cm-2",
            "display" : "per square centimeter"
          },
          {
            "code" : "g/min.m2",
            "display" : "gram per minute square meter"
          },
          {
            "code" : "kBq",
            "display" : "kilobecquerel"
          },
          {
            "code" : "kg/d",
            "display" : "kilogram per day"
          },
          {
            "code" : "kJ/L",
            "display" : "kilojoule per liter"
          },
          {
            "code" : "kU/kg",
            "display" : "kilo enzyme unit per kilogram"
          },
          {
            "code" : "kU/mol",
            "display" : "kilo enzyme unit per mole"
          },
          {
            "code" : "mkat/L",
            "display" : "millikatal per liter"
          },
          {
            "code" : "mkat/mol",
            "display" : "millikatal per mole"
          },
          {
            "code" : "mm2/s",
            "display" : "square millimeter per second"
          },
          {
            "code" : "mmol/m3",
            "display" : "millimole per cubic meter"
          },
          {
            "code" : "mmol/s",
            "display" : "millimole per second"
          },
          {
            "code" : "mol/kg.s",
            "display" : "mole per kilogram second"
          },
          {
            "code" : "mol/d",
            "display" : "mole per day"
          },
          {
            "code" : "ng/[IU]",
            "display" : "nanogram per international unit"
          },
          {
            "code" : "nkat/L",
            "display" : "nanokatal per liter"
          },
          {
            "code" : "nmol/kg",
            "display" : "nanomole per kilogram"
          },
          {
            "code" : "nmol/m3",
            "display" : "nanomole per cubic meter"
          },
          {
            "code" : "pmol/kg",
            "display" : "picomole per kilogram"
          },
          {
            "code" : "pmol/m3",
            "display" : "picomole per cubic meter"
          },
          {
            "code" : "pU",
            "display" : "pico enzyme unit"
          },
          {
            "code" : "U/kg",
            "display" : "enzyme unit per kilogram"
          },
          {
            "code" : "ukat/d",
            "display" : "microkatal per day"
          },
          {
            "code" : "ukat/kg",
            "display" : "microkatal per kilogram"
          },
          {
            "code" : "ukat/L",
            "display" : "microkatal per liter"
          },
          {
            "code" : "ukat/s",
            "display" : "microkatal per second"
          },
          {
            "code" : "um2",
            "display" : "square micrometer"
          },
          {
            "code" : "umol/kg.s",
            "display" : "micromole per kilogram second"
          },
          {
            "code" : "umol/m3",
            "display" : "micromole per cubic meter"
          }
        ]
      }
    ]
  }
}

```
