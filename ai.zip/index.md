# Home - eHDSI Terminologies v0.2.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://hl7europe.org/fhir/terminology/ehdsi/ImplementationGuide/hl7.eu.terminology.ehdsi | *Version*:0.2.0 |
| Active as of 2025-12-23 | *Computable Name*:EHDSI |

This is a Terminology Package

