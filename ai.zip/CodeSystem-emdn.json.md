# EMDN CodeSystem - JSON Representation - eHDSI Terminologies v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **EMDN CodeSystem**

## : EMDN CodeSystem - JSON Representation

| |
| :--- |
| Active as of 2025-12-23 |

[Raw json](CodeSystem-emdn.json) | [Download](CodeSystem-emdn.json)

content temporarily excluded                  

              

