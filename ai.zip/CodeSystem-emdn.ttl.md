# EMDN CodeSystem - TTL Representation - eHDSI Terminologies v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **EMDN CodeSystem**

## : EMDN CodeSystem - TTL Representation

| |
| :--- |
| Active as of 2025-12-23 |

[Raw ttl](CodeSystem-emdn.ttl) | [Download](CodeSystem-emdn.ttl)

content temporarily excluded                  

              

