# eHDSI Active Ingredient - eHDSI Terminologies v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **eHDSI Active Ingredient**

## ValueSet: eHDSI Active Ingredient 

| | |
| :--- | :--- |
| *Official URL*:http://terminology.ehdsi.eu/ValueSet/eHDSIActiveIngredient | *Version*:0.2.0 |
| Active as of 2025-12-23 | *Computable Name*:eHDSIActiveIngredient |
| *Other Identifiers:*OID:1.3.6.1.4.1.12559.11.10.1.3.1.42.24 | |

 
The Value Set is used as a mandatory code for the Active Ingredient of medications in the Medications Summary as well as the prescription Sections. Also used to code allergy agents in the Allergies and Other Adverse Reactions Section of the patient Summary. 

 **References** 

This value set is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "eHDSIActiveIngredient-8.1.0",
  "url" : "http://terminology.ehdsi.eu/ValueSet/eHDSIActiveIngredient",
  "identifier" : [
    {
      "system" : "urn:ietf:rfc:3986",
      "value" : "urn:oid:1.3.6.1.4.1.12559.11.10.1.3.1.42.24"
    }
  ],
  "version" : "0.2.0",
  "name" : "eHDSIActiveIngredient",
  "title" : "eHDSI Active Ingredient",
  "status" : "active",
  "experimental" : false,
  "date" : "2025-12-23T10:21:27+00:00",
  "publisher" : "HL7 Europe",
  "contact" : [
    {
      "name" : "HL7 Europe",
      "telecom" : [
        {
          "system" : "url",
          "value" : "http://hl7europe.org"
        }
      ]
    }
  ],
  "description" : "The Value Set is used as a mandatory code for the Active Ingredient of medications in the Medications Summary as well as the prescription Sections. Also used to code allergy agents in the Allergies and Other Adverse Reactions Section of the patient Summary.",
  "compose" : {
    "include" : [
      {
        "system" : "http://www.whocc.no/atc",
        "concept" : [
          {
            "code" : "A",
            "display" : "ALIMENTARY TRACT AND METABOLISM"
          },
          {
            "code" : "A01",
            "display" : "STOMATOLOGICAL PREPARATIONS"
          },
          {
            "code" : "A01A",
            "display" : "STOMATOLOGICAL PREPARATIONS"
          },
          {
            "code" : "A01AA",
            "display" : "Caries prophylactic agents"
          },
          {
            "code" : "A01AA01",
            "display" : "sodium fluoride"
          },
          {
            "code" : "A01AA02",
            "display" : "sodium monofluorophosphate"
          },
          {
            "code" : "A01AA03",
            "display" : "olaflur"
          },
          {
            "code" : "A01AA04",
            "display" : "stannous fluoride"
          },
          {
            "code" : "A01AA30",
            "display" : "combinations"
          },
          {
            "code" : "A01AA51",
            "display" : "sodium fluoride, combinations"
          },
          {
            "code" : "A01AB",
            "display" : "Antiinfectives and antiseptics for local oral treatment"
          },
          {
            "code" : "A01AB02",
            "display" : "hydrogen peroxide"
          },
          {
            "code" : "A01AB03",
            "display" : "chlorhexidine"
          },
          {
            "code" : "A01AB04",
            "display" : "amphotericin B"
          },
          {
            "code" : "A01AB05",
            "display" : "polynoxylin"
          },
          {
            "code" : "A01AB06",
            "display" : "domiphen"
          },
          {
            "code" : "A01AB07",
            "display" : "oxyquinoline"
          },
          {
            "code" : "A01AB08",
            "display" : "neomycin"
          },
          {
            "code" : "A01AB09",
            "display" : "miconazole"
          },
          {
            "code" : "A01AB10",
            "display" : "natamycin"
          },
          {
            "code" : "A01AB11",
            "display" : "various"
          },
          {
            "code" : "A01AB12",
            "display" : "hexetidine"
          },
          {
            "code" : "A01AB13",
            "display" : "tetracycline"
          },
          {
            "code" : "A01AB14",
            "display" : "benzoxonium chloride"
          },
          {
            "code" : "A01AB15",
            "display" : "tibezonium iodide"
          },
          {
            "code" : "A01AB16",
            "display" : "mepartricin"
          },
          {
            "code" : "A01AB17",
            "display" : "metronidazole"
          },
          {
            "code" : "A01AB18",
            "display" : "clotrimazole"
          },
          {
            "code" : "A01AB19",
            "display" : "sodium perborate"
          },
          {
            "code" : "A01AB21",
            "display" : "chlortetracycline"
          },
          {
            "code" : "A01AB22",
            "display" : "doxycycline"
          },
          {
            "code" : "A01AB23",
            "display" : "minocycline"
          },
          {
            "code" : "A01AB24",
            "display" : "octenidine"
          },
          {
            "code" : "A01AB25",
            "display" : "oxytetracycline"
          },
          {
            "code" : "A01AB53",
            "display" : "chlorhexidine and cetylpyridinium"
          },
          {
            "code" : "A01AC",
            "display" : "Corticosteroids for local oral treatment"
          },
          {
            "code" : "A01AC01",
            "display" : "triamcinolone"
          },
          {
            "code" : "A01AC02",
            "display" : "dexamethasone"
          },
          {
            "code" : "A01AC03",
            "display" : "hydrocortisone"
          },
          {
            "code" : "A01AC04",
            "display" : "prednisolone"
          },
          {
            "code" : "A01AC54",
            "display" : "prednisolone, combinations"
          },
          {
            "code" : "A01AD",
            "display" : "Other agents for local oral treatment"
          },
          {
            "code" : "A01AD01",
            "display" : "epinephrine"
          },
          {
            "code" : "A01AD02",
            "display" : "benzydamine"
          },
          {
            "code" : "A01AD05",
            "display" : "acetylsalicylic acid"
          },
          {
            "code" : "A01AD06",
            "display" : "adrenalone"
          },
          {
            "code" : "A01AD07",
            "display" : "amlexanox"
          },
          {
            "code" : "A01AD08",
            "display" : "becaplermin"
          },
          {
            "code" : "A01AD11",
            "display" : "various"
          },
          {
            "code" : "A02",
            "display" : "DRUGS FOR ACID RELATED DISORDERS"
          },
          {
            "code" : "A02A",
            "display" : "ANTACIDS"
          },
          {
            "code" : "A02AA",
            "display" : "Magnesium compounds"
          },
          {
            "code" : "A02AA01",
            "display" : "magnesium carbonate"
          },
          {
            "code" : "A02AA02",
            "display" : "magnesium oxide"
          },
          {
            "code" : "A02AA03",
            "display" : "magnesium peroxide"
          },
          {
            "code" : "A02AA04",
            "display" : "magnesium hydroxide"
          },
          {
            "code" : "A02AA05",
            "display" : "magnesium silicate"
          },
          {
            "code" : "A02AA10",
            "display" : "combinations"
          },
          {
            "code" : "A02AB",
            "display" : "Aluminium compounds"
          },
          {
            "code" : "A02AB01",
            "display" : "aluminium hydroxide"
          },
          {
            "code" : "A02AB02",
            "display" : "algeldrate"
          },
          {
            "code" : "A02AB03",
            "display" : "aluminium phosphate"
          },
          {
            "code" : "A02AB04",
            "display" : "dihydroxialumini sodium carbonate"
          },
          {
            "code" : "A02AB05",
            "display" : "aluminium acetoacetate"
          },
          {
            "code" : "A02AB06",
            "display" : "aloglutamol"
          },
          {
            "code" : "A02AB07",
            "display" : "aluminium glycinate"
          },
          {
            "code" : "A02AB10",
            "display" : "combinations"
          },
          {
            "code" : "A02AC",
            "display" : "Calcium compounds"
          },
          {
            "code" : "A02AC01",
            "display" : "calcium carbonate"
          },
          {
            "code" : "A02AC02",
            "display" : "calcium silicate"
          },
          {
            "code" : "A02AC10",
            "display" : "combinations"
          },
          {
            "code" : "A02AD",
            "display" : "Combinations and complexes of aluminium, calcium and magnesium compounds"
          },
          {
            "code" : "A02AD01",
            "display" : "ordinary salt combinations"
          },
          {
            "code" : "A02AD02",
            "display" : "magaldrate"
          },
          {
            "code" : "A02AD03",
            "display" : "almagate"
          },
          {
            "code" : "A02AD04",
            "display" : "hydrotalcite"
          },
          {
            "code" : "A02AD05",
            "display" : "almasilate"
          },
          {
            "code" : "A02AF",
            "display" : "Antacids with antiflatulents"
          },
          {
            "code" : "A02AF01",
            "display" : "magaldrate and antiflatulents"
          },
          {
            "code" : "A02AF02",
            "display" : "ordinary salt combinations and antiflatulents"
          },
          {
            "code" : "A02AG",
            "display" : "Antacids with antispasmodics"
          },
          {
            "code" : "A02AH",
            "display" : "Antacids with sodium bicarbonate"
          },
          {
            "code" : "A02AX",
            "display" : "Antacids, other combinations"
          },
          {
            "code" : "A02B",
            "display" : "DRUGS FOR PEPTIC ULCER AND GASTRO-OESOPHAGEAL REFLUX DISEASE (GORD)"
          },
          {
            "code" : "A02BA",
            "display" : "H2-receptor antagonists"
          },
          {
            "code" : "A02BA01",
            "display" : "cimetidine"
          },
          {
            "code" : "A02BA02",
            "display" : "ranitidine"
          },
          {
            "code" : "A02BA03",
            "display" : "famotidine"
          },
          {
            "code" : "A02BA04",
            "display" : "nizatidine"
          },
          {
            "code" : "A02BA05",
            "display" : "niperotidine"
          },
          {
            "code" : "A02BA06",
            "display" : "roxatidine"
          },
          {
            "code" : "A02BA07",
            "display" : "ranitidine bismuth citrate"
          },
          {
            "code" : "A02BA08",
            "display" : "lafutidine"
          },
          {
            "code" : "A02BA51",
            "display" : "cimetidine, combinations"
          },
          {
            "code" : "A02BA53",
            "display" : "famotidine, combinations"
          },
          {
            "code" : "A02BB",
            "display" : "Prostaglandins"
          },
          {
            "code" : "A02BB01",
            "display" : "misoprostol"
          },
          {
            "code" : "A02BB02",
            "display" : "enprostil"
          },
          {
            "code" : "A02BC",
            "display" : "Proton pump inhibitors"
          },
          {
            "code" : "A02BC01",
            "display" : "omeprazole"
          },
          {
            "code" : "A02BC02",
            "display" : "pantoprazole"
          },
          {
            "code" : "A02BC03",
            "display" : "lansoprazole"
          },
          {
            "code" : "A02BC04",
            "display" : "rabeprazole"
          },
          {
            "code" : "A02BC05",
            "display" : "esomeprazole"
          },
          {
            "code" : "A02BC06",
            "display" : "dexlansoprazole"
          },
          {
            "code" : "A02BC07",
            "display" : "dexrabeprazole"
          },
          {
            "code" : "A02BC08",
            "display" : "vonoprazan"
          },
          {
            "code" : "A02BC09",
            "display" : "tegoprazan"
          },
          {
            "code" : "A02BC10",
            "display" : "fexuprazan"
          },
          {
            "code" : "A02BC11",
            "display" : "ilaprazole"
          },
          {
            "code" : "A02BC51",
            "display" : "omeprazole, combinations"
          },
          {
            "code" : "A02BC53",
            "display" : "lansoprazole, combinations"
          },
          {
            "code" : "A02BC54",
            "display" : "rabeprazole, combinations"
          },
          {
            "code" : "A02BD",
            "display" : "Combinations for eradication of Helicobacter pylori"
          },
          {
            "code" : "A02BD01",
            "display" : "omeprazole, amoxicillin and metronidazole"
          },
          {
            "code" : "A02BD02",
            "display" : "lansoprazole, tetracycline and metronidazole"
          },
          {
            "code" : "A02BD03",
            "display" : "lansoprazole, amoxicillin and metronidazole"
          },
          {
            "code" : "A02BD04",
            "display" : "pantoprazole, amoxicillin and clarithromycin"
          },
          {
            "code" : "A02BD05",
            "display" : "omeprazole, amoxicillin and clarithromycin"
          },
          {
            "code" : "A02BD06",
            "display" : "esomeprazole, amoxicillin and clarithromycin"
          },
          {
            "code" : "A02BD07",
            "display" : "lansoprazole, amoxicillin and clarithromycin"
          },
          {
            "code" : "A02BD08",
            "display" : "bismuth subcitrate, tetracycline and metronidazole"
          },
          {
            "code" : "A02BD09",
            "display" : "lansoprazole, clarithromycin and tinidazole"
          },
          {
            "code" : "A02BD10",
            "display" : "lansoprazole, amoxicillin and levofloxacin"
          },
          {
            "code" : "A02BD11",
            "display" : "pantoprazole, amoxicillin, clarithromycin and metronidazole"
          },
          {
            "code" : "A02BD12",
            "display" : "rabeprazole, amoxicillin and clarithromycin"
          },
          {
            "code" : "A02BD13",
            "display" : "rabeprazole, amoxicillin and metronidazole"
          },
          {
            "code" : "A02BD14",
            "display" : "vonoprazan, amoxicillin and clarithromycin"
          },
          {
            "code" : "A02BD15",
            "display" : "vonoprazan, amoxicillin and metronidazole"
          },
          {
            "code" : "A02BD16",
            "display" : "omeprazole, amoxicillin and rifabutin"
          },
          {
            "code" : "A02BD17",
            "display" : "vonoprazan and amoxicillin"
          },
          {
            "code" : "A02BX",
            "display" : "Other drugs for peptic ulcer and gastro-oesophageal reflux disease (GORD)"
          },
          {
            "code" : "A02BX01",
            "display" : "carbenoxolone"
          },
          {
            "code" : "A02BX02",
            "display" : "sucralfate"
          },
          {
            "code" : "A02BX03",
            "display" : "pirenzepine"
          },
          {
            "code" : "A02BX04",
            "display" : "methiosulfonium chloride"
          },
          {
            "code" : "A02BX05",
            "display" : "bismuth subcitrate"
          },
          {
            "code" : "A02BX06",
            "display" : "proglumide"
          },
          {
            "code" : "A02BX07",
            "display" : "gefarnate"
          },
          {
            "code" : "A02BX08",
            "display" : "sulglicotide"
          },
          {
            "code" : "A02BX09",
            "display" : "acetoxolone"
          },
          {
            "code" : "A02BX10",
            "display" : "zolimidine"
          },
          {
            "code" : "A02BX11",
            "display" : "troxipide"
          },
          {
            "code" : "A02BX12",
            "display" : "bismuth subnitrate"
          },
          {
            "code" : "A02BX13",
            "display" : "alginic acid"
          },
          {
            "code" : "A02BX14",
            "display" : "rebamipide"
          },
          {
            "code" : "A02BX15",
            "display" : "teprenone"
          },
          {
            "code" : "A02BX16",
            "display" : "irsogladine"
          },
          {
            "code" : "A02BX51",
            "display" : "carbenoxolone, combinations excl. psycholeptics"
          },
          {
            "code" : "A02BX71",
            "display" : "carbenoxolone, combinations with psycholeptics"
          },
          {
            "code" : "A02BX77",
            "display" : "gefarnate, combinations with psycholeptics"
          },
          {
            "code" : "A02X",
            "display" : "OTHER DRUGS FOR ACID RELATED DISORDERS"
          },
          {
            "code" : "A03",
            "display" : "DRUGS FOR FUNCTIONAL GASTROINTESTINAL DISORDERS"
          },
          {
            "code" : "A03A",
            "display" : "DRUGS FOR FUNCTIONAL GASTROINTESTINAL DISORDERS"
          },
          {
            "code" : "A03AA",
            "display" : "Synthetic anticholinergics, esters with tertiary amino group"
          },
          {
            "code" : "A03AA01",
            "display" : "oxyphencyclimine"
          },
          {
            "code" : "A03AA03",
            "display" : "camylofin"
          },
          {
            "code" : "A03AA04",
            "display" : "mebeverine"
          },
          {
            "code" : "A03AA05",
            "display" : "trimebutine"
          },
          {
            "code" : "A03AA06",
            "display" : "rociverine"
          },
          {
            "code" : "A03AA07",
            "display" : "dicycloverine"
          },
          {
            "code" : "A03AA08",
            "display" : "dihexyverine"
          },
          {
            "code" : "A03AA09",
            "display" : "difemerine"
          },
          {
            "code" : "A03AA30",
            "display" : "piperidolate"
          },
          {
            "code" : "A03AB",
            "display" : "Synthetic anticholinergics, quaternary ammonium compounds"
          },
          {
            "code" : "A03AB01",
            "display" : "benzilone"
          },
          {
            "code" : "A03AB02",
            "display" : "glycopyrronium bromide"
          },
          {
            "code" : "A03AB03",
            "display" : "oxyphenonium"
          },
          {
            "code" : "A03AB04",
            "display" : "penthienate"
          },
          {
            "code" : "A03AB05",
            "display" : "propantheline"
          },
          {
            "code" : "A03AB06",
            "display" : "otilonium bromide"
          },
          {
            "code" : "A03AB07",
            "display" : "methantheline"
          },
          {
            "code" : "A03AB08",
            "display" : "tridihexethyl"
          },
          {
            "code" : "A03AB09",
            "display" : "isopropamide"
          },
          {
            "code" : "A03AB10",
            "display" : "hexocyclium"
          },
          {
            "code" : "A03AB11",
            "display" : "poldine"
          },
          {
            "code" : "A03AB12",
            "display" : "mepenzolate"
          },
          {
            "code" : "A03AB13",
            "display" : "bevonium"
          },
          {
            "code" : "A03AB14",
            "display" : "pipenzolate"
          },
          {
            "code" : "A03AB15",
            "display" : "diphemanil"
          },
          {
            "code" : "A03AB16",
            "display" : "(2-benzhydryloxyethyl)diethyl-methylammonium iodide"
          },
          {
            "code" : "A03AB17",
            "display" : "tiemonium iodide"
          },
          {
            "code" : "A03AB18",
            "display" : "prifinium bromide"
          },
          {
            "code" : "A03AB19",
            "display" : "timepidium bromide"
          },
          {
            "code" : "A03AB21",
            "display" : "fenpiverinium"
          },
          {
            "code" : "A03AB53",
            "display" : "oxyphenonium, combinations"
          },
          {
            "code" : "A03AC",
            "display" : "Synthetic antispasmodics, amides with tertiary amines"
          },
          {
            "code" : "A03AC02",
            "display" : "dimethylaminopropionylphenothiazine"
          },
          {
            "code" : "A03AC04",
            "display" : "nicofetamide"
          },
          {
            "code" : "A03AC05",
            "display" : "tiropramide"
          },
          {
            "code" : "A03AD",
            "display" : "Papaverine and derivatives"
          },
          {
            "code" : "A03AD01",
            "display" : "papaverine"
          },
          {
            "code" : "A03AD02",
            "display" : "drotaverine"
          },
          {
            "code" : "A03AD30",
            "display" : "moxaverine"
          },
          {
            "code" : "A03AE",
            "display" : "Serotonin receptor antagonists"
          },
          {
            "code" : "A03AE01",
            "display" : "alosetron"
          },
          {
            "code" : "A03AE03",
            "display" : "cilansetron"
          },
          {
            "code" : "A03AX",
            "display" : "Other drugs for functional gastrointestinal disorders"
          },
          {
            "code" : "A03AX01",
            "display" : "fenpiprane"
          },
          {
            "code" : "A03AX02",
            "display" : "diisopromine"
          },
          {
            "code" : "A03AX03",
            "display" : "chlorbenzoxamine"
          },
          {
            "code" : "A03AX04",
            "display" : "pinaverium"
          },
          {
            "code" : "A03AX05",
            "display" : "fenoverine"
          },
          {
            "code" : "A03AX06",
            "display" : "idanpramine"
          },
          {
            "code" : "A03AX07",
            "display" : "proxazole"
          },
          {
            "code" : "A03AX08",
            "display" : "alverine"
          },
          {
            "code" : "A03AX09",
            "display" : "trepibutone"
          },
          {
            "code" : "A03AX10",
            "display" : "isometheptene"
          },
          {
            "code" : "A03AX11",
            "display" : "caroverine"
          },
          {
            "code" : "A03AX12",
            "display" : "phloroglucinol"
          },
          {
            "code" : "A03AX13",
            "display" : "silicones"
          },
          {
            "code" : "A03AX14",
            "display" : "valethamate"
          },
          {
            "code" : "A03AX15",
            "display" : "menthae piperitae aetheroleum"
          },
          {
            "code" : "A03AX30",
            "display" : "trimethyldiphenylpropylamine"
          },
          {
            "code" : "A03AX58",
            "display" : "alverine, combinations"
          },
          {
            "code" : "A03B",
            "display" : "BELLADONNA AND DERIVATIVES, PLAIN"
          },
          {
            "code" : "A03BA",
            "display" : "Belladonna alkaloids, tertiary amines"
          },
          {
            "code" : "A03BA01",
            "display" : "atropine"
          },
          {
            "code" : "A03BA03",
            "display" : "hyoscyamine"
          },
          {
            "code" : "A03BA04",
            "display" : "belladonna total alkaloids"
          },
          {
            "code" : "A03BB",
            "display" : "Belladonna alkaloids, semisynthetic, quaternary ammonium compounds"
          },
          {
            "code" : "A03BB01",
            "display" : "butylscopolamine"
          },
          {
            "code" : "A03BB02",
            "display" : "methylatropine"
          },
          {
            "code" : "A03BB03",
            "display" : "methylscopolamine"
          },
          {
            "code" : "A03BB04",
            "display" : "fentonium"
          },
          {
            "code" : "A03BB05",
            "display" : "cimetropium bromide"
          },
          {
            "code" : "A03BB06",
            "display" : "homatropine methylbromide"
          },
          {
            "code" : "A03C",
            "display" : "ANTISPASMODICS IN COMBINATION WITH PSYCHOLEPTICS"
          },
          {
            "code" : "A03CA",
            "display" : "Synthetic anticholinergic agents in combination with psycholeptics"
          },
          {
            "code" : "A03CA01",
            "display" : "isopropamide and psycholeptics"
          },
          {
            "code" : "A03CA02",
            "display" : "clidinium and psycholeptics"
          },
          {
            "code" : "A03CA03",
            "display" : "oxyphencyclimine and psycholeptics"
          },
          {
            "code" : "A03CA04",
            "display" : "otilonium bromide and psycholeptics"
          },
          {
            "code" : "A03CA05",
            "display" : "glycopyrronium bromide and psycholeptics"
          },
          {
            "code" : "A03CA06",
            "display" : "bevonium and psycholeptics"
          },
          {
            "code" : "A03CA07",
            "display" : "ambutonium and psycholeptics"
          },
          {
            "code" : "A03CA08",
            "display" : "diphemanil and psycholeptics"
          },
          {
            "code" : "A03CA09",
            "display" : "pipenzolate and psycholeptics"
          },
          {
            "code" : "A03CA30",
            "display" : "emepronium and psycholeptics"
          },
          {
            "code" : "A03CA34",
            "display" : "propantheline and psycholeptics"
          },
          {
            "code" : "A03CB",
            "display" : "Belladonna and derivatives in combination with psycholeptics"
          },
          {
            "code" : "A03CB01",
            "display" : "methylscopolamine and psycholeptics"
          },
          {
            "code" : "A03CB02",
            "display" : "belladonna total alkaloids and psycholeptics"
          },
          {
            "code" : "A03CB03",
            "display" : "atropine and psycholeptics"
          },
          {
            "code" : "A03CB04",
            "display" : "homatropine methylbromide and psycholeptics"
          },
          {
            "code" : "A03CB31",
            "display" : "hyoscyamine and psycholeptics"
          },
          {
            "code" : "A03CC",
            "display" : "Other antispasmodics in combination with psycholeptics"
          },
          {
            "code" : "A03D",
            "display" : "ANTISPASMODICS IN COMBINATION WITH ANALGESICS"
          },
          {
            "code" : "A03DA",
            "display" : "Synthetic anticholinergic agents in combination with analgesics"
          },
          {
            "code" : "A03DA01",
            "display" : "tropenzilone and analgesics"
          },
          {
            "code" : "A03DA02",
            "display" : "pitofenone and analgesics"
          },
          {
            "code" : "A03DA03",
            "display" : "bevonium and analgesics"
          },
          {
            "code" : "A03DA04",
            "display" : "ciclonium and analgesics"
          },
          {
            "code" : "A03DA05",
            "display" : "camylofin and analgesics"
          },
          {
            "code" : "A03DA06",
            "display" : "trospium and analgesics"
          },
          {
            "code" : "A03DA07",
            "display" : "tiemonium iodide and analgesics"
          },
          {
            "code" : "A03DB",
            "display" : "Belladonna and derivatives in combination with analgesics"
          },
          {
            "code" : "A03DB04",
            "display" : "butylscopolamine and analgesics"
          },
          {
            "code" : "A03DC",
            "display" : "Other antispasmodics in combination with analgesics"
          },
          {
            "code" : "A03E",
            "display" : "ANTISPASMODICS AND ANTICHOLINERGICS IN COMBINATION WITH OTHER DRUGS"
          },
          {
            "code" : "A03EA",
            "display" : "Antispasmodics, psycholeptics and analgesics in combination"
          },
          {
            "code" : "A03ED",
            "display" : "Antispasmodics in combination with other drugs"
          },
          {
            "code" : "A03F",
            "display" : "PROPULSIVES"
          },
          {
            "code" : "A03FA",
            "display" : "Propulsives"
          },
          {
            "code" : "A03FA01",
            "display" : "metoclopramide"
          },
          {
            "code" : "A03FA02",
            "display" : "cisapride"
          },
          {
            "code" : "A03FA03",
            "display" : "domperidone"
          },
          {
            "code" : "A03FA04",
            "display" : "bromopride"
          },
          {
            "code" : "A03FA05",
            "display" : "alizapride"
          },
          {
            "code" : "A03FA06",
            "display" : "clebopride"
          },
          {
            "code" : "A03FA07",
            "display" : "itopride"
          },
          {
            "code" : "A03FA08",
            "display" : "cinitapride"
          },
          {
            "code" : "A03FA09",
            "display" : "mosapride"
          },
          {
            "code" : "A03FA10",
            "display" : "acotiamide"
          },
          {
            "code" : "A04",
            "display" : "ANTIEMETICS AND ANTINAUSEANTS"
          },
          {
            "code" : "A04A",
            "display" : "ANTIEMETICS AND ANTINAUSEANTS"
          },
          {
            "code" : "A04AA",
            "display" : "Serotonin (5HT3) antagonists"
          },
          {
            "code" : "A04AA01",
            "display" : "ondansetron"
          },
          {
            "code" : "A04AA02",
            "display" : "granisetron"
          },
          {
            "code" : "A04AA03",
            "display" : "tropisetron"
          },
          {
            "code" : "A04AA04",
            "display" : "dolasetron"
          },
          {
            "code" : "A04AA05",
            "display" : "palonosetron"
          },
          {
            "code" : "A04AA55",
            "display" : "palonosetron, combinations"
          },
          {
            "code" : "A04AD",
            "display" : "Other antiemetics"
          },
          {
            "code" : "A04AD01",
            "display" : "scopolamine"
          },
          {
            "code" : "A04AD02",
            "display" : "cerium oxalate"
          },
          {
            "code" : "A04AD04",
            "display" : "chlorobutanol"
          },
          {
            "code" : "A04AD05",
            "display" : "metopimazine"
          },
          {
            "code" : "A04AD10",
            "display" : "dronabinol"
          },
          {
            "code" : "A04AD11",
            "display" : "nabilone"
          },
          {
            "code" : "A04AD12",
            "display" : "aprepitant"
          },
          {
            "code" : "A04AD13",
            "display" : "casopitant"
          },
          {
            "code" : "A04AD14",
            "display" : "rolapitant"
          },
          {
            "code" : "A04AD51",
            "display" : "scopolamine, combinations"
          },
          {
            "code" : "A04AD54",
            "display" : "chlorobutanol, combinations"
          },
          {
            "code" : "A05",
            "display" : "BILE AND LIVER THERAPY"
          },
          {
            "code" : "A05A",
            "display" : "BILE THERAPY"
          },
          {
            "code" : "A05AA",
            "display" : "Bile acids and derivatives"
          },
          {
            "code" : "A05AA01",
            "display" : "chenodeoxycholic acid"
          },
          {
            "code" : "A05AA02",
            "display" : "ursodeoxycholic acid"
          },
          {
            "code" : "A05AA03",
            "display" : "cholic acid"
          },
          {
            "code" : "A05AA04",
            "display" : "obeticholic acid"
          },
          {
            "code" : "A05AA05",
            "display" : "ursodoxicoltaurine"
          },
          {
            "code" : "A05AB",
            "display" : "Preparations for biliary tract therapy"
          },
          {
            "code" : "A05AB01",
            "display" : "nicotinyl methylamide"
          },
          {
            "code" : "A05AX",
            "display" : "Other drugs for bile therapy"
          },
          {
            "code" : "A05AX01",
            "display" : "piprozolin"
          },
          {
            "code" : "A05AX02",
            "display" : "hymecromone"
          },
          {
            "code" : "A05AX03",
            "display" : "cyclobutyrol"
          },
          {
            "code" : "A05AX04",
            "display" : "maralixibat chloride"
          },
          {
            "code" : "A05AX05",
            "display" : "odevixibat"
          },
          {
            "code" : "A05AX06",
            "display" : "elafibranor"
          },
          {
            "code" : "A05AX07",
            "display" : "seladelpar"
          },
          {
            "code" : "A05B",
            "display" : "LIVER THERAPY, LIPOTROPICS"
          },
          {
            "code" : "A05BA",
            "display" : "Liver therapy"
          },
          {
            "code" : "A05BA01",
            "display" : "arginine glutamate"
          },
          {
            "code" : "A05BA03",
            "display" : "silymarin"
          },
          {
            "code" : "A05BA04",
            "display" : "citiolone"
          },
          {
            "code" : "A05BA05",
            "display" : "epomediol"
          },
          {
            "code" : "A05BA06",
            "display" : "ornithine oxoglurate"
          },
          {
            "code" : "A05BA07",
            "display" : "tidiacic arginine"
          },
          {
            "code" : "A05BA08",
            "display" : "glycyrrhizic acid"
          },
          {
            "code" : "A05BA09",
            "display" : "metadoxine"
          },
          {
            "code" : "A05BA10",
            "display" : "phospholipids"
          },
          {
            "code" : "A05C",
            "display" : "DRUGS FOR BILE THERAPY AND LIPOTROPICS IN COMBINATION"
          },
          {
            "code" : "A06",
            "display" : "DRUGS FOR CONSTIPATION"
          },
          {
            "code" : "A06A",
            "display" : "DRUGS FOR CONSTIPATION"
          },
          {
            "code" : "A06AA",
            "display" : "Softeners, emollients"
          },
          {
            "code" : "A06AA01",
            "display" : "liquid paraffin"
          },
          {
            "code" : "A06AA02",
            "display" : "docusate sodium"
          },
          {
            "code" : "A06AA51",
            "display" : "liquid paraffin, combinations"
          },
          {
            "code" : "A06AB",
            "display" : "Contact laxatives"
          },
          {
            "code" : "A06AB01",
            "display" : "oxyphenisatine"
          },
          {
            "code" : "A06AB02",
            "display" : "bisacodyl"
          },
          {
            "code" : "A06AB03",
            "display" : "dantron"
          },
          {
            "code" : "A06AB04",
            "display" : "phenolphthalein"
          },
          {
            "code" : "A06AB05",
            "display" : "castor oil"
          },
          {
            "code" : "A06AB06",
            "display" : "senna glycosides"
          },
          {
            "code" : "A06AB07",
            "display" : "cascara"
          },
          {
            "code" : "A06AB08",
            "display" : "sodium picosulfate"
          },
          {
            "code" : "A06AB09",
            "display" : "bisoxatin"
          },
          {
            "code" : "A06AB20",
            "display" : "contact laxatives in combination"
          },
          {
            "code" : "A06AB30",
            "display" : "contact laxatives in combination with belladonna alkaloids"
          },
          {
            "code" : "A06AB52",
            "display" : "bisacodyl, combinations"
          },
          {
            "code" : "A06AB53",
            "display" : "dantron, combinations"
          },
          {
            "code" : "A06AB56",
            "display" : "senna glycosides, combinations"
          },
          {
            "code" : "A06AB57",
            "display" : "cascara, combinations"
          },
          {
            "code" : "A06AB58",
            "display" : "sodium picosulfate, combinations"
          },
          {
            "code" : "A06AC",
            "display" : "Bulk-forming laxatives"
          },
          {
            "code" : "A06AC01",
            "display" : "ispaghula (psylla seeds)"
          },
          {
            "code" : "A06AC02",
            "display" : "ethulose"
          },
          {
            "code" : "A06AC03",
            "display" : "sterculia"
          },
          {
            "code" : "A06AC05",
            "display" : "linseed"
          },
          {
            "code" : "A06AC06",
            "display" : "methylcellulose"
          },
          {
            "code" : "A06AC07",
            "display" : "triticum (wheat fibre)"
          },
          {
            "code" : "A06AC08",
            "display" : "polycarbophil calcium"
          },
          {
            "code" : "A06AC51",
            "display" : "ispaghula, combinations"
          },
          {
            "code" : "A06AC53",
            "display" : "sterculia, combinations"
          },
          {
            "code" : "A06AC55",
            "display" : "linseed, combinations"
          },
          {
            "code" : "A06AD",
            "display" : "Osmotically acting laxatives"
          },
          {
            "code" : "A06AD01",
            "display" : "magnesium carbonate"
          },
          {
            "code" : "A06AD02",
            "display" : "magnesium oxide"
          },
          {
            "code" : "A06AD03",
            "display" : "magnesium peroxide"
          },
          {
            "code" : "A06AD04",
            "display" : "magnesium sulfate"
          },
          {
            "code" : "A06AD10",
            "display" : "mineral salts in combination"
          },
          {
            "code" : "A06AD11",
            "display" : "lactulose"
          },
          {
            "code" : "A06AD12",
            "display" : "lactitol"
          },
          {
            "code" : "A06AD13",
            "display" : "sodium sulfate"
          },
          {
            "code" : "A06AD14",
            "display" : "pentaerithrityl"
          },
          {
            "code" : "A06AD15",
            "display" : "macrogol"
          },
          {
            "code" : "A06AD16",
            "display" : "mannitol"
          },
          {
            "code" : "A06AD17",
            "display" : "sodium phosphate"
          },
          {
            "code" : "A06AD18",
            "display" : "sorbitol"
          },
          {
            "code" : "A06AD19",
            "display" : "magnesium citrate"
          },
          {
            "code" : "A06AD21",
            "display" : "sodium tartrate"
          },
          {
            "code" : "A06AD61",
            "display" : "lactulose, combinations"
          },
          {
            "code" : "A06AD65",
            "display" : "macrogol, combinations"
          },
          {
            "code" : "A06AG",
            "display" : "Enemas"
          },
          {
            "code" : "A06AG01",
            "display" : "sodium phosphate"
          },
          {
            "code" : "A06AG02",
            "display" : "bisacodyl"
          },
          {
            "code" : "A06AG03",
            "display" : "dantron, incl. combinations"
          },
          {
            "code" : "A06AG04",
            "display" : "glycerol"
          },
          {
            "code" : "A06AG06",
            "display" : "oil"
          },
          {
            "code" : "A06AG07",
            "display" : "sorbitol"
          },
          {
            "code" : "A06AG10",
            "display" : "docusate sodium, incl. combinations"
          },
          {
            "code" : "A06AG11",
            "display" : "sodium lauryl sulfoacetate, incl. combinations"
          },
          {
            "code" : "A06AG20",
            "display" : "combinations"
          },
          {
            "code" : "A06AH",
            "display" : "Peripheral opioid receptor antagonists"
          },
          {
            "code" : "A06AH01",
            "display" : "methylnaltrexone bromide"
          },
          {
            "code" : "A06AH02",
            "display" : "alvimopan"
          },
          {
            "code" : "A06AH03",
            "display" : "naloxegol"
          },
          {
            "code" : "A06AH04",
            "display" : "naloxone"
          },
          {
            "code" : "A06AH05",
            "display" : "naldemedine"
          },
          {
            "code" : "A06AX",
            "display" : "Other drugs for constipation"
          },
          {
            "code" : "A06AX01",
            "display" : "glycerol"
          },
          {
            "code" : "A06AX02",
            "display" : "carbon dioxide producing drugs"
          },
          {
            "code" : "A06AX03",
            "display" : "lubiprostone"
          },
          {
            "code" : "A06AX04",
            "display" : "linaclotide"
          },
          {
            "code" : "A06AX05",
            "display" : "prucalopride"
          },
          {
            "code" : "A06AX06",
            "display" : "tegaserod"
          },
          {
            "code" : "A06AX07",
            "display" : "plecanatide"
          },
          {
            "code" : "A06AX08",
            "display" : "tenapanor"
          },
          {
            "code" : "A06AX09",
            "display" : "elobixibat"
          },
          {
            "code" : "A07",
            "display" : "ANTIDIARRHEALS, INTESTINAL ANTIINFLAMMATORY/ANTIINFECTIVE AGENTS"
          },
          {
            "code" : "A07A",
            "display" : "INTESTINAL ANTIINFECTIVES"
          },
          {
            "code" : "A07AA",
            "display" : "Antibiotics"
          },
          {
            "code" : "A07AA01",
            "display" : "neomycin"
          },
          {
            "code" : "A07AA02",
            "display" : "nystatin"
          },
          {
            "code" : "A07AA03",
            "display" : "natamycin"
          },
          {
            "code" : "A07AA04",
            "display" : "streptomycin"
          },
          {
            "code" : "A07AA05",
            "display" : "polymyxin B"
          },
          {
            "code" : "A07AA06",
            "display" : "paromomycin"
          },
          {
            "code" : "A07AA07",
            "display" : "amphotericin B"
          },
          {
            "code" : "A07AA08",
            "display" : "kanamycin"
          },
          {
            "code" : "A07AA09",
            "display" : "vancomycin"
          },
          {
            "code" : "A07AA10",
            "display" : "colistin"
          },
          {
            "code" : "A07AA11",
            "display" : "rifaximin"
          },
          {
            "code" : "A07AA12",
            "display" : "fidaxomicin"
          },
          {
            "code" : "A07AA13",
            "display" : "rifamycin"
          },
          {
            "code" : "A07AA51",
            "display" : "neomycin, combinations"
          },
          {
            "code" : "A07AA54",
            "display" : "streptomycin, combinations"
          },
          {
            "code" : "A07AB",
            "display" : "Sulfonamides"
          },
          {
            "code" : "A07AB02",
            "display" : "phthalylsulfathiazole"
          },
          {
            "code" : "A07AB03",
            "display" : "sulfaguanidine"
          },
          {
            "code" : "A07AB04",
            "display" : "succinylsulfathiazole"
          },
          {
            "code" : "A07AC",
            "display" : "Imidazole derivatives"
          },
          {
            "code" : "A07AC01",
            "display" : "miconazole"
          },
          {
            "code" : "A07AX",
            "display" : "Other intestinal antiinfectives"
          },
          {
            "code" : "A07AX01",
            "display" : "broxyquinoline"
          },
          {
            "code" : "A07AX02",
            "display" : "acetarsol"
          },
          {
            "code" : "A07AX03",
            "display" : "nifuroxazide"
          },
          {
            "code" : "A07AX04",
            "display" : "nifurzide"
          },
          {
            "code" : "A07B",
            "display" : "INTESTINAL ADSORBENTS"
          },
          {
            "code" : "A07BA",
            "display" : "Charcoal preparations"
          },
          {
            "code" : "A07BA01",
            "display" : "medicinal charcoal"
          },
          {
            "code" : "A07BA51",
            "display" : "medicinal charcoal, combinations"
          },
          {
            "code" : "A07BB",
            "display" : "Bismuth preparations"
          },
          {
            "code" : "A07BC",
            "display" : "Other intestinal adsorbents"
          },
          {
            "code" : "A07BC01",
            "display" : "pectin"
          },
          {
            "code" : "A07BC02",
            "display" : "kaolin"
          },
          {
            "code" : "A07BC03",
            "display" : "crospovidone"
          },
          {
            "code" : "A07BC04",
            "display" : "attapulgite"
          },
          {
            "code" : "A07BC05",
            "display" : "diosmectite"
          },
          {
            "code" : "A07BC30",
            "display" : "combinations"
          },
          {
            "code" : "A07BC54",
            "display" : "attapulgite, combinations"
          },
          {
            "code" : "A07C",
            "display" : "ELECTROLYTES WITH CARBOHYDRATES"
          },
          {
            "code" : "A07CA",
            "display" : "Oral rehydration salt formulations"
          },
          {
            "code" : "A07D",
            "display" : "ANTIPROPULSIVES"
          },
          {
            "code" : "A07DA",
            "display" : "Antipropulsives"
          },
          {
            "code" : "A07DA01",
            "display" : "diphenoxylate"
          },
          {
            "code" : "A07DA02",
            "display" : "opium"
          },
          {
            "code" : "A07DA03",
            "display" : "loperamide"
          },
          {
            "code" : "A07DA04",
            "display" : "difenoxin"
          },
          {
            "code" : "A07DA05",
            "display" : "loperamide oxide"
          },
          {
            "code" : "A07DA06",
            "display" : "eluxadoline"
          },
          {
            "code" : "A07DA52",
            "display" : "morphine, combinations"
          },
          {
            "code" : "A07DA53",
            "display" : "loperamide, combinations"
          },
          {
            "code" : "A07E",
            "display" : "INTESTINAL ANTIINFLAMMATORY AGENTS"
          },
          {
            "code" : "A07EA",
            "display" : "Corticosteroids acting locally"
          },
          {
            "code" : "A07EA01",
            "display" : "prednisolone"
          },
          {
            "code" : "A07EA02",
            "display" : "hydrocortisone"
          },
          {
            "code" : "A07EA03",
            "display" : "prednisone"
          },
          {
            "code" : "A07EA04",
            "display" : "betamethasone"
          },
          {
            "code" : "A07EA05",
            "display" : "tixocortol"
          },
          {
            "code" : "A07EA06",
            "display" : "budesonide"
          },
          {
            "code" : "A07EA07",
            "display" : "beclometasone"
          },
          {
            "code" : "A07EB",
            "display" : "Antiallergic agents, excl. corticosteroids"
          },
          {
            "code" : "A07EB01",
            "display" : "cromoglicic acid"
          },
          {
            "code" : "A07EC",
            "display" : "Aminosalicylic acid and similar agents"
          },
          {
            "code" : "A07EC01",
            "display" : "sulfasalazine"
          },
          {
            "code" : "A07EC02",
            "display" : "mesalazine"
          },
          {
            "code" : "A07EC03",
            "display" : "olsalazine"
          },
          {
            "code" : "A07EC04",
            "display" : "balsalazide"
          },
          {
            "code" : "A07F",
            "display" : "ANTIDIARRHEAL MICROORGANISMS"
          },
          {
            "code" : "A07FA",
            "display" : "Antidiarrheal microorganisms"
          },
          {
            "code" : "A07FA01",
            "display" : "lactic acid producing organisms"
          },
          {
            "code" : "A07FA02",
            "display" : "saccharomyces boulardii"
          },
          {
            "code" : "A07FA03",
            "display" : "escherichia coli"
          },
          {
            "code" : "A07FA51",
            "display" : "lactic acid producing organisms, combinations"
          },
          {
            "code" : "A07X",
            "display" : "OTHER ANTIDIARRHEALS"
          },
          {
            "code" : "A07XA",
            "display" : "Other antidiarrheals"
          },
          {
            "code" : "A07XA01",
            "display" : "albumin tannate"
          },
          {
            "code" : "A07XA02",
            "display" : "ceratonia"
          },
          {
            "code" : "A07XA03",
            "display" : "calcium compounds"
          },
          {
            "code" : "A07XA04",
            "display" : "racecadotril"
          },
          {
            "code" : "A07XA06",
            "display" : "crofelemer"
          },
          {
            "code" : "A07XA51",
            "display" : "albumin tannate, combinations"
          },
          {
            "code" : "A08",
            "display" : "ANTIOBESITY PREPARATIONS, EXCL. DIET PRODUCTS"
          },
          {
            "code" : "A08A",
            "display" : "ANTIOBESITY PREPARATIONS, EXCL. DIET PRODUCTS"
          },
          {
            "code" : "A08AA",
            "display" : "Centrally acting antiobesity products"
          },
          {
            "code" : "A08AA01",
            "display" : "phentermine"
          },
          {
            "code" : "A08AA02",
            "display" : "fenfluramine"
          },
          {
            "code" : "A08AA03",
            "display" : "amfepramone"
          },
          {
            "code" : "A08AA04",
            "display" : "dexfenfluramine"
          },
          {
            "code" : "A08AA05",
            "display" : "mazindol"
          },
          {
            "code" : "A08AA06",
            "display" : "etilamfetamine"
          },
          {
            "code" : "A08AA07",
            "display" : "cathine"
          },
          {
            "code" : "A08AA08",
            "display" : "clobenzorex"
          },
          {
            "code" : "A08AA09",
            "display" : "mefenorex"
          },
          {
            "code" : "A08AA10",
            "display" : "sibutramine"
          },
          {
            "code" : "A08AA11",
            "display" : "lorcaserin"
          },
          {
            "code" : "A08AA12",
            "display" : "setmelanotide"
          },
          {
            "code" : "A08AA51",
            "display" : "phentermine and topiramate"
          },
          {
            "code" : "A08AA56",
            "display" : "ephedrine, combinations"
          },
          {
            "code" : "A08AA62",
            "display" : "bupropion and naltrexone"
          },
          {
            "code" : "A08AB",
            "display" : "Peripherally acting antiobesity products"
          },
          {
            "code" : "A08AB01",
            "display" : "orlistat"
          },
          {
            "code" : "A08AX",
            "display" : "Other antiobesity drugs"
          },
          {
            "code" : "A08AX01",
            "display" : "rimonabant"
          },
          {
            "code" : "A09",
            "display" : "DIGESTIVES, INCL. ENZYMES"
          },
          {
            "code" : "A09A",
            "display" : "DIGESTIVES, INCL. ENZYMES"
          },
          {
            "code" : "A09AA",
            "display" : "Enzyme preparations"
          },
          {
            "code" : "A09AA01",
            "display" : "diastase"
          },
          {
            "code" : "A09AA02",
            "display" : "multienzymes (lipase, protease etc.)"
          },
          {
            "code" : "A09AA03",
            "display" : "pepsin"
          },
          {
            "code" : "A09AA04",
            "display" : "tilactase"
          },
          {
            "code" : "A09AB",
            "display" : "Acid preparations"
          },
          {
            "code" : "A09AB01",
            "display" : "glutamic acid hydrochloride"
          },
          {
            "code" : "A09AB02",
            "display" : "betaine hydrochloride"
          },
          {
            "code" : "A09AB03",
            "display" : "hydrochloric acid"
          },
          {
            "code" : "A09AB04",
            "display" : "citric acid"
          },
          {
            "code" : "A09AC",
            "display" : "Enzyme and acid preparations, combinations"
          },
          {
            "code" : "A09AC01",
            "display" : "pepsin and acid preparations"
          },
          {
            "code" : "A09AC02",
            "display" : "multienzymes and acid preparations"
          },
          {
            "code" : "A10",
            "display" : "DRUGS USED IN DIABETES"
          },
          {
            "code" : "A10A",
            "display" : "INSULINS AND ANALOGUES"
          },
          {
            "code" : "A10AB",
            "display" : "Insulins and analogues for injection, fast-acting"
          },
          {
            "code" : "A10AB01",
            "display" : "insulin (human)"
          },
          {
            "code" : "A10AB02",
            "display" : "insulin (beef)"
          },
          {
            "code" : "A10AB03",
            "display" : "insulin (pork)"
          },
          {
            "code" : "A10AB04",
            "display" : "insulin lispro"
          },
          {
            "code" : "A10AB05",
            "display" : "insulin aspart"
          },
          {
            "code" : "A10AB06",
            "display" : "insulin glulisine"
          },
          {
            "code" : "A10AB30",
            "display" : "combinations"
          },
          {
            "code" : "A10AC",
            "display" : "Insulins and analogues for injection, intermediate-acting"
          },
          {
            "code" : "A10AC01",
            "display" : "insulin (human)"
          },
          {
            "code" : "A10AC02",
            "display" : "insulin (beef)"
          },
          {
            "code" : "A10AC03",
            "display" : "insulin (pork)"
          },
          {
            "code" : "A10AC04",
            "display" : "insulin lispro"
          },
          {
            "code" : "A10AC30",
            "display" : "combinations"
          },
          {
            "code" : "A10AD",
            "display" : "Insulins and analogues for injection, intermediate- or long-acting combined with fast-acting"
          },
          {
            "code" : "A10AD01",
            "display" : "insulin (human)"
          },
          {
            "code" : "A10AD02",
            "display" : "insulin (beef)"
          },
          {
            "code" : "A10AD03",
            "display" : "insulin (pork)"
          },
          {
            "code" : "A10AD04",
            "display" : "insulin lispro"
          },
          {
            "code" : "A10AD05",
            "display" : "insulin aspart"
          },
          {
            "code" : "A10AD06",
            "display" : "insulin degludec and insulin aspart"
          },
          {
            "code" : "A10AD30",
            "display" : "combinations"
          },
          {
            "code" : "A10AE",
            "display" : "Insulins and analogues for injection, long-acting"
          },
          {
            "code" : "A10AE01",
            "display" : "insulin (human)"
          },
          {
            "code" : "A10AE02",
            "display" : "insulin (beef)"
          },
          {
            "code" : "A10AE03",
            "display" : "insulin (pork)"
          },
          {
            "code" : "A10AE04",
            "display" : "insulin glargine"
          },
          {
            "code" : "A10AE05",
            "display" : "insulin detemir"
          },
          {
            "code" : "A10AE06",
            "display" : "insulin degludec"
          },
          {
            "code" : "A10AE07",
            "display" : "insulin icodec"
          },
          {
            "code" : "A10AE30",
            "display" : "combinations"
          },
          {
            "code" : "A10AE54",
            "display" : "insulin glargine and lixisenatide"
          },
          {
            "code" : "A10AE56",
            "display" : "insulin degludec and liraglutide"
          },
          {
            "code" : "A10AF",
            "display" : "Insulins and analogues for inhalation"
          },
          {
            "code" : "A10AF01",
            "display" : "insulin (human)"
          },
          {
            "code" : "A10B",
            "display" : "BLOOD GLUCOSE LOWERING DRUGS, EXCL. INSULINS"
          },
          {
            "code" : "A10BA",
            "display" : "Biguanides"
          },
          {
            "code" : "A10BA01",
            "display" : "phenformin"
          },
          {
            "code" : "A10BA02",
            "display" : "metformin"
          },
          {
            "code" : "A10BA03",
            "display" : "buformin"
          },
          {
            "code" : "A10BB",
            "display" : "Sulfonylureas"
          },
          {
            "code" : "A10BB01",
            "display" : "glibenclamide"
          },
          {
            "code" : "A10BB02",
            "display" : "chlorpropamide"
          },
          {
            "code" : "A10BB03",
            "display" : "tolbutamide"
          },
          {
            "code" : "A10BB04",
            "display" : "glibornuride"
          },
          {
            "code" : "A10BB05",
            "display" : "tolazamide"
          },
          {
            "code" : "A10BB06",
            "display" : "carbutamide"
          },
          {
            "code" : "A10BB07",
            "display" : "glipizide"
          },
          {
            "code" : "A10BB08",
            "display" : "gliquidone"
          },
          {
            "code" : "A10BB09",
            "display" : "gliclazide"
          },
          {
            "code" : "A10BB10",
            "display" : "metahexamide"
          },
          {
            "code" : "A10BB11",
            "display" : "glisoxepide"
          },
          {
            "code" : "A10BB12",
            "display" : "glimepiride"
          },
          {
            "code" : "A10BB31",
            "display" : "acetohexamide"
          },
          {
            "code" : "A10BC",
            "display" : "Sulfonamides (heterocyclic)"
          },
          {
            "code" : "A10BC01",
            "display" : "glymidine"
          },
          {
            "code" : "A10BD",
            "display" : "Combinations of oral blood glucose lowering drugs"
          },
          {
            "code" : "A10BD01",
            "display" : "phenformin and sulfonylureas"
          },
          {
            "code" : "A10BD02",
            "display" : "metformin and sulfonylureas"
          },
          {
            "code" : "A10BD03",
            "display" : "metformin and rosiglitazone"
          },
          {
            "code" : "A10BD04",
            "display" : "glimepiride and rosiglitazone"
          },
          {
            "code" : "A10BD05",
            "display" : "metformin and pioglitazone"
          },
          {
            "code" : "A10BD06",
            "display" : "glimepiride and pioglitazone"
          },
          {
            "code" : "A10BD07",
            "display" : "metformin and sitagliptin"
          },
          {
            "code" : "A10BD08",
            "display" : "metformin and vildagliptin"
          },
          {
            "code" : "A10BD09",
            "display" : "pioglitazone and alogliptin"
          },
          {
            "code" : "A10BD10",
            "display" : "metformin and saxagliptin"
          },
          {
            "code" : "A10BD11",
            "display" : "metformin and linagliptin"
          },
          {
            "code" : "A10BD12",
            "display" : "pioglitazone and sitagliptin"
          },
          {
            "code" : "A10BD13",
            "display" : "metformin and alogliptin"
          },
          {
            "code" : "A10BD14",
            "display" : "metformin and repaglinide"
          },
          {
            "code" : "A10BD15",
            "display" : "metformin and dapagliflozin"
          },
          {
            "code" : "A10BD16",
            "display" : "metformin and canagliflozin"
          },
          {
            "code" : "A10BD17",
            "display" : "metformin and acarbose"
          },
          {
            "code" : "A10BD18",
            "display" : "metformin and gemigliptin"
          },
          {
            "code" : "A10BD19",
            "display" : "linagliptin and empagliflozin"
          },
          {
            "code" : "A10BD20",
            "display" : "metformin and empagliflozin"
          },
          {
            "code" : "A10BD21",
            "display" : "saxagliptin and dapagliflozin"
          },
          {
            "code" : "A10BD22",
            "display" : "metformin and evogliptin"
          },
          {
            "code" : "A10BD23",
            "display" : "metformin and ertugliflozin"
          },
          {
            "code" : "A10BD24",
            "display" : "sitagliptin and ertugliflozin"
          },
          {
            "code" : "A10BD25",
            "display" : "metformin, saxagliptin and dapagliflozin"
          },
          {
            "code" : "A10BD26",
            "display" : "metformin and lobeglitazone"
          },
          {
            "code" : "A10BD27",
            "display" : "metformin, linagliptin and empagliflozin"
          },
          {
            "code" : "A10BD28",
            "display" : "metformin and teneligliptin"
          },
          {
            "code" : "A10BD29",
            "display" : "sitagliptin and dapagliflozin"
          },
          {
            "code" : "A10BD30",
            "display" : "gemigliptin and dapagliflozin"
          },
          {
            "code" : "A10BF",
            "display" : "Alpha glucosidase inhibitors"
          },
          {
            "code" : "A10BF01",
            "display" : "acarbose"
          },
          {
            "code" : "A10BF02",
            "display" : "miglitol"
          },
          {
            "code" : "A10BF03",
            "display" : "voglibose"
          },
          {
            "code" : "A10BG",
            "display" : "Thiazolidinediones"
          },
          {
            "code" : "A10BG01",
            "display" : "troglitazone"
          },
          {
            "code" : "A10BG02",
            "display" : "rosiglitazone"
          },
          {
            "code" : "A10BG03",
            "display" : "pioglitazone"
          },
          {
            "code" : "A10BG04",
            "display" : "lobeglitazone"
          },
          {
            "code" : "A10BH",
            "display" : "Dipeptidyl peptidase 4 (DPP-4) inhibitors"
          },
          {
            "code" : "A10BH01",
            "display" : "sitagliptin"
          },
          {
            "code" : "A10BH02",
            "display" : "vildagliptin"
          },
          {
            "code" : "A10BH03",
            "display" : "saxagliptin"
          },
          {
            "code" : "A10BH04",
            "display" : "alogliptin"
          },
          {
            "code" : "A10BH05",
            "display" : "linagliptin"
          },
          {
            "code" : "A10BH06",
            "display" : "gemigliptin"
          },
          {
            "code" : "A10BH07",
            "display" : "evogliptin"
          },
          {
            "code" : "A10BH08",
            "display" : "teneligliptin"
          },
          {
            "code" : "A10BH51",
            "display" : "sitagliptin and simvastatin"
          },
          {
            "code" : "A10BH52",
            "display" : "gemigliptin and rosuvastatin"
          },
          {
            "code" : "A10BJ",
            "display" : "Glucagon-like peptide-1 (GLP-1) analogues"
          },
          {
            "code" : "A10BJ01",
            "display" : "exenatide"
          },
          {
            "code" : "A10BJ02",
            "display" : "liraglutide"
          },
          {
            "code" : "A10BJ03",
            "display" : "lixisenatide"
          },
          {
            "code" : "A10BJ04",
            "display" : "albiglutide"
          },
          {
            "code" : "A10BJ05",
            "display" : "dulaglutide"
          },
          {
            "code" : "A10BJ06",
            "display" : "semaglutide"
          },
          {
            "code" : "A10BJ07",
            "display" : "beinaglutide"
          },
          {
            "code" : "A10BK",
            "display" : "Sodium-glucose co-transporter 2 (SGLT2) inhibitors"
          },
          {
            "code" : "A10BK01",
            "display" : "dapagliflozin"
          },
          {
            "code" : "A10BK02",
            "display" : "canagliflozin"
          },
          {
            "code" : "A10BK03",
            "display" : "empagliflozin"
          },
          {
            "code" : "A10BK04",
            "display" : "ertugliflozin"
          },
          {
            "code" : "A10BK05",
            "display" : "ipragliflozin"
          },
          {
            "code" : "A10BK06",
            "display" : "sotagliflozin"
          },
          {
            "code" : "A10BK07",
            "display" : "luseogliflozin"
          },
          {
            "code" : "A10BK08",
            "display" : "bexagliflozin"
          },
          {
            "code" : "A10BK09",
            "display" : "enavogliflozin"
          },
          {
            "code" : "A10BX",
            "display" : "Other blood glucose lowering drugs, excl. insulins"
          },
          {
            "code" : "A10BX01",
            "display" : "guar gum"
          },
          {
            "code" : "A10BX02",
            "display" : "repaglinide"
          },
          {
            "code" : "A10BX03",
            "display" : "nateglinide"
          },
          {
            "code" : "A10BX05",
            "display" : "pramlintide"
          },
          {
            "code" : "A10BX06",
            "display" : "benfluorex"
          },
          {
            "code" : "A10BX08",
            "display" : "mitiglinide"
          },
          {
            "code" : "A10BX15",
            "display" : "imeglimin"
          },
          {
            "code" : "A10BX16",
            "display" : "tirzepatide"
          },
          {
            "code" : "A10BX17",
            "display" : "carfloglitazar"
          },
          {
            "code" : "A10BX18",
            "display" : "dorzagliatin"
          },
          {
            "code" : "A10X",
            "display" : "OTHER DRUGS USED IN DIABETES"
          },
          {
            "code" : "A10XA",
            "display" : "Aldose reductase inhibitors"
          },
          {
            "code" : "A10XA01",
            "display" : "tolrestat"
          },
          {
            "code" : "A10XX",
            "display" : "Other drugs used in diabetes"
          },
          {
            "code" : "A10XX01",
            "display" : "teplizumab"
          },
          {
            "code" : "A10XX02",
            "display" : "donislecel"
          },
          {
            "code" : "A11",
            "display" : "VITAMINS"
          },
          {
            "code" : "A11A",
            "display" : "MULTIVITAMINS, COMBINATIONS"
          },
          {
            "code" : "A11AA",
            "display" : "Multivitamins with minerals"
          },
          {
            "code" : "A11AA01",
            "display" : "multivitamins and iron"
          },
          {
            "code" : "A11AA02",
            "display" : "multivitamins and calcium"
          },
          {
            "code" : "A11AA03",
            "display" : "multivitamins and other minerals, incl. combinations"
          },
          {
            "code" : "A11AA04",
            "display" : "multivitamins and trace elements"
          },
          {
            "code" : "A11AB",
            "display" : "Multivitamins, other combinations"
          },
          {
            "code" : "A11B",
            "display" : "MULTIVITAMINS, PLAIN"
          },
          {
            "code" : "A11BA",
            "display" : "Multivitamins, plain"
          },
          {
            "code" : "A11C",
            "display" : "VITAMIN A AND D, INCL. COMBINATIONS OF THE TWO"
          },
          {
            "code" : "A11CA",
            "display" : "Vitamin A, plain"
          },
          {
            "code" : "A11CA01",
            "display" : "retinol (vit A)"
          },
          {
            "code" : "A11CA02",
            "display" : "betacarotene"
          },
          {
            "code" : "A11CB",
            "display" : "Vitamin A and D in combination"
          },
          {
            "code" : "A11CC",
            "display" : "Vitamin D and analogues"
          },
          {
            "code" : "A11CC01",
            "display" : "ergocalciferol"
          },
          {
            "code" : "A11CC02",
            "display" : "dihydrotachysterol"
          },
          {
            "code" : "A11CC03",
            "display" : "alfacalcidol"
          },
          {
            "code" : "A11CC04",
            "display" : "calcitriol"
          },
          {
            "code" : "A11CC05",
            "display" : "colecalciferol"
          },
          {
            "code" : "A11CC06",
            "display" : "calcifediol"
          },
          {
            "code" : "A11CC20",
            "display" : "combinations"
          },
          {
            "code" : "A11CC55",
            "display" : "colecalciferol, combinations"
          },
          {
            "code" : "A11D",
            "display" : "VITAMIN B1, PLAIN AND IN COMBINATION WITH VITAMIN B6 AND B12"
          },
          {
            "code" : "A11DA",
            "display" : "Vitamin B1, plain"
          },
          {
            "code" : "A11DA01",
            "display" : "thiamine (vit B1)"
          },
          {
            "code" : "A11DA02",
            "display" : "sulbutiamine"
          },
          {
            "code" : "A11DA03",
            "display" : "benfotiamine"
          },
          {
            "code" : "A11DB",
            "display" : "Vitamin B1 in combination with vitamin B6 and/or vitamin B12"
          },
          {
            "code" : "A11E",
            "display" : "VITAMIN B-COMPLEX, INCL. COMBINATIONS"
          },
          {
            "code" : "A11EA",
            "display" : "Vitamin B-complex, plain"
          },
          {
            "code" : "A11EB",
            "display" : "Vitamin B-complex with vitamin C"
          },
          {
            "code" : "A11EC",
            "display" : "Vitamin B-complex with minerals"
          },
          {
            "code" : "A11ED",
            "display" : "Vitamin B-complex with anabolic steroids"
          },
          {
            "code" : "A11EX",
            "display" : "Vitamin B-complex, other combinations"
          },
          {
            "code" : "A11G",
            "display" : "ASCORBIC ACID (VITAMIN C), INCL. COMBINATIONS"
          },
          {
            "code" : "A11GA",
            "display" : "Ascorbic acid (vitamin C), plain"
          },
          {
            "code" : "A11GA01",
            "display" : "ascorbic acid (vit C)"
          },
          {
            "code" : "A11GB",
            "display" : "Ascorbic acid (vitamin C), combinations"
          },
          {
            "code" : "A11GB01",
            "display" : "ascorbic acid (vit C) and calcium"
          },
          {
            "code" : "A11H",
            "display" : "OTHER PLAIN VITAMIN PREPARATIONS"
          },
          {
            "code" : "A11HA",
            "display" : "Other plain vitamin preparations"
          },
          {
            "code" : "A11HA01",
            "display" : "nicotinamide"
          },
          {
            "code" : "A11HA02",
            "display" : "pyridoxine (vit B6)"
          },
          {
            "code" : "A11HA03",
            "display" : "tocopherol (vit E)"
          },
          {
            "code" : "A11HA04",
            "display" : "riboflavin (vit B2)"
          },
          {
            "code" : "A11HA05",
            "display" : "biotin"
          },
          {
            "code" : "A11HA06",
            "display" : "pyridoxal phosphate"
          },
          {
            "code" : "A11HA07",
            "display" : "inositol"
          },
          {
            "code" : "A11HA08",
            "display" : "tocofersolan"
          },
          {
            "code" : "A11HA30",
            "display" : "dexpanthenol"
          },
          {
            "code" : "A11HA31",
            "display" : "calcium pantothenate"
          },
          {
            "code" : "A11HA32",
            "display" : "pantethine"
          },
          {
            "code" : "A11J",
            "display" : "OTHER VITAMIN PRODUCTS, COMBINATIONS"
          },
          {
            "code" : "A11JA",
            "display" : "Combinations of vitamins"
          },
          {
            "code" : "A11JB",
            "display" : "Vitamins with minerals"
          },
          {
            "code" : "A11JC",
            "display" : "Vitamins, other combinations"
          },
          {
            "code" : "A12",
            "display" : "MINERAL SUPPLEMENTS"
          },
          {
            "code" : "A12A",
            "display" : "CALCIUM"
          },
          {
            "code" : "A12AA",
            "display" : "Calcium"
          },
          {
            "code" : "A12AA01",
            "display" : "calcium phosphate"
          },
          {
            "code" : "A12AA02",
            "display" : "calcium glubionate"
          },
          {
            "code" : "A12AA03",
            "display" : "calcium gluconate"
          },
          {
            "code" : "A12AA04",
            "display" : "calcium carbonate"
          },
          {
            "code" : "A12AA05",
            "display" : "calcium lactate"
          },
          {
            "code" : "A12AA06",
            "display" : "calcium lactate gluconate"
          },
          {
            "code" : "A12AA07",
            "display" : "calcium chloride"
          },
          {
            "code" : "A12AA08",
            "display" : "calcium glycerylphosphate"
          },
          {
            "code" : "A12AA09",
            "display" : "calcium citrate lysine complex"
          },
          {
            "code" : "A12AA10",
            "display" : "calcium glucoheptonate"
          },
          {
            "code" : "A12AA11",
            "display" : "calcium pangamate"
          },
          {
            "code" : "A12AA13",
            "display" : "calcium citrate"
          },
          {
            "code" : "A12AA20",
            "display" : "calcium (different salts in combination)"
          },
          {
            "code" : "A12AA30",
            "display" : "calcium laevulate"
          },
          {
            "code" : "A12AX",
            "display" : "Calcium, combinations with vitamin D and/or other drugs"
          },
          {
            "code" : "A12B",
            "display" : "POTASSIUM"
          },
          {
            "code" : "A12BA",
            "display" : "Potassium"
          },
          {
            "code" : "A12BA01",
            "display" : "potassium chloride"
          },
          {
            "code" : "A12BA02",
            "display" : "potassium citrate"
          },
          {
            "code" : "A12BA03",
            "display" : "potassium hydrogentartrate"
          },
          {
            "code" : "A12BA04",
            "display" : "potassium hydrogencarbonate"
          },
          {
            "code" : "A12BA05",
            "display" : "potassium gluconate"
          },
          {
            "code" : "A12BA30",
            "display" : "potassium (different salts in combination)"
          },
          {
            "code" : "A12BA51",
            "display" : "potassium, combinations"
          },
          {
            "code" : "A12C",
            "display" : "OTHER MINERAL SUPPLEMENTS"
          },
          {
            "code" : "A12CA",
            "display" : "Sodium"
          },
          {
            "code" : "A12CA01",
            "display" : "sodium chloride"
          },
          {
            "code" : "A12CA02",
            "display" : "sodium sulfate"
          },
          {
            "code" : "A12CB",
            "display" : "Zinc"
          },
          {
            "code" : "A12CB01",
            "display" : "zinc sulfate"
          },
          {
            "code" : "A12CB02",
            "display" : "zinc gluconate"
          },
          {
            "code" : "A12CB03",
            "display" : "zinc protein complex"
          },
          {
            "code" : "A12CC",
            "display" : "Magnesium"
          },
          {
            "code" : "A12CC01",
            "display" : "magnesium chloride"
          },
          {
            "code" : "A12CC02",
            "display" : "magnesium sulfate"
          },
          {
            "code" : "A12CC03",
            "display" : "magnesium gluconate"
          },
          {
            "code" : "A12CC04",
            "display" : "magnesium citrate"
          },
          {
            "code" : "A12CC05",
            "display" : "magnesium aspartate"
          },
          {
            "code" : "A12CC06",
            "display" : "magnesium lactate"
          },
          {
            "code" : "A12CC07",
            "display" : "magnesium levulinate"
          },
          {
            "code" : "A12CC08",
            "display" : "magnesium pidolate"
          },
          {
            "code" : "A12CC09",
            "display" : "magnesium orotate"
          },
          {
            "code" : "A12CC10",
            "display" : "magnesium oxide"
          },
          {
            "code" : "A12CC30",
            "display" : "magnesium (different salts in combination)"
          },
          {
            "code" : "A12CD",
            "display" : "Fluoride"
          },
          {
            "code" : "A12CD01",
            "display" : "sodium fluoride"
          },
          {
            "code" : "A12CD02",
            "display" : "sodium monofluorophosphate"
          },
          {
            "code" : "A12CD51",
            "display" : "fluoride, combinations"
          },
          {
            "code" : "A12CE",
            "display" : "Selenium"
          },
          {
            "code" : "A12CE01",
            "display" : "sodium selenate"
          },
          {
            "code" : "A12CE02",
            "display" : "sodium selenite"
          },
          {
            "code" : "A12CX",
            "display" : "Other mineral products"
          },
          {
            "code" : "A13",
            "display" : "TONICS"
          },
          {
            "code" : "A13A",
            "display" : "TONICS"
          },
          {
            "code" : "A14",
            "display" : "ANABOLIC AGENTS FOR SYSTEMIC USE"
          },
          {
            "code" : "A14A",
            "display" : "ANABOLIC STEROIDS"
          },
          {
            "code" : "A14AA",
            "display" : "Androstan derivatives"
          },
          {
            "code" : "A14AA01",
            "display" : "androstanolone"
          },
          {
            "code" : "A14AA02",
            "display" : "stanozolol"
          },
          {
            "code" : "A14AA03",
            "display" : "metandienone"
          },
          {
            "code" : "A14AA04",
            "display" : "metenolone"
          },
          {
            "code" : "A14AA05",
            "display" : "oxymetholone"
          },
          {
            "code" : "A14AA06",
            "display" : "quinbolone"
          },
          {
            "code" : "A14AA07",
            "display" : "prasterone"
          },
          {
            "code" : "A14AA08",
            "display" : "oxandrolone"
          },
          {
            "code" : "A14AA09",
            "display" : "norethandrolone"
          },
          {
            "code" : "A14AB",
            "display" : "Estren derivatives"
          },
          {
            "code" : "A14AB01",
            "display" : "nandrolone"
          },
          {
            "code" : "A14AB02",
            "display" : "ethylestrenol"
          },
          {
            "code" : "A14AB03",
            "display" : "oxabolone cipionate"
          },
          {
            "code" : "A14B",
            "display" : "OTHER ANABOLIC AGENTS"
          },
          {
            "code" : "A15",
            "display" : "APPETITE STIMULANTS"
          },
          {
            "code" : "A16",
            "display" : "OTHER ALIMENTARY TRACT AND METABOLISM PRODUCTS"
          },
          {
            "code" : "A16A",
            "display" : "OTHER ALIMENTARY TRACT AND METABOLISM PRODUCTS"
          },
          {
            "code" : "A16AA",
            "display" : "Amino acids and derivatives"
          },
          {
            "code" : "A16AA01",
            "display" : "levocarnitine"
          },
          {
            "code" : "A16AA02",
            "display" : "ademetionine"
          },
          {
            "code" : "A16AA03",
            "display" : "glutamine"
          },
          {
            "code" : "A16AA04",
            "display" : "mercaptamine"
          },
          {
            "code" : "A16AA05",
            "display" : "carglumic acid"
          },
          {
            "code" : "A16AA06",
            "display" : "betaine"
          },
          {
            "code" : "A16AA07",
            "display" : "metreleptin"
          },
          {
            "code" : "A16AB",
            "display" : "Enzymes"
          },
          {
            "code" : "A16AB01",
            "display" : "alglucerase"
          },
          {
            "code" : "A16AB02",
            "display" : "imiglucerase"
          },
          {
            "code" : "A16AB03",
            "display" : "agalsidase alfa"
          },
          {
            "code" : "A16AB04",
            "display" : "agalsidase beta"
          },
          {
            "code" : "A16AB05",
            "display" : "laronidase"
          },
          {
            "code" : "A16AB06",
            "display" : "sacrosidase"
          },
          {
            "code" : "A16AB07",
            "display" : "alglucosidase alfa"
          },
          {
            "code" : "A16AB08",
            "display" : "galsulfase"
          },
          {
            "code" : "A16AB09",
            "display" : "idursulfase"
          },
          {
            "code" : "A16AB10",
            "display" : "velaglucerase alfa"
          },
          {
            "code" : "A16AB11",
            "display" : "taliglucerase alfa"
          },
          {
            "code" : "A16AB12",
            "display" : "elosulfase alfa"
          },
          {
            "code" : "A16AB13",
            "display" : "asfotase alfa"
          },
          {
            "code" : "A16AB14",
            "display" : "sebelipase alfa"
          },
          {
            "code" : "A16AB15",
            "display" : "velmanase alfa"
          },
          {
            "code" : "A16AB16",
            "display" : "idursulfase beta"
          },
          {
            "code" : "A16AB17",
            "display" : "cerliponase alfa"
          },
          {
            "code" : "A16AB18",
            "display" : "vestronidase alfa"
          },
          {
            "code" : "A16AB19",
            "display" : "pegvaliase"
          },
          {
            "code" : "A16AB20",
            "display" : "pegunigalsidase alfa"
          },
          {
            "code" : "A16AB21",
            "display" : "atidarsagene autotemcel"
          },
          {
            "code" : "A16AB22",
            "display" : "avalglucosidase alfa"
          },
          {
            "code" : "A16AB23",
            "display" : "cipaglucosidase alfa"
          },
          {
            "code" : "A16AB24",
            "display" : "pegzilarginase"
          },
          {
            "code" : "A16AB25",
            "display" : "olipudase alfa"
          },
          {
            "code" : "A16AB26",
            "display" : "eladocagene exuparvovec"
          },
          {
            "code" : "A16AB27",
            "display" : "pabinafusp alfa"
          },
          {
            "code" : "A16AX",
            "display" : "Various alimentary tract and metabolism products"
          },
          {
            "code" : "A16AX01",
            "display" : "thioctic acid"
          },
          {
            "code" : "A16AX02",
            "display" : "anethole trithione"
          },
          {
            "code" : "A16AX03",
            "display" : "sodium phenylbutyrate"
          },
          {
            "code" : "A16AX04",
            "display" : "nitisinone"
          },
          {
            "code" : "A16AX05",
            "display" : "zinc acetate"
          },
          {
            "code" : "A16AX06",
            "display" : "miglustat"
          },
          {
            "code" : "A16AX07",
            "display" : "sapropterin"
          },
          {
            "code" : "A16AX08",
            "display" : "teduglutide"
          },
          {
            "code" : "A16AX09",
            "display" : "glycerol phenylbutyrate"
          },
          {
            "code" : "A16AX10",
            "display" : "eliglustat"
          },
          {
            "code" : "A16AX11",
            "display" : "sodium benzoate"
          },
          {
            "code" : "A16AX12",
            "display" : "trientine"
          },
          {
            "code" : "A16AX13",
            "display" : "uridine triacetate"
          },
          {
            "code" : "A16AX14",
            "display" : "migalastat"
          },
          {
            "code" : "A16AX15",
            "display" : "telotristat"
          },
          {
            "code" : "A16AX16",
            "display" : "givosiran"
          },
          {
            "code" : "A16AX17",
            "display" : "triheptanoin"
          },
          {
            "code" : "A16AX18",
            "display" : "lumasiran"
          },
          {
            "code" : "A16AX19",
            "display" : "fosdenopterin"
          },
          {
            "code" : "A16AX20",
            "display" : "lonafarnib"
          },
          {
            "code" : "A16AX21",
            "display" : "elivaldogene autotemcel"
          },
          {
            "code" : "A16AX22",
            "display" : "tiomolibdic acid"
          },
          {
            "code" : "A16AX23",
            "display" : "leriglitazone"
          },
          {
            "code" : "A16AX24",
            "display" : "govorestat"
          },
          {
            "code" : "A16AX25",
            "display" : "nedosiran"
          },
          {
            "code" : "A16AX30",
            "display" : "sodium benzoate and sodium phenylacetate"
          },
          {
            "code" : "B",
            "display" : "BLOOD AND BLOOD FORMING ORGANS"
          },
          {
            "code" : "B01",
            "display" : "ANTITHROMBOTIC AGENTS"
          },
          {
            "code" : "B01A",
            "display" : "ANTITHROMBOTIC AGENTS"
          },
          {
            "code" : "B01AA",
            "display" : "Vitamin K antagonists"
          },
          {
            "code" : "B01AA01",
            "display" : "dicoumarol"
          },
          {
            "code" : "B01AA02",
            "display" : "phenindione"
          },
          {
            "code" : "B01AA03",
            "display" : "warfarin"
          },
          {
            "code" : "B01AA04",
            "display" : "phenprocoumon"
          },
          {
            "code" : "B01AA07",
            "display" : "acenocoumarol"
          },
          {
            "code" : "B01AA08",
            "display" : "ethyl biscoumacetate"
          },
          {
            "code" : "B01AA09",
            "display" : "clorindione"
          },
          {
            "code" : "B01AA10",
            "display" : "diphenadione"
          },
          {
            "code" : "B01AA11",
            "display" : "tioclomarol"
          },
          {
            "code" : "B01AA12",
            "display" : "fluindione"
          },
          {
            "code" : "B01AB",
            "display" : "Heparin group"
          },
          {
            "code" : "B01AB01",
            "display" : "heparin"
          },
          {
            "code" : "B01AB02",
            "display" : "antithrombin III"
          },
          {
            "code" : "B01AB04",
            "display" : "dalteparin"
          },
          {
            "code" : "B01AB05",
            "display" : "enoxaparin"
          },
          {
            "code" : "B01AB06",
            "display" : "nadroparin"
          },
          {
            "code" : "B01AB07",
            "display" : "parnaparin"
          },
          {
            "code" : "B01AB08",
            "display" : "reviparin"
          },
          {
            "code" : "B01AB09",
            "display" : "danaparoid"
          },
          {
            "code" : "B01AB10",
            "display" : "tinzaparin"
          },
          {
            "code" : "B01AB11",
            "display" : "sulodexide"
          },
          {
            "code" : "B01AB12",
            "display" : "bemiparin"
          },
          {
            "code" : "B01AB51",
            "display" : "heparin, combinations"
          },
          {
            "code" : "B01AC",
            "display" : "Platelet aggregation inhibitors excl. heparin"
          },
          {
            "code" : "B01AC01",
            "display" : "ditazole"
          },
          {
            "code" : "B01AC02",
            "display" : "cloricromen"
          },
          {
            "code" : "B01AC03",
            "display" : "picotamide"
          },
          {
            "code" : "B01AC04",
            "display" : "clopidogrel"
          },
          {
            "code" : "B01AC05",
            "display" : "ticlopidine"
          },
          {
            "code" : "B01AC06",
            "display" : "acetylsalicylic acid"
          },
          {
            "code" : "B01AC07",
            "display" : "dipyridamole"
          },
          {
            "code" : "B01AC08",
            "display" : "carbasalate calcium"
          },
          {
            "code" : "B01AC09",
            "display" : "epoprostenol"
          },
          {
            "code" : "B01AC10",
            "display" : "indobufen"
          },
          {
            "code" : "B01AC11",
            "display" : "iloprost"
          },
          {
            "code" : "B01AC13",
            "display" : "abciximab"
          },
          {
            "code" : "B01AC15",
            "display" : "aloxiprin"
          },
          {
            "code" : "B01AC16",
            "display" : "eptifibatide"
          },
          {
            "code" : "B01AC17",
            "display" : "tirofiban"
          },
          {
            "code" : "B01AC18",
            "display" : "triflusal"
          },
          {
            "code" : "B01AC19",
            "display" : "beraprost"
          },
          {
            "code" : "B01AC21",
            "display" : "treprostinil"
          },
          {
            "code" : "B01AC22",
            "display" : "prasugrel"
          },
          {
            "code" : "B01AC23",
            "display" : "cilostazol"
          },
          {
            "code" : "B01AC24",
            "display" : "ticagrelor"
          },
          {
            "code" : "B01AC25",
            "display" : "cangrelor"
          },
          {
            "code" : "B01AC26",
            "display" : "vorapaxar"
          },
          {
            "code" : "B01AC27",
            "display" : "selexipag"
          },
          {
            "code" : "B01AC28",
            "display" : "limaprost"
          },
          {
            "code" : "B01AC30",
            "display" : "combinations"
          },
          {
            "code" : "B01AC56",
            "display" : "acetylsalicylic acid, combinations with proton pump inhibitors"
          },
          {
            "code" : "B01AD",
            "display" : "Enzymes"
          },
          {
            "code" : "B01AD01",
            "display" : "streptokinase"
          },
          {
            "code" : "B01AD02",
            "display" : "alteplase"
          },
          {
            "code" : "B01AD03",
            "display" : "anistreplase"
          },
          {
            "code" : "B01AD04",
            "display" : "urokinase"
          },
          {
            "code" : "B01AD05",
            "display" : "fibrinolysin"
          },
          {
            "code" : "B01AD06",
            "display" : "brinase"
          },
          {
            "code" : "B01AD07",
            "display" : "reteplase"
          },
          {
            "code" : "B01AD08",
            "display" : "saruplase"
          },
          {
            "code" : "B01AD09",
            "display" : "ancrod"
          },
          {
            "code" : "B01AD10",
            "display" : "drotrecogin alfa (activated)"
          },
          {
            "code" : "B01AD11",
            "display" : "tenecteplase"
          },
          {
            "code" : "B01AD12",
            "display" : "protein C"
          },
          {
            "code" : "B01AD13",
            "display" : "apadamtase alfa and cinaxadamtase alfa"
          },
          {
            "code" : "B01AE",
            "display" : "Direct thrombin inhibitors"
          },
          {
            "code" : "B01AE01",
            "display" : "desirudin"
          },
          {
            "code" : "B01AE02",
            "display" : "lepirudin"
          },
          {
            "code" : "B01AE03",
            "display" : "argatroban"
          },
          {
            "code" : "B01AE04",
            "display" : "melagatran"
          },
          {
            "code" : "B01AE05",
            "display" : "ximelagatran"
          },
          {
            "code" : "B01AE06",
            "display" : "bivalirudin"
          },
          {
            "code" : "B01AE07",
            "display" : "dabigatran etexilate"
          },
          {
            "code" : "B01AF",
            "display" : "Direct factor Xa inhibitors"
          },
          {
            "code" : "B01AF01",
            "display" : "rivaroxaban"
          },
          {
            "code" : "B01AF02",
            "display" : "apixaban"
          },
          {
            "code" : "B01AF03",
            "display" : "edoxaban"
          },
          {
            "code" : "B01AF04",
            "display" : "betrixaban"
          },
          {
            "code" : "B01AF51",
            "display" : "rivaroxaban and acetylsalicylic acid"
          },
          {
            "code" : "B01AX",
            "display" : "Other antithrombotic agents"
          },
          {
            "code" : "B01AX01",
            "display" : "defibrotide"
          },
          {
            "code" : "B01AX04",
            "display" : "dermatan sulfate"
          },
          {
            "code" : "B01AX05",
            "display" : "fondaparinux"
          },
          {
            "code" : "B01AX07",
            "display" : "caplacizumab"
          },
          {
            "code" : "B02",
            "display" : "ANTIHEMORRHAGICS"
          },
          {
            "code" : "B02A",
            "display" : "ANTIFIBRINOLYTICS"
          },
          {
            "code" : "B02AA",
            "display" : "Amino acids"
          },
          {
            "code" : "B02AA01",
            "display" : "aminocaproic acid"
          },
          {
            "code" : "B02AA02",
            "display" : "tranexamic acid"
          },
          {
            "code" : "B02AA03",
            "display" : "aminomethylbenzoic acid"
          },
          {
            "code" : "B02AB",
            "display" : "Proteinase inhibitors"
          },
          {
            "code" : "B02AB01",
            "display" : "aprotinin"
          },
          {
            "code" : "B02AB02",
            "display" : "alfa1 antitrypsin"
          },
          {
            "code" : "B02AB04",
            "display" : "camostat"
          },
          {
            "code" : "B02AB05",
            "display" : "ulinastatin"
          },
          {
            "code" : "B02B",
            "display" : "VITAMIN K AND OTHER HEMOSTATICS"
          },
          {
            "code" : "B02BA",
            "display" : "Vitamin K"
          },
          {
            "code" : "B02BA01",
            "display" : "phytomenadione"
          },
          {
            "code" : "B02BA02",
            "display" : "menadione"
          },
          {
            "code" : "B02BB",
            "display" : "Fibrinogen"
          },
          {
            "code" : "B02BB01",
            "display" : "fibrinogen, human"
          },
          {
            "code" : "B02BC",
            "display" : "Local hemostatics"
          },
          {
            "code" : "B02BC01",
            "display" : "absorbable gelatin sponge"
          },
          {
            "code" : "B02BC02",
            "display" : "oxidized cellulose"
          },
          {
            "code" : "B02BC03",
            "display" : "tetragalacturonic acid hydroxymethylester"
          },
          {
            "code" : "B02BC05",
            "display" : "adrenalone"
          },
          {
            "code" : "B02BC06",
            "display" : "thrombin"
          },
          {
            "code" : "B02BC07",
            "display" : "collagen"
          },
          {
            "code" : "B02BC08",
            "display" : "calcium alginate"
          },
          {
            "code" : "B02BC09",
            "display" : "epinephrine"
          },
          {
            "code" : "B02BC30",
            "display" : "combinations"
          },
          {
            "code" : "B02BD",
            "display" : "Blood coagulation factors"
          },
          {
            "code" : "B02BD01",
            "display" : "coagulation factor IX, II, VII and X in combination"
          },
          {
            "code" : "B02BD02",
            "display" : "coagulation factor VIII"
          },
          {
            "code" : "B02BD03",
            "display" : "factor VIII inhibitor bypassing activity"
          },
          {
            "code" : "B02BD04",
            "display" : "coagulation factor IX"
          },
          {
            "code" : "B02BD05",
            "display" : "coagulation factor VII"
          },
          {
            "code" : "B02BD06",
            "display" : "von Willebrand factor and coagulation factor VIII in combination"
          },
          {
            "code" : "B02BD07",
            "display" : "coagulation factor XIII"
          },
          {
            "code" : "B02BD08",
            "display" : "coagulation factor VIIa"
          },
          {
            "code" : "B02BD10",
            "display" : "von Willebrand factor"
          },
          {
            "code" : "B02BD11",
            "display" : "catridecacog"
          },
          {
            "code" : "B02BD13",
            "display" : "coagulation factor X"
          },
          {
            "code" : "B02BD14",
            "display" : "susoctocog alfa"
          },
          {
            "code" : "B02BD15",
            "display" : "valoctocogene roxaparvovec"
          },
          {
            "code" : "B02BD16",
            "display" : "etranacogene dezaparvovec"
          },
          {
            "code" : "B02BD17",
            "display" : "fidanacogene elaparvovec"
          },
          {
            "code" : "B02BD30",
            "display" : "thrombin"
          },
          {
            "code" : "B02BX",
            "display" : "Other systemic hemostatics"
          },
          {
            "code" : "B02BX01",
            "display" : "etamsylate"
          },
          {
            "code" : "B02BX02",
            "display" : "carbazochrome"
          },
          {
            "code" : "B02BX03",
            "display" : "batroxobin"
          },
          {
            "code" : "B02BX04",
            "display" : "romiplostim"
          },
          {
            "code" : "B02BX05",
            "display" : "eltrombopag"
          },
          {
            "code" : "B02BX06",
            "display" : "emicizumab"
          },
          {
            "code" : "B02BX07",
            "display" : "lusutrombopag"
          },
          {
            "code" : "B02BX08",
            "display" : "avatrombopag"
          },
          {
            "code" : "B02BX09",
            "display" : "fostamatinib"
          },
          {
            "code" : "B02BX10",
            "display" : "concizumab"
          },
          {
            "code" : "B02BX11",
            "display" : "marstacimab"
          },
          {
            "code" : "B03",
            "display" : "ANTIANEMIC PREPARATIONS"
          },
          {
            "code" : "B03A",
            "display" : "IRON PREPARATIONS"
          },
          {
            "code" : "B03AA",
            "display" : "Iron bivalent, oral preparations"
          },
          {
            "code" : "B03AA01",
            "display" : "ferrous glycine sulfate"
          },
          {
            "code" : "B03AA02",
            "display" : "ferrous fumarate"
          },
          {
            "code" : "B03AA03",
            "display" : "ferrous gluconate"
          },
          {
            "code" : "B03AA04",
            "display" : "ferrous carbonate"
          },
          {
            "code" : "B03AA05",
            "display" : "ferrous chloride"
          },
          {
            "code" : "B03AA06",
            "display" : "ferrous succinate"
          },
          {
            "code" : "B03AA07",
            "display" : "ferrous sulfate"
          },
          {
            "code" : "B03AA08",
            "display" : "ferrous tartrate"
          },
          {
            "code" : "B03AA09",
            "display" : "ferrous aspartate"
          },
          {
            "code" : "B03AA10",
            "display" : "ferrous ascorbate"
          },
          {
            "code" : "B03AA11",
            "display" : "ferrous iodine"
          },
          {
            "code" : "B03AA12",
            "display" : "ferrous sodium citrate"
          },
          {
            "code" : "B03AB",
            "display" : "Iron trivalent, oral preparations"
          },
          {
            "code" : "B03AB01",
            "display" : "ferric sodium citrate"
          },
          {
            "code" : "B03AB02",
            "display" : "saccharated iron oxide"
          },
          {
            "code" : "B03AB03",
            "display" : "sodium feredetate"
          },
          {
            "code" : "B03AB04",
            "display" : "ferric hydroxide"
          },
          {
            "code" : "B03AB05",
            "display" : "ferric oxide polymaltose complexes"
          },
          {
            "code" : "B03AB07",
            "display" : "chondroitin sulfate-iron complex"
          },
          {
            "code" : "B03AB08",
            "display" : "ferric acetyl transferrin"
          },
          {
            "code" : "B03AB09",
            "display" : "ferric proteinsuccinylate"
          },
          {
            "code" : "B03AB10",
            "display" : "ferric maltol"
          },
          {
            "code" : "B03AC",
            "display" : "Iron, parenteral preparations"
          },
          {
            "code" : "B03AD",
            "display" : "Iron in combination with folic acid"
          },
          {
            "code" : "B03AD01",
            "display" : "ferrous amino acid complex and folic acid"
          },
          {
            "code" : "B03AD02",
            "display" : "ferrous fumarate and folic acid"
          },
          {
            "code" : "B03AD03",
            "display" : "ferrous sulfate and folic acid"
          },
          {
            "code" : "B03AD04",
            "display" : "ferric oxide polymaltose complexes and folic acid"
          },
          {
            "code" : "B03AD05",
            "display" : "ferrous gluconate and folic acid"
          },
          {
            "code" : "B03AE",
            "display" : "Iron in other combinations"
          },
          {
            "code" : "B03AE01",
            "display" : "iron, vitamin B12 and folic acid"
          },
          {
            "code" : "B03AE02",
            "display" : "iron, multivitamins and folic acid"
          },
          {
            "code" : "B03AE03",
            "display" : "iron and multivitamins"
          },
          {
            "code" : "B03AE04",
            "display" : "iron, multivitamins and minerals"
          },
          {
            "code" : "B03AE10",
            "display" : "various combinations"
          },
          {
            "code" : "B03B",
            "display" : "VITAMIN B12 AND FOLIC ACID"
          },
          {
            "code" : "B03BA",
            "display" : "Vitamin B12 (cyanocobalamin and analogues)"
          },
          {
            "code" : "B03BA01",
            "display" : "cyanocobalamin"
          },
          {
            "code" : "B03BA02",
            "display" : "cyanocobalamin tannin complex"
          },
          {
            "code" : "B03BA03",
            "display" : "hydroxocobalamin"
          },
          {
            "code" : "B03BA04",
            "display" : "cobamamide"
          },
          {
            "code" : "B03BA05",
            "display" : "mecobalamin"
          },
          {
            "code" : "B03BA51",
            "display" : "cyanocobalamin, combinations"
          },
          {
            "code" : "B03BA53",
            "display" : "hydroxocobalamin, combinations"
          },
          {
            "code" : "B03BB",
            "display" : "Folic acid and derivatives"
          },
          {
            "code" : "B03BB01",
            "display" : "folic acid"
          },
          {
            "code" : "B03BB51",
            "display" : "folic acid, combinations"
          },
          {
            "code" : "B03X",
            "display" : "OTHER ANTIANEMIC PREPARATIONS"
          },
          {
            "code" : "B03XA",
            "display" : "Other antianemic preparations"
          },
          {
            "code" : "B03XA01",
            "display" : "erythropoietin"
          },
          {
            "code" : "B03XA02",
            "display" : "darbepoetin alfa"
          },
          {
            "code" : "B03XA03",
            "display" : "methoxy polyethylene glycol-epoetin beta"
          },
          {
            "code" : "B03XA04",
            "display" : "peginesatide"
          },
          {
            "code" : "B03XA05",
            "display" : "roxadustat"
          },
          {
            "code" : "B03XA06",
            "display" : "luspatercept"
          },
          {
            "code" : "B03XA07",
            "display" : "daprodustat"
          },
          {
            "code" : "B03XA08",
            "display" : "vadadustat"
          },
          {
            "code" : "B03XA09",
            "display" : "molidustat"
          },
          {
            "code" : "B03XA10",
            "display" : "efepoetin alfa"
          },
          {
            "code" : "B05",
            "display" : "BLOOD SUBSTITUTES AND PERFUSION SOLUTIONS"
          },
          {
            "code" : "B05A",
            "display" : "BLOOD AND RELATED PRODUCTS"
          },
          {
            "code" : "B05AA",
            "display" : "Blood substitutes and plasma protein fractions"
          },
          {
            "code" : "B05AA01",
            "display" : "albumin"
          },
          {
            "code" : "B05AA02",
            "display" : "other plasma protein fractions"
          },
          {
            "code" : "B05AA03",
            "display" : "fluorocarbon blood substitutes"
          },
          {
            "code" : "B05AA05",
            "display" : "dextran"
          },
          {
            "code" : "B05AA06",
            "display" : "gelatin agents"
          },
          {
            "code" : "B05AA07",
            "display" : "hydroxyethylstarch"
          },
          {
            "code" : "B05AA08",
            "display" : "hemoglobin crosfumaril"
          },
          {
            "code" : "B05AA09",
            "display" : "hemoglobin raffimer"
          },
          {
            "code" : "B05AA10",
            "display" : "hemoglobin glutamer (bovine)"
          },
          {
            "code" : "B05AX",
            "display" : "Other blood products"
          },
          {
            "code" : "B05AX01",
            "display" : "erythrocytes"
          },
          {
            "code" : "B05AX02",
            "display" : "thrombocytes"
          },
          {
            "code" : "B05AX03",
            "display" : "blood plasma"
          },
          {
            "code" : "B05AX04",
            "display" : "stem cells from umbilical cord blood"
          },
          {
            "code" : "B05B",
            "display" : "I.V. SOLUTIONS"
          },
          {
            "code" : "B05BA",
            "display" : "Solutions for parenteral nutrition"
          },
          {
            "code" : "B05BA01",
            "display" : "amino acids"
          },
          {
            "code" : "B05BA02",
            "display" : "fat emulsions"
          },
          {
            "code" : "B05BA03",
            "display" : "carbohydrates"
          },
          {
            "code" : "B05BA04",
            "display" : "protein hydrolysates"
          },
          {
            "code" : "B05BA10",
            "display" : "combinations"
          },
          {
            "code" : "B05BB",
            "display" : "Solutions affecting the electrolyte balance"
          },
          {
            "code" : "B05BB01",
            "display" : "electrolytes"
          },
          {
            "code" : "B05BB02",
            "display" : "electrolytes with carbohydrates"
          },
          {
            "code" : "B05BB03",
            "display" : "trometamol"
          },
          {
            "code" : "B05BB04",
            "display" : "electrolytes in combination with other drugs"
          },
          {
            "code" : "B05BC",
            "display" : "Solutions producing osmotic diuresis"
          },
          {
            "code" : "B05BC01",
            "display" : "mannitol"
          },
          {
            "code" : "B05BC02",
            "display" : "carbamide"
          },
          {
            "code" : "B05C",
            "display" : "IRRIGATING SOLUTIONS"
          },
          {
            "code" : "B05CA",
            "display" : "Antiinfectives"
          },
          {
            "code" : "B05CA01",
            "display" : "cetylpyridinium"
          },
          {
            "code" : "B05CA02",
            "display" : "chlorhexidine"
          },
          {
            "code" : "B05CA03",
            "display" : "nitrofural"
          },
          {
            "code" : "B05CA04",
            "display" : "sulfamethizole"
          },
          {
            "code" : "B05CA05",
            "display" : "taurolidine"
          },
          {
            "code" : "B05CA06",
            "display" : "mandelic acid"
          },
          {
            "code" : "B05CA07",
            "display" : "noxytiolin"
          },
          {
            "code" : "B05CA08",
            "display" : "ethacridine lactate"
          },
          {
            "code" : "B05CA09",
            "display" : "neomycin"
          },
          {
            "code" : "B05CA10",
            "display" : "combinations"
          },
          {
            "code" : "B05CB",
            "display" : "Salt solutions"
          },
          {
            "code" : "B05CB01",
            "display" : "sodium chloride"
          },
          {
            "code" : "B05CB02",
            "display" : "sodium citrate"
          },
          {
            "code" : "B05CB03",
            "display" : "magnesium citrate"
          },
          {
            "code" : "B05CB04",
            "display" : "sodium bicarbonate"
          },
          {
            "code" : "B05CB10",
            "display" : "combinations"
          },
          {
            "code" : "B05CX",
            "display" : "Other irrigating solutions"
          },
          {
            "code" : "B05CX01",
            "display" : "glucose"
          },
          {
            "code" : "B05CX02",
            "display" : "sorbitol"
          },
          {
            "code" : "B05CX03",
            "display" : "glycine"
          },
          {
            "code" : "B05CX04",
            "display" : "mannitol"
          },
          {
            "code" : "B05CX10",
            "display" : "combinations"
          },
          {
            "code" : "B05D",
            "display" : "PERITONEAL DIALYTICS"
          },
          {
            "code" : "B05DA",
            "display" : "Isotonic solutions"
          },
          {
            "code" : "B05DB",
            "display" : "Hypertonic solutions"
          },
          {
            "code" : "B05X",
            "display" : "I.V. SOLUTION ADDITIVES"
          },
          {
            "code" : "B05XA",
            "display" : "Electrolyte solutions"
          },
          {
            "code" : "B05XA01",
            "display" : "potassium chloride"
          },
          {
            "code" : "B05XA02",
            "display" : "sodium bicarbonate"
          },
          {
            "code" : "B05XA03",
            "display" : "sodium chloride"
          },
          {
            "code" : "B05XA04",
            "display" : "ammonium chloride"
          },
          {
            "code" : "B05XA05",
            "display" : "magnesium sulfate"
          },
          {
            "code" : "B05XA06",
            "display" : "potassium phosphate, incl. combinations with other potassium salts"
          },
          {
            "code" : "B05XA07",
            "display" : "calcium chloride"
          },
          {
            "code" : "B05XA08",
            "display" : "sodium acetate"
          },
          {
            "code" : "B05XA09",
            "display" : "sodium phosphate"
          },
          {
            "code" : "B05XA10",
            "display" : "magnesium phosphate"
          },
          {
            "code" : "B05XA11",
            "display" : "magnesium chloride"
          },
          {
            "code" : "B05XA12",
            "display" : "zinc chloride"
          },
          {
            "code" : "B05XA13",
            "display" : "hydrochloric acid"
          },
          {
            "code" : "B05XA14",
            "display" : "sodium glycerophosphate"
          },
          {
            "code" : "B05XA15",
            "display" : "potassium lactate"
          },
          {
            "code" : "B05XA16",
            "display" : "cardioplegia solutions"
          },
          {
            "code" : "B05XA17",
            "display" : "potassium acetate"
          },
          {
            "code" : "B05XA18",
            "display" : "zinc sulfate"
          },
          {
            "code" : "B05XA19",
            "display" : "calcium gluconate"
          },
          {
            "code" : "B05XA20",
            "display" : "sodium selenite"
          },
          {
            "code" : "B05XA30",
            "display" : "combinations of electrolytes"
          },
          {
            "code" : "B05XA31",
            "display" : "electrolytes in combination with other drugs"
          },
          {
            "code" : "B05XB",
            "display" : "Amino acids"
          },
          {
            "code" : "B05XB01",
            "display" : "arginine hydrochloride"
          },
          {
            "code" : "B05XB02",
            "display" : "alanyl glutamine"
          },
          {
            "code" : "B05XB03",
            "display" : "lysine"
          },
          {
            "code" : "B05XC",
            "display" : "Vitamins"
          },
          {
            "code" : "B05XX",
            "display" : "Other i.v. solution additives"
          },
          {
            "code" : "B05XX02",
            "display" : "trometamol"
          },
          {
            "code" : "B05Z",
            "display" : "HEMODIALYTICS AND HEMOFILTRATES"
          },
          {
            "code" : "B05ZA",
            "display" : "Hemodialytics, concentrates"
          },
          {
            "code" : "B05ZB",
            "display" : "Hemofiltrates"
          },
          {
            "code" : "B06",
            "display" : "OTHER HEMATOLOGICAL AGENTS"
          },
          {
            "code" : "B06A",
            "display" : "OTHER HEMATOLOGICAL AGENTS"
          },
          {
            "code" : "B06AA",
            "display" : "Enzymes"
          },
          {
            "code" : "B06AA02",
            "display" : "fibrinolysin and desoxyribonuclease"
          },
          {
            "code" : "B06AA03",
            "display" : "hyaluronidase"
          },
          {
            "code" : "B06AA04",
            "display" : "chymotrypsin"
          },
          {
            "code" : "B06AA07",
            "display" : "trypsin"
          },
          {
            "code" : "B06AA10",
            "display" : "desoxyribonuclease"
          },
          {
            "code" : "B06AA55",
            "display" : "streptokinase, combinations"
          },
          {
            "code" : "B06AB",
            "display" : "Heme products"
          },
          {
            "code" : "B06AB01",
            "display" : "hemin"
          },
          {
            "code" : "B06AC",
            "display" : "Drugs used in hereditary angioedema"
          },
          {
            "code" : "B06AC01",
            "display" : "c1-inhibitor, plasma derived"
          },
          {
            "code" : "B06AC02",
            "display" : "icatibant"
          },
          {
            "code" : "B06AC03",
            "display" : "ecallantide"
          },
          {
            "code" : "B06AC04",
            "display" : "conestat alfa"
          },
          {
            "code" : "B06AC05",
            "display" : "lanadelumab"
          },
          {
            "code" : "B06AC06",
            "display" : "berotralstat"
          },
          {
            "code" : "B06AC07",
            "display" : "garadacimab"
          },
          {
            "code" : "B06AC08",
            "display" : "sebetralstat"
          },
          {
            "code" : "B06AX",
            "display" : "Other hematological agents"
          },
          {
            "code" : "B06AX01",
            "display" : "crizanlizumab"
          },
          {
            "code" : "B06AX02",
            "display" : "betibeglogene autotemcel"
          },
          {
            "code" : "B06AX03",
            "display" : "voxelotor"
          },
          {
            "code" : "B06AX04",
            "display" : "mitapivat"
          },
          {
            "code" : "B06AX05",
            "display" : "exagamglogene autotemcel"
          },
          {
            "code" : "C",
            "display" : "CARDIOVASCULAR SYSTEM"
          },
          {
            "code" : "C01",
            "display" : "CARDIAC THERAPY"
          },
          {
            "code" : "C01A",
            "display" : "CARDIAC GLYCOSIDES"
          },
          {
            "code" : "C01AA",
            "display" : "Digitalis glycosides"
          },
          {
            "code" : "C01AA01",
            "display" : "acetyldigitoxin"
          },
          {
            "code" : "C01AA02",
            "display" : "acetyldigoxin"
          },
          {
            "code" : "C01AA03",
            "display" : "digitalis leaves"
          },
          {
            "code" : "C01AA04",
            "display" : "digitoxin"
          },
          {
            "code" : "C01AA05",
            "display" : "digoxin"
          },
          {
            "code" : "C01AA06",
            "display" : "lanatoside C"
          },
          {
            "code" : "C01AA07",
            "display" : "deslanoside"
          },
          {
            "code" : "C01AA08",
            "display" : "metildigoxin"
          },
          {
            "code" : "C01AA09",
            "display" : "gitoformate"
          },
          {
            "code" : "C01AA52",
            "display" : "acetyldigoxin, combinations"
          },
          {
            "code" : "C01AB",
            "display" : "Scilla glycosides"
          },
          {
            "code" : "C01AB01",
            "display" : "proscillaridin"
          },
          {
            "code" : "C01AB51",
            "display" : "proscillaridin, combinations"
          },
          {
            "code" : "C01AC",
            "display" : "Strophanthus glycosides"
          },
          {
            "code" : "C01AC01",
            "display" : "g-strophanthin"
          },
          {
            "code" : "C01AC03",
            "display" : "cymarin"
          },
          {
            "code" : "C01AX",
            "display" : "Other cardiac glycosides"
          },
          {
            "code" : "C01AX02",
            "display" : "peruvoside"
          },
          {
            "code" : "C01B",
            "display" : "ANTIARRHYTHMICS, CLASS I AND III"
          },
          {
            "code" : "C01BA",
            "display" : "Antiarrhythmics, class Ia"
          },
          {
            "code" : "C01BA01",
            "display" : "quinidine"
          },
          {
            "code" : "C01BA02",
            "display" : "procainamide"
          },
          {
            "code" : "C01BA03",
            "display" : "disopyramide"
          },
          {
            "code" : "C01BA04",
            "display" : "sparteine"
          },
          {
            "code" : "C01BA05",
            "display" : "ajmaline"
          },
          {
            "code" : "C01BA08",
            "display" : "prajmaline"
          },
          {
            "code" : "C01BA12",
            "display" : "lorajmine"
          },
          {
            "code" : "C01BA13",
            "display" : "hydroquinidine"
          },
          {
            "code" : "C01BA51",
            "display" : "quinidine, combinations excl. psycholeptics"
          },
          {
            "code" : "C01BA71",
            "display" : "quinidine, combinations with psycholeptics"
          },
          {
            "code" : "C01BB",
            "display" : "Antiarrhythmics, class Ib"
          },
          {
            "code" : "C01BB01",
            "display" : "lidocaine"
          },
          {
            "code" : "C01BB02",
            "display" : "mexiletine"
          },
          {
            "code" : "C01BB03",
            "display" : "tocainide"
          },
          {
            "code" : "C01BB04",
            "display" : "aprindine"
          },
          {
            "code" : "C01BC",
            "display" : "Antiarrhythmics, class Ic"
          },
          {
            "code" : "C01BC03",
            "display" : "propafenone"
          },
          {
            "code" : "C01BC04",
            "display" : "flecainide"
          },
          {
            "code" : "C01BC07",
            "display" : "lorcainide"
          },
          {
            "code" : "C01BC08",
            "display" : "encainide"
          },
          {
            "code" : "C01BC09",
            "display" : "ethacizine"
          },
          {
            "code" : "C01BD",
            "display" : "Antiarrhythmics, class III"
          },
          {
            "code" : "C01BD01",
            "display" : "amiodarone"
          },
          {
            "code" : "C01BD02",
            "display" : "bretylium tosilate"
          },
          {
            "code" : "C01BD03",
            "display" : "bunaftine"
          },
          {
            "code" : "C01BD04",
            "display" : "dofetilide"
          },
          {
            "code" : "C01BD05",
            "display" : "ibutilide"
          },
          {
            "code" : "C01BD06",
            "display" : "tedisamil"
          },
          {
            "code" : "C01BD07",
            "display" : "dronedarone"
          },
          {
            "code" : "C01BG",
            "display" : "Other antiarrhythmics, class I and III"
          },
          {
            "code" : "C01BG01",
            "display" : "moracizine"
          },
          {
            "code" : "C01BG07",
            "display" : "cibenzoline"
          },
          {
            "code" : "C01BG11",
            "display" : "vernakalant"
          },
          {
            "code" : "C01C",
            "display" : "CARDIAC STIMULANTS EXCL. CARDIAC GLYCOSIDES"
          },
          {
            "code" : "C01CA",
            "display" : "Adrenergic and dopaminergic agents"
          },
          {
            "code" : "C01CA01",
            "display" : "etilefrine"
          },
          {
            "code" : "C01CA02",
            "display" : "isoprenaline"
          },
          {
            "code" : "C01CA03",
            "display" : "norepinephrine"
          },
          {
            "code" : "C01CA04",
            "display" : "dopamine"
          },
          {
            "code" : "C01CA05",
            "display" : "norfenefrine"
          },
          {
            "code" : "C01CA06",
            "display" : "phenylephrine"
          },
          {
            "code" : "C01CA07",
            "display" : "dobutamine"
          },
          {
            "code" : "C01CA08",
            "display" : "oxedrine"
          },
          {
            "code" : "C01CA09",
            "display" : "metaraminol"
          },
          {
            "code" : "C01CA10",
            "display" : "methoxamine"
          },
          {
            "code" : "C01CA11",
            "display" : "mephentermine"
          },
          {
            "code" : "C01CA12",
            "display" : "dimetofrine"
          },
          {
            "code" : "C01CA13",
            "display" : "prenalterol"
          },
          {
            "code" : "C01CA14",
            "display" : "dopexamine"
          },
          {
            "code" : "C01CA15",
            "display" : "gepefrine"
          },
          {
            "code" : "C01CA16",
            "display" : "ibopamine"
          },
          {
            "code" : "C01CA17",
            "display" : "midodrine"
          },
          {
            "code" : "C01CA18",
            "display" : "octopamine"
          },
          {
            "code" : "C01CA19",
            "display" : "fenoldopam"
          },
          {
            "code" : "C01CA21",
            "display" : "cafedrine"
          },
          {
            "code" : "C01CA22",
            "display" : "arbutamine"
          },
          {
            "code" : "C01CA23",
            "display" : "theodrenaline"
          },
          {
            "code" : "C01CA24",
            "display" : "epinephrine"
          },
          {
            "code" : "C01CA25",
            "display" : "amezinium metilsulfate"
          },
          {
            "code" : "C01CA26",
            "display" : "ephedrine"
          },
          {
            "code" : "C01CA27",
            "display" : "droxidopa"
          },
          {
            "code" : "C01CA28",
            "display" : "centhaquine"
          },
          {
            "code" : "C01CA30",
            "display" : "combinations"
          },
          {
            "code" : "C01CA51",
            "display" : "etilefrine, combinations"
          },
          {
            "code" : "C01CE",
            "display" : "Phosphodiesterase inhibitors"
          },
          {
            "code" : "C01CE01",
            "display" : "amrinone"
          },
          {
            "code" : "C01CE02",
            "display" : "milrinone"
          },
          {
            "code" : "C01CE03",
            "display" : "enoximone"
          },
          {
            "code" : "C01CE04",
            "display" : "bucladesine"
          },
          {
            "code" : "C01CX",
            "display" : "Other cardiac stimulants"
          },
          {
            "code" : "C01CX06",
            "display" : "angiotensinamide"
          },
          {
            "code" : "C01CX07",
            "display" : "xamoterol"
          },
          {
            "code" : "C01CX08",
            "display" : "levosimendan"
          },
          {
            "code" : "C01CX09",
            "display" : "angiotensin II"
          },
          {
            "code" : "C01CX10",
            "display" : "omecamtiv mecarbil"
          },
          {
            "code" : "C01D",
            "display" : "VASODILATORS USED IN CARDIAC DISEASES"
          },
          {
            "code" : "C01DA",
            "display" : "Organic nitrates"
          },
          {
            "code" : "C01DA02",
            "display" : "glyceryl trinitrate"
          },
          {
            "code" : "C01DA04",
            "display" : "methylpropylpropanediol dinitrate"
          },
          {
            "code" : "C01DA05",
            "display" : "pentaerithrityl tetranitrate"
          },
          {
            "code" : "C01DA07",
            "display" : "propatylnitrate"
          },
          {
            "code" : "C01DA08",
            "display" : "isosorbide dinitrate"
          },
          {
            "code" : "C01DA09",
            "display" : "trolnitrate"
          },
          {
            "code" : "C01DA13",
            "display" : "eritrityl tetranitrate"
          },
          {
            "code" : "C01DA14",
            "display" : "isosorbide mononitrate"
          },
          {
            "code" : "C01DA20",
            "display" : "organic nitrates in combination"
          },
          {
            "code" : "C01DA38",
            "display" : "tenitramine"
          },
          {
            "code" : "C01DA52",
            "display" : "glyceryl trinitrate, combinations"
          },
          {
            "code" : "C01DA54",
            "display" : "methylpropylpropanediol dinitrate, combinations"
          },
          {
            "code" : "C01DA55",
            "display" : "pentaerithrityl tetranitrate, combinations"
          },
          {
            "code" : "C01DA57",
            "display" : "propatylnitrate, combinations"
          },
          {
            "code" : "C01DA58",
            "display" : "isosorbide dinitrate, combinations"
          },
          {
            "code" : "C01DA59",
            "display" : "trolnitrate, combinations"
          },
          {
            "code" : "C01DA63",
            "display" : "eritrityl tetranitrate, combinations"
          },
          {
            "code" : "C01DA70",
            "display" : "organic nitrates in combination with psycholeptics"
          },
          {
            "code" : "C01DB",
            "display" : "Quinolone vasodilators"
          },
          {
            "code" : "C01DB01",
            "display" : "flosequinan"
          },
          {
            "code" : "C01DX",
            "display" : "Other vasodilators used in cardiac diseases"
          },
          {
            "code" : "C01DX01",
            "display" : "itramin tosilate"
          },
          {
            "code" : "C01DX02",
            "display" : "prenylamine"
          },
          {
            "code" : "C01DX03",
            "display" : "oxyfedrine"
          },
          {
            "code" : "C01DX04",
            "display" : "benziodarone"
          },
          {
            "code" : "C01DX05",
            "display" : "carbocromen"
          },
          {
            "code" : "C01DX06",
            "display" : "hexobendine"
          },
          {
            "code" : "C01DX07",
            "display" : "etafenone"
          },
          {
            "code" : "C01DX08",
            "display" : "heptaminol"
          },
          {
            "code" : "C01DX09",
            "display" : "imolamine"
          },
          {
            "code" : "C01DX10",
            "display" : "dilazep"
          },
          {
            "code" : "C01DX11",
            "display" : "trapidil"
          },
          {
            "code" : "C01DX12",
            "display" : "molsidomine"
          },
          {
            "code" : "C01DX13",
            "display" : "efloxate"
          },
          {
            "code" : "C01DX14",
            "display" : "cinepazet"
          },
          {
            "code" : "C01DX15",
            "display" : "cloridarol"
          },
          {
            "code" : "C01DX16",
            "display" : "nicorandil"
          },
          {
            "code" : "C01DX18",
            "display" : "linsidomine"
          },
          {
            "code" : "C01DX19",
            "display" : "nesiritide"
          },
          {
            "code" : "C01DX21",
            "display" : "serelaxin"
          },
          {
            "code" : "C01DX22",
            "display" : "vericiguat"
          },
          {
            "code" : "C01DX51",
            "display" : "itramin tosilate, combinations"
          },
          {
            "code" : "C01DX52",
            "display" : "prenylamine, combinations"
          },
          {
            "code" : "C01DX53",
            "display" : "oxyfedrine, combinations"
          },
          {
            "code" : "C01DX54",
            "display" : "benziodarone, combinations"
          },
          {
            "code" : "C01E",
            "display" : "OTHER CARDIAC PREPARATIONS"
          },
          {
            "code" : "C01EA",
            "display" : "Prostaglandins"
          },
          {
            "code" : "C01EA01",
            "display" : "alprostadil"
          },
          {
            "code" : "C01EB",
            "display" : "Other cardiac preparations"
          },
          {
            "code" : "C01EB02",
            "display" : "camphora"
          },
          {
            "code" : "C01EB03",
            "display" : "indometacin"
          },
          {
            "code" : "C01EB04",
            "display" : "crataegus glycosides"
          },
          {
            "code" : "C01EB05",
            "display" : "creatinolfosfate"
          },
          {
            "code" : "C01EB06",
            "display" : "fosfocreatine"
          },
          {
            "code" : "C01EB07",
            "display" : "fructose 1,6-diphosphate"
          },
          {
            "code" : "C01EB09",
            "display" : "ubidecarenone"
          },
          {
            "code" : "C01EB10",
            "display" : "adenosine"
          },
          {
            "code" : "C01EB11",
            "display" : "tiracizine"
          },
          {
            "code" : "C01EB13",
            "display" : "acadesine"
          },
          {
            "code" : "C01EB15",
            "display" : "trimetazidine"
          },
          {
            "code" : "C01EB16",
            "display" : "ibuprofen"
          },
          {
            "code" : "C01EB17",
            "display" : "ivabradine"
          },
          {
            "code" : "C01EB18",
            "display" : "ranolazine"
          },
          {
            "code" : "C01EB21",
            "display" : "regadenoson"
          },
          {
            "code" : "C01EB22",
            "display" : "meldonium"
          },
          {
            "code" : "C01EB23",
            "display" : "tiazotic acid"
          },
          {
            "code" : "C01EB24",
            "display" : "mavacamten"
          },
          {
            "code" : "C01EB25",
            "display" : "acoramidis"
          },
          {
            "code" : "C01EX",
            "display" : "Other cardiac combination products"
          },
          {
            "code" : "C02",
            "display" : "ANTIHYPERTENSIVES"
          },
          {
            "code" : "C02A",
            "display" : "ANTIADRENERGIC AGENTS, CENTRALLY ACTING"
          },
          {
            "code" : "C02AA",
            "display" : "Rauwolfia alkaloids"
          },
          {
            "code" : "C02AA01",
            "display" : "rescinnamine"
          },
          {
            "code" : "C02AA02",
            "display" : "reserpine"
          },
          {
            "code" : "C02AA03",
            "display" : "combinations of rauwolfia alkaloids"
          },
          {
            "code" : "C02AA04",
            "display" : "rauwolfia alkaloids, whole root"
          },
          {
            "code" : "C02AA05",
            "display" : "deserpidine"
          },
          {
            "code" : "C02AA06",
            "display" : "methoserpidine"
          },
          {
            "code" : "C02AA07",
            "display" : "bietaserpine"
          },
          {
            "code" : "C02AA52",
            "display" : "reserpine, combinations"
          },
          {
            "code" : "C02AA53",
            "display" : "combinations of rauwolfia alkoloids, combinations"
          },
          {
            "code" : "C02AA57",
            "display" : "bietaserpine, combinations"
          },
          {
            "code" : "C02AB",
            "display" : "Methyldopa"
          },
          {
            "code" : "C02AB01",
            "display" : "methyldopa (levorotatory)"
          },
          {
            "code" : "C02AB02",
            "display" : "methyldopa (racemic)"
          },
          {
            "code" : "C02AC",
            "display" : "Imidazoline receptor agonists"
          },
          {
            "code" : "C02AC01",
            "display" : "clonidine"
          },
          {
            "code" : "C02AC02",
            "display" : "guanfacine"
          },
          {
            "code" : "C02AC04",
            "display" : "tolonidine"
          },
          {
            "code" : "C02AC05",
            "display" : "moxonidine"
          },
          {
            "code" : "C02AC06",
            "display" : "rilmenidine"
          },
          {
            "code" : "C02B",
            "display" : "ANTIADRENERGIC AGENTS, GANGLION-BLOCKING"
          },
          {
            "code" : "C02BA",
            "display" : "Sulfonium derivatives"
          },
          {
            "code" : "C02BA01",
            "display" : "trimetaphan"
          },
          {
            "code" : "C02BB",
            "display" : "Secondary and tertiary amines"
          },
          {
            "code" : "C02BB01",
            "display" : "mecamylamine"
          },
          {
            "code" : "C02BC",
            "display" : "Bisquaternary ammonium compounds"
          },
          {
            "code" : "C02C",
            "display" : "ANTIADRENERGIC AGENTS, PERIPHERALLY ACTING"
          },
          {
            "code" : "C02CA",
            "display" : "Alpha-adrenoreceptor antagonists"
          },
          {
            "code" : "C02CA01",
            "display" : "prazosin"
          },
          {
            "code" : "C02CA02",
            "display" : "indoramin"
          },
          {
            "code" : "C02CA03",
            "display" : "trimazosin"
          },
          {
            "code" : "C02CA04",
            "display" : "doxazosin"
          },
          {
            "code" : "C02CA06",
            "display" : "urapidil"
          },
          {
            "code" : "C02CC",
            "display" : "Guanidine derivatives"
          },
          {
            "code" : "C02CC01",
            "display" : "betanidine"
          },
          {
            "code" : "C02CC02",
            "display" : "guanethidine"
          },
          {
            "code" : "C02CC03",
            "display" : "guanoxan"
          },
          {
            "code" : "C02CC04",
            "display" : "debrisoquine"
          },
          {
            "code" : "C02CC05",
            "display" : "guanoclor"
          },
          {
            "code" : "C02CC06",
            "display" : "guanazodine"
          },
          {
            "code" : "C02CC07",
            "display" : "guanoxabenz"
          },
          {
            "code" : "C02D",
            "display" : "ARTERIOLAR SMOOTH MUSCLE, AGENTS ACTING ON"
          },
          {
            "code" : "C02DA",
            "display" : "Thiazide derivatives"
          },
          {
            "code" : "C02DA01",
            "display" : "diazoxide"
          },
          {
            "code" : "C02DB",
            "display" : "Hydrazinophthalazine derivatives"
          },
          {
            "code" : "C02DB01",
            "display" : "dihydralazine"
          },
          {
            "code" : "C02DB02",
            "display" : "hydralazine"
          },
          {
            "code" : "C02DB03",
            "display" : "endralazine"
          },
          {
            "code" : "C02DB04",
            "display" : "cadralazine"
          },
          {
            "code" : "C02DC",
            "display" : "Pyrimidine derivatives"
          },
          {
            "code" : "C02DC01",
            "display" : "minoxidil"
          },
          {
            "code" : "C02DD",
            "display" : "Nitroferricyanide derivatives"
          },
          {
            "code" : "C02DD01",
            "display" : "nitroprusside"
          },
          {
            "code" : "C02DG",
            "display" : "Guanidine derivatives"
          },
          {
            "code" : "C02DG01",
            "display" : "pinacidil"
          },
          {
            "code" : "C02K",
            "display" : "OTHER ANTIHYPERTENSIVES"
          },
          {
            "code" : "C02KA",
            "display" : "Alkaloids, excl. rauwolfia"
          },
          {
            "code" : "C02KA01",
            "display" : "veratrum"
          },
          {
            "code" : "C02KB",
            "display" : "Tyrosine hydroxylase inhibitors"
          },
          {
            "code" : "C02KB01",
            "display" : "metirosine"
          },
          {
            "code" : "C02KC",
            "display" : "MAO inhibitors"
          },
          {
            "code" : "C02KC01",
            "display" : "pargyline"
          },
          {
            "code" : "C02KD",
            "display" : "Serotonin antagonists"
          },
          {
            "code" : "C02KD01",
            "display" : "ketanserin"
          },
          {
            "code" : "C02KN",
            "display" : "Other antihypertensives"
          },
          {
            "code" : "C02KN01",
            "display" : "aprocitentan"
          },
          {
            "code" : "C02KX",
            "display" : "Antihypertensives for pulmonary arterial hypertension"
          },
          {
            "code" : "C02KX01",
            "display" : "bosentan"
          },
          {
            "code" : "C02KX02",
            "display" : "ambrisentan"
          },
          {
            "code" : "C02KX03",
            "display" : "sitaxentan"
          },
          {
            "code" : "C02KX04",
            "display" : "macitentan"
          },
          {
            "code" : "C02KX05",
            "display" : "riociguat"
          },
          {
            "code" : "C02KX06",
            "display" : "sotatercept"
          },
          {
            "code" : "C02KX52",
            "display" : "ambrisentan and tadalafil"
          },
          {
            "code" : "C02KX54",
            "display" : "macitentan and tadalafil"
          },
          {
            "code" : "C02L",
            "display" : "ANTIHYPERTENSIVES AND DIURETICS IN COMBINATION"
          },
          {
            "code" : "C02LA",
            "display" : "Rauwolfia alkaloids and diuretics in combination"
          },
          {
            "code" : "C02LA01",
            "display" : "reserpine and diuretics"
          },
          {
            "code" : "C02LA02",
            "display" : "rescinnamine and diuretics"
          },
          {
            "code" : "C02LA03",
            "display" : "deserpidine and diuretics"
          },
          {
            "code" : "C02LA04",
            "display" : "methoserpidine and diuretics"
          },
          {
            "code" : "C02LA07",
            "display" : "bietaserpine and diuretics"
          },
          {
            "code" : "C02LA08",
            "display" : "rauwolfia alkaloids, whole root and diuretics"
          },
          {
            "code" : "C02LA09",
            "display" : "syrosingopine and diuretics"
          },
          {
            "code" : "C02LA50",
            "display" : "combination of rauwolfia alkaloids and diuretics incl. other combinations"
          },
          {
            "code" : "C02LA51",
            "display" : "reserpine and diuretics, combinations with other drugs"
          },
          {
            "code" : "C02LA52",
            "display" : "rescinnamine and diuretics, combinations with other drugs"
          },
          {
            "code" : "C02LA71",
            "display" : "reserpine and diuretics, combinations with psycholeptics"
          },
          {
            "code" : "C02LB",
            "display" : "Methyldopa and diuretics in combination"
          },
          {
            "code" : "C02LB01",
            "display" : "methyldopa (levorotatory) and diuretics"
          },
          {
            "code" : "C02LC",
            "display" : "Imidazoline receptor agonists in combination with diuretics"
          },
          {
            "code" : "C02LC01",
            "display" : "clonidine and diuretics"
          },
          {
            "code" : "C02LC05",
            "display" : "moxonidine and diuretics"
          },
          {
            "code" : "C02LC51",
            "display" : "clonidine and diuretics, combinations with other drugs"
          },
          {
            "code" : "C02LE",
            "display" : "Alpha-adrenoreceptor antagonists and diuretics"
          },
          {
            "code" : "C02LE01",
            "display" : "prazosin and diuretics"
          },
          {
            "code" : "C02LF",
            "display" : "Guanidine derivatives and diuretics"
          },
          {
            "code" : "C02LF01",
            "display" : "guanethidine and diuretics"
          },
          {
            "code" : "C02LG",
            "display" : "Hydrazinophthalazine derivatives and diuretics"
          },
          {
            "code" : "C02LG01",
            "display" : "dihydralazine and diuretics"
          },
          {
            "code" : "C02LG02",
            "display" : "hydralazine and diuretics"
          },
          {
            "code" : "C02LG03",
            "display" : "picodralazine and diuretics"
          },
          {
            "code" : "C02LG51",
            "display" : "dihydralazine and diuretics, combinations with other drugs"
          },
          {
            "code" : "C02LG73",
            "display" : "picodralazine and diuretics, combinations with psycholeptics"
          },
          {
            "code" : "C02LK",
            "display" : "Alkaloids, excl. rauwolfia, in combination with diuretics"
          },
          {
            "code" : "C02LK01",
            "display" : "veratrum and diuretics"
          },
          {
            "code" : "C02LL",
            "display" : "MAO inhibitors and diuretics"
          },
          {
            "code" : "C02LL01",
            "display" : "pargyline and diuretics"
          },
          {
            "code" : "C02LN",
            "display" : "Serotonin antagonists and diuretics"
          },
          {
            "code" : "C02LX",
            "display" : "Other antihypertensives and diuretics"
          },
          {
            "code" : "C02LX01",
            "display" : "pinacidil and diuretics"
          },
          {
            "code" : "C02N",
            "display" : "COMBINATIONS OF ANTIHYPERTENSIVES IN ATC-GR. C02"
          },
          {
            "code" : "C03",
            "display" : "DIURETICS"
          },
          {
            "code" : "C03A",
            "display" : "LOW-CEILING DIURETICS, THIAZIDES"
          },
          {
            "code" : "C03AA",
            "display" : "Thiazides, plain"
          },
          {
            "code" : "C03AA01",
            "display" : "bendroflumethiazide"
          },
          {
            "code" : "C03AA02",
            "display" : "hydroflumethiazide"
          },
          {
            "code" : "C03AA03",
            "display" : "hydrochlorothiazide"
          },
          {
            "code" : "C03AA04",
            "display" : "chlorothiazide"
          },
          {
            "code" : "C03AA05",
            "display" : "polythiazide"
          },
          {
            "code" : "C03AA06",
            "display" : "trichlormethiazide"
          },
          {
            "code" : "C03AA07",
            "display" : "cyclopenthiazide"
          },
          {
            "code" : "C03AA08",
            "display" : "methyclothiazide"
          },
          {
            "code" : "C03AA09",
            "display" : "cyclothiazide"
          },
          {
            "code" : "C03AA13",
            "display" : "mebutizide"
          },
          {
            "code" : "C03AB",
            "display" : "Thiazides and potassium in combination"
          },
          {
            "code" : "C03AB01",
            "display" : "bendroflumethiazide and potassium"
          },
          {
            "code" : "C03AB02",
            "display" : "hydroflumethiazide and potassium"
          },
          {
            "code" : "C03AB03",
            "display" : "hydrochlorothiazide and potassium"
          },
          {
            "code" : "C03AB04",
            "display" : "chlorothiazide and potassium"
          },
          {
            "code" : "C03AB05",
            "display" : "polythiazide and potassium"
          },
          {
            "code" : "C03AB06",
            "display" : "trichlormethiazide and potassium"
          },
          {
            "code" : "C03AB07",
            "display" : "cyclopenthiazide and potassium"
          },
          {
            "code" : "C03AB08",
            "display" : "methyclothiazide and potassium"
          },
          {
            "code" : "C03AB09",
            "display" : "cyclothiazide and potassium"
          },
          {
            "code" : "C03AH",
            "display" : "Thiazides, combinations with psycholeptics and/or analgesics"
          },
          {
            "code" : "C03AH01",
            "display" : "chlorothiazide, combinations"
          },
          {
            "code" : "C03AH02",
            "display" : "hydroflumethiazide, combinations"
          },
          {
            "code" : "C03AX",
            "display" : "Thiazides, combinations with other drugs"
          },
          {
            "code" : "C03AX01",
            "display" : "hydrochlorothiazide, combinations"
          },
          {
            "code" : "C03B",
            "display" : "LOW-CEILING DIURETICS, EXCL. THIAZIDES"
          },
          {
            "code" : "C03BA",
            "display" : "Sulfonamides, plain"
          },
          {
            "code" : "C03BA02",
            "display" : "quinethazone"
          },
          {
            "code" : "C03BA03",
            "display" : "clopamide"
          },
          {
            "code" : "C03BA04",
            "display" : "chlortalidone"
          },
          {
            "code" : "C03BA05",
            "display" : "mefruside"
          },
          {
            "code" : "C03BA07",
            "display" : "clofenamide"
          },
          {
            "code" : "C03BA08",
            "display" : "metolazone"
          },
          {
            "code" : "C03BA09",
            "display" : "meticrane"
          },
          {
            "code" : "C03BA10",
            "display" : "xipamide"
          },
          {
            "code" : "C03BA11",
            "display" : "indapamide"
          },
          {
            "code" : "C03BA12",
            "display" : "clorexolone"
          },
          {
            "code" : "C03BA13",
            "display" : "fenquizone"
          },
          {
            "code" : "C03BA82",
            "display" : "clorexolone, combinations with psycholeptics"
          },
          {
            "code" : "C03BB",
            "display" : "Sulfonamides and potassium in combination"
          },
          {
            "code" : "C03BB02",
            "display" : "quinethazone and potassium"
          },
          {
            "code" : "C03BB03",
            "display" : "clopamide and potassium"
          },
          {
            "code" : "C03BB04",
            "display" : "chlortalidone and potassium"
          },
          {
            "code" : "C03BB05",
            "display" : "mefruside and potassium"
          },
          {
            "code" : "C03BB07",
            "display" : "clofenamide and potassium"
          },
          {
            "code" : "C03BC",
            "display" : "Mercurial diuretics"
          },
          {
            "code" : "C03BC01",
            "display" : "mersalyl"
          },
          {
            "code" : "C03BD",
            "display" : "Xanthine derivatives"
          },
          {
            "code" : "C03BD01",
            "display" : "theobromine"
          },
          {
            "code" : "C03BK",
            "display" : "Sulfonamides, combinations with other drugs"
          },
          {
            "code" : "C03BX",
            "display" : "Other low-ceiling diuretics"
          },
          {
            "code" : "C03BX03",
            "display" : "cicletanine"
          },
          {
            "code" : "C03C",
            "display" : "HIGH-CEILING DIURETICS"
          },
          {
            "code" : "C03CA",
            "display" : "Sulfonamides, plain"
          },
          {
            "code" : "C03CA01",
            "display" : "furosemide"
          },
          {
            "code" : "C03CA02",
            "display" : "bumetanide"
          },
          {
            "code" : "C03CA03",
            "display" : "piretanide"
          },
          {
            "code" : "C03CA04",
            "display" : "torasemide"
          },
          {
            "code" : "C03CB",
            "display" : "Sulfonamides and potassium in combination"
          },
          {
            "code" : "C03CB01",
            "display" : "furosemide and potassium"
          },
          {
            "code" : "C03CB02",
            "display" : "bumetanide and potassium"
          },
          {
            "code" : "C03CC",
            "display" : "Aryloxyacetic acid derivatives"
          },
          {
            "code" : "C03CC01",
            "display" : "etacrynic acid"
          },
          {
            "code" : "C03CC02",
            "display" : "tienilic acid"
          },
          {
            "code" : "C03CD",
            "display" : "Pyrazolone derivatives"
          },
          {
            "code" : "C03CD01",
            "display" : "muzolimine"
          },
          {
            "code" : "C03CX",
            "display" : "Other high-ceiling diuretics"
          },
          {
            "code" : "C03CX01",
            "display" : "etozolin"
          },
          {
            "code" : "C03D",
            "display" : "ALDOSTERONE ANTAGONISTS AND OTHER POTASSIUM-SPARING AGENTS"
          },
          {
            "code" : "C03DA",
            "display" : "Aldosterone antagonists"
          },
          {
            "code" : "C03DA01",
            "display" : "spironolactone"
          },
          {
            "code" : "C03DA02",
            "display" : "potassium canrenoate"
          },
          {
            "code" : "C03DA03",
            "display" : "canrenone"
          },
          {
            "code" : "C03DA04",
            "display" : "eplerenone"
          },
          {
            "code" : "C03DA05",
            "display" : "finerenone"
          },
          {
            "code" : "C03DB",
            "display" : "Other potassium-sparing agents"
          },
          {
            "code" : "C03DB01",
            "display" : "amiloride"
          },
          {
            "code" : "C03DB02",
            "display" : "triamterene"
          },
          {
            "code" : "C03E",
            "display" : "DIURETICS AND POTASSIUM-SPARING AGENTS IN COMBINATION"
          },
          {
            "code" : "C03EA",
            "display" : "Low-ceiling diuretics and potassium-sparing agents"
          },
          {
            "code" : "C03EA01",
            "display" : "hydrochlorothiazide and potassium-sparing agents"
          },
          {
            "code" : "C03EA02",
            "display" : "trichlormethiazide and potassium-sparing agents"
          },
          {
            "code" : "C03EA03",
            "display" : "epitizide and potassium-sparing agents"
          },
          {
            "code" : "C03EA04",
            "display" : "altizide and potassium-sparing agents"
          },
          {
            "code" : "C03EA05",
            "display" : "mebutizide and potassium-sparing agents"
          },
          {
            "code" : "C03EA06",
            "display" : "chlortalidone and potassium-sparing agents"
          },
          {
            "code" : "C03EA07",
            "display" : "cyclopenthiazide and potassium-sparing agents"
          },
          {
            "code" : "C03EA12",
            "display" : "metolazone and potassium-sparing agents"
          },
          {
            "code" : "C03EA13",
            "display" : "bendroflumethiazide and potassium-sparing agents"
          },
          {
            "code" : "C03EA14",
            "display" : "butizide and potassium-sparing agents"
          },
          {
            "code" : "C03EB",
            "display" : "High-ceiling diuretics and potassium-sparing agents"
          },
          {
            "code" : "C03EB01",
            "display" : "furosemide and potassium-sparing agents"
          },
          {
            "code" : "C03EB02",
            "display" : "bumetanide and potassium-sparing agents"
          },
          {
            "code" : "C03X",
            "display" : "OTHER DIURETICS"
          },
          {
            "code" : "C03XA",
            "display" : "Vasopressin antagonists"
          },
          {
            "code" : "C03XA01",
            "display" : "tolvaptan"
          },
          {
            "code" : "C03XA02",
            "display" : "conivaptan"
          },
          {
            "code" : "C04",
            "display" : "PERIPHERAL VASODILATORS"
          },
          {
            "code" : "C04A",
            "display" : "PERIPHERAL VASODILATORS"
          },
          {
            "code" : "C04AA",
            "display" : "2-amino-1-phenylethanol derivatives"
          },
          {
            "code" : "C04AA01",
            "display" : "isoxsuprine"
          },
          {
            "code" : "C04AA02",
            "display" : "buphenine"
          },
          {
            "code" : "C04AA31",
            "display" : "bamethan"
          },
          {
            "code" : "C04AB",
            "display" : "Imidazoline derivatives"
          },
          {
            "code" : "C04AB01",
            "display" : "phentolamine"
          },
          {
            "code" : "C04AB02",
            "display" : "tolazoline"
          },
          {
            "code" : "C04AC",
            "display" : "Nicotinic acid and derivatives"
          },
          {
            "code" : "C04AC01",
            "display" : "nicotinic acid"
          },
          {
            "code" : "C04AC02",
            "display" : "nicotinyl alcohol (pyridylcarbinol)"
          },
          {
            "code" : "C04AC03",
            "display" : "inositol nicotinate"
          },
          {
            "code" : "C04AC07",
            "display" : "ciclonicate"
          },
          {
            "code" : "C04AD",
            "display" : "Purine derivatives"
          },
          {
            "code" : "C04AD01",
            "display" : "pentifylline"
          },
          {
            "code" : "C04AD02",
            "display" : "xantinol nicotinate"
          },
          {
            "code" : "C04AD03",
            "display" : "pentoxifylline"
          },
          {
            "code" : "C04AD04",
            "display" : "etofylline nicotinate"
          },
          {
            "code" : "C04AE",
            "display" : "Ergot alkaloids"
          },
          {
            "code" : "C04AE01",
            "display" : "ergoloid mesylates"
          },
          {
            "code" : "C04AE02",
            "display" : "nicergoline"
          },
          {
            "code" : "C04AE04",
            "display" : "dihydroergocristine"
          },
          {
            "code" : "C04AE51",
            "display" : "ergoloid mesylates, combinations"
          },
          {
            "code" : "C04AE54",
            "display" : "dihydroergocristine, combinations"
          },
          {
            "code" : "C04AF",
            "display" : "Enzymes"
          },
          {
            "code" : "C04AF01",
            "display" : "kallidinogenase"
          },
          {
            "code" : "C04AX",
            "display" : "Other peripheral vasodilators"
          },
          {
            "code" : "C04AX01",
            "display" : "cyclandelate"
          },
          {
            "code" : "C04AX02",
            "display" : "phenoxybenzamine"
          },
          {
            "code" : "C04AX07",
            "display" : "vincamine"
          },
          {
            "code" : "C04AX10",
            "display" : "moxisylyte"
          },
          {
            "code" : "C04AX11",
            "display" : "bencyclane"
          },
          {
            "code" : "C04AX17",
            "display" : "vinburnine"
          },
          {
            "code" : "C04AX19",
            "display" : "suloctidil"
          },
          {
            "code" : "C04AX20",
            "display" : "buflomedil"
          },
          {
            "code" : "C04AX21",
            "display" : "naftidrofuryl"
          },
          {
            "code" : "C04AX23",
            "display" : "butalamine"
          },
          {
            "code" : "C04AX24",
            "display" : "visnadine"
          },
          {
            "code" : "C04AX26",
            "display" : "cetiedil"
          },
          {
            "code" : "C04AX27",
            "display" : "cinepazide"
          },
          {
            "code" : "C04AX28",
            "display" : "ifenprodil"
          },
          {
            "code" : "C04AX30",
            "display" : "azapetine"
          },
          {
            "code" : "C04AX32",
            "display" : "fasudil"
          },
          {
            "code" : "C04AX33",
            "display" : "clazosentan"
          },
          {
            "code" : "C05",
            "display" : "VASOPROTECTIVES"
          },
          {
            "code" : "C05A",
            "display" : "AGENTS FOR TREATMENT OF HEMORRHOIDS AND ANAL FISSURES FOR TOPICAL USE"
          },
          {
            "code" : "C05AA",
            "display" : "Corticosteroids"
          },
          {
            "code" : "C05AA01",
            "display" : "hydrocortisone"
          },
          {
            "code" : "C05AA04",
            "display" : "prednisolone"
          },
          {
            "code" : "C05AA05",
            "display" : "betamethasone"
          },
          {
            "code" : "C05AA06",
            "display" : "fluorometholone"
          },
          {
            "code" : "C05AA08",
            "display" : "fluocortolone"
          },
          {
            "code" : "C05AA09",
            "display" : "dexamethasone"
          },
          {
            "code" : "C05AA10",
            "display" : "fluocinolone acetonide"
          },
          {
            "code" : "C05AA11",
            "display" : "fluocinonide"
          },
          {
            "code" : "C05AA12",
            "display" : "triamcinolone"
          },
          {
            "code" : "C05AB",
            "display" : "Antibiotics"
          },
          {
            "code" : "C05AD",
            "display" : "Local anesthetics"
          },
          {
            "code" : "C05AD01",
            "display" : "lidocaine"
          },
          {
            "code" : "C05AD02",
            "display" : "tetracaine"
          },
          {
            "code" : "C05AD03",
            "display" : "benzocaine"
          },
          {
            "code" : "C05AD04",
            "display" : "cinchocaine"
          },
          {
            "code" : "C05AD05",
            "display" : "procaine"
          },
          {
            "code" : "C05AD06",
            "display" : "oxetacaine"
          },
          {
            "code" : "C05AD07",
            "display" : "pramocaine"
          },
          {
            "code" : "C05AE",
            "display" : "Muscle relaxants"
          },
          {
            "code" : "C05AE01",
            "display" : "glyceryl trinitrate"
          },
          {
            "code" : "C05AE02",
            "display" : "isosorbide dinitrate"
          },
          {
            "code" : "C05AE03",
            "display" : "diltiazem"
          },
          {
            "code" : "C05AX",
            "display" : "Other agents for treatment of hemorrhoids and anal fissures for topical use"
          },
          {
            "code" : "C05AX01",
            "display" : "aluminium preparations"
          },
          {
            "code" : "C05AX02",
            "display" : "bismuth preparations, combinations"
          },
          {
            "code" : "C05AX03",
            "display" : "other preparations, combinations"
          },
          {
            "code" : "C05AX04",
            "display" : "zinc preparations"
          },
          {
            "code" : "C05AX05",
            "display" : "tribenoside"
          },
          {
            "code" : "C05AX06",
            "display" : "phenylephrine"
          },
          {
            "code" : "C05B",
            "display" : "ANTIVARICOSE THERAPY"
          },
          {
            "code" : "C05BA",
            "display" : "Heparins or heparinoids for topical use"
          },
          {
            "code" : "C05BA01",
            "display" : "organo-heparinoid"
          },
          {
            "code" : "C05BA02",
            "display" : "sodium apolate"
          },
          {
            "code" : "C05BA03",
            "display" : "heparin"
          },
          {
            "code" : "C05BA04",
            "display" : "pentosan polysulfate sodium"
          },
          {
            "code" : "C05BA51",
            "display" : "heparinoid, combinations"
          },
          {
            "code" : "C05BA53",
            "display" : "heparin, combinations"
          },
          {
            "code" : "C05BB",
            "display" : "Sclerosing agents for local injection"
          },
          {
            "code" : "C05BB01",
            "display" : "monoethanolamine oleate"
          },
          {
            "code" : "C05BB02",
            "display" : "polidocanol"
          },
          {
            "code" : "C05BB03",
            "display" : "invert sugar"
          },
          {
            "code" : "C05BB04",
            "display" : "sodium tetradecyl sulfate"
          },
          {
            "code" : "C05BB05",
            "display" : "phenol"
          },
          {
            "code" : "C05BB56",
            "display" : "glucose, combinations"
          },
          {
            "code" : "C05BX",
            "display" : "Other sclerosing agents"
          },
          {
            "code" : "C05BX01",
            "display" : "calcium dobesilate"
          },
          {
            "code" : "C05BX51",
            "display" : "calcium dobesilate, combinations"
          },
          {
            "code" : "C05C",
            "display" : "CAPILLARY STABILIZING AGENTS"
          },
          {
            "code" : "C05CA",
            "display" : "Bioflavonoids"
          },
          {
            "code" : "C05CA01",
            "display" : "rutoside"
          },
          {
            "code" : "C05CA02",
            "display" : "monoxerutin"
          },
          {
            "code" : "C05CA03",
            "display" : "diosmin"
          },
          {
            "code" : "C05CA04",
            "display" : "troxerutin"
          },
          {
            "code" : "C05CA05",
            "display" : "hidrosmin"
          },
          {
            "code" : "C05CA51",
            "display" : "rutoside, combinations"
          },
          {
            "code" : "C05CA53",
            "display" : "diosmin, combinations"
          },
          {
            "code" : "C05CA54",
            "display" : "troxerutin, combinations"
          },
          {
            "code" : "C05CX",
            "display" : "Other capillary stabilizing agents"
          },
          {
            "code" : "C05CX01",
            "display" : "tribenoside"
          },
          {
            "code" : "C05CX02",
            "display" : "naftazone"
          },
          {
            "code" : "C05CX03",
            "display" : "Hippocastani semen"
          },
          {
            "code" : "C05X",
            "display" : "OTHER VASOPROTECTIVES"
          },
          {
            "code" : "C05XX",
            "display" : "Other vasoprotectives"
          },
          {
            "code" : "C05XX01",
            "display" : "beperminogene perplasmid"
          },
          {
            "code" : "C07",
            "display" : "BETA BLOCKING AGENTS"
          },
          {
            "code" : "C07A",
            "display" : "BETA BLOCKING AGENTS"
          },
          {
            "code" : "C07AA",
            "display" : "Beta blocking agents, non-selective"
          },
          {
            "code" : "C07AA01",
            "display" : "alprenolol"
          },
          {
            "code" : "C07AA02",
            "display" : "oxprenolol"
          },
          {
            "code" : "C07AA03",
            "display" : "pindolol"
          },
          {
            "code" : "C07AA05",
            "display" : "propranolol"
          },
          {
            "code" : "C07AA06",
            "display" : "timolol"
          },
          {
            "code" : "C07AA07",
            "display" : "sotalol"
          },
          {
            "code" : "C07AA12",
            "display" : "nadolol"
          },
          {
            "code" : "C07AA14",
            "display" : "mepindolol"
          },
          {
            "code" : "C07AA15",
            "display" : "carteolol"
          },
          {
            "code" : "C07AA16",
            "display" : "tertatolol"
          },
          {
            "code" : "C07AA17",
            "display" : "bopindolol"
          },
          {
            "code" : "C07AA19",
            "display" : "bupranolol"
          },
          {
            "code" : "C07AA23",
            "display" : "penbutolol"
          },
          {
            "code" : "C07AA27",
            "display" : "cloranolol"
          },
          {
            "code" : "C07AB",
            "display" : "Beta blocking agents, selective"
          },
          {
            "code" : "C07AB01",
            "display" : "practolol"
          },
          {
            "code" : "C07AB02",
            "display" : "metoprolol"
          },
          {
            "code" : "C07AB03",
            "display" : "atenolol"
          },
          {
            "code" : "C07AB04",
            "display" : "acebutolol"
          },
          {
            "code" : "C07AB05",
            "display" : "betaxolol"
          },
          {
            "code" : "C07AB06",
            "display" : "bevantolol"
          },
          {
            "code" : "C07AB07",
            "display" : "bisoprolol"
          },
          {
            "code" : "C07AB08",
            "display" : "celiprolol"
          },
          {
            "code" : "C07AB09",
            "display" : "esmolol"
          },
          {
            "code" : "C07AB10",
            "display" : "epanolol"
          },
          {
            "code" : "C07AB11",
            "display" : "s-atenolol"
          },
          {
            "code" : "C07AB12",
            "display" : "nebivolol"
          },
          {
            "code" : "C07AB13",
            "display" : "talinolol"
          },
          {
            "code" : "C07AB14",
            "display" : "landiolol"
          },
          {
            "code" : "C07AG",
            "display" : "Alpha and beta blocking agents"
          },
          {
            "code" : "C07AG01",
            "display" : "labetalol"
          },
          {
            "code" : "C07AG02",
            "display" : "carvedilol"
          },
          {
            "code" : "C07B",
            "display" : "BETA BLOCKING AGENTS AND THIAZIDES"
          },
          {
            "code" : "C07BA",
            "display" : "Beta blocking agents, non-selective, and thiazides"
          },
          {
            "code" : "C07BA02",
            "display" : "oxprenolol and thiazides"
          },
          {
            "code" : "C07BA05",
            "display" : "propranolol and thiazides"
          },
          {
            "code" : "C07BA06",
            "display" : "timolol and thiazides"
          },
          {
            "code" : "C07BA07",
            "display" : "sotalol and thiazides"
          },
          {
            "code" : "C07BA12",
            "display" : "nadolol and thiazides"
          },
          {
            "code" : "C07BA68",
            "display" : "metipranolol and thiazides, combinations"
          },
          {
            "code" : "C07BB",
            "display" : "Beta blocking agents, selective, and thiazides"
          },
          {
            "code" : "C07BB02",
            "display" : "metoprolol and thiazides"
          },
          {
            "code" : "C07BB03",
            "display" : "atenolol and thiazides"
          },
          {
            "code" : "C07BB04",
            "display" : "acebutolol and thiazides"
          },
          {
            "code" : "C07BB06",
            "display" : "bevantolol and thiazides"
          },
          {
            "code" : "C07BB07",
            "display" : "bisoprolol and thiazides"
          },
          {
            "code" : "C07BB12",
            "display" : "nebivolol and thiazides"
          },
          {
            "code" : "C07BB52",
            "display" : "metoprolol and thiazides, combinations"
          },
          {
            "code" : "C07BG",
            "display" : "Alpha and beta blocking agents and thiazides"
          },
          {
            "code" : "C07BG01",
            "display" : "labetalol and thiazides"
          },
          {
            "code" : "C07C",
            "display" : "BETA BLOCKING AGENTS AND OTHER DIURETICS"
          },
          {
            "code" : "C07CA",
            "display" : "Beta blocking agents, non-selective, and other diuretics"
          },
          {
            "code" : "C07CA02",
            "display" : "oxprenolol and other diuretics"
          },
          {
            "code" : "C07CA03",
            "display" : "pindolol and other diuretics"
          },
          {
            "code" : "C07CA17",
            "display" : "bopindolol and other diuretics"
          },
          {
            "code" : "C07CA23",
            "display" : "penbutolol and other diuretics"
          },
          {
            "code" : "C07CB",
            "display" : "Beta blocking agents, selective, and other diuretics"
          },
          {
            "code" : "C07CB02",
            "display" : "metoprolol and other diuretics"
          },
          {
            "code" : "C07CB03",
            "display" : "atenolol and other diuretics"
          },
          {
            "code" : "C07CB53",
            "display" : "atenolol and other diuretics, combinations"
          },
          {
            "code" : "C07CG",
            "display" : "Alpha and beta blocking agents and other diuretics"
          },
          {
            "code" : "C07CG01",
            "display" : "labetalol and other diuretics"
          },
          {
            "code" : "C07D",
            "display" : "BETA BLOCKING AGENTS, THIAZIDES AND OTHER DIURETICS"
          },
          {
            "code" : "C07DA",
            "display" : "Beta blocking agents, non-selective, thiazides and other diuretics"
          },
          {
            "code" : "C07DA06",
            "display" : "timolol, thiazides and other diuretics"
          },
          {
            "code" : "C07DB",
            "display" : "Beta blocking agents, selective, thiazides and other diuretics"
          },
          {
            "code" : "C07DB01",
            "display" : "atenolol, thiazides and other diuretics"
          },
          {
            "code" : "C07E",
            "display" : "BETA BLOCKING AGENTS AND VASODILATORS"
          },
          {
            "code" : "C07EA",
            "display" : "Beta blocking agents, non-selective, and vasodilators"
          },
          {
            "code" : "C07EB",
            "display" : "Beta blocking agents, selective, and vasodilators"
          },
          {
            "code" : "C07F",
            "display" : "BETA BLOCKING AGENTS, OTHER COMBINATIONS"
          },
          {
            "code" : "C07FB",
            "display" : "Beta blocking agents and calcium channel blockers"
          },
          {
            "code" : "C07FB02",
            "display" : "metoprolol and felodipine"
          },
          {
            "code" : "C07FB03",
            "display" : "atenolol and nifedipine"
          },
          {
            "code" : "C07FB07",
            "display" : "bisoprolol and amlodipine"
          },
          {
            "code" : "C07FB12",
            "display" : "nebivolol and amlodipine"
          },
          {
            "code" : "C07FB13",
            "display" : "metoprolol and amlodipine"
          },
          {
            "code" : "C07FX",
            "display" : "Beta blocking agents, other combinations"
          },
          {
            "code" : "C07FX01",
            "display" : "propranolol and other combinations"
          },
          {
            "code" : "C07FX02",
            "display" : "sotalol and acetylsalicylic acid"
          },
          {
            "code" : "C07FX03",
            "display" : "metoprolol and acetylsalicylic acid"
          },
          {
            "code" : "C07FX04",
            "display" : "bisoprolol and acetylsalicylic acid"
          },
          {
            "code" : "C07FX05",
            "display" : "metoprolol and ivabradine"
          },
          {
            "code" : "C07FX06",
            "display" : "carvedilol and ivabradine"
          },
          {
            "code" : "C08",
            "display" : "CALCIUM CHANNEL BLOCKERS"
          },
          {
            "code" : "C08C",
            "display" : "SELECTIVE CALCIUM CHANNEL BLOCKERS WITH MAINLY VASCULAR EFFECTS"
          },
          {
            "code" : "C08CA",
            "display" : "Dihydropyridine derivatives"
          },
          {
            "code" : "C08CA01",
            "display" : "amlodipine"
          },
          {
            "code" : "C08CA02",
            "display" : "felodipine"
          },
          {
            "code" : "C08CA03",
            "display" : "isradipine"
          },
          {
            "code" : "C08CA04",
            "display" : "nicardipine"
          },
          {
            "code" : "C08CA05",
            "display" : "nifedipine"
          },
          {
            "code" : "C08CA06",
            "display" : "nimodipine"
          },
          {
            "code" : "C08CA07",
            "display" : "nisoldipine"
          },
          {
            "code" : "C08CA08",
            "display" : "nitrendipine"
          },
          {
            "code" : "C08CA09",
            "display" : "lacidipine"
          },
          {
            "code" : "C08CA10",
            "display" : "nilvadipine"
          },
          {
            "code" : "C08CA11",
            "display" : "manidipine"
          },
          {
            "code" : "C08CA12",
            "display" : "barnidipine"
          },
          {
            "code" : "C08CA13",
            "display" : "lercanidipine"
          },
          {
            "code" : "C08CA14",
            "display" : "cilnidipine"
          },
          {
            "code" : "C08CA15",
            "display" : "benidipine"
          },
          {
            "code" : "C08CA16",
            "display" : "clevidipine"
          },
          {
            "code" : "C08CA17",
            "display" : "levamlodipine"
          },
          {
            "code" : "C08CA51",
            "display" : "amlodipine and celecoxib"
          },
          {
            "code" : "C08CA55",
            "display" : "nifedipine, combinations"
          },
          {
            "code" : "C08CX",
            "display" : "Other selective calcium channel blockers with mainly vascular effects"
          },
          {
            "code" : "C08CX01",
            "display" : "mibefradil"
          },
          {
            "code" : "C08D",
            "display" : "SELECTIVE CALCIUM CHANNEL BLOCKERS WITH DIRECT CARDIAC EFFECTS"
          },
          {
            "code" : "C08DA",
            "display" : "Phenylalkylamine derivatives"
          },
          {
            "code" : "C08DA01",
            "display" : "verapamil"
          },
          {
            "code" : "C08DA02",
            "display" : "gallopamil"
          },
          {
            "code" : "C08DA03",
            "display" : "etripamil"
          },
          {
            "code" : "C08DA51",
            "display" : "verapamil, combinations"
          },
          {
            "code" : "C08DB",
            "display" : "Benzothiazepine derivatives"
          },
          {
            "code" : "C08DB01",
            "display" : "diltiazem"
          },
          {
            "code" : "C08E",
            "display" : "NON-SELECTIVE CALCIUM CHANNEL BLOCKERS"
          },
          {
            "code" : "C08EA",
            "display" : "Phenylalkylamine derivatives"
          },
          {
            "code" : "C08EA01",
            "display" : "fendiline"
          },
          {
            "code" : "C08EA02",
            "display" : "bepridil"
          },
          {
            "code" : "C08EX",
            "display" : "Other non-selective calcium channel blockers"
          },
          {
            "code" : "C08EX01",
            "display" : "lidoflazine"
          },
          {
            "code" : "C08EX02",
            "display" : "perhexiline"
          },
          {
            "code" : "C08G",
            "display" : "CALCIUM CHANNEL BLOCKERS AND DIURETICS"
          },
          {
            "code" : "C08GA",
            "display" : "Calcium channel blockers and diuretics"
          },
          {
            "code" : "C08GA01",
            "display" : "nifedipine and diuretics"
          },
          {
            "code" : "C08GA02",
            "display" : "amlodipine and diuretics"
          },
          {
            "code" : "C09",
            "display" : "AGENTS ACTING ON THE RENIN-ANGIOTENSIN SYSTEM"
          },
          {
            "code" : "C09A",
            "display" : "ACE INHIBITORS, PLAIN"
          },
          {
            "code" : "C09AA",
            "display" : "ACE inhibitors, plain"
          },
          {
            "code" : "C09AA01",
            "display" : "captopril"
          },
          {
            "code" : "C09AA02",
            "display" : "enalapril"
          },
          {
            "code" : "C09AA03",
            "display" : "lisinopril"
          },
          {
            "code" : "C09AA04",
            "display" : "perindopril"
          },
          {
            "code" : "C09AA05",
            "display" : "ramipril"
          },
          {
            "code" : "C09AA06",
            "display" : "quinapril"
          },
          {
            "code" : "C09AA07",
            "display" : "benazepril"
          },
          {
            "code" : "C09AA08",
            "display" : "cilazapril"
          },
          {
            "code" : "C09AA09",
            "display" : "fosinopril"
          },
          {
            "code" : "C09AA10",
            "display" : "trandolapril"
          },
          {
            "code" : "C09AA11",
            "display" : "spirapril"
          },
          {
            "code" : "C09AA12",
            "display" : "delapril"
          },
          {
            "code" : "C09AA13",
            "display" : "moexipril"
          },
          {
            "code" : "C09AA14",
            "display" : "temocapril"
          },
          {
            "code" : "C09AA15",
            "display" : "zofenopril"
          },
          {
            "code" : "C09AA16",
            "display" : "imidapril"
          },
          {
            "code" : "C09B",
            "display" : "ACE INHIBITORS, COMBINATIONS"
          },
          {
            "code" : "C09BA",
            "display" : "ACE inhibitors and diuretics"
          },
          {
            "code" : "C09BA01",
            "display" : "captopril and diuretics"
          },
          {
            "code" : "C09BA02",
            "display" : "enalapril and diuretics"
          },
          {
            "code" : "C09BA03",
            "display" : "lisinopril and diuretics"
          },
          {
            "code" : "C09BA04",
            "display" : "perindopril and diuretics"
          },
          {
            "code" : "C09BA05",
            "display" : "ramipril and diuretics"
          },
          {
            "code" : "C09BA06",
            "display" : "quinapril and diuretics"
          },
          {
            "code" : "C09BA07",
            "display" : "benazepril and diuretics"
          },
          {
            "code" : "C09BA08",
            "display" : "cilazapril and diuretics"
          },
          {
            "code" : "C09BA09",
            "display" : "fosinopril and diuretics"
          },
          {
            "code" : "C09BA12",
            "display" : "delapril and diuretics"
          },
          {
            "code" : "C09BA13",
            "display" : "moexipril and diuretics"
          },
          {
            "code" : "C09BA15",
            "display" : "zofenopril and diuretics"
          },
          {
            "code" : "C09BB",
            "display" : "ACE inhibitors and calcium channel blockers"
          },
          {
            "code" : "C09BB02",
            "display" : "enalapril and lercanidipine"
          },
          {
            "code" : "C09BB03",
            "display" : "lisinopril and amlodipine"
          },
          {
            "code" : "C09BB04",
            "display" : "perindopril and amlodipine"
          },
          {
            "code" : "C09BB05",
            "display" : "ramipril and felodipine"
          },
          {
            "code" : "C09BB06",
            "display" : "enalapril and nitrendipine"
          },
          {
            "code" : "C09BB07",
            "display" : "ramipril and amlodipine"
          },
          {
            "code" : "C09BB10",
            "display" : "trandolapril and verapamil"
          },
          {
            "code" : "C09BB12",
            "display" : "delapril and manidipine"
          },
          {
            "code" : "C09BB13",
            "display" : "benazepril and amlodipine"
          },
          {
            "code" : "C09BX",
            "display" : "ACE inhibitors, other combinations"
          },
          {
            "code" : "C09BX01",
            "display" : "perindopril, amlodipine and indapamide"
          },
          {
            "code" : "C09BX02",
            "display" : "perindopril and bisoprolol"
          },
          {
            "code" : "C09BX03",
            "display" : "ramipril, amlodipine and hydrochlorothiazide"
          },
          {
            "code" : "C09BX04",
            "display" : "perindopril, bisoprolol and amlodipine"
          },
          {
            "code" : "C09BX05",
            "display" : "ramipril and bisoprolol"
          },
          {
            "code" : "C09BX06",
            "display" : "perindopril, bisoprolol, amlodipine and indapamide"
          },
          {
            "code" : "C09BX07",
            "display" : "zofenopril and nebivolol"
          },
          {
            "code" : "C09C",
            "display" : "ANGIOTENSIN II RECEPTOR BLOCKERS (ARBs), PLAIN"
          },
          {
            "code" : "C09CA",
            "display" : "Angiotensin II receptor blockers (ARBs), plain"
          },
          {
            "code" : "C09CA01",
            "display" : "losartan"
          },
          {
            "code" : "C09CA02",
            "display" : "eprosartan"
          },
          {
            "code" : "C09CA03",
            "display" : "valsartan"
          },
          {
            "code" : "C09CA04",
            "display" : "irbesartan"
          },
          {
            "code" : "C09CA05",
            "display" : "tasosartan"
          },
          {
            "code" : "C09CA06",
            "display" : "candesartan"
          },
          {
            "code" : "C09CA07",
            "display" : "telmisartan"
          },
          {
            "code" : "C09CA08",
            "display" : "olmesartan medoxomil"
          },
          {
            "code" : "C09CA09",
            "display" : "azilsartan medoxomil"
          },
          {
            "code" : "C09CA10",
            "display" : "fimasartan"
          },
          {
            "code" : "C09D",
            "display" : "ANGIOTENSIN II RECEPTOR BLOCKERS (ARBs), COMBINATIONS"
          },
          {
            "code" : "C09DA",
            "display" : "Angiotensin II receptor blockers (ARBs) and diuretics"
          },
          {
            "code" : "C09DA01",
            "display" : "losartan and diuretics"
          },
          {
            "code" : "C09DA02",
            "display" : "eprosartan and diuretics"
          },
          {
            "code" : "C09DA03",
            "display" : "valsartan and diuretics"
          },
          {
            "code" : "C09DA04",
            "display" : "irbesartan and diuretics"
          },
          {
            "code" : "C09DA06",
            "display" : "candesartan and diuretics"
          },
          {
            "code" : "C09DA07",
            "display" : "telmisartan and diuretics"
          },
          {
            "code" : "C09DA08",
            "display" : "olmesartan medoxomil and diuretics"
          },
          {
            "code" : "C09DA09",
            "display" : "azilsartan medoxomil and diuretics"
          },
          {
            "code" : "C09DA10",
            "display" : "fimasartan and diuretics"
          },
          {
            "code" : "C09DB",
            "display" : "Angiotensin II receptor blockers (ARBs) and calcium channel blockers"
          },
          {
            "code" : "C09DB01",
            "display" : "valsartan and amlodipine"
          },
          {
            "code" : "C09DB02",
            "display" : "olmesartan medoxomil and amlodipine"
          },
          {
            "code" : "C09DB04",
            "display" : "telmisartan and amlodipine"
          },
          {
            "code" : "C09DB05",
            "display" : "irbesartan and amlodipine"
          },
          {
            "code" : "C09DB06",
            "display" : "losartan and amlodipine"
          },
          {
            "code" : "C09DB07",
            "display" : "candesartan and amlodipine"
          },
          {
            "code" : "C09DB08",
            "display" : "valsartan and lercanidipine"
          },
          {
            "code" : "C09DB09",
            "display" : "fimasartan and amlodipine"
          },
          {
            "code" : "C09DX",
            "display" : "Angiotensin II receptor blockers (ARBs), other combinations"
          },
          {
            "code" : "C09DX01",
            "display" : "valsartan, amlodipine and hydrochlorothiazide"
          },
          {
            "code" : "C09DX02",
            "display" : "valsartan and aliskiren"
          },
          {
            "code" : "C09DX03",
            "display" : "olmesartan medoxomil, amlodipine and hydrochlorothiazide"
          },
          {
            "code" : "C09DX04",
            "display" : "valsartan and sacubitril"
          },
          {
            "code" : "C09DX05",
            "display" : "valsartan and nebivolol"
          },
          {
            "code" : "C09DX06",
            "display" : "candesartan, amlodipine and hydrochlorothiazide"
          },
          {
            "code" : "C09DX07",
            "display" : "irbesartan, amlodipine and hydrochlorothiazide"
          },
          {
            "code" : "C09DX08",
            "display" : "telmisartan, amlodipine and hydrochlorothiazide"
          },
          {
            "code" : "C09X",
            "display" : "OTHER AGENTS ACTING ON THE RENIN-ANGIOTENSIN SYSTEM"
          },
          {
            "code" : "C09XA",
            "display" : "Renin-inhibitors"
          },
          {
            "code" : "C09XA01",
            "display" : "remikiren"
          },
          {
            "code" : "C09XA02",
            "display" : "aliskiren"
          },
          {
            "code" : "C09XA52",
            "display" : "aliskiren and hydrochlorothiazide"
          },
          {
            "code" : "C09XA53",
            "display" : "aliskiren and amlodipine"
          },
          {
            "code" : "C09XA54",
            "display" : "aliskiren, amlodipine and hydrochlorothiazide"
          },
          {
            "code" : "C09XX",
            "display" : "Other agents acting on the renin-angiotensin system"
          },
          {
            "code" : "C09XX01",
            "display" : "sparsentan"
          },
          {
            "code" : "C10",
            "display" : "LIPID MODIFYING AGENTS"
          },
          {
            "code" : "C10A",
            "display" : "LIPID MODIFYING AGENTS, PLAIN"
          },
          {
            "code" : "C10AA",
            "display" : "HMG CoA reductase inhibitors"
          },
          {
            "code" : "C10AA01",
            "display" : "simvastatin"
          },
          {
            "code" : "C10AA02",
            "display" : "lovastatin"
          },
          {
            "code" : "C10AA03",
            "display" : "pravastatin"
          },
          {
            "code" : "C10AA04",
            "display" : "fluvastatin"
          },
          {
            "code" : "C10AA05",
            "display" : "atorvastatin"
          },
          {
            "code" : "C10AA06",
            "display" : "cerivastatin"
          },
          {
            "code" : "C10AA07",
            "display" : "rosuvastatin"
          },
          {
            "code" : "C10AA08",
            "display" : "pitavastatin"
          },
          {
            "code" : "C10AB",
            "display" : "Fibrates"
          },
          {
            "code" : "C10AB01",
            "display" : "clofibrate"
          },
          {
            "code" : "C10AB02",
            "display" : "bezafibrate"
          },
          {
            "code" : "C10AB03",
            "display" : "aluminium clofibrate"
          },
          {
            "code" : "C10AB04",
            "display" : "gemfibrozil"
          },
          {
            "code" : "C10AB05",
            "display" : "fenofibrate"
          },
          {
            "code" : "C10AB06",
            "display" : "simfibrate"
          },
          {
            "code" : "C10AB07",
            "display" : "ronifibrate"
          },
          {
            "code" : "C10AB08",
            "display" : "ciprofibrate"
          },
          {
            "code" : "C10AB09",
            "display" : "etofibrate"
          },
          {
            "code" : "C10AB10",
            "display" : "clofibride"
          },
          {
            "code" : "C10AB11",
            "display" : "choline fenofibrate"
          },
          {
            "code" : "C10AB12",
            "display" : "pemafibrate"
          },
          {
            "code" : "C10AC",
            "display" : "Bile acid sequestrants"
          },
          {
            "code" : "C10AC01",
            "display" : "colestyramine"
          },
          {
            "code" : "C10AC02",
            "display" : "colestipol"
          },
          {
            "code" : "C10AC03",
            "display" : "colextran"
          },
          {
            "code" : "C10AC04",
            "display" : "colesevelam"
          },
          {
            "code" : "C10AD",
            "display" : "Nicotinic acid and derivatives"
          },
          {
            "code" : "C10AD01",
            "display" : "niceritrol"
          },
          {
            "code" : "C10AD02",
            "display" : "nicotinic acid"
          },
          {
            "code" : "C10AD03",
            "display" : "nicofuranose"
          },
          {
            "code" : "C10AD04",
            "display" : "aluminium nicotinate"
          },
          {
            "code" : "C10AD05",
            "display" : "nicotinyl alcohol (pyridylcarbinol)"
          },
          {
            "code" : "C10AD06",
            "display" : "acipimox"
          },
          {
            "code" : "C10AD52",
            "display" : "nicotinic acid, combinations"
          },
          {
            "code" : "C10AX",
            "display" : "Other lipid modifying agents"
          },
          {
            "code" : "C10AX01",
            "display" : "dextrothyroxine"
          },
          {
            "code" : "C10AX02",
            "display" : "probucol"
          },
          {
            "code" : "C10AX03",
            "display" : "tiadenol"
          },
          {
            "code" : "C10AX05",
            "display" : "meglutol"
          },
          {
            "code" : "C10AX06",
            "display" : "omega-3-triglycerides incl. other esters and acids"
          },
          {
            "code" : "C10AX07",
            "display" : "magnesium pyridoxal 5-phosphate glutamate"
          },
          {
            "code" : "C10AX08",
            "display" : "policosanol"
          },
          {
            "code" : "C10AX09",
            "display" : "ezetimibe"
          },
          {
            "code" : "C10AX10",
            "display" : "alipogene tiparvovec"
          },
          {
            "code" : "C10AX11",
            "display" : "mipomersen"
          },
          {
            "code" : "C10AX12",
            "display" : "lomitapide"
          },
          {
            "code" : "C10AX13",
            "display" : "evolocumab"
          },
          {
            "code" : "C10AX14",
            "display" : "alirocumab"
          },
          {
            "code" : "C10AX15",
            "display" : "bempedoic acid"
          },
          {
            "code" : "C10AX16",
            "display" : "inclisiran"
          },
          {
            "code" : "C10AX17",
            "display" : "evinacumab"
          },
          {
            "code" : "C10AX18",
            "display" : "volanesorsen"
          },
          {
            "code" : "C10B",
            "display" : "LIPID MODIFYING AGENTS, COMBINATIONS"
          },
          {
            "code" : "C10BA",
            "display" : "Combinations of various lipid modifying agents"
          },
          {
            "code" : "C10BA01",
            "display" : "lovastatin and nicotinic acid"
          },
          {
            "code" : "C10BA02",
            "display" : "simvastatin and ezetimibe"
          },
          {
            "code" : "C10BA03",
            "display" : "pravastatin and fenofibrate"
          },
          {
            "code" : "C10BA04",
            "display" : "simvastatin and fenofibrate"
          },
          {
            "code" : "C10BA05",
            "display" : "atorvastatin and ezetimibe"
          },
          {
            "code" : "C10BA06",
            "display" : "rosuvastatin and ezetimibe"
          },
          {
            "code" : "C10BA07",
            "display" : "rosuvastatin and omega-3 fatty acids"
          },
          {
            "code" : "C10BA08",
            "display" : "atorvastatin and omega-3 fatty acids"
          },
          {
            "code" : "C10BA09",
            "display" : "rosuvastatin and fenofibrate"
          },
          {
            "code" : "C10BA10",
            "display" : "bempedoic acid and ezetimibe"
          },
          {
            "code" : "C10BA11",
            "display" : "pravastatin and ezetimibe"
          },
          {
            "code" : "C10BA12",
            "display" : "pravastatin, ezetimibe and fenofibrate"
          },
          {
            "code" : "C10BA13",
            "display" : "pitavastatin and ezetimibe"
          },
          {
            "code" : "C10BX",
            "display" : "Lipid modifying agents in combination with other drugs"
          },
          {
            "code" : "C10BX01",
            "display" : "simvastatin and acetylsalicylic acid"
          },
          {
            "code" : "C10BX02",
            "display" : "pravastatin and acetylsalicylic acid"
          },
          {
            "code" : "C10BX03",
            "display" : "atorvastatin and amlodipine"
          },
          {
            "code" : "C10BX04",
            "display" : "simvastatin, acetylsalicylic acid and ramipril"
          },
          {
            "code" : "C10BX05",
            "display" : "rosuvastatin and acetylsalicylic acid"
          },
          {
            "code" : "C10BX06",
            "display" : "atorvastatin, acetylsalicylic acid and ramipril"
          },
          {
            "code" : "C10BX07",
            "display" : "rosuvastatin, amlodipine and lisinopril"
          },
          {
            "code" : "C10BX08",
            "display" : "atorvastatin and acetylsalicylic acid"
          },
          {
            "code" : "C10BX09",
            "display" : "rosuvastatin and amlodipine"
          },
          {
            "code" : "C10BX10",
            "display" : "rosuvastatin and valsartan"
          },
          {
            "code" : "C10BX11",
            "display" : "atorvastatin, amlodipine and perindopril"
          },
          {
            "code" : "C10BX12",
            "display" : "atorvastatin, acetylsalicylic acid and perindopril"
          },
          {
            "code" : "C10BX13",
            "display" : "rosuvastatin, perindopril and indapamide"
          },
          {
            "code" : "C10BX14",
            "display" : "rosuvastatin, amlodipine and perindopril"
          },
          {
            "code" : "C10BX15",
            "display" : "atorvastatin and perindopril"
          },
          {
            "code" : "C10BX16",
            "display" : "rosuvastatin and fimasartan"
          },
          {
            "code" : "C10BX17",
            "display" : "rosuvastatin and ramipril"
          },
          {
            "code" : "C10BX18",
            "display" : "atorvastatin, amlodipine and ramipril"
          },
          {
            "code" : "C10BX19",
            "display" : "atorvastatin, amlodipine and candesartan"
          },
          {
            "code" : "C10BX20",
            "display" : "rosuvastatin and telmisartan"
          },
          {
            "code" : "C10BX21",
            "display" : "rosuvastatin and perindopril"
          },
          {
            "code" : "C10BX22",
            "display" : "rosuvastatin and nebivolol"
          },
          {
            "code" : "D",
            "display" : "DERMATOLOGICALS"
          },
          {
            "code" : "D01",
            "display" : "ANTIFUNGALS FOR DERMATOLOGICAL USE"
          },
          {
            "code" : "D01A",
            "display" : "ANTIFUNGALS FOR TOPICAL USE"
          },
          {
            "code" : "D01AA",
            "display" : "Antibiotics"
          },
          {
            "code" : "D01AA01",
            "display" : "nystatin"
          },
          {
            "code" : "D01AA02",
            "display" : "natamycin"
          },
          {
            "code" : "D01AA03",
            "display" : "hachimycin"
          },
          {
            "code" : "D01AA04",
            "display" : "pecilocin"
          },
          {
            "code" : "D01AA06",
            "display" : "mepartricin"
          },
          {
            "code" : "D01AA07",
            "display" : "pyrrolnitrin"
          },
          {
            "code" : "D01AA08",
            "display" : "griseofulvin"
          },
          {
            "code" : "D01AA20",
            "display" : "antibiotics in combination with corticosteroids"
          },
          {
            "code" : "D01AC",
            "display" : "Imidazole and triazole derivatives"
          },
          {
            "code" : "D01AC01",
            "display" : "clotrimazole"
          },
          {
            "code" : "D01AC02",
            "display" : "miconazole"
          },
          {
            "code" : "D01AC03",
            "display" : "econazole"
          },
          {
            "code" : "D01AC04",
            "display" : "chlormidazole"
          },
          {
            "code" : "D01AC05",
            "display" : "isoconazole"
          },
          {
            "code" : "D01AC06",
            "display" : "tiabendazole"
          },
          {
            "code" : "D01AC07",
            "display" : "tioconazole"
          },
          {
            "code" : "D01AC08",
            "display" : "ketoconazole"
          },
          {
            "code" : "D01AC09",
            "display" : "sulconazole"
          },
          {
            "code" : "D01AC10",
            "display" : "bifonazole"
          },
          {
            "code" : "D01AC11",
            "display" : "oxiconazole"
          },
          {
            "code" : "D01AC12",
            "display" : "fenticonazole"
          },
          {
            "code" : "D01AC13",
            "display" : "omoconazole"
          },
          {
            "code" : "D01AC14",
            "display" : "sertaconazole"
          },
          {
            "code" : "D01AC15",
            "display" : "fluconazole"
          },
          {
            "code" : "D01AC16",
            "display" : "flutrimazole"
          },
          {
            "code" : "D01AC17",
            "display" : "eberconazole"
          },
          {
            "code" : "D01AC18",
            "display" : "luliconazole"
          },
          {
            "code" : "D01AC19",
            "display" : "efinaconazole"
          },
          {
            "code" : "D01AC20",
            "display" : "imidazoles/triazoles in combination with corticosteroids"
          },
          {
            "code" : "D01AC21",
            "display" : "neticonazole"
          },
          {
            "code" : "D01AC22",
            "display" : "lanoconazole"
          },
          {
            "code" : "D01AC52",
            "display" : "miconazole, combinations"
          },
          {
            "code" : "D01AC60",
            "display" : "bifonazole, combinations"
          },
          {
            "code" : "D01AE",
            "display" : "Other antifungals for topical use"
          },
          {
            "code" : "D01AE01",
            "display" : "bromochlorosalicylanilide"
          },
          {
            "code" : "D01AE02",
            "display" : "methylrosaniline"
          },
          {
            "code" : "D01AE03",
            "display" : "tribromometacresol"
          },
          {
            "code" : "D01AE04",
            "display" : "undecylenic acid"
          },
          {
            "code" : "D01AE05",
            "display" : "polynoxylin"
          },
          {
            "code" : "D01AE06",
            "display" : "2-(4-chlorphenoxy)-ethanol"
          },
          {
            "code" : "D01AE07",
            "display" : "chlorphenesin"
          },
          {
            "code" : "D01AE08",
            "display" : "ticlatone"
          },
          {
            "code" : "D01AE09",
            "display" : "sulbentine"
          },
          {
            "code" : "D01AE10",
            "display" : "ethyl hydroxybenzoate"
          },
          {
            "code" : "D01AE11",
            "display" : "haloprogin"
          },
          {
            "code" : "D01AE12",
            "display" : "salicylic acid"
          },
          {
            "code" : "D01AE13",
            "display" : "selenium sulfide"
          },
          {
            "code" : "D01AE14",
            "display" : "ciclopirox"
          },
          {
            "code" : "D01AE15",
            "display" : "terbinafine"
          },
          {
            "code" : "D01AE16",
            "display" : "amorolfine"
          },
          {
            "code" : "D01AE17",
            "display" : "dimazole"
          },
          {
            "code" : "D01AE18",
            "display" : "tolnaftate"
          },
          {
            "code" : "D01AE19",
            "display" : "tolciclate"
          },
          {
            "code" : "D01AE20",
            "display" : "combinations"
          },
          {
            "code" : "D01AE21",
            "display" : "flucytosine"
          },
          {
            "code" : "D01AE22",
            "display" : "naftifine"
          },
          {
            "code" : "D01AE23",
            "display" : "butenafine"
          },
          {
            "code" : "D01AE24",
            "display" : "tavaborole"
          },
          {
            "code" : "D01AE25",
            "display" : "liranaftate"
          },
          {
            "code" : "D01AE54",
            "display" : "undecylenic acid, combinations"
          },
          {
            "code" : "D01B",
            "display" : "ANTIFUNGALS FOR SYSTEMIC USE"
          },
          {
            "code" : "D01BA",
            "display" : "Antifungals for systemic use"
          },
          {
            "code" : "D01BA01",
            "display" : "griseofulvin"
          },
          {
            "code" : "D01BA02",
            "display" : "terbinafine"
          },
          {
            "code" : "D01BA03",
            "display" : "fosravuconazole"
          },
          {
            "code" : "D02",
            "display" : "EMOLLIENTS AND PROTECTIVES"
          },
          {
            "code" : "D02A",
            "display" : "EMOLLIENTS AND PROTECTIVES"
          },
          {
            "code" : "D02AA",
            "display" : "Silicone products"
          },
          {
            "code" : "D02AB",
            "display" : "Zinc products"
          },
          {
            "code" : "D02AC",
            "display" : "Soft paraffin and fat products"
          },
          {
            "code" : "D02AD",
            "display" : "Liquid plasters"
          },
          {
            "code" : "D02AE",
            "display" : "Carbamide products"
          },
          {
            "code" : "D02AE01",
            "display" : "carbamide"
          },
          {
            "code" : "D02AE51",
            "display" : "carbamide, combinations"
          },
          {
            "code" : "D02AF",
            "display" : "Salicylic acid preparations"
          },
          {
            "code" : "D02AX",
            "display" : "Other emollients and protectives"
          },
          {
            "code" : "D02B",
            "display" : "PROTECTIVES AGAINST UV-RADIATION"
          },
          {
            "code" : "D02BA",
            "display" : "Protectives against UV-radiation for topical use"
          },
          {
            "code" : "D02BA01",
            "display" : "aminobenzoic acid"
          },
          {
            "code" : "D02BA02",
            "display" : "octinoxate"
          },
          {
            "code" : "D02BB",
            "display" : "Protectives against UV-radiation for systemic use"
          },
          {
            "code" : "D02BB01",
            "display" : "betacarotene"
          },
          {
            "code" : "D02BB02",
            "display" : "afamelanotide"
          },
          {
            "code" : "D03",
            "display" : "PREPARATIONS FOR TREATMENT OF WOUNDS AND ULCERS"
          },
          {
            "code" : "D03A",
            "display" : "CICATRIZANTS"
          },
          {
            "code" : "D03AA",
            "display" : "Cod-liver oil ointments"
          },
          {
            "code" : "D03AX",
            "display" : "Other cicatrizants"
          },
          {
            "code" : "D03AX01",
            "display" : "cadexomer iodine"
          },
          {
            "code" : "D03AX02",
            "display" : "dextranomer"
          },
          {
            "code" : "D03AX03",
            "display" : "dexpanthenol"
          },
          {
            "code" : "D03AX04",
            "display" : "calcium pantothenate"
          },
          {
            "code" : "D03AX05",
            "display" : "hyaluronic acid"
          },
          {
            "code" : "D03AX06",
            "display" : "becaplermin"
          },
          {
            "code" : "D03AX09",
            "display" : "crilanomer"
          },
          {
            "code" : "D03AX10",
            "display" : "enoxolone"
          },
          {
            "code" : "D03AX11",
            "display" : "sodium chlorite"
          },
          {
            "code" : "D03AX12",
            "display" : "trolamine"
          },
          {
            "code" : "D03AX13",
            "display" : "Betulae cortex"
          },
          {
            "code" : "D03AX14",
            "display" : "Centella asiatica herba, incl. combinations"
          },
          {
            "code" : "D03AX15",
            "display" : "trafermin"
          },
          {
            "code" : "D03AX16",
            "display" : "beremagene geperpavec"
          },
          {
            "code" : "D03B",
            "display" : "ENZYMES"
          },
          {
            "code" : "D03BA",
            "display" : "Proteolytic enzymes"
          },
          {
            "code" : "D03BA01",
            "display" : "trypsin"
          },
          {
            "code" : "D03BA02",
            "display" : "collagenase"
          },
          {
            "code" : "D03BA03",
            "display" : "bromelains"
          },
          {
            "code" : "D03BA52",
            "display" : "collagenase, combinations"
          },
          {
            "code" : "D04",
            "display" : "ANTIPRURITICS, INCL. ANTIHISTAMINES, ANESTHETICS, ETC."
          },
          {
            "code" : "D04A",
            "display" : "ANTIPRURITICS, INCL. ANTIHISTAMINES, ANESTHETICS, ETC."
          },
          {
            "code" : "D04AA",
            "display" : "Antihistamines for topical use"
          },
          {
            "code" : "D04AA01",
            "display" : "thonzylamine"
          },
          {
            "code" : "D04AA02",
            "display" : "mepyramine"
          },
          {
            "code" : "D04AA03",
            "display" : "thenalidine"
          },
          {
            "code" : "D04AA04",
            "display" : "tripelennamine"
          },
          {
            "code" : "D04AA09",
            "display" : "chloropyramine"
          },
          {
            "code" : "D04AA10",
            "display" : "promethazine"
          },
          {
            "code" : "D04AA12",
            "display" : "tolpropamine"
          },
          {
            "code" : "D04AA13",
            "display" : "dimetindene"
          },
          {
            "code" : "D04AA14",
            "display" : "clemastine"
          },
          {
            "code" : "D04AA15",
            "display" : "bamipine"
          },
          {
            "code" : "D04AA16",
            "display" : "pheniramine"
          },
          {
            "code" : "D04AA22",
            "display" : "isothipendyl"
          },
          {
            "code" : "D04AA32",
            "display" : "diphenhydramine"
          },
          {
            "code" : "D04AA33",
            "display" : "diphenhydramine methylbromide"
          },
          {
            "code" : "D04AA34",
            "display" : "chlorphenoxamine"
          },
          {
            "code" : "D04AB",
            "display" : "Anesthetics for topical use"
          },
          {
            "code" : "D04AB01",
            "display" : "lidocaine"
          },
          {
            "code" : "D04AB02",
            "display" : "cinchocaine"
          },
          {
            "code" : "D04AB03",
            "display" : "oxybuprocaine"
          },
          {
            "code" : "D04AB04",
            "display" : "benzocaine"
          },
          {
            "code" : "D04AB05",
            "display" : "quinisocaine"
          },
          {
            "code" : "D04AB06",
            "display" : "tetracaine"
          },
          {
            "code" : "D04AB07",
            "display" : "pramocaine"
          },
          {
            "code" : "D04AX",
            "display" : "Other antipruritics"
          },
          {
            "code" : "D04AX01",
            "display" : "doxepin"
          },
          {
            "code" : "D05",
            "display" : "ANTIPSORIATICS"
          },
          {
            "code" : "D05A",
            "display" : "ANTIPSORIATICS FOR TOPICAL USE"
          },
          {
            "code" : "D05AA",
            "display" : "Tars"
          },
          {
            "code" : "D05AC",
            "display" : "Antracen derivatives"
          },
          {
            "code" : "D05AC01",
            "display" : "dithranol"
          },
          {
            "code" : "D05AC51",
            "display" : "dithranol, combinations"
          },
          {
            "code" : "D05AD",
            "display" : "Psoralens for topical use"
          },
          {
            "code" : "D05AD01",
            "display" : "trioxysalen"
          },
          {
            "code" : "D05AD02",
            "display" : "methoxsalen"
          },
          {
            "code" : "D05AX",
            "display" : "Other antipsoriatics for topical use"
          },
          {
            "code" : "D05AX01",
            "display" : "fumaric acid"
          },
          {
            "code" : "D05AX02",
            "display" : "calcipotriol"
          },
          {
            "code" : "D05AX03",
            "display" : "calcitriol"
          },
          {
            "code" : "D05AX04",
            "display" : "tacalcitol"
          },
          {
            "code" : "D05AX05",
            "display" : "tazarotene"
          },
          {
            "code" : "D05AX06",
            "display" : "roflumilast"
          },
          {
            "code" : "D05AX07",
            "display" : "tapinarof"
          },
          {
            "code" : "D05AX52",
            "display" : "calcipotriol, combinations"
          },
          {
            "code" : "D05AX55",
            "display" : "tazarotene and ulobetasol"
          },
          {
            "code" : "D05B",
            "display" : "ANTIPSORIATICS FOR SYSTEMIC USE"
          },
          {
            "code" : "D05BA",
            "display" : "Psoralens for systemic use"
          },
          {
            "code" : "D05BA01",
            "display" : "trioxysalen"
          },
          {
            "code" : "D05BA02",
            "display" : "methoxsalen"
          },
          {
            "code" : "D05BA03",
            "display" : "bergapten"
          },
          {
            "code" : "D05BB",
            "display" : "Retinoids for treatment of psoriasis"
          },
          {
            "code" : "D05BB01",
            "display" : "etretinate"
          },
          {
            "code" : "D05BB02",
            "display" : "acitretin"
          },
          {
            "code" : "D05BX",
            "display" : "Other antipsoriatics for systemic use"
          },
          {
            "code" : "D05BX51",
            "display" : "fumaric acid derivatives, combinations"
          },
          {
            "code" : "D06",
            "display" : "ANTIBIOTICS AND CHEMOTHERAPEUTICS FOR DERMATOLOGICAL USE"
          },
          {
            "code" : "D06A",
            "display" : "ANTIBIOTICS FOR TOPICAL USE"
          },
          {
            "code" : "D06AA",
            "display" : "Tetracycline and derivatives"
          },
          {
            "code" : "D06AA01",
            "display" : "demeclocycline"
          },
          {
            "code" : "D06AA02",
            "display" : "chlortetracycline"
          },
          {
            "code" : "D06AA03",
            "display" : "oxytetracycline"
          },
          {
            "code" : "D06AA04",
            "display" : "tetracycline"
          },
          {
            "code" : "D06AX",
            "display" : "Other antibiotics for topical use"
          },
          {
            "code" : "D06AX01",
            "display" : "fusidic acid"
          },
          {
            "code" : "D06AX02",
            "display" : "chloramphenicol"
          },
          {
            "code" : "D06AX04",
            "display" : "neomycin"
          },
          {
            "code" : "D06AX05",
            "display" : "bacitracin"
          },
          {
            "code" : "D06AX07",
            "display" : "gentamicin"
          },
          {
            "code" : "D06AX08",
            "display" : "tyrothricin"
          },
          {
            "code" : "D06AX09",
            "display" : "mupirocin"
          },
          {
            "code" : "D06AX10",
            "display" : "virginiamycin"
          },
          {
            "code" : "D06AX11",
            "display" : "rifaximin"
          },
          {
            "code" : "D06AX12",
            "display" : "amikacin"
          },
          {
            "code" : "D06AX13",
            "display" : "retapamulin"
          },
          {
            "code" : "D06AX14",
            "display" : "ozenoxacin"
          },
          {
            "code" : "D06AX15",
            "display" : "rifamycin"
          },
          {
            "code" : "D06B",
            "display" : "CHEMOTHERAPEUTICS FOR TOPICAL USE"
          },
          {
            "code" : "D06BA",
            "display" : "Sulfonamides"
          },
          {
            "code" : "D06BA01",
            "display" : "silver sulfadiazine"
          },
          {
            "code" : "D06BA02",
            "display" : "sulfathiazole"
          },
          {
            "code" : "D06BA03",
            "display" : "mafenide"
          },
          {
            "code" : "D06BA04",
            "display" : "sulfamethizole"
          },
          {
            "code" : "D06BA05",
            "display" : "sulfanilamide"
          },
          {
            "code" : "D06BA06",
            "display" : "sulfamerazine"
          },
          {
            "code" : "D06BA51",
            "display" : "silver sulfadiazine, combinations"
          },
          {
            "code" : "D06BB",
            "display" : "Antivirals"
          },
          {
            "code" : "D06BB01",
            "display" : "idoxuridine"
          },
          {
            "code" : "D06BB02",
            "display" : "tromantadine"
          },
          {
            "code" : "D06BB03",
            "display" : "aciclovir"
          },
          {
            "code" : "D06BB04",
            "display" : "podophyllotoxin"
          },
          {
            "code" : "D06BB05",
            "display" : "inosine"
          },
          {
            "code" : "D06BB06",
            "display" : "penciclovir"
          },
          {
            "code" : "D06BB07",
            "display" : "lysozyme"
          },
          {
            "code" : "D06BB08",
            "display" : "ibacitabine"
          },
          {
            "code" : "D06BB09",
            "display" : "edoxudine"
          },
          {
            "code" : "D06BB10",
            "display" : "imiquimod"
          },
          {
            "code" : "D06BB11",
            "display" : "docosanol"
          },
          {
            "code" : "D06BB12",
            "display" : "sinecatechins"
          },
          {
            "code" : "D06BB53",
            "display" : "aciclovir, combinations"
          },
          {
            "code" : "D06BX",
            "display" : "Other chemotherapeutics"
          },
          {
            "code" : "D06BX01",
            "display" : "metronidazole"
          },
          {
            "code" : "D06BX02",
            "display" : "ingenol mebutate"
          },
          {
            "code" : "D06BX03",
            "display" : "tirbanibulin"
          },
          {
            "code" : "D06C",
            "display" : "ANTIBIOTICS AND CHEMOTHERAPEUTICS, COMBINATIONS"
          },
          {
            "code" : "D07",
            "display" : "CORTICOSTEROIDS, DERMATOLOGICAL PREPARATIONS"
          },
          {
            "code" : "D07A",
            "display" : "CORTICOSTEROIDS, PLAIN"
          },
          {
            "code" : "D07AA",
            "display" : "Corticosteroids, weak (group I)"
          },
          {
            "code" : "D07AA01",
            "display" : "methylprednisolone"
          },
          {
            "code" : "D07AA02",
            "display" : "hydrocortisone"
          },
          {
            "code" : "D07AA03",
            "display" : "prednisolone"
          },
          {
            "code" : "D07AB",
            "display" : "Corticosteroids, moderately potent (group II)"
          },
          {
            "code" : "D07AB01",
            "display" : "clobetasone"
          },
          {
            "code" : "D07AB02",
            "display" : "hydrocortisone butyrate"
          },
          {
            "code" : "D07AB03",
            "display" : "flumetasone"
          },
          {
            "code" : "D07AB04",
            "display" : "fluocortin"
          },
          {
            "code" : "D07AB05",
            "display" : "fluperolone"
          },
          {
            "code" : "D07AB06",
            "display" : "fluorometholone"
          },
          {
            "code" : "D07AB07",
            "display" : "fluprednidene"
          },
          {
            "code" : "D07AB08",
            "display" : "desonide"
          },
          {
            "code" : "D07AB09",
            "display" : "triamcinolone"
          },
          {
            "code" : "D07AB10",
            "display" : "alclometasone"
          },
          {
            "code" : "D07AB11",
            "display" : "hydrocortisone buteprate"
          },
          {
            "code" : "D07AB19",
            "display" : "dexamethasone"
          },
          {
            "code" : "D07AB21",
            "display" : "clocortolone"
          },
          {
            "code" : "D07AB30",
            "display" : "combinations of corticosteroids"
          },
          {
            "code" : "D07AC",
            "display" : "Corticosteroids, potent (group III)"
          },
          {
            "code" : "D07AC01",
            "display" : "betamethasone"
          },
          {
            "code" : "D07AC02",
            "display" : "fluclorolone"
          },
          {
            "code" : "D07AC03",
            "display" : "desoximetasone"
          },
          {
            "code" : "D07AC04",
            "display" : "fluocinolone acetonide"
          },
          {
            "code" : "D07AC05",
            "display" : "fluocortolone"
          },
          {
            "code" : "D07AC06",
            "display" : "diflucortolone"
          },
          {
            "code" : "D07AC07",
            "display" : "fludroxycortide"
          },
          {
            "code" : "D07AC08",
            "display" : "fluocinonide"
          },
          {
            "code" : "D07AC09",
            "display" : "budesonide"
          },
          {
            "code" : "D07AC10",
            "display" : "diflorasone"
          },
          {
            "code" : "D07AC11",
            "display" : "amcinonide"
          },
          {
            "code" : "D07AC12",
            "display" : "halometasone"
          },
          {
            "code" : "D07AC13",
            "display" : "mometasone"
          },
          {
            "code" : "D07AC14",
            "display" : "methylprednisolone aceponate"
          },
          {
            "code" : "D07AC15",
            "display" : "beclometasone"
          },
          {
            "code" : "D07AC16",
            "display" : "hydrocortisone aceponate"
          },
          {
            "code" : "D07AC17",
            "display" : "fluticasone"
          },
          {
            "code" : "D07AC18",
            "display" : "prednicarbate"
          },
          {
            "code" : "D07AC19",
            "display" : "difluprednate"
          },
          {
            "code" : "D07AC21",
            "display" : "ulobetasol"
          },
          {
            "code" : "D07AD",
            "display" : "Corticosteroids, very potent (group IV)"
          },
          {
            "code" : "D07AD01",
            "display" : "clobetasol"
          },
          {
            "code" : "D07AD02",
            "display" : "halcinonide"
          },
          {
            "code" : "D07B",
            "display" : "CORTICOSTEROIDS, COMBINATIONS WITH ANTISEPTICS"
          },
          {
            "code" : "D07BA",
            "display" : "Corticosteroids, weak, combinations with antiseptics"
          },
          {
            "code" : "D07BA01",
            "display" : "prednisolone and antiseptics"
          },
          {
            "code" : "D07BA04",
            "display" : "hydrocortisone and antiseptics"
          },
          {
            "code" : "D07BB",
            "display" : "Corticosteroids, moderately potent, combinations with antiseptics"
          },
          {
            "code" : "D07BB01",
            "display" : "flumetasone and antiseptics"
          },
          {
            "code" : "D07BB02",
            "display" : "desonide and antiseptics"
          },
          {
            "code" : "D07BB03",
            "display" : "triamcinolone and antiseptics"
          },
          {
            "code" : "D07BB04",
            "display" : "hydrocortisone butyrate and antiseptics"
          },
          {
            "code" : "D07BC",
            "display" : "Corticosteroids, potent, combinations with antiseptics"
          },
          {
            "code" : "D07BC01",
            "display" : "betamethasone and antiseptics"
          },
          {
            "code" : "D07BC02",
            "display" : "fluocinolone acetonide and antiseptics"
          },
          {
            "code" : "D07BC03",
            "display" : "fluocortolone and antiseptics"
          },
          {
            "code" : "D07BC04",
            "display" : "diflucortolone and antiseptics"
          },
          {
            "code" : "D07BD",
            "display" : "Corticosteroids, very potent, combinations with antiseptics"
          },
          {
            "code" : "D07C",
            "display" : "CORTICOSTEROIDS, COMBINATIONS WITH ANTIBIOTICS"
          },
          {
            "code" : "D07CA",
            "display" : "Corticosteroids, weak, combinations with antibiotics"
          },
          {
            "code" : "D07CA01",
            "display" : "hydrocortisone and antibiotics"
          },
          {
            "code" : "D07CA02",
            "display" : "methylprednisolone and antibiotics"
          },
          {
            "code" : "D07CA03",
            "display" : "prednisolone and antibiotics"
          },
          {
            "code" : "D07CB",
            "display" : "Corticosteroids, moderately potent, combinations with antibiotics"
          },
          {
            "code" : "D07CB01",
            "display" : "triamcinolone and antibiotics"
          },
          {
            "code" : "D07CB02",
            "display" : "fluprednidene and antibiotics"
          },
          {
            "code" : "D07CB03",
            "display" : "fluorometholone and antibiotics"
          },
          {
            "code" : "D07CB04",
            "display" : "dexamethasone and antibiotics"
          },
          {
            "code" : "D07CB05",
            "display" : "flumetasone and antibiotics"
          },
          {
            "code" : "D07CC",
            "display" : "Corticosteroids, potent, combinations with antibiotics"
          },
          {
            "code" : "D07CC01",
            "display" : "betamethasone and antibiotics"
          },
          {
            "code" : "D07CC02",
            "display" : "fluocinolone acetonide and antibiotics"
          },
          {
            "code" : "D07CC03",
            "display" : "fludroxycortide and antibiotics"
          },
          {
            "code" : "D07CC04",
            "display" : "beclometasone and antibiotics"
          },
          {
            "code" : "D07CC05",
            "display" : "fluocinonide and antibiotics"
          },
          {
            "code" : "D07CC06",
            "display" : "fluocortolone and antibiotics"
          },
          {
            "code" : "D07CD",
            "display" : "Corticosteroids, very potent, combinations with antibiotics"
          },
          {
            "code" : "D07CD01",
            "display" : "clobetasol and antibiotics"
          },
          {
            "code" : "D07X",
            "display" : "CORTICOSTEROIDS, OTHER COMBINATIONS"
          },
          {
            "code" : "D07XA",
            "display" : "Corticosteroids, weak, other combinations"
          },
          {
            "code" : "D07XA01",
            "display" : "hydrocortisone"
          },
          {
            "code" : "D07XA02",
            "display" : "prednisolone"
          },
          {
            "code" : "D07XB",
            "display" : "Corticosteroids, moderately potent, other combinations"
          },
          {
            "code" : "D07XB01",
            "display" : "flumetasone"
          },
          {
            "code" : "D07XB02",
            "display" : "triamcinolone"
          },
          {
            "code" : "D07XB03",
            "display" : "fluprednidene"
          },
          {
            "code" : "D07XB04",
            "display" : "fluorometholone"
          },
          {
            "code" : "D07XB05",
            "display" : "dexamethasone"
          },
          {
            "code" : "D07XB30",
            "display" : "combinations of corticosteroids"
          },
          {
            "code" : "D07XC",
            "display" : "Corticosteroids, potent, other combinations"
          },
          {
            "code" : "D07XC01",
            "display" : "betamethasone"
          },
          {
            "code" : "D07XC02",
            "display" : "desoximetasone"
          },
          {
            "code" : "D07XC03",
            "display" : "mometasone"
          },
          {
            "code" : "D07XC04",
            "display" : "diflucortolone"
          },
          {
            "code" : "D07XC05",
            "display" : "fluocortolone"
          },
          {
            "code" : "D07XD",
            "display" : "Corticosteroids, very potent, other combinations"
          },
          {
            "code" : "D08",
            "display" : "ANTISEPTICS AND DISINFECTANTS"
          },
          {
            "code" : "D08A",
            "display" : "ANTISEPTICS AND DISINFECTANTS"
          },
          {
            "code" : "D08AA",
            "display" : "Acridine derivatives"
          },
          {
            "code" : "D08AA01",
            "display" : "ethacridine lactate"
          },
          {
            "code" : "D08AA02",
            "display" : "aminoacridine"
          },
          {
            "code" : "D08AA03",
            "display" : "euflavine"
          },
          {
            "code" : "D08AB",
            "display" : "Aluminium agents"
          },
          {
            "code" : "D08AC",
            "display" : "Biguanides and amidines"
          },
          {
            "code" : "D08AC01",
            "display" : "dibrompropamidine"
          },
          {
            "code" : "D08AC02",
            "display" : "chlorhexidine"
          },
          {
            "code" : "D08AC03",
            "display" : "propamidine"
          },
          {
            "code" : "D08AC04",
            "display" : "hexamidine"
          },
          {
            "code" : "D08AC05",
            "display" : "polihexanide"
          },
          {
            "code" : "D08AC52",
            "display" : "chlorhexidine, combinations"
          },
          {
            "code" : "D08AD",
            "display" : "Boric acid products"
          },
          {
            "code" : "D08AE",
            "display" : "Phenol and derivatives"
          },
          {
            "code" : "D08AE01",
            "display" : "hexachlorophene"
          },
          {
            "code" : "D08AE02",
            "display" : "policresulen"
          },
          {
            "code" : "D08AE03",
            "display" : "phenol"
          },
          {
            "code" : "D08AE04",
            "display" : "triclosan"
          },
          {
            "code" : "D08AE05",
            "display" : "chloroxylenol"
          },
          {
            "code" : "D08AE06",
            "display" : "biphenylol"
          },
          {
            "code" : "D08AF",
            "display" : "Nitrofuran derivatives"
          },
          {
            "code" : "D08AF01",
            "display" : "nitrofural"
          },
          {
            "code" : "D08AG",
            "display" : "Iodine products"
          },
          {
            "code" : "D08AG01",
            "display" : "iodine/octylphenoxypolyglycolether"
          },
          {
            "code" : "D08AG02",
            "display" : "povidone-iodine"
          },
          {
            "code" : "D08AG03",
            "display" : "iodine"
          },
          {
            "code" : "D08AG04",
            "display" : "diiodohydroxypropane"
          },
          {
            "code" : "D08AH",
            "display" : "Quinoline derivatives"
          },
          {
            "code" : "D08AH01",
            "display" : "dequalinium"
          },
          {
            "code" : "D08AH02",
            "display" : "chlorquinaldol"
          },
          {
            "code" : "D08AH03",
            "display" : "oxyquinoline"
          },
          {
            "code" : "D08AH30",
            "display" : "clioquinol"
          },
          {
            "code" : "D08AJ",
            "display" : "Quaternary ammonium compounds"
          },
          {
            "code" : "D08AJ01",
            "display" : "benzalkonium"
          },
          {
            "code" : "D08AJ02",
            "display" : "cetrimonium"
          },
          {
            "code" : "D08AJ03",
            "display" : "cetylpyridinium"
          },
          {
            "code" : "D08AJ04",
            "display" : "cetrimide"
          },
          {
            "code" : "D08AJ05",
            "display" : "benzoxonium chloride"
          },
          {
            "code" : "D08AJ06",
            "display" : "didecyldimethylammonium chloride"
          },
          {
            "code" : "D08AJ08",
            "display" : "benzethonium chloride"
          },
          {
            "code" : "D08AJ10",
            "display" : "decamethoxine"
          },
          {
            "code" : "D08AJ57",
            "display" : "octenidine, combinations"
          },
          {
            "code" : "D08AJ58",
            "display" : "benzethonium chloride, combinations"
          },
          {
            "code" : "D08AJ59",
            "display" : "dodeclonium bromide, combinations"
          },
          {
            "code" : "D08AK",
            "display" : "Mercurial products"
          },
          {
            "code" : "D08AK01",
            "display" : "mercuric amidochloride"
          },
          {
            "code" : "D08AK02",
            "display" : "phenylmercuric borate"
          },
          {
            "code" : "D08AK03",
            "display" : "mercuric chloride"
          },
          {
            "code" : "D08AK04",
            "display" : "merbromin"
          },
          {
            "code" : "D08AK05",
            "display" : "mercury, metallic"
          },
          {
            "code" : "D08AK06",
            "display" : "thiomersal"
          },
          {
            "code" : "D08AK30",
            "display" : "mercuric iodide"
          },
          {
            "code" : "D08AL",
            "display" : "Silver compounds"
          },
          {
            "code" : "D08AL01",
            "display" : "silver nitrate"
          },
          {
            "code" : "D08AL30",
            "display" : "silver"
          },
          {
            "code" : "D08AX",
            "display" : "Other antiseptics and disinfectants"
          },
          {
            "code" : "D08AX01",
            "display" : "hydrogen peroxide"
          },
          {
            "code" : "D08AX02",
            "display" : "eosin"
          },
          {
            "code" : "D08AX03",
            "display" : "propanol"
          },
          {
            "code" : "D08AX04",
            "display" : "tosylchloramide sodium"
          },
          {
            "code" : "D08AX05",
            "display" : "isopropanol"
          },
          {
            "code" : "D08AX06",
            "display" : "potassium permanganate"
          },
          {
            "code" : "D08AX07",
            "display" : "sodium hypochlorite"
          },
          {
            "code" : "D08AX08",
            "display" : "ethanol"
          },
          {
            "code" : "D08AX53",
            "display" : "propanol, combinations"
          },
          {
            "code" : "D09",
            "display" : "MEDICATED DRESSINGS"
          },
          {
            "code" : "D09A",
            "display" : "MEDICATED DRESSINGS"
          },
          {
            "code" : "D09AA",
            "display" : "Medicated dressings with antiinfectives"
          },
          {
            "code" : "D09AA01",
            "display" : "framycetin"
          },
          {
            "code" : "D09AA02",
            "display" : "fusidic acid"
          },
          {
            "code" : "D09AA03",
            "display" : "nitrofural"
          },
          {
            "code" : "D09AA04",
            "display" : "phenylmercuric nitrate"
          },
          {
            "code" : "D09AA05",
            "display" : "benzododecinium"
          },
          {
            "code" : "D09AA06",
            "display" : "triclosan"
          },
          {
            "code" : "D09AA07",
            "display" : "cetylpyridinium"
          },
          {
            "code" : "D09AA08",
            "display" : "aluminium chlorohydrate"
          },
          {
            "code" : "D09AA09",
            "display" : "povidone-iodine"
          },
          {
            "code" : "D09AA10",
            "display" : "clioquinol"
          },
          {
            "code" : "D09AA11",
            "display" : "benzalkonium"
          },
          {
            "code" : "D09AA12",
            "display" : "chlorhexidine"
          },
          {
            "code" : "D09AA13",
            "display" : "iodoform"
          },
          {
            "code" : "D09AB",
            "display" : "Zinc bandages"
          },
          {
            "code" : "D09AB01",
            "display" : "zinc bandage without supplements"
          },
          {
            "code" : "D09AB02",
            "display" : "zinc bandage with supplements"
          },
          {
            "code" : "D09AX",
            "display" : "Soft paraffin dressings"
          },
          {
            "code" : "D10",
            "display" : "ANTI-ACNE PREPARATIONS"
          },
          {
            "code" : "D10A",
            "display" : "ANTI-ACNE PREPARATIONS FOR TOPICAL USE"
          },
          {
            "code" : "D10AA",
            "display" : "Corticosteroids, combinations for treatment of acne"
          },
          {
            "code" : "D10AA01",
            "display" : "fluorometholone"
          },
          {
            "code" : "D10AA02",
            "display" : "methylprednisolone"
          },
          {
            "code" : "D10AA03",
            "display" : "dexamethasone"
          },
          {
            "code" : "D10AB",
            "display" : "Preparations containing sulfur"
          },
          {
            "code" : "D10AB01",
            "display" : "bithionol"
          },
          {
            "code" : "D10AB02",
            "display" : "sulfur"
          },
          {
            "code" : "D10AB03",
            "display" : "tioxolone"
          },
          {
            "code" : "D10AB05",
            "display" : "mesulfen"
          },
          {
            "code" : "D10AD",
            "display" : "Retinoids for topical use in acne"
          },
          {
            "code" : "D10AD01",
            "display" : "tretinoin"
          },
          {
            "code" : "D10AD02",
            "display" : "retinol"
          },
          {
            "code" : "D10AD03",
            "display" : "adapalene"
          },
          {
            "code" : "D10AD04",
            "display" : "isotretinoin"
          },
          {
            "code" : "D10AD05",
            "display" : "motretinide"
          },
          {
            "code" : "D10AD06",
            "display" : "trifarotene"
          },
          {
            "code" : "D10AD51",
            "display" : "tretinoin, combinations"
          },
          {
            "code" : "D10AD53",
            "display" : "adapalene, combinations"
          },
          {
            "code" : "D10AD54",
            "display" : "isotretinoin, combinations"
          },
          {
            "code" : "D10AE",
            "display" : "Peroxides"
          },
          {
            "code" : "D10AE01",
            "display" : "benzoyl peroxide"
          },
          {
            "code" : "D10AE51",
            "display" : "benzoyl peroxide, combinations"
          },
          {
            "code" : "D10AF",
            "display" : "Antiinfectives for treatment of acne"
          },
          {
            "code" : "D10AF01",
            "display" : "clindamycin"
          },
          {
            "code" : "D10AF02",
            "display" : "erythromycin"
          },
          {
            "code" : "D10AF03",
            "display" : "chloramphenicol"
          },
          {
            "code" : "D10AF04",
            "display" : "meclocycline"
          },
          {
            "code" : "D10AF05",
            "display" : "nadifloxacin"
          },
          {
            "code" : "D10AF06",
            "display" : "sulfacetamide"
          },
          {
            "code" : "D10AF07",
            "display" : "minocycline"
          },
          {
            "code" : "D10AF51",
            "display" : "clindamycin, combinations"
          },
          {
            "code" : "D10AF52",
            "display" : "erythromycin, combinations"
          },
          {
            "code" : "D10AX",
            "display" : "Other anti-acne preparations for topical use"
          },
          {
            "code" : "D10AX01",
            "display" : "aluminium chloride"
          },
          {
            "code" : "D10AX02",
            "display" : "resorcinol"
          },
          {
            "code" : "D10AX03",
            "display" : "azelaic acid"
          },
          {
            "code" : "D10AX04",
            "display" : "aluminium oxide"
          },
          {
            "code" : "D10AX05",
            "display" : "dapsone"
          },
          {
            "code" : "D10AX06",
            "display" : "clascoterone"
          },
          {
            "code" : "D10AX30",
            "display" : "various combinations"
          },
          {
            "code" : "D10B",
            "display" : "ANTI-ACNE PREPARATIONS FOR SYSTEMIC USE"
          },
          {
            "code" : "D10BA",
            "display" : "Retinoids for treatment of acne"
          },
          {
            "code" : "D10BA01",
            "display" : "isotretinoin"
          },
          {
            "code" : "D10BX",
            "display" : "Other anti-acne preparations for systemic use"
          },
          {
            "code" : "D10BX01",
            "display" : "ichtasol"
          },
          {
            "code" : "D11",
            "display" : "OTHER DERMATOLOGICAL PREPARATIONS"
          },
          {
            "code" : "D11A",
            "display" : "OTHER DERMATOLOGICAL PREPARATIONS"
          },
          {
            "code" : "D11AA",
            "display" : "Antihidrotics"
          },
          {
            "code" : "D11AA01",
            "display" : "glycopyrronium"
          },
          {
            "code" : "D11AC",
            "display" : "Medicated shampoos"
          },
          {
            "code" : "D11AC01",
            "display" : "cetrimide"
          },
          {
            "code" : "D11AC02",
            "display" : "cadmium compounds"
          },
          {
            "code" : "D11AC03",
            "display" : "selenium compounds"
          },
          {
            "code" : "D11AC06",
            "display" : "povidone-iodine"
          },
          {
            "code" : "D11AC08",
            "display" : "sulfur compounds"
          },
          {
            "code" : "D11AC09",
            "display" : "xenysalate"
          },
          {
            "code" : "D11AC30",
            "display" : "others"
          },
          {
            "code" : "D11AE",
            "display" : "Androgens for topical use"
          },
          {
            "code" : "D11AE01",
            "display" : "metandienone"
          },
          {
            "code" : "D11AF",
            "display" : "Wart and anti-corn preparations"
          },
          {
            "code" : "D11AH",
            "display" : "Agents for dermatitis, excluding corticosteroids"
          },
          {
            "code" : "D11AH01",
            "display" : "tacrolimus"
          },
          {
            "code" : "D11AH02",
            "display" : "pimecrolimus"
          },
          {
            "code" : "D11AH03",
            "display" : "cromoglicic acid"
          },
          {
            "code" : "D11AH04",
            "display" : "alitretinoin"
          },
          {
            "code" : "D11AH05",
            "display" : "dupilumab"
          },
          {
            "code" : "D11AH06",
            "display" : "crisaborole"
          },
          {
            "code" : "D11AH07",
            "display" : "tralokinumab"
          },
          {
            "code" : "D11AH08",
            "display" : "abrocitinib"
          },
          {
            "code" : "D11AH09",
            "display" : "ruxolitinib"
          },
          {
            "code" : "D11AH10",
            "display" : "lebrikizumab"
          },
          {
            "code" : "D11AH11",
            "display" : "delgocitinib"
          },
          {
            "code" : "D11AH12",
            "display" : "nemolizumab"
          },
          {
            "code" : "D11AX",
            "display" : "Other dermatologicals"
          },
          {
            "code" : "D11AX01",
            "display" : "minoxidil"
          },
          {
            "code" : "D11AX02",
            "display" : "gamolenic acid"
          },
          {
            "code" : "D11AX03",
            "display" : "calcium gluconate"
          },
          {
            "code" : "D11AX04",
            "display" : "lithium succinate"
          },
          {
            "code" : "D11AX05",
            "display" : "magnesium sulfate"
          },
          {
            "code" : "D11AX06",
            "display" : "mequinol"
          },
          {
            "code" : "D11AX08",
            "display" : "tiratricol"
          },
          {
            "code" : "D11AX09",
            "display" : "oxaceprol"
          },
          {
            "code" : "D11AX10",
            "display" : "finasteride"
          },
          {
            "code" : "D11AX11",
            "display" : "hydroquinone"
          },
          {
            "code" : "D11AX12",
            "display" : "pyrithione zinc"
          },
          {
            "code" : "D11AX13",
            "display" : "monobenzone"
          },
          {
            "code" : "D11AX16",
            "display" : "eflornithine"
          },
          {
            "code" : "D11AX18",
            "display" : "diclofenac"
          },
          {
            "code" : "D11AX21",
            "display" : "brimonidine"
          },
          {
            "code" : "D11AX22",
            "display" : "ivermectin"
          },
          {
            "code" : "D11AX23",
            "display" : "aminobenzoate potassium"
          },
          {
            "code" : "D11AX24",
            "display" : "deoxycholic acid"
          },
          {
            "code" : "D11AX25",
            "display" : "hydrogen peroxide"
          },
          {
            "code" : "D11AX26",
            "display" : "caffeine"
          },
          {
            "code" : "D11AX27",
            "display" : "oxymetazoline"
          },
          {
            "code" : "D11AX52",
            "display" : "gamolenic acid, combinations"
          },
          {
            "code" : "D11AX57",
            "display" : "collagen, combinations"
          },
          {
            "code" : "G",
            "display" : "GENITO URINARY SYSTEM AND SEX HORMONES"
          },
          {
            "code" : "G01",
            "display" : "GYNECOLOGICAL ANTIINFECTIVES AND ANTISEPTICS"
          },
          {
            "code" : "G01A",
            "display" : "ANTIINFECTIVES AND ANTISEPTICS, EXCL. COMBINATIONS WITH CORTICOSTEROIDS"
          },
          {
            "code" : "G01AA",
            "display" : "Antibiotics"
          },
          {
            "code" : "G01AA01",
            "display" : "nystatin"
          },
          {
            "code" : "G01AA02",
            "display" : "natamycin"
          },
          {
            "code" : "G01AA03",
            "display" : "amphotericin B"
          },
          {
            "code" : "G01AA04",
            "display" : "candicidin"
          },
          {
            "code" : "G01AA05",
            "display" : "chloramphenicol"
          },
          {
            "code" : "G01AA06",
            "display" : "hachimycin"
          },
          {
            "code" : "G01AA07",
            "display" : "oxytetracycline"
          },
          {
            "code" : "G01AA08",
            "display" : "carfecillin"
          },
          {
            "code" : "G01AA09",
            "display" : "mepartricin"
          },
          {
            "code" : "G01AA10",
            "display" : "clindamycin"
          },
          {
            "code" : "G01AA11",
            "display" : "pentamycin"
          },
          {
            "code" : "G01AA51",
            "display" : "nystatin, combinations"
          },
          {
            "code" : "G01AB",
            "display" : "Arsenic compounds"
          },
          {
            "code" : "G01AB01",
            "display" : "acetarsol"
          },
          {
            "code" : "G01AC",
            "display" : "Quinoline derivatives"
          },
          {
            "code" : "G01AC01",
            "display" : "diiodohydroxyquinoline"
          },
          {
            "code" : "G01AC02",
            "display" : "clioquinol"
          },
          {
            "code" : "G01AC03",
            "display" : "chlorquinaldol"
          },
          {
            "code" : "G01AC05",
            "display" : "dequalinium"
          },
          {
            "code" : "G01AC06",
            "display" : "broxyquinoline"
          },
          {
            "code" : "G01AC30",
            "display" : "oxyquinoline"
          },
          {
            "code" : "G01AD",
            "display" : "Organic acids"
          },
          {
            "code" : "G01AD01",
            "display" : "lactic acid"
          },
          {
            "code" : "G01AD02",
            "display" : "acetic acid"
          },
          {
            "code" : "G01AD03",
            "display" : "ascorbic acid"
          },
          {
            "code" : "G01AE",
            "display" : "Sulfonamides"
          },
          {
            "code" : "G01AE01",
            "display" : "sulfatolamide"
          },
          {
            "code" : "G01AE10",
            "display" : "combinations of sulfonamides"
          },
          {
            "code" : "G01AF",
            "display" : "Imidazole derivatives"
          },
          {
            "code" : "G01AF01",
            "display" : "metronidazole"
          },
          {
            "code" : "G01AF02",
            "display" : "clotrimazole"
          },
          {
            "code" : "G01AF04",
            "display" : "miconazole"
          },
          {
            "code" : "G01AF05",
            "display" : "econazole"
          },
          {
            "code" : "G01AF06",
            "display" : "ornidazole"
          },
          {
            "code" : "G01AF07",
            "display" : "isoconazole"
          },
          {
            "code" : "G01AF08",
            "display" : "tioconazole"
          },
          {
            "code" : "G01AF11",
            "display" : "ketoconazole"
          },
          {
            "code" : "G01AF12",
            "display" : "fenticonazole"
          },
          {
            "code" : "G01AF13",
            "display" : "azanidazole"
          },
          {
            "code" : "G01AF14",
            "display" : "propenidazole"
          },
          {
            "code" : "G01AF15",
            "display" : "butoconazole"
          },
          {
            "code" : "G01AF16",
            "display" : "omoconazole"
          },
          {
            "code" : "G01AF17",
            "display" : "oxiconazole"
          },
          {
            "code" : "G01AF18",
            "display" : "flutrimazole"
          },
          {
            "code" : "G01AF19",
            "display" : "sertaconazole"
          },
          {
            "code" : "G01AF20",
            "display" : "combinations of imidazole derivatives"
          },
          {
            "code" : "G01AF21",
            "display" : "tinidazole"
          },
          {
            "code" : "G01AF55",
            "display" : "econazole, combinations"
          },
          {
            "code" : "G01AG",
            "display" : "Triazole derivatives"
          },
          {
            "code" : "G01AG02",
            "display" : "terconazole"
          },
          {
            "code" : "G01AX",
            "display" : "Other antiinfectives and antiseptics"
          },
          {
            "code" : "G01AX01",
            "display" : "clodantoin"
          },
          {
            "code" : "G01AX02",
            "display" : "inosine"
          },
          {
            "code" : "G01AX03",
            "display" : "policresulen"
          },
          {
            "code" : "G01AX05",
            "display" : "nifuratel"
          },
          {
            "code" : "G01AX06",
            "display" : "furazolidone"
          },
          {
            "code" : "G01AX09",
            "display" : "methylrosaniline"
          },
          {
            "code" : "G01AX11",
            "display" : "povidone-iodine"
          },
          {
            "code" : "G01AX12",
            "display" : "ciclopirox"
          },
          {
            "code" : "G01AX13",
            "display" : "protiofate"
          },
          {
            "code" : "G01AX14",
            "display" : "lactobacillus"
          },
          {
            "code" : "G01AX15",
            "display" : "copper usnate"
          },
          {
            "code" : "G01AX16",
            "display" : "hexetidine"
          },
          {
            "code" : "G01AX17",
            "display" : "dapivirine"
          },
          {
            "code" : "G01AX66",
            "display" : "octenidine, combinations"
          },
          {
            "code" : "G01B",
            "display" : "ANTIINFECTIVES/ANTISEPTICS IN COMBINATION WITH CORTICOSTEROIDS"
          },
          {
            "code" : "G01BA",
            "display" : "Antibiotics and corticosteroids"
          },
          {
            "code" : "G01BC",
            "display" : "Quinoline derivatives and corticosteroids"
          },
          {
            "code" : "G01BD",
            "display" : "Antiseptics and corticosteroids"
          },
          {
            "code" : "G01BE",
            "display" : "Sulfonamides and corticosteroids"
          },
          {
            "code" : "G01BF",
            "display" : "Imidazole derivatives and corticosteroids"
          },
          {
            "code" : "G02",
            "display" : "OTHER GYNECOLOGICALS"
          },
          {
            "code" : "G02A",
            "display" : "UTEROTONICS"
          },
          {
            "code" : "G02AB",
            "display" : "Ergot alkaloids"
          },
          {
            "code" : "G02AB01",
            "display" : "methylergometrine"
          },
          {
            "code" : "G02AB02",
            "display" : "ergot alkaloids"
          },
          {
            "code" : "G02AB03",
            "display" : "ergometrine"
          },
          {
            "code" : "G02AC",
            "display" : "Ergot alkaloids and oxytocin incl. analogues, in combination"
          },
          {
            "code" : "G02AC01",
            "display" : "methylergometrine and oxytocin"
          },
          {
            "code" : "G02AD",
            "display" : "Prostaglandins"
          },
          {
            "code" : "G02AD01",
            "display" : "dinoprost"
          },
          {
            "code" : "G02AD02",
            "display" : "dinoprostone"
          },
          {
            "code" : "G02AD03",
            "display" : "gemeprost"
          },
          {
            "code" : "G02AD04",
            "display" : "carboprost"
          },
          {
            "code" : "G02AD05",
            "display" : "sulprostone"
          },
          {
            "code" : "G02AD06",
            "display" : "misoprostol"
          },
          {
            "code" : "G02AX",
            "display" : "Other uterotonics"
          },
          {
            "code" : "G02B",
            "display" : "CONTRACEPTIVES FOR TOPICAL USE"
          },
          {
            "code" : "G02BA",
            "display" : "Intrauterine contraceptives"
          },
          {
            "code" : "G02BA01",
            "display" : "plastic IUD"
          },
          {
            "code" : "G02BA02",
            "display" : "plastic IUD with copper"
          },
          {
            "code" : "G02BA03",
            "display" : "plastic IUD with progestogen"
          },
          {
            "code" : "G02BB",
            "display" : "Intravaginal contraceptives"
          },
          {
            "code" : "G02BB01",
            "display" : "vaginal ring with progestogen and estrogen"
          },
          {
            "code" : "G02BB02",
            "display" : "vaginal ring with progestogen"
          },
          {
            "code" : "G02C",
            "display" : "OTHER GYNECOLOGICALS"
          },
          {
            "code" : "G02CA",
            "display" : "Sympathomimetics, labour repressants"
          },
          {
            "code" : "G02CA01",
            "display" : "ritodrine"
          },
          {
            "code" : "G02CA02",
            "display" : "buphenine"
          },
          {
            "code" : "G02CA03",
            "display" : "fenoterol"
          },
          {
            "code" : "G02CB",
            "display" : "Prolactine inhibitors"
          },
          {
            "code" : "G02CB01",
            "display" : "bromocriptine"
          },
          {
            "code" : "G02CB02",
            "display" : "lisuride"
          },
          {
            "code" : "G02CB03",
            "display" : "cabergoline"
          },
          {
            "code" : "G02CB04",
            "display" : "quinagolide"
          },
          {
            "code" : "G02CB05",
            "display" : "metergoline"
          },
          {
            "code" : "G02CB06",
            "display" : "terguride"
          },
          {
            "code" : "G02CC",
            "display" : "Antiinflammatory products for vaginal administration"
          },
          {
            "code" : "G02CC01",
            "display" : "ibuprofen"
          },
          {
            "code" : "G02CC02",
            "display" : "naproxen"
          },
          {
            "code" : "G02CC03",
            "display" : "benzydamine"
          },
          {
            "code" : "G02CC04",
            "display" : "flunoxaprofen"
          },
          {
            "code" : "G02CX",
            "display" : "Other gynecologicals"
          },
          {
            "code" : "G02CX01",
            "display" : "atosiban"
          },
          {
            "code" : "G02CX02",
            "display" : "flibanserin"
          },
          {
            "code" : "G02CX03",
            "display" : "Agni casti fructus"
          },
          {
            "code" : "G02CX04",
            "display" : "Cimicifugae rhizoma"
          },
          {
            "code" : "G02CX05",
            "display" : "bremelanotide"
          },
          {
            "code" : "G02CX06",
            "display" : "fezolinetant"
          },
          {
            "code" : "G03",
            "display" : "SEX HORMONES AND MODULATORS OF THE GENITAL SYSTEM"
          },
          {
            "code" : "G03A",
            "display" : "HORMONAL CONTRACEPTIVES FOR SYSTEMIC USE"
          },
          {
            "code" : "G03AA",
            "display" : "Progestogens and estrogens, fixed combinations"
          },
          {
            "code" : "G03AA01",
            "display" : "etynodiol and ethinylestradiol"
          },
          {
            "code" : "G03AA02",
            "display" : "quingestanol and ethinylestradiol"
          },
          {
            "code" : "G03AA03",
            "display" : "lynestrenol and ethinylestradiol"
          },
          {
            "code" : "G03AA04",
            "display" : "megestrol and ethinylestradiol"
          },
          {
            "code" : "G03AA05",
            "display" : "norethisterone and ethinylestradiol"
          },
          {
            "code" : "G03AA06",
            "display" : "norgestrel and ethinylestradiol"
          },
          {
            "code" : "G03AA07",
            "display" : "levonorgestrel and ethinylestradiol"
          },
          {
            "code" : "G03AA08",
            "display" : "medroxyprogesterone and ethinylestradiol"
          },
          {
            "code" : "G03AA09",
            "display" : "desogestrel and ethinylestradiol"
          },
          {
            "code" : "G03AA10",
            "display" : "gestodene and ethinylestradiol"
          },
          {
            "code" : "G03AA11",
            "display" : "norgestimate and ethinylestradiol"
          },
          {
            "code" : "G03AA12",
            "display" : "drospirenone and ethinylestradiol"
          },
          {
            "code" : "G03AA13",
            "display" : "norelgestromin and ethinylestradiol"
          },
          {
            "code" : "G03AA14",
            "display" : "nomegestrol and estradiol"
          },
          {
            "code" : "G03AA15",
            "display" : "chlormadinone and ethinylestradiol"
          },
          {
            "code" : "G03AA16",
            "display" : "dienogest and ethinylestradiol"
          },
          {
            "code" : "G03AA17",
            "display" : "medroxyprogesterone and estradiol"
          },
          {
            "code" : "G03AA18",
            "display" : "drospirenone and estetrol"
          },
          {
            "code" : "G03AB",
            "display" : "Progestogens and estrogens, sequential preparations"
          },
          {
            "code" : "G03AB01",
            "display" : "megestrol and ethinylestradiol"
          },
          {
            "code" : "G03AB02",
            "display" : "lynestrenol and ethinylestradiol"
          },
          {
            "code" : "G03AB03",
            "display" : "levonorgestrel and ethinylestradiol"
          },
          {
            "code" : "G03AB04",
            "display" : "norethisterone and ethinylestradiol"
          },
          {
            "code" : "G03AB05",
            "display" : "desogestrel and ethinylestradiol"
          },
          {
            "code" : "G03AB06",
            "display" : "gestodene and ethinylestradiol"
          },
          {
            "code" : "G03AB07",
            "display" : "chlormadinone and ethinylestradiol"
          },
          {
            "code" : "G03AB08",
            "display" : "dienogest and estradiol"
          },
          {
            "code" : "G03AB09",
            "display" : "norgestimate and ethinylestradiol"
          },
          {
            "code" : "G03AC",
            "display" : "Progestogens"
          },
          {
            "code" : "G03AC01",
            "display" : "norethisterone"
          },
          {
            "code" : "G03AC02",
            "display" : "lynestrenol"
          },
          {
            "code" : "G03AC03",
            "display" : "levonorgestrel"
          },
          {
            "code" : "G03AC04",
            "display" : "quingestanol"
          },
          {
            "code" : "G03AC05",
            "display" : "megestrol"
          },
          {
            "code" : "G03AC06",
            "display" : "medroxyprogesterone"
          },
          {
            "code" : "G03AC07",
            "display" : "norgestrienone"
          },
          {
            "code" : "G03AC08",
            "display" : "etonogestrel"
          },
          {
            "code" : "G03AC09",
            "display" : "desogestrel"
          },
          {
            "code" : "G03AC10",
            "display" : "drospirenone"
          },
          {
            "code" : "G03AD",
            "display" : "Emergency contraceptives"
          },
          {
            "code" : "G03AD01",
            "display" : "levonorgestrel"
          },
          {
            "code" : "G03AD02",
            "display" : "ulipristal"
          },
          {
            "code" : "G03B",
            "display" : "ANDROGENS"
          },
          {
            "code" : "G03BA",
            "display" : "3-oxoandrosten (4) derivatives"
          },
          {
            "code" : "G03BA01",
            "display" : "fluoxymesterone"
          },
          {
            "code" : "G03BA02",
            "display" : "methyltestosterone"
          },
          {
            "code" : "G03BA03",
            "display" : "testosterone"
          },
          {
            "code" : "G03BB",
            "display" : "5-androstanon (3) derivatives"
          },
          {
            "code" : "G03BB01",
            "display" : "mesterolone"
          },
          {
            "code" : "G03BB02",
            "display" : "androstanolone"
          },
          {
            "code" : "G03C",
            "display" : "ESTROGENS"
          },
          {
            "code" : "G03CA",
            "display" : "Natural and semisynthetic estrogens, plain"
          },
          {
            "code" : "G03CA01",
            "display" : "ethinylestradiol"
          },
          {
            "code" : "G03CA03",
            "display" : "estradiol"
          },
          {
            "code" : "G03CA04",
            "display" : "estriol"
          },
          {
            "code" : "G03CA06",
            "display" : "chlorotrianisene"
          },
          {
            "code" : "G03CA07",
            "display" : "estrone"
          },
          {
            "code" : "G03CA09",
            "display" : "promestriene"
          },
          {
            "code" : "G03CA53",
            "display" : "estradiol, combinations"
          },
          {
            "code" : "G03CA57",
            "display" : "conjugated estrogens"
          },
          {
            "code" : "G03CB",
            "display" : "Synthetic estrogens, plain"
          },
          {
            "code" : "G03CB01",
            "display" : "dienestrol"
          },
          {
            "code" : "G03CB02",
            "display" : "diethylstilbestrol"
          },
          {
            "code" : "G03CB03",
            "display" : "methallenestril"
          },
          {
            "code" : "G03CB04",
            "display" : "moxestrol"
          },
          {
            "code" : "G03CC",
            "display" : "Estrogens, combinations with other drugs"
          },
          {
            "code" : "G03CC02",
            "display" : "dienestrol"
          },
          {
            "code" : "G03CC03",
            "display" : "methallenestril"
          },
          {
            "code" : "G03CC04",
            "display" : "estrone"
          },
          {
            "code" : "G03CC05",
            "display" : "diethylstilbestrol"
          },
          {
            "code" : "G03CC06",
            "display" : "estriol"
          },
          {
            "code" : "G03CC07",
            "display" : "conjugated estrogens and bazedoxifene"
          },
          {
            "code" : "G03CX",
            "display" : "Other estrogens"
          },
          {
            "code" : "G03CX01",
            "display" : "tibolone"
          },
          {
            "code" : "G03D",
            "display" : "PROGESTOGENS"
          },
          {
            "code" : "G03DA",
            "display" : "Pregnen (4) derivatives"
          },
          {
            "code" : "G03DA01",
            "display" : "gestonorone"
          },
          {
            "code" : "G03DA02",
            "display" : "medroxyprogesterone"
          },
          {
            "code" : "G03DA03",
            "display" : "hydroxyprogesterone"
          },
          {
            "code" : "G03DA04",
            "display" : "progesterone"
          },
          {
            "code" : "G03DB",
            "display" : "Pregnadien derivatives"
          },
          {
            "code" : "G03DB01",
            "display" : "dydrogesterone"
          },
          {
            "code" : "G03DB02",
            "display" : "megestrol"
          },
          {
            "code" : "G03DB03",
            "display" : "medrogestone"
          },
          {
            "code" : "G03DB04",
            "display" : "nomegestrol"
          },
          {
            "code" : "G03DB05",
            "display" : "demegestone"
          },
          {
            "code" : "G03DB06",
            "display" : "chlormadinone"
          },
          {
            "code" : "G03DB07",
            "display" : "promegestone"
          },
          {
            "code" : "G03DB08",
            "display" : "dienogest"
          },
          {
            "code" : "G03DC",
            "display" : "Estren derivatives"
          },
          {
            "code" : "G03DC01",
            "display" : "allylestrenol"
          },
          {
            "code" : "G03DC02",
            "display" : "norethisterone"
          },
          {
            "code" : "G03DC03",
            "display" : "lynestrenol"
          },
          {
            "code" : "G03DC04",
            "display" : "ethisterone"
          },
          {
            "code" : "G03DC06",
            "display" : "etynodiol"
          },
          {
            "code" : "G03DC31",
            "display" : "methylestrenolone"
          },
          {
            "code" : "G03E",
            "display" : "ANDROGENS AND FEMALE SEX HORMONES IN COMBINATION"
          },
          {
            "code" : "G03EA",
            "display" : "Androgens and estrogens"
          },
          {
            "code" : "G03EA01",
            "display" : "methyltestosterone and estrogen"
          },
          {
            "code" : "G03EA02",
            "display" : "testosterone and estrogen"
          },
          {
            "code" : "G03EA03",
            "display" : "prasterone and estrogen"
          },
          {
            "code" : "G03EB",
            "display" : "Androgen, progestogen and estrogen in combination"
          },
          {
            "code" : "G03EK",
            "display" : "Androgens and female sex hormones in combination with other drugs"
          },
          {
            "code" : "G03EK01",
            "display" : "methyltestosterone"
          },
          {
            "code" : "G03F",
            "display" : "PROGESTOGENS AND ESTROGENS IN COMBINATION"
          },
          {
            "code" : "G03FA",
            "display" : "Progestogens and estrogens, fixed combinations"
          },
          {
            "code" : "G03FA01",
            "display" : "norethisterone and estrogen"
          },
          {
            "code" : "G03FA02",
            "display" : "hydroxyprogesterone and estrogen"
          },
          {
            "code" : "G03FA03",
            "display" : "ethisterone and estrogen"
          },
          {
            "code" : "G03FA04",
            "display" : "progesterone and estrogen"
          },
          {
            "code" : "G03FA05",
            "display" : "methylnortestosterone and estrogen"
          },
          {
            "code" : "G03FA06",
            "display" : "etynodiol and estrogen"
          },
          {
            "code" : "G03FA07",
            "display" : "lynestrenol and estrogen"
          },
          {
            "code" : "G03FA08",
            "display" : "megestrol and estrogen"
          },
          {
            "code" : "G03FA09",
            "display" : "noretynodrel and estrogen"
          },
          {
            "code" : "G03FA10",
            "display" : "norgestrel and estrogen"
          },
          {
            "code" : "G03FA11",
            "display" : "levonorgestrel and estrogen"
          },
          {
            "code" : "G03FA12",
            "display" : "medroxyprogesterone and estrogen"
          },
          {
            "code" : "G03FA13",
            "display" : "norgestimate and estrogen"
          },
          {
            "code" : "G03FA14",
            "display" : "dydrogesterone and estrogen"
          },
          {
            "code" : "G03FA15",
            "display" : "dienogest and estrogen"
          },
          {
            "code" : "G03FA16",
            "display" : "trimegestone and estrogen"
          },
          {
            "code" : "G03FA17",
            "display" : "drospirenone and estrogen"
          },
          {
            "code" : "G03FB",
            "display" : "Progestogens and estrogens, sequential preparations"
          },
          {
            "code" : "G03FB01",
            "display" : "norgestrel and estrogen"
          },
          {
            "code" : "G03FB02",
            "display" : "lynestrenol and estrogen"
          },
          {
            "code" : "G03FB03",
            "display" : "chlormadinone and estrogen"
          },
          {
            "code" : "G03FB04",
            "display" : "megestrol and estrogen"
          },
          {
            "code" : "G03FB05",
            "display" : "norethisterone and estrogen"
          },
          {
            "code" : "G03FB06",
            "display" : "medroxyprogesterone and estrogen"
          },
          {
            "code" : "G03FB07",
            "display" : "medrogestone and estrogen"
          },
          {
            "code" : "G03FB08",
            "display" : "dydrogesterone and estrogen"
          },
          {
            "code" : "G03FB09",
            "display" : "levonorgestrel and estrogen"
          },
          {
            "code" : "G03FB10",
            "display" : "desogestrel and estrogen"
          },
          {
            "code" : "G03FB11",
            "display" : "trimegestone and estrogen"
          },
          {
            "code" : "G03FB12",
            "display" : "nomegestrol and estrogen"
          },
          {
            "code" : "G03G",
            "display" : "GONADOTROPINS AND OTHER OVULATION STIMULANTS"
          },
          {
            "code" : "G03GA",
            "display" : "Gonadotropins"
          },
          {
            "code" : "G03GA01",
            "display" : "chorionic gonadotrophin"
          },
          {
            "code" : "G03GA02",
            "display" : "human menopausal gonadotrophin"
          },
          {
            "code" : "G03GA03",
            "display" : "serum gonadotrophin"
          },
          {
            "code" : "G03GA04",
            "display" : "urofollitropin"
          },
          {
            "code" : "G03GA05",
            "display" : "follitropin alfa"
          },
          {
            "code" : "G03GA06",
            "display" : "follitropin beta"
          },
          {
            "code" : "G03GA07",
            "display" : "lutropin alfa"
          },
          {
            "code" : "G03GA08",
            "display" : "choriogonadotropin alfa"
          },
          {
            "code" : "G03GA09",
            "display" : "corifollitropin alfa"
          },
          {
            "code" : "G03GA10",
            "display" : "follitropin delta"
          },
          {
            "code" : "G03GA30",
            "display" : "combinations"
          },
          {
            "code" : "G03GB",
            "display" : "Ovulation stimulants, synthetic"
          },
          {
            "code" : "G03GB01",
            "display" : "cyclofenil"
          },
          {
            "code" : "G03GB02",
            "display" : "clomifene"
          },
          {
            "code" : "G03GB03",
            "display" : "epimestrol"
          },
          {
            "code" : "G03H",
            "display" : "ANTIANDROGENS"
          },
          {
            "code" : "G03HA",
            "display" : "Antiandrogens, plain"
          },
          {
            "code" : "G03HA01",
            "display" : "cyproterone"
          },
          {
            "code" : "G03HB",
            "display" : "Antiandrogens and estrogens"
          },
          {
            "code" : "G03HB01",
            "display" : "cyproterone and estrogen"
          },
          {
            "code" : "G03X",
            "display" : "OTHER SEX HORMONES AND MODULATORS OF THE GENITAL SYSTEM"
          },
          {
            "code" : "G03XA",
            "display" : "Antigonadotropins and similar agents"
          },
          {
            "code" : "G03XA01",
            "display" : "danazol"
          },
          {
            "code" : "G03XA02",
            "display" : "gestrinone"
          },
          {
            "code" : "G03XB",
            "display" : "Progesterone receptor modulators"
          },
          {
            "code" : "G03XB01",
            "display" : "mifepristone"
          },
          {
            "code" : "G03XB02",
            "display" : "ulipristal"
          },
          {
            "code" : "G03XB51",
            "display" : "mifepristone, combinations"
          },
          {
            "code" : "G03XC",
            "display" : "Selective estrogen receptor modulators"
          },
          {
            "code" : "G03XC01",
            "display" : "raloxifene"
          },
          {
            "code" : "G03XC02",
            "display" : "bazedoxifene"
          },
          {
            "code" : "G03XC03",
            "display" : "lasofoxifene"
          },
          {
            "code" : "G03XC04",
            "display" : "ormeloxifene"
          },
          {
            "code" : "G03XC05",
            "display" : "ospemifene"
          },
          {
            "code" : "G03XX",
            "display" : "Other sex hormones and modulators of the genital system"
          },
          {
            "code" : "G03XX01",
            "display" : "prasterone"
          },
          {
            "code" : "G04",
            "display" : "UROLOGICALS"
          },
          {
            "code" : "G04B",
            "display" : "UROLOGICALS"
          },
          {
            "code" : "G04BA",
            "display" : "Acidifiers"
          },
          {
            "code" : "G04BA01",
            "display" : "ammonium chloride"
          },
          {
            "code" : "G04BA03",
            "display" : "calcium chloride"
          },
          {
            "code" : "G04BC",
            "display" : "Urinary concrement solvents"
          },
          {
            "code" : "G04BD",
            "display" : "Drugs for urinary frequency and incontinence"
          },
          {
            "code" : "G04BD01",
            "display" : "emepronium"
          },
          {
            "code" : "G04BD02",
            "display" : "flavoxate"
          },
          {
            "code" : "G04BD03",
            "display" : "meladrazine"
          },
          {
            "code" : "G04BD04",
            "display" : "oxybutynin"
          },
          {
            "code" : "G04BD05",
            "display" : "terodiline"
          },
          {
            "code" : "G04BD06",
            "display" : "propiverine"
          },
          {
            "code" : "G04BD07",
            "display" : "tolterodine"
          },
          {
            "code" : "G04BD08",
            "display" : "solifenacin"
          },
          {
            "code" : "G04BD09",
            "display" : "trospium"
          },
          {
            "code" : "G04BD10",
            "display" : "darifenacin"
          },
          {
            "code" : "G04BD11",
            "display" : "fesoterodine"
          },
          {
            "code" : "G04BD12",
            "display" : "mirabegron"
          },
          {
            "code" : "G04BD13",
            "display" : "desfesoterodine"
          },
          {
            "code" : "G04BD14",
            "display" : "imidafenacin"
          },
          {
            "code" : "G04BD15",
            "display" : "vibegron"
          },
          {
            "code" : "G04BE",
            "display" : "Drugs used in erectile dysfunction"
          },
          {
            "code" : "G04BE01",
            "display" : "alprostadil"
          },
          {
            "code" : "G04BE02",
            "display" : "papaverine"
          },
          {
            "code" : "G04BE03",
            "display" : "sildenafil"
          },
          {
            "code" : "G04BE04",
            "display" : "yohimbine"
          },
          {
            "code" : "G04BE06",
            "display" : "moxisylyte"
          },
          {
            "code" : "G04BE07",
            "display" : "apomorphine"
          },
          {
            "code" : "G04BE08",
            "display" : "tadalafil"
          },
          {
            "code" : "G04BE09",
            "display" : "vardenafil"
          },
          {
            "code" : "G04BE10",
            "display" : "avanafil"
          },
          {
            "code" : "G04BE11",
            "display" : "udenafil"
          },
          {
            "code" : "G04BE30",
            "display" : "combinations"
          },
          {
            "code" : "G04BE52",
            "display" : "papaverine, combinations"
          },
          {
            "code" : "G04BX",
            "display" : "Other urologicals"
          },
          {
            "code" : "G04BX01",
            "display" : "magnesium hydroxide"
          },
          {
            "code" : "G04BX03",
            "display" : "acetohydroxamic acid"
          },
          {
            "code" : "G04BX06",
            "display" : "phenazopyridine"
          },
          {
            "code" : "G04BX10",
            "display" : "succinimide"
          },
          {
            "code" : "G04BX11",
            "display" : "collagen"
          },
          {
            "code" : "G04BX12",
            "display" : "phenyl salicylate"
          },
          {
            "code" : "G04BX13",
            "display" : "dimethyl sulfoxide"
          },
          {
            "code" : "G04BX14",
            "display" : "dapoxetine"
          },
          {
            "code" : "G04BX15",
            "display" : "pentosan polysulfate sodium"
          },
          {
            "code" : "G04BX16",
            "display" : "tiopronin"
          },
          {
            "code" : "G04BX17",
            "display" : "sodium salicylate and methenamine"
          },
          {
            "code" : "G04C",
            "display" : "DRUGS USED IN BENIGN PROSTATIC HYPERTROPHY"
          },
          {
            "code" : "G04CA",
            "display" : "Alpha-adrenoreceptor antagonists"
          },
          {
            "code" : "G04CA01",
            "display" : "alfuzosin"
          },
          {
            "code" : "G04CA02",
            "display" : "tamsulosin"
          },
          {
            "code" : "G04CA03",
            "display" : "terazosin"
          },
          {
            "code" : "G04CA04",
            "display" : "silodosin"
          },
          {
            "code" : "G04CA51",
            "display" : "alfuzosin and finasteride"
          },
          {
            "code" : "G04CA52",
            "display" : "tamsulosin and dutasteride"
          },
          {
            "code" : "G04CA53",
            "display" : "tamsulosin and solifenacin"
          },
          {
            "code" : "G04CA54",
            "display" : "tamsulosin and tadalafil"
          },
          {
            "code" : "G04CA55",
            "display" : "doxazosin and finasteride"
          },
          {
            "code" : "G04CB",
            "display" : "Testosterone-5-alpha reductase inhibitors"
          },
          {
            "code" : "G04CB01",
            "display" : "finasteride"
          },
          {
            "code" : "G04CB02",
            "display" : "dutasteride"
          },
          {
            "code" : "G04CB51",
            "display" : "finasteride and tadalafil"
          },
          {
            "code" : "G04CX",
            "display" : "Other drugs used in benign prostatic hypertrophy"
          },
          {
            "code" : "G04CX01",
            "display" : "Prunus africanae cortex"
          },
          {
            "code" : "G04CX02",
            "display" : "Sabalis serrulatae fructus"
          },
          {
            "code" : "G04CX03",
            "display" : "mepartricin"
          },
          {
            "code" : "G04CX04",
            "display" : "fexapotide"
          },
          {
            "code" : "H",
            "display" : "SYSTEMIC HORMONAL PREPARATIONS, EXCL. SEX HORMONES AND INSULINS"
          },
          {
            "code" : "H01",
            "display" : "PITUITARY AND HYPOTHALAMIC HORMONES AND ANALOGUES"
          },
          {
            "code" : "H01A",
            "display" : "ANTERIOR PITUITARY LOBE HORMONES AND ANALOGUES"
          },
          {
            "code" : "H01AA",
            "display" : "ACTH"
          },
          {
            "code" : "H01AA01",
            "display" : "corticotropin"
          },
          {
            "code" : "H01AA02",
            "display" : "tetracosactide"
          },
          {
            "code" : "H01AB",
            "display" : "Thyrotropin"
          },
          {
            "code" : "H01AB01",
            "display" : "thyrotropin alfa"
          },
          {
            "code" : "H01AC",
            "display" : "Somatropin and somatropin agonists"
          },
          {
            "code" : "H01AC01",
            "display" : "somatropin"
          },
          {
            "code" : "H01AC02",
            "display" : "somatrem"
          },
          {
            "code" : "H01AC03",
            "display" : "mecasermin"
          },
          {
            "code" : "H01AC04",
            "display" : "sermorelin"
          },
          {
            "code" : "H01AC05",
            "display" : "mecasermin rinfabate"
          },
          {
            "code" : "H01AC06",
            "display" : "tesamorelin"
          },
          {
            "code" : "H01AC07",
            "display" : "somapacitan"
          },
          {
            "code" : "H01AC08",
            "display" : "somatrogon"
          },
          {
            "code" : "H01AC09",
            "display" : "lonapegsomatropin"
          },
          {
            "code" : "H01AX",
            "display" : "Other anterior pituitary lobe hormones and analogues"
          },
          {
            "code" : "H01AX01",
            "display" : "pegvisomant"
          },
          {
            "code" : "H01B",
            "display" : "POSTERIOR PITUITARY LOBE HORMONES"
          },
          {
            "code" : "H01BA",
            "display" : "Vasopressin and analogues"
          },
          {
            "code" : "H01BA01",
            "display" : "vasopressin (argipressin)"
          },
          {
            "code" : "H01BA02",
            "display" : "desmopressin"
          },
          {
            "code" : "H01BA03",
            "display" : "lypressin"
          },
          {
            "code" : "H01BA04",
            "display" : "terlipressin"
          },
          {
            "code" : "H01BA05",
            "display" : "ornipressin"
          },
          {
            "code" : "H01BB",
            "display" : "Oxytocin and analogues"
          },
          {
            "code" : "H01BB01",
            "display" : "demoxytocin"
          },
          {
            "code" : "H01BB02",
            "display" : "oxytocin"
          },
          {
            "code" : "H01BB03",
            "display" : "carbetocin"
          },
          {
            "code" : "H01C",
            "display" : "HYPOTHALAMIC HORMONES"
          },
          {
            "code" : "H01CA",
            "display" : "Gonadotropin-releasing hormones"
          },
          {
            "code" : "H01CA01",
            "display" : "gonadorelin"
          },
          {
            "code" : "H01CA02",
            "display" : "nafarelin"
          },
          {
            "code" : "H01CB",
            "display" : "Somatostatin and analogues"
          },
          {
            "code" : "H01CB01",
            "display" : "somatostatin"
          },
          {
            "code" : "H01CB02",
            "display" : "octreotide"
          },
          {
            "code" : "H01CB03",
            "display" : "lanreotide"
          },
          {
            "code" : "H01CB04",
            "display" : "vapreotide"
          },
          {
            "code" : "H01CB05",
            "display" : "pasireotide"
          },
          {
            "code" : "H01CC",
            "display" : "Anti-gonadotropin-releasing hormones"
          },
          {
            "code" : "H01CC01",
            "display" : "ganirelix"
          },
          {
            "code" : "H01CC02",
            "display" : "cetrorelix"
          },
          {
            "code" : "H01CC03",
            "display" : "elagolix"
          },
          {
            "code" : "H01CC04",
            "display" : "linzagolix"
          },
          {
            "code" : "H01CC53",
            "display" : "elagolix, estradiol and norethisterone"
          },
          {
            "code" : "H01CC54",
            "display" : "relugolix, estradiol and norethisterone"
          },
          {
            "code" : "H02",
            "display" : "CORTICOSTEROIDS FOR SYSTEMIC USE"
          },
          {
            "code" : "H02A",
            "display" : "CORTICOSTEROIDS FOR SYSTEMIC USE, PLAIN"
          },
          {
            "code" : "H02AA",
            "display" : "Mineralocorticoids"
          },
          {
            "code" : "H02AA01",
            "display" : "aldosterone"
          },
          {
            "code" : "H02AA02",
            "display" : "fludrocortisone"
          },
          {
            "code" : "H02AA03",
            "display" : "desoxycortone"
          },
          {
            "code" : "H02AB",
            "display" : "Glucocorticoids"
          },
          {
            "code" : "H02AB01",
            "display" : "betamethasone"
          },
          {
            "code" : "H02AB02",
            "display" : "dexamethasone"
          },
          {
            "code" : "H02AB03",
            "display" : "fluocortolone"
          },
          {
            "code" : "H02AB04",
            "display" : "methylprednisolone"
          },
          {
            "code" : "H02AB05",
            "display" : "paramethasone"
          },
          {
            "code" : "H02AB06",
            "display" : "prednisolone"
          },
          {
            "code" : "H02AB07",
            "display" : "prednisone"
          },
          {
            "code" : "H02AB08",
            "display" : "triamcinolone"
          },
          {
            "code" : "H02AB09",
            "display" : "hydrocortisone"
          },
          {
            "code" : "H02AB10",
            "display" : "cortisone"
          },
          {
            "code" : "H02AB11",
            "display" : "prednylidene"
          },
          {
            "code" : "H02AB12",
            "display" : "rimexolone"
          },
          {
            "code" : "H02AB13",
            "display" : "deflazacort"
          },
          {
            "code" : "H02AB14",
            "display" : "cloprednol"
          },
          {
            "code" : "H02AB15",
            "display" : "meprednisone"
          },
          {
            "code" : "H02AB17",
            "display" : "cortivazol"
          },
          {
            "code" : "H02AB18",
            "display" : "vamorolone"
          },
          {
            "code" : "H02B",
            "display" : "CORTICOSTEROIDS FOR SYSTEMIC USE, COMBINATIONS"
          },
          {
            "code" : "H02BX",
            "display" : "Corticosteroids for systemic use, combinations"
          },
          {
            "code" : "H02BX01",
            "display" : "methylprednisolone, combinations"
          },
          {
            "code" : "H02C",
            "display" : "ANTIADRENAL PREPARATIONS"
          },
          {
            "code" : "H02CA",
            "display" : "Anticorticosteroids"
          },
          {
            "code" : "H02CA01",
            "display" : "trilostane"
          },
          {
            "code" : "H02CA02",
            "display" : "osilodrostat"
          },
          {
            "code" : "H02CA03",
            "display" : "ketoconazole"
          },
          {
            "code" : "H02CA04",
            "display" : "levoketoconazole"
          },
          {
            "code" : "H03",
            "display" : "THYROID THERAPY"
          },
          {
            "code" : "H03A",
            "display" : "THYROID PREPARATIONS"
          },
          {
            "code" : "H03AA",
            "display" : "Thyroid hormones"
          },
          {
            "code" : "H03AA01",
            "display" : "levothyroxine sodium"
          },
          {
            "code" : "H03AA02",
            "display" : "liothyronine sodium"
          },
          {
            "code" : "H03AA03",
            "display" : "combinations of levothyroxine and liothyronine"
          },
          {
            "code" : "H03AA04",
            "display" : "tiratricol"
          },
          {
            "code" : "H03AA05",
            "display" : "thyroid gland preparations"
          },
          {
            "code" : "H03AA51",
            "display" : "levothyroxine sodium and iodine compounds"
          },
          {
            "code" : "H03B",
            "display" : "ANTITHYROID PREPARATIONS"
          },
          {
            "code" : "H03BA",
            "display" : "Thiouracils"
          },
          {
            "code" : "H03BA01",
            "display" : "methylthiouracil"
          },
          {
            "code" : "H03BA02",
            "display" : "propylthiouracil"
          },
          {
            "code" : "H03BA03",
            "display" : "benzylthiouracil"
          },
          {
            "code" : "H03BB",
            "display" : "Sulfur-containing imidazole derivatives"
          },
          {
            "code" : "H03BB01",
            "display" : "carbimazole"
          },
          {
            "code" : "H03BB02",
            "display" : "thiamazole"
          },
          {
            "code" : "H03BB52",
            "display" : "thiamazole, combinations"
          },
          {
            "code" : "H03BC",
            "display" : "Perchlorates"
          },
          {
            "code" : "H03BC01",
            "display" : "potassium perchlorate"
          },
          {
            "code" : "H03BX",
            "display" : "Other antithyroid preparations"
          },
          {
            "code" : "H03BX01",
            "display" : "diiodotyrosine"
          },
          {
            "code" : "H03BX02",
            "display" : "dibromotyrosine"
          },
          {
            "code" : "H03C",
            "display" : "IODINE THERAPY"
          },
          {
            "code" : "H03CA",
            "display" : "Iodine therapy"
          },
          {
            "code" : "H04",
            "display" : "PANCREATIC HORMONES"
          },
          {
            "code" : "H04A",
            "display" : "GLYCOGENOLYTIC HORMONES"
          },
          {
            "code" : "H04AA",
            "display" : "Glycogenolytic hormones"
          },
          {
            "code" : "H04AA01",
            "display" : "glucagon"
          },
          {
            "code" : "H04AA02",
            "display" : "dasiglucagon"
          },
          {
            "code" : "H05",
            "display" : "CALCIUM HOMEOSTASIS"
          },
          {
            "code" : "H05A",
            "display" : "PARATHYROID HORMONES AND ANALOGUES"
          },
          {
            "code" : "H05AA",
            "display" : "Parathyroid hormones and analogues"
          },
          {
            "code" : "H05AA01",
            "display" : "parathyroid gland extract"
          },
          {
            "code" : "H05AA02",
            "display" : "teriparatide"
          },
          {
            "code" : "H05AA03",
            "display" : "parathyroid hormone"
          },
          {
            "code" : "H05AA04",
            "display" : "abaloparatide"
          },
          {
            "code" : "H05AA05",
            "display" : "palopegteriparatide"
          },
          {
            "code" : "H05B",
            "display" : "ANTI-PARATHYROID AGENTS"
          },
          {
            "code" : "H05BA",
            "display" : "Calcitonin preparations"
          },
          {
            "code" : "H05BA01",
            "display" : "calcitonin (salmon synthetic)"
          },
          {
            "code" : "H05BA02",
            "display" : "calcitonin (pork natural)"
          },
          {
            "code" : "H05BA03",
            "display" : "calcitonin (human synthetic)"
          },
          {
            "code" : "H05BA04",
            "display" : "elcatonin"
          },
          {
            "code" : "H05BX",
            "display" : "Other anti-parathyroid agents"
          },
          {
            "code" : "H05BX01",
            "display" : "cinacalcet"
          },
          {
            "code" : "H05BX02",
            "display" : "paricalcitol"
          },
          {
            "code" : "H05BX03",
            "display" : "doxercalciferol"
          },
          {
            "code" : "H05BX04",
            "display" : "etelcalcetide"
          },
          {
            "code" : "H05BX05",
            "display" : "calcifediol"
          },
          {
            "code" : "H05BX06",
            "display" : "evocalcet"
          },
          {
            "code" : "J",
            "display" : "ANTIINFECTIVES FOR SYSTEMIC USE"
          },
          {
            "code" : "J01",
            "display" : "ANTIBACTERIALS FOR SYSTEMIC USE"
          },
          {
            "code" : "J01A",
            "display" : "TETRACYCLINES"
          },
          {
            "code" : "J01AA",
            "display" : "Tetracyclines"
          },
          {
            "code" : "J01AA01",
            "display" : "demeclocycline"
          },
          {
            "code" : "J01AA02",
            "display" : "doxycycline"
          },
          {
            "code" : "J01AA03",
            "display" : "chlortetracycline"
          },
          {
            "code" : "J01AA04",
            "display" : "lymecycline"
          },
          {
            "code" : "J01AA05",
            "display" : "metacycline"
          },
          {
            "code" : "J01AA06",
            "display" : "oxytetracycline"
          },
          {
            "code" : "J01AA07",
            "display" : "tetracycline"
          },
          {
            "code" : "J01AA08",
            "display" : "minocycline"
          },
          {
            "code" : "J01AA09",
            "display" : "rolitetracycline"
          },
          {
            "code" : "J01AA10",
            "display" : "penimepicycline"
          },
          {
            "code" : "J01AA11",
            "display" : "clomocycline"
          },
          {
            "code" : "J01AA12",
            "display" : "tigecycline"
          },
          {
            "code" : "J01AA13",
            "display" : "eravacycline"
          },
          {
            "code" : "J01AA14",
            "display" : "sarecycline"
          },
          {
            "code" : "J01AA15",
            "display" : "omadacycline"
          },
          {
            "code" : "J01AA20",
            "display" : "combinations of tetracyclines"
          },
          {
            "code" : "J01AA56",
            "display" : "oxytetracycline, combinations"
          },
          {
            "code" : "J01B",
            "display" : "AMPHENICOLS"
          },
          {
            "code" : "J01BA",
            "display" : "Amphenicols"
          },
          {
            "code" : "J01BA01",
            "display" : "chloramphenicol"
          },
          {
            "code" : "J01BA02",
            "display" : "thiamphenicol"
          },
          {
            "code" : "J01BA52",
            "display" : "thiamphenicol, combinations"
          },
          {
            "code" : "J01C",
            "display" : "BETA-LACTAM ANTIBACTERIALS, PENICILLINS"
          },
          {
            "code" : "J01CA",
            "display" : "Penicillins with extended spectrum"
          },
          {
            "code" : "J01CA01",
            "display" : "ampicillin"
          },
          {
            "code" : "J01CA02",
            "display" : "pivampicillin"
          },
          {
            "code" : "J01CA03",
            "display" : "carbenicillin"
          },
          {
            "code" : "J01CA04",
            "display" : "amoxicillin"
          },
          {
            "code" : "J01CA05",
            "display" : "carindacillin"
          },
          {
            "code" : "J01CA06",
            "display" : "bacampicillin"
          },
          {
            "code" : "J01CA07",
            "display" : "epicillin"
          },
          {
            "code" : "J01CA08",
            "display" : "pivmecillinam"
          },
          {
            "code" : "J01CA09",
            "display" : "azlocillin"
          },
          {
            "code" : "J01CA10",
            "display" : "mezlocillin"
          },
          {
            "code" : "J01CA11",
            "display" : "mecillinam"
          },
          {
            "code" : "J01CA12",
            "display" : "piperacillin"
          },
          {
            "code" : "J01CA13",
            "display" : "ticarcillin"
          },
          {
            "code" : "J01CA14",
            "display" : "metampicillin"
          },
          {
            "code" : "J01CA15",
            "display" : "talampicillin"
          },
          {
            "code" : "J01CA16",
            "display" : "sulbenicillin"
          },
          {
            "code" : "J01CA17",
            "display" : "temocillin"
          },
          {
            "code" : "J01CA18",
            "display" : "hetacillin"
          },
          {
            "code" : "J01CA19",
            "display" : "aspoxicillin"
          },
          {
            "code" : "J01CA20",
            "display" : "combinations"
          },
          {
            "code" : "J01CA51",
            "display" : "ampicillin, combinations"
          },
          {
            "code" : "J01CE",
            "display" : "Beta-lactamase sensitive penicillins"
          },
          {
            "code" : "J01CE01",
            "display" : "benzylpenicillin"
          },
          {
            "code" : "J01CE02",
            "display" : "phenoxymethylpenicillin"
          },
          {
            "code" : "J01CE03",
            "display" : "propicillin"
          },
          {
            "code" : "J01CE04",
            "display" : "azidocillin"
          },
          {
            "code" : "J01CE05",
            "display" : "pheneticillin"
          },
          {
            "code" : "J01CE06",
            "display" : "penamecillin"
          },
          {
            "code" : "J01CE07",
            "display" : "clometocillin"
          },
          {
            "code" : "J01CE08",
            "display" : "benzathine benzylpenicillin"
          },
          {
            "code" : "J01CE09",
            "display" : "procaine benzylpenicillin"
          },
          {
            "code" : "J01CE10",
            "display" : "benzathine phenoxymethylpenicillin"
          },
          {
            "code" : "J01CE30",
            "display" : "combinations"
          },
          {
            "code" : "J01CF",
            "display" : "Beta-lactamase resistant penicillins"
          },
          {
            "code" : "J01CF01",
            "display" : "dicloxacillin"
          },
          {
            "code" : "J01CF02",
            "display" : "cloxacillin"
          },
          {
            "code" : "J01CF03",
            "display" : "meticillin"
          },
          {
            "code" : "J01CF04",
            "display" : "oxacillin"
          },
          {
            "code" : "J01CF05",
            "display" : "flucloxacillin"
          },
          {
            "code" : "J01CF06",
            "display" : "nafcillin"
          },
          {
            "code" : "J01CG",
            "display" : "Beta-lactamase inhibitors"
          },
          {
            "code" : "J01CG01",
            "display" : "sulbactam"
          },
          {
            "code" : "J01CG02",
            "display" : "tazobactam"
          },
          {
            "code" : "J01CR",
            "display" : "Combinations of penicillins, incl. beta-lactamase inhibitors"
          },
          {
            "code" : "J01CR01",
            "display" : "ampicillin and beta-lactamase inhibitor"
          },
          {
            "code" : "J01CR02",
            "display" : "amoxicillin and beta-lactamase inhibitor"
          },
          {
            "code" : "J01CR03",
            "display" : "ticarcillin and beta-lactamase inhibitor"
          },
          {
            "code" : "J01CR04",
            "display" : "sultamicillin"
          },
          {
            "code" : "J01CR05",
            "display" : "piperacillin and beta-lactamase inhibitor"
          },
          {
            "code" : "J01CR50",
            "display" : "combinations of penicillins"
          },
          {
            "code" : "J01D",
            "display" : "OTHER BETA-LACTAM ANTIBACTERIALS"
          },
          {
            "code" : "J01DB",
            "display" : "First-generation cephalosporins"
          },
          {
            "code" : "J01DB01",
            "display" : "cefalexin"
          },
          {
            "code" : "J01DB02",
            "display" : "cefaloridine"
          },
          {
            "code" : "J01DB03",
            "display" : "cefalotin"
          },
          {
            "code" : "J01DB04",
            "display" : "cefazolin"
          },
          {
            "code" : "J01DB05",
            "display" : "cefadroxil"
          },
          {
            "code" : "J01DB06",
            "display" : "cefazedone"
          },
          {
            "code" : "J01DB07",
            "display" : "cefatrizine"
          },
          {
            "code" : "J01DB08",
            "display" : "cefapirin"
          },
          {
            "code" : "J01DB09",
            "display" : "cefradine"
          },
          {
            "code" : "J01DB10",
            "display" : "cefacetrile"
          },
          {
            "code" : "J01DB11",
            "display" : "cefroxadine"
          },
          {
            "code" : "J01DB12",
            "display" : "ceftezole"
          },
          {
            "code" : "J01DC",
            "display" : "Second-generation cephalosporins"
          },
          {
            "code" : "J01DC01",
            "display" : "cefoxitin"
          },
          {
            "code" : "J01DC02",
            "display" : "cefuroxime"
          },
          {
            "code" : "J01DC03",
            "display" : "cefamandole"
          },
          {
            "code" : "J01DC04",
            "display" : "cefaclor"
          },
          {
            "code" : "J01DC05",
            "display" : "cefotetan"
          },
          {
            "code" : "J01DC06",
            "display" : "cefonicid"
          },
          {
            "code" : "J01DC07",
            "display" : "cefotiam"
          },
          {
            "code" : "J01DC08",
            "display" : "loracarbef"
          },
          {
            "code" : "J01DC09",
            "display" : "cefmetazole"
          },
          {
            "code" : "J01DC10",
            "display" : "cefprozil"
          },
          {
            "code" : "J01DC11",
            "display" : "ceforanide"
          },
          {
            "code" : "J01DC12",
            "display" : "cefminox"
          },
          {
            "code" : "J01DC13",
            "display" : "cefbuperazone"
          },
          {
            "code" : "J01DC14",
            "display" : "flomoxef"
          },
          {
            "code" : "J01DC52",
            "display" : "cefuroxime and beta-lactamase inhibitor"
          },
          {
            "code" : "J01DD",
            "display" : "Third-generation cephalosporins"
          },
          {
            "code" : "J01DD01",
            "display" : "cefotaxime"
          },
          {
            "code" : "J01DD02",
            "display" : "ceftazidime"
          },
          {
            "code" : "J01DD03",
            "display" : "cefsulodin"
          },
          {
            "code" : "J01DD04",
            "display" : "ceftriaxone"
          },
          {
            "code" : "J01DD05",
            "display" : "cefmenoxime"
          },
          {
            "code" : "J01DD06",
            "display" : "latamoxef"
          },
          {
            "code" : "J01DD07",
            "display" : "ceftizoxime"
          },
          {
            "code" : "J01DD08",
            "display" : "cefixime"
          },
          {
            "code" : "J01DD09",
            "display" : "cefodizime"
          },
          {
            "code" : "J01DD10",
            "display" : "cefetamet"
          },
          {
            "code" : "J01DD11",
            "display" : "cefpiramide"
          },
          {
            "code" : "J01DD12",
            "display" : "cefoperazone"
          },
          {
            "code" : "J01DD13",
            "display" : "cefpodoxime"
          },
          {
            "code" : "J01DD14",
            "display" : "ceftibuten"
          },
          {
            "code" : "J01DD15",
            "display" : "cefdinir"
          },
          {
            "code" : "J01DD16",
            "display" : "cefditoren"
          },
          {
            "code" : "J01DD17",
            "display" : "cefcapene"
          },
          {
            "code" : "J01DD18",
            "display" : "cefteram"
          },
          {
            "code" : "J01DD51",
            "display" : "cefotaxime and beta-lactamase inhibitor"
          },
          {
            "code" : "J01DD52",
            "display" : "ceftazidime and beta-lactamase inhibitor"
          },
          {
            "code" : "J01DD54",
            "display" : "ceftriaxone, combinations"
          },
          {
            "code" : "J01DD58",
            "display" : "cefixime and beta-lactamase inhibitor"
          },
          {
            "code" : "J01DD62",
            "display" : "cefoperazone and beta-lactamase inhibitor"
          },
          {
            "code" : "J01DD63",
            "display" : "ceftriaxone and beta-lactamase inhibitor"
          },
          {
            "code" : "J01DD64",
            "display" : "cefpodoxime and beta-lactamase inhibitor"
          },
          {
            "code" : "J01DE",
            "display" : "Fourth-generation cephalosporins"
          },
          {
            "code" : "J01DE01",
            "display" : "cefepime"
          },
          {
            "code" : "J01DE02",
            "display" : "cefpirome"
          },
          {
            "code" : "J01DE03",
            "display" : "cefozopran"
          },
          {
            "code" : "J01DE51",
            "display" : "cefepime and beta-lactamase inhibitor"
          },
          {
            "code" : "J01DF",
            "display" : "Monobactams"
          },
          {
            "code" : "J01DF01",
            "display" : "aztreonam"
          },
          {
            "code" : "J01DF02",
            "display" : "carumonam"
          },
          {
            "code" : "J01DF51",
            "display" : "aztreonam and beta-lactamase inhibitor"
          },
          {
            "code" : "J01DH",
            "display" : "Carbapenems"
          },
          {
            "code" : "J01DH02",
            "display" : "meropenem"
          },
          {
            "code" : "J01DH03",
            "display" : "ertapenem"
          },
          {
            "code" : "J01DH04",
            "display" : "doripenem"
          },
          {
            "code" : "J01DH05",
            "display" : "biapenem"
          },
          {
            "code" : "J01DH06",
            "display" : "tebipenem pivoxil"
          },
          {
            "code" : "J01DH51",
            "display" : "imipenem and cilastatin"
          },
          {
            "code" : "J01DH52",
            "display" : "meropenem and vaborbactam"
          },
          {
            "code" : "J01DH55",
            "display" : "panipenem and betamipron"
          },
          {
            "code" : "J01DH56",
            "display" : "imipenem, cilastatin and relebactam"
          },
          {
            "code" : "J01DI",
            "display" : "Other cephalosporins and penems"
          },
          {
            "code" : "J01DI01",
            "display" : "ceftobiprole medocaril"
          },
          {
            "code" : "J01DI02",
            "display" : "ceftaroline fosamil"
          },
          {
            "code" : "J01DI03",
            "display" : "faropenem"
          },
          {
            "code" : "J01DI04",
            "display" : "cefiderocol"
          },
          {
            "code" : "J01DI54",
            "display" : "ceftolozane and beta-lactamase inhibitor"
          },
          {
            "code" : "J01E",
            "display" : "SULFONAMIDES AND TRIMETHOPRIM"
          },
          {
            "code" : "J01EA",
            "display" : "Trimethoprim and derivatives"
          },
          {
            "code" : "J01EA01",
            "display" : "trimethoprim"
          },
          {
            "code" : "J01EA02",
            "display" : "brodimoprim"
          },
          {
            "code" : "J01EA03",
            "display" : "iclaprim"
          },
          {
            "code" : "J01EB",
            "display" : "Short-acting sulfonamides"
          },
          {
            "code" : "J01EB01",
            "display" : "sulfaisodimidine"
          },
          {
            "code" : "J01EB02",
            "display" : "sulfamethizole"
          },
          {
            "code" : "J01EB03",
            "display" : "sulfadimidine"
          },
          {
            "code" : "J01EB04",
            "display" : "sulfapyridine"
          },
          {
            "code" : "J01EB05",
            "display" : "sulfafurazole"
          },
          {
            "code" : "J01EB06",
            "display" : "sulfanilamide"
          },
          {
            "code" : "J01EB07",
            "display" : "sulfathiazole"
          },
          {
            "code" : "J01EB08",
            "display" : "sulfathiourea"
          },
          {
            "code" : "J01EB20",
            "display" : "combinations"
          },
          {
            "code" : "J01EC",
            "display" : "Intermediate-acting sulfonamides"
          },
          {
            "code" : "J01EC01",
            "display" : "sulfamethoxazole"
          },
          {
            "code" : "J01EC02",
            "display" : "sulfadiazine"
          },
          {
            "code" : "J01EC03",
            "display" : "sulfamoxole"
          },
          {
            "code" : "J01EC20",
            "display" : "combinations"
          },
          {
            "code" : "J01ED",
            "display" : "Long-acting sulfonamides"
          },
          {
            "code" : "J01ED01",
            "display" : "sulfadimethoxine"
          },
          {
            "code" : "J01ED02",
            "display" : "sulfalene"
          },
          {
            "code" : "J01ED03",
            "display" : "sulfametomidine"
          },
          {
            "code" : "J01ED04",
            "display" : "sulfametoxydiazine"
          },
          {
            "code" : "J01ED05",
            "display" : "sulfamethoxypyridazine"
          },
          {
            "code" : "J01ED06",
            "display" : "sulfaperin"
          },
          {
            "code" : "J01ED07",
            "display" : "sulfamerazine"
          },
          {
            "code" : "J01ED08",
            "display" : "sulfaphenazole"
          },
          {
            "code" : "J01ED09",
            "display" : "sulfamazone"
          },
          {
            "code" : "J01ED20",
            "display" : "combinations"
          },
          {
            "code" : "J01EE",
            "display" : "Combinations of sulfonamides and trimethoprim, incl. derivatives"
          },
          {
            "code" : "J01EE01",
            "display" : "sulfamethoxazole and trimethoprim"
          },
          {
            "code" : "J01EE02",
            "display" : "sulfadiazine and trimethoprim"
          },
          {
            "code" : "J01EE03",
            "display" : "sulfametrole and trimethoprim"
          },
          {
            "code" : "J01EE04",
            "display" : "sulfamoxole and trimethoprim"
          },
          {
            "code" : "J01EE05",
            "display" : "sulfadimidine and trimethoprim"
          },
          {
            "code" : "J01EE06",
            "display" : "sulfadiazine and tetroxoprim"
          },
          {
            "code" : "J01EE07",
            "display" : "sulfamerazine and trimethoprim"
          },
          {
            "code" : "J01F",
            "display" : "MACROLIDES, LINCOSAMIDES AND STREPTOGRAMINS"
          },
          {
            "code" : "J01FA",
            "display" : "Macrolides"
          },
          {
            "code" : "J01FA01",
            "display" : "erythromycin"
          },
          {
            "code" : "J01FA02",
            "display" : "spiramycin"
          },
          {
            "code" : "J01FA03",
            "display" : "midecamycin"
          },
          {
            "code" : "J01FA05",
            "display" : "oleandomycin"
          },
          {
            "code" : "J01FA06",
            "display" : "roxithromycin"
          },
          {
            "code" : "J01FA07",
            "display" : "josamycin"
          },
          {
            "code" : "J01FA08",
            "display" : "troleandomycin"
          },
          {
            "code" : "J01FA09",
            "display" : "clarithromycin"
          },
          {
            "code" : "J01FA10",
            "display" : "azithromycin"
          },
          {
            "code" : "J01FA11",
            "display" : "miocamycin"
          },
          {
            "code" : "J01FA12",
            "display" : "rokitamycin"
          },
          {
            "code" : "J01FA13",
            "display" : "dirithromycin"
          },
          {
            "code" : "J01FA14",
            "display" : "flurithromycin"
          },
          {
            "code" : "J01FA15",
            "display" : "telithromycin"
          },
          {
            "code" : "J01FA16",
            "display" : "solithromycin"
          },
          {
            "code" : "J01FF",
            "display" : "Lincosamides"
          },
          {
            "code" : "J01FF01",
            "display" : "clindamycin"
          },
          {
            "code" : "J01FF02",
            "display" : "lincomycin"
          },
          {
            "code" : "J01FG",
            "display" : "Streptogramins"
          },
          {
            "code" : "J01FG01",
            "display" : "pristinamycin"
          },
          {
            "code" : "J01FG02",
            "display" : "quinupristin/dalfopristin"
          },
          {
            "code" : "J01G",
            "display" : "AMINOGLYCOSIDE ANTIBACTERIALS"
          },
          {
            "code" : "J01GA",
            "display" : "Streptomycins"
          },
          {
            "code" : "J01GA01",
            "display" : "streptomycin"
          },
          {
            "code" : "J01GA02",
            "display" : "streptoduocin"
          },
          {
            "code" : "J01GB",
            "display" : "Other aminoglycosides"
          },
          {
            "code" : "J01GB01",
            "display" : "tobramycin"
          },
          {
            "code" : "J01GB03",
            "display" : "gentamicin"
          },
          {
            "code" : "J01GB04",
            "display" : "kanamycin"
          },
          {
            "code" : "J01GB05",
            "display" : "neomycin"
          },
          {
            "code" : "J01GB06",
            "display" : "amikacin"
          },
          {
            "code" : "J01GB07",
            "display" : "netilmicin"
          },
          {
            "code" : "J01GB08",
            "display" : "sisomicin"
          },
          {
            "code" : "J01GB09",
            "display" : "dibekacin"
          },
          {
            "code" : "J01GB10",
            "display" : "ribostamycin"
          },
          {
            "code" : "J01GB11",
            "display" : "isepamicin"
          },
          {
            "code" : "J01GB12",
            "display" : "arbekacin"
          },
          {
            "code" : "J01GB13",
            "display" : "bekanamycin"
          },
          {
            "code" : "J01GB14",
            "display" : "plazomicin"
          },
          {
            "code" : "J01M",
            "display" : "QUINOLONE ANTIBACTERIALS"
          },
          {
            "code" : "J01MA",
            "display" : "Fluoroquinolones"
          },
          {
            "code" : "J01MA01",
            "display" : "ofloxacin"
          },
          {
            "code" : "J01MA02",
            "display" : "ciprofloxacin"
          },
          {
            "code" : "J01MA03",
            "display" : "pefloxacin"
          },
          {
            "code" : "J01MA04",
            "display" : "enoxacin"
          },
          {
            "code" : "J01MA05",
            "display" : "temafloxacin"
          },
          {
            "code" : "J01MA06",
            "display" : "norfloxacin"
          },
          {
            "code" : "J01MA07",
            "display" : "lomefloxacin"
          },
          {
            "code" : "J01MA08",
            "display" : "fleroxacin"
          },
          {
            "code" : "J01MA09",
            "display" : "sparfloxacin"
          },
          {
            "code" : "J01MA10",
            "display" : "rufloxacin"
          },
          {
            "code" : "J01MA11",
            "display" : "grepafloxacin"
          },
          {
            "code" : "J01MA12",
            "display" : "levofloxacin"
          },
          {
            "code" : "J01MA13",
            "display" : "trovafloxacin"
          },
          {
            "code" : "J01MA14",
            "display" : "moxifloxacin"
          },
          {
            "code" : "J01MA15",
            "display" : "gemifloxacin"
          },
          {
            "code" : "J01MA16",
            "display" : "gatifloxacin"
          },
          {
            "code" : "J01MA17",
            "display" : "prulifloxacin"
          },
          {
            "code" : "J01MA18",
            "display" : "pazufloxacin"
          },
          {
            "code" : "J01MA19",
            "display" : "garenoxacin"
          },
          {
            "code" : "J01MA21",
            "display" : "sitafloxacin"
          },
          {
            "code" : "J01MA22",
            "display" : "tosufloxacin"
          },
          {
            "code" : "J01MA23",
            "display" : "delafloxacin"
          },
          {
            "code" : "J01MA24",
            "display" : "levonadifloxacin"
          },
          {
            "code" : "J01MA25",
            "display" : "lascufloxacin"
          },
          {
            "code" : "J01MB",
            "display" : "Other quinolones"
          },
          {
            "code" : "J01MB01",
            "display" : "rosoxacin"
          },
          {
            "code" : "J01MB02",
            "display" : "nalidixic acid"
          },
          {
            "code" : "J01MB03",
            "display" : "piromidic acid"
          },
          {
            "code" : "J01MB04",
            "display" : "pipemidic acid"
          },
          {
            "code" : "J01MB05",
            "display" : "oxolinic acid"
          },
          {
            "code" : "J01MB06",
            "display" : "cinoxacin"
          },
          {
            "code" : "J01MB07",
            "display" : "flumequine"
          },
          {
            "code" : "J01MB08",
            "display" : "nemonoxacin"
          },
          {
            "code" : "J01R",
            "display" : "COMBINATIONS OF ANTIBACTERIALS"
          },
          {
            "code" : "J01RA",
            "display" : "Combinations of antibacterials"
          },
          {
            "code" : "J01RA01",
            "display" : "penicillins, combinations with other antibacterials"
          },
          {
            "code" : "J01RA02",
            "display" : "sulfonamides, combinations with other antibacterials (excl. trimethoprim)"
          },
          {
            "code" : "J01RA03",
            "display" : "cefuroxime and metronidazole"
          },
          {
            "code" : "J01RA04",
            "display" : "spiramycin and metronidazole"
          },
          {
            "code" : "J01RA05",
            "display" : "levofloxacin and ornidazole"
          },
          {
            "code" : "J01RA06",
            "display" : "cefepime and amikacin"
          },
          {
            "code" : "J01RA07",
            "display" : "azithromycin, fluconazole and secnidazole"
          },
          {
            "code" : "J01RA08",
            "display" : "tetracycline and oleandomycin"
          },
          {
            "code" : "J01RA09",
            "display" : "ofloxacin and ornidazole"
          },
          {
            "code" : "J01RA10",
            "display" : "ciprofloxacin and metronidazole"
          },
          {
            "code" : "J01RA11",
            "display" : "ciprofloxacin and tinidazole"
          },
          {
            "code" : "J01RA12",
            "display" : "ciprofloxacin and ornidazole"
          },
          {
            "code" : "J01RA13",
            "display" : "norfloxacin and tinidazole"
          },
          {
            "code" : "J01RA14",
            "display" : "norfloxacin and metronidazole"
          },
          {
            "code" : "J01RA15",
            "display" : "cefixime and ornidazole"
          },
          {
            "code" : "J01RA16",
            "display" : "cefixime and azithromycin"
          },
          {
            "code" : "J01RA17",
            "display" : "ofloxacin and nitazoxanide"
          },
          {
            "code" : "J01RA18",
            "display" : "ofloxacin and tinidazole"
          },
          {
            "code" : "J01RA19",
            "display" : "tetracycline and nystatin"
          },
          {
            "code" : "J01X",
            "display" : "OTHER ANTIBACTERIALS"
          },
          {
            "code" : "J01XA",
            "display" : "Glycopeptide antibacterials"
          },
          {
            "code" : "J01XA01",
            "display" : "vancomycin"
          },
          {
            "code" : "J01XA02",
            "display" : "teicoplanin"
          },
          {
            "code" : "J01XA03",
            "display" : "telavancin"
          },
          {
            "code" : "J01XA04",
            "display" : "dalbavancin"
          },
          {
            "code" : "J01XA05",
            "display" : "oritavancin"
          },
          {
            "code" : "J01XB",
            "display" : "Polymyxins"
          },
          {
            "code" : "J01XB01",
            "display" : "colistin"
          },
          {
            "code" : "J01XB02",
            "display" : "polymyxin B"
          },
          {
            "code" : "J01XC",
            "display" : "Steroid antibacterials"
          },
          {
            "code" : "J01XC01",
            "display" : "fusidic acid"
          },
          {
            "code" : "J01XD",
            "display" : "Imidazole derivatives"
          },
          {
            "code" : "J01XD01",
            "display" : "metronidazole"
          },
          {
            "code" : "J01XD02",
            "display" : "tinidazole"
          },
          {
            "code" : "J01XD03",
            "display" : "ornidazole"
          },
          {
            "code" : "J01XE",
            "display" : "Nitrofuran derivatives"
          },
          {
            "code" : "J01XE01",
            "display" : "nitrofurantoin"
          },
          {
            "code" : "J01XE02",
            "display" : "nifurtoinol"
          },
          {
            "code" : "J01XE03",
            "display" : "furazidin"
          },
          {
            "code" : "J01XE51",
            "display" : "nitrofurantoin, combinations"
          },
          {
            "code" : "J01XX",
            "display" : "Other antibacterials"
          },
          {
            "code" : "J01XX01",
            "display" : "fosfomycin"
          },
          {
            "code" : "J01XX02",
            "display" : "xibornol"
          },
          {
            "code" : "J01XX03",
            "display" : "clofoctol"
          },
          {
            "code" : "J01XX04",
            "display" : "spectinomycin"
          },
          {
            "code" : "J01XX05",
            "display" : "methenamine"
          },
          {
            "code" : "J01XX06",
            "display" : "mandelic acid"
          },
          {
            "code" : "J01XX07",
            "display" : "nitroxoline"
          },
          {
            "code" : "J01XX08",
            "display" : "linezolid"
          },
          {
            "code" : "J01XX09",
            "display" : "daptomycin"
          },
          {
            "code" : "J01XX10",
            "display" : "bacitracin"
          },
          {
            "code" : "J01XX11",
            "display" : "tedizolid"
          },
          {
            "code" : "J01XX12",
            "display" : "lefamulin"
          },
          {
            "code" : "J01XX13",
            "display" : "gepotidacin"
          },
          {
            "code" : "J02",
            "display" : "ANTIMYCOTICS FOR SYSTEMIC USE"
          },
          {
            "code" : "J02A",
            "display" : "ANTIMYCOTICS FOR SYSTEMIC USE"
          },
          {
            "code" : "J02AA",
            "display" : "Antibiotics"
          },
          {
            "code" : "J02AA01",
            "display" : "amphotericin B"
          },
          {
            "code" : "J02AA02",
            "display" : "hachimycin"
          },
          {
            "code" : "J02AB",
            "display" : "Imidazole derivatives"
          },
          {
            "code" : "J02AB01",
            "display" : "miconazole"
          },
          {
            "code" : "J02AB02",
            "display" : "ketoconazole"
          },
          {
            "code" : "J02AC",
            "display" : "Triazole and tetrazole derivatives"
          },
          {
            "code" : "J02AC01",
            "display" : "fluconazole"
          },
          {
            "code" : "J02AC02",
            "display" : "itraconazole"
          },
          {
            "code" : "J02AC03",
            "display" : "voriconazole"
          },
          {
            "code" : "J02AC04",
            "display" : "posaconazole"
          },
          {
            "code" : "J02AC05",
            "display" : "isavuconazole"
          },
          {
            "code" : "J02AC06",
            "display" : "oteseconazole"
          },
          {
            "code" : "J02AX",
            "display" : "Other antimycotics for systemic use"
          },
          {
            "code" : "J02AX01",
            "display" : "flucytosine"
          },
          {
            "code" : "J02AX04",
            "display" : "caspofungin"
          },
          {
            "code" : "J02AX05",
            "display" : "micafungin"
          },
          {
            "code" : "J02AX06",
            "display" : "anidulafungin"
          },
          {
            "code" : "J02AX07",
            "display" : "ibrexafungerp"
          },
          {
            "code" : "J02AX08",
            "display" : "rezafungin acetate"
          },
          {
            "code" : "J04",
            "display" : "ANTIMYCOBACTERIALS"
          },
          {
            "code" : "J04A",
            "display" : "DRUGS FOR TREATMENT OF TUBERCULOSIS"
          },
          {
            "code" : "J04AA",
            "display" : "Aminosalicylic acid and derivatives"
          },
          {
            "code" : "J04AA01",
            "display" : "4-aminosalicylic acid"
          },
          {
            "code" : "J04AA02",
            "display" : "sodium aminosalicylate"
          },
          {
            "code" : "J04AA03",
            "display" : "calcium aminosalicylate"
          },
          {
            "code" : "J04AB",
            "display" : "Antibiotics"
          },
          {
            "code" : "J04AB01",
            "display" : "cycloserine"
          },
          {
            "code" : "J04AB02",
            "display" : "rifampicin"
          },
          {
            "code" : "J04AB03",
            "display" : "rifamycin"
          },
          {
            "code" : "J04AB04",
            "display" : "rifabutin"
          },
          {
            "code" : "J04AB05",
            "display" : "rifapentine"
          },
          {
            "code" : "J04AB06",
            "display" : "enviomycin"
          },
          {
            "code" : "J04AB30",
            "display" : "capreomycin"
          },
          {
            "code" : "J04AC",
            "display" : "Hydrazides"
          },
          {
            "code" : "J04AC01",
            "display" : "isoniazid"
          },
          {
            "code" : "J04AC02",
            "display" : "ftivazide"
          },
          {
            "code" : "J04AC51",
            "display" : "isoniazid, combinations"
          },
          {
            "code" : "J04AD",
            "display" : "Thiocarbamide derivatives"
          },
          {
            "code" : "J04AD01",
            "display" : "protionamide"
          },
          {
            "code" : "J04AD02",
            "display" : "tiocarlide"
          },
          {
            "code" : "J04AD03",
            "display" : "ethionamide"
          },
          {
            "code" : "J04AK",
            "display" : "Other drugs for treatment of tuberculosis"
          },
          {
            "code" : "J04AK01",
            "display" : "pyrazinamide"
          },
          {
            "code" : "J04AK02",
            "display" : "ethambutol"
          },
          {
            "code" : "J04AK03",
            "display" : "terizidone"
          },
          {
            "code" : "J04AK04",
            "display" : "morinamide"
          },
          {
            "code" : "J04AK05",
            "display" : "bedaquiline"
          },
          {
            "code" : "J04AK06",
            "display" : "delamanid"
          },
          {
            "code" : "J04AK07",
            "display" : "thioacetazone"
          },
          {
            "code" : "J04AK08",
            "display" : "pretomanid"
          },
          {
            "code" : "J04AM",
            "display" : "Combinations of drugs for treatment of tuberculosis"
          },
          {
            "code" : "J04AM01",
            "display" : "streptomycin and isoniazid"
          },
          {
            "code" : "J04AM02",
            "display" : "rifampicin and isoniazid"
          },
          {
            "code" : "J04AM03",
            "display" : "ethambutol and isoniazid"
          },
          {
            "code" : "J04AM04",
            "display" : "thioacetazone and isoniazid"
          },
          {
            "code" : "J04AM05",
            "display" : "rifampicin, pyrazinamide and isoniazid"
          },
          {
            "code" : "J04AM06",
            "display" : "rifampicin, pyrazinamide, ethambutol and isoniazid"
          },
          {
            "code" : "J04AM07",
            "display" : "rifampicin, ethambutol and isoniazid"
          },
          {
            "code" : "J04AM08",
            "display" : "isoniazid, sulfamethoxazole and trimethoprim"
          },
          {
            "code" : "J04AM09",
            "display" : "pyrazinamide, ethambutol, isoniazid and lomefloxacin"
          },
          {
            "code" : "J04AM10",
            "display" : "pyrazinamide, ethambutol, protionamide and lomefloxacin"
          },
          {
            "code" : "J04AM11",
            "display" : "rifabutin, pyrazinamide and protionamide"
          },
          {
            "code" : "J04AM12",
            "display" : "rifampicin, pyrazinamide, isoniazid and levofloxacin"
          },
          {
            "code" : "J04B",
            "display" : "DRUGS FOR TREATMENT OF LEPRA"
          },
          {
            "code" : "J04BA",
            "display" : "Drugs for treatment of lepra"
          },
          {
            "code" : "J04BA01",
            "display" : "clofazimine"
          },
          {
            "code" : "J04BA02",
            "display" : "dapsone"
          },
          {
            "code" : "J04BA03",
            "display" : "aldesulfone sodium"
          },
          {
            "code" : "J04BA50",
            "display" : "dapsone and rifampicin"
          },
          {
            "code" : "J04BA51",
            "display" : "dapsone, rifampicin and clofazimine"
          },
          {
            "code" : "J05",
            "display" : "ANTIVIRALS FOR SYSTEMIC USE"
          },
          {
            "code" : "J05A",
            "display" : "DIRECT ACTING ANTIVIRALS"
          },
          {
            "code" : "J05AA",
            "display" : "Thiosemicarbazones"
          },
          {
            "code" : "J05AA01",
            "display" : "metisazone"
          },
          {
            "code" : "J05AB",
            "display" : "Nucleosides and nucleotides excl. reverse transcriptase inhibitors"
          },
          {
            "code" : "J05AB01",
            "display" : "aciclovir"
          },
          {
            "code" : "J05AB02",
            "display" : "idoxuridine"
          },
          {
            "code" : "J05AB03",
            "display" : "vidarabine"
          },
          {
            "code" : "J05AB06",
            "display" : "ganciclovir"
          },
          {
            "code" : "J05AB09",
            "display" : "famciclovir"
          },
          {
            "code" : "J05AB11",
            "display" : "valaciclovir"
          },
          {
            "code" : "J05AB12",
            "display" : "cidofovir"
          },
          {
            "code" : "J05AB13",
            "display" : "penciclovir"
          },
          {
            "code" : "J05AB14",
            "display" : "valganciclovir"
          },
          {
            "code" : "J05AB15",
            "display" : "brivudine"
          },
          {
            "code" : "J05AB16",
            "display" : "remdesivir"
          },
          {
            "code" : "J05AB17",
            "display" : "brincidofovir"
          },
          {
            "code" : "J05AB18",
            "display" : "molnupiravir"
          },
          {
            "code" : "J05AC",
            "display" : "Cyclic amines"
          },
          {
            "code" : "J05AC02",
            "display" : "rimantadine"
          },
          {
            "code" : "J05AC03",
            "display" : "tromantadine"
          },
          {
            "code" : "J05AD",
            "display" : "Phosphonic acid derivatives"
          },
          {
            "code" : "J05AD01",
            "display" : "foscarnet"
          },
          {
            "code" : "J05AD02",
            "display" : "fosfonet"
          },
          {
            "code" : "J05AE",
            "display" : "Protease inhibitors"
          },
          {
            "code" : "J05AE01",
            "display" : "saquinavir"
          },
          {
            "code" : "J05AE02",
            "display" : "indinavir"
          },
          {
            "code" : "J05AE03",
            "display" : "ritonavir"
          },
          {
            "code" : "J05AE04",
            "display" : "nelfinavir"
          },
          {
            "code" : "J05AE05",
            "display" : "amprenavir"
          },
          {
            "code" : "J05AE07",
            "display" : "fosamprenavir"
          },
          {
            "code" : "J05AE08",
            "display" : "atazanavir"
          },
          {
            "code" : "J05AE09",
            "display" : "tipranavir"
          },
          {
            "code" : "J05AE10",
            "display" : "darunavir"
          },
          {
            "code" : "J05AE16",
            "display" : "ensitrelvir"
          },
          {
            "code" : "J05AE30",
            "display" : "nirmatrelvir and ritonavir"
          },
          {
            "code" : "J05AF",
            "display" : "Nucleoside and nucleotide reverse transcriptase inhibitors"
          },
          {
            "code" : "J05AF01",
            "display" : "zidovudine"
          },
          {
            "code" : "J05AF02",
            "display" : "didanosine"
          },
          {
            "code" : "J05AF03",
            "display" : "zalcitabine"
          },
          {
            "code" : "J05AF04",
            "display" : "stavudine"
          },
          {
            "code" : "J05AF05",
            "display" : "lamivudine"
          },
          {
            "code" : "J05AF06",
            "display" : "abacavir"
          },
          {
            "code" : "J05AF07",
            "display" : "tenofovir disoproxil"
          },
          {
            "code" : "J05AF08",
            "display" : "adefovir dipivoxil"
          },
          {
            "code" : "J05AF09",
            "display" : "emtricitabine"
          },
          {
            "code" : "J05AF10",
            "display" : "entecavir"
          },
          {
            "code" : "J05AF11",
            "display" : "telbivudine"
          },
          {
            "code" : "J05AF12",
            "display" : "clevudine"
          },
          {
            "code" : "J05AF13",
            "display" : "tenofovir alafenamide"
          },
          {
            "code" : "J05AG",
            "display" : "Non-nucleoside reverse transcriptase inhibitors"
          },
          {
            "code" : "J05AG01",
            "display" : "nevirapine"
          },
          {
            "code" : "J05AG02",
            "display" : "delavirdine"
          },
          {
            "code" : "J05AG03",
            "display" : "efavirenz"
          },
          {
            "code" : "J05AG04",
            "display" : "etravirine"
          },
          {
            "code" : "J05AG05",
            "display" : "rilpivirine"
          },
          {
            "code" : "J05AG06",
            "display" : "doravirine"
          },
          {
            "code" : "J05AG07",
            "display" : "elsulfavirine"
          },
          {
            "code" : "J05AH",
            "display" : "Neuraminidase inhibitors"
          },
          {
            "code" : "J05AH01",
            "display" : "zanamivir"
          },
          {
            "code" : "J05AH02",
            "display" : "oseltamivir"
          },
          {
            "code" : "J05AH03",
            "display" : "peramivir"
          },
          {
            "code" : "J05AH04",
            "display" : "laninamivir"
          },
          {
            "code" : "J05AJ",
            "display" : "Integrase inhibitors"
          },
          {
            "code" : "J05AJ01",
            "display" : "raltegravir"
          },
          {
            "code" : "J05AJ02",
            "display" : "elvitegravir"
          },
          {
            "code" : "J05AJ03",
            "display" : "dolutegravir"
          },
          {
            "code" : "J05AJ04",
            "display" : "cabotegravir"
          },
          {
            "code" : "J05AP",
            "display" : "Antivirals for treatment of HCV infections"
          },
          {
            "code" : "J05AP01",
            "display" : "ribavirin"
          },
          {
            "code" : "J05AP02",
            "display" : "telaprevir"
          },
          {
            "code" : "J05AP03",
            "display" : "boceprevir"
          },
          {
            "code" : "J05AP04",
            "display" : "faldaprevir"
          },
          {
            "code" : "J05AP05",
            "display" : "simeprevir"
          },
          {
            "code" : "J05AP06",
            "display" : "asunaprevir"
          },
          {
            "code" : "J05AP07",
            "display" : "daclatasvir"
          },
          {
            "code" : "J05AP08",
            "display" : "sofosbuvir"
          },
          {
            "code" : "J05AP09",
            "display" : "dasabuvir"
          },
          {
            "code" : "J05AP10",
            "display" : "elbasvir"
          },
          {
            "code" : "J05AP11",
            "display" : "grazoprevir"
          },
          {
            "code" : "J05AP12",
            "display" : "coblopasvir"
          },
          {
            "code" : "J05AP13",
            "display" : "ravidasvir"
          },
          {
            "code" : "J05AP14",
            "display" : "narlaprevir"
          },
          {
            "code" : "J05AP51",
            "display" : "sofosbuvir and ledipasvir"
          },
          {
            "code" : "J05AP52",
            "display" : "dasabuvir, ombitasvir, paritaprevir and ritonavir"
          },
          {
            "code" : "J05AP53",
            "display" : "ombitasvir, paritaprevir and ritonavir"
          },
          {
            "code" : "J05AP54",
            "display" : "elbasvir and grazoprevir"
          },
          {
            "code" : "J05AP55",
            "display" : "sofosbuvir and velpatasvir"
          },
          {
            "code" : "J05AP56",
            "display" : "sofosbuvir, velpatasvir and voxilaprevir"
          },
          {
            "code" : "J05AP57",
            "display" : "glecaprevir and pibrentasvir"
          },
          {
            "code" : "J05AP58",
            "display" : "daclatasvir, asunaprevir and beclabuvir"
          },
          {
            "code" : "J05AR",
            "display" : "Antivirals for treatment of HIV infections, combinations"
          },
          {
            "code" : "J05AR01",
            "display" : "zidovudine and lamivudine"
          },
          {
            "code" : "J05AR02",
            "display" : "lamivudine and abacavir"
          },
          {
            "code" : "J05AR03",
            "display" : "tenofovir disoproxil and emtricitabine"
          },
          {
            "code" : "J05AR04",
            "display" : "zidovudine, lamivudine and abacavir"
          },
          {
            "code" : "J05AR05",
            "display" : "zidovudine, lamivudine and nevirapine"
          },
          {
            "code" : "J05AR06",
            "display" : "emtricitabine, tenofovir disoproxil and efavirenz"
          },
          {
            "code" : "J05AR07",
            "display" : "stavudine, lamivudine and nevirapine"
          },
          {
            "code" : "J05AR08",
            "display" : "emtricitabine, tenofovir disoproxil and rilpivirine"
          },
          {
            "code" : "J05AR09",
            "display" : "emtricitabine, tenofovir disoproxil, elvitegravir and cobicistat"
          },
          {
            "code" : "J05AR10",
            "display" : "lopinavir and ritonavir"
          },
          {
            "code" : "J05AR11",
            "display" : "lamivudine, tenofovir disoproxil and efavirenz"
          },
          {
            "code" : "J05AR12",
            "display" : "lamivudine and tenofovir disoproxil"
          },
          {
            "code" : "J05AR13",
            "display" : "lamivudine, abacavir and dolutegravir"
          },
          {
            "code" : "J05AR14",
            "display" : "darunavir and cobicistat"
          },
          {
            "code" : "J05AR15",
            "display" : "atazanavir and cobicistat"
          },
          {
            "code" : "J05AR16",
            "display" : "lamivudine and raltegravir"
          },
          {
            "code" : "J05AR17",
            "display" : "emtricitabine and tenofovir alafenamide"
          },
          {
            "code" : "J05AR18",
            "display" : "emtricitabine, tenofovir alafenamide, elvitegravir and cobicistat"
          },
          {
            "code" : "J05AR19",
            "display" : "emtricitabine, tenofovir alafenamide and rilpivirine"
          },
          {
            "code" : "J05AR20",
            "display" : "emtricitabine, tenofovir alafenamide and bictegravir"
          },
          {
            "code" : "J05AR21",
            "display" : "dolutegravir and rilpivirine"
          },
          {
            "code" : "J05AR22",
            "display" : "emtricitabine, tenofovir alafenamide, darunavir and cobicistat"
          },
          {
            "code" : "J05AR23",
            "display" : "atazanavir and ritonavir"
          },
          {
            "code" : "J05AR24",
            "display" : "lamivudine, tenofovir disoproxil and doravirine"
          },
          {
            "code" : "J05AR25",
            "display" : "lamivudine and dolutegravir"
          },
          {
            "code" : "J05AR26",
            "display" : "darunavir and ritonavir"
          },
          {
            "code" : "J05AR27",
            "display" : "lamivudine, tenofovir disoproxil and dolutegravir"
          },
          {
            "code" : "J05AR28",
            "display" : "stavudine and lamivudine"
          },
          {
            "code" : "J05AR29",
            "display" : "emtricitabine, tenofovir alafenamide and dolutegravir"
          },
          {
            "code" : "J05AX",
            "display" : "Other antivirals"
          },
          {
            "code" : "J05AX01",
            "display" : "moroxydine"
          },
          {
            "code" : "J05AX02",
            "display" : "lysozyme"
          },
          {
            "code" : "J05AX05",
            "display" : "inosine pranobex"
          },
          {
            "code" : "J05AX06",
            "display" : "pleconaril"
          },
          {
            "code" : "J05AX07",
            "display" : "enfuvirtide"
          },
          {
            "code" : "J05AX09",
            "display" : "maraviroc"
          },
          {
            "code" : "J05AX10",
            "display" : "maribavir"
          },
          {
            "code" : "J05AX13",
            "display" : "umifenovir"
          },
          {
            "code" : "J05AX17",
            "display" : "enisamium iodide"
          },
          {
            "code" : "J05AX18",
            "display" : "letermovir"
          },
          {
            "code" : "J05AX19",
            "display" : "tilorone"
          },
          {
            "code" : "J05AX21",
            "display" : "pentanedioic acid imidazolyl ethanamide"
          },
          {
            "code" : "J05AX23",
            "display" : "ibalizumab"
          },
          {
            "code" : "J05AX24",
            "display" : "tecovirimat"
          },
          {
            "code" : "J05AX25",
            "display" : "baloxavir marboxil"
          },
          {
            "code" : "J05AX26",
            "display" : "amenamevir"
          },
          {
            "code" : "J05AX27",
            "display" : "favipiravir"
          },
          {
            "code" : "J05AX28",
            "display" : "bulevirtide"
          },
          {
            "code" : "J05AX29",
            "display" : "fostemsavir"
          },
          {
            "code" : "J05AX31",
            "display" : "lenacapavir"
          },
          {
            "code" : "J05AX32",
            "display" : "riamilovir"
          },
          {
            "code" : "J05AX33",
            "display" : "labuvirtide"
          },
          {
            "code" : "J06",
            "display" : "IMMUNE SERA AND IMMUNOGLOBULINS"
          },
          {
            "code" : "J06A",
            "display" : "IMMUNE SERA"
          },
          {
            "code" : "J06AA",
            "display" : "Immune sera"
          },
          {
            "code" : "J06AA01",
            "display" : "diphtheria antitoxin"
          },
          {
            "code" : "J06AA02",
            "display" : "tetanus antitoxin"
          },
          {
            "code" : "J06AA03",
            "display" : "snake venom antiserum"
          },
          {
            "code" : "J06AA04",
            "display" : "botulinum antitoxin"
          },
          {
            "code" : "J06AA05",
            "display" : "gas-gangrene sera"
          },
          {
            "code" : "J06AA06",
            "display" : "rabies serum"
          },
          {
            "code" : "J06B",
            "display" : "IMMUNOGLOBULINS"
          },
          {
            "code" : "J06BA",
            "display" : "Immunoglobulins, normal human"
          },
          {
            "code" : "J06BA01",
            "display" : "immunoglobulins, normal human, for extravascular adm."
          },
          {
            "code" : "J06BA02",
            "display" : "immunoglobulins, normal human, for intravascular adm."
          },
          {
            "code" : "J06BB",
            "display" : "Specific immunoglobulins"
          },
          {
            "code" : "J06BB01",
            "display" : "anti-D (rh) immunoglobulin"
          },
          {
            "code" : "J06BB02",
            "display" : "tetanus immunoglobulin"
          },
          {
            "code" : "J06BB03",
            "display" : "varicella/zoster immunoglobulin"
          },
          {
            "code" : "J06BB04",
            "display" : "hepatitis B immunoglobulin"
          },
          {
            "code" : "J06BB05",
            "display" : "rabies immunoglobulin"
          },
          {
            "code" : "J06BB06",
            "display" : "rubella immunoglobulin"
          },
          {
            "code" : "J06BB07",
            "display" : "vaccinia immunoglobulin"
          },
          {
            "code" : "J06BB08",
            "display" : "staphylococcus immunoglobulin"
          },
          {
            "code" : "J06BB09",
            "display" : "cytomegalovirus immunoglobulin"
          },
          {
            "code" : "J06BB10",
            "display" : "diphtheria immunoglobulin"
          },
          {
            "code" : "J06BB11",
            "display" : "hepatitis A immunoglobulin"
          },
          {
            "code" : "J06BB12",
            "display" : "encephalitis, tick borne immunoglobulin"
          },
          {
            "code" : "J06BB13",
            "display" : "pertussis immunoglobulin"
          },
          {
            "code" : "J06BB14",
            "display" : "measles immunoglobulin"
          },
          {
            "code" : "J06BB15",
            "display" : "mumps immunoglobulin"
          },
          {
            "code" : "J06BB19",
            "display" : "anthrax immunoglobulin"
          },
          {
            "code" : "J06BB30",
            "display" : "combinations"
          },
          {
            "code" : "J06BC",
            "display" : "Antibacterial monoclonal antibodies"
          },
          {
            "code" : "J06BC01",
            "display" : "nebacumab"
          },
          {
            "code" : "J06BC02",
            "display" : "raxibacumab"
          },
          {
            "code" : "J06BC03",
            "display" : "bezlotoxumab"
          },
          {
            "code" : "J06BC04",
            "display" : "obiltoxaximab"
          },
          {
            "code" : "J06BD",
            "display" : "Antiviral monoclonal antibodies"
          },
          {
            "code" : "J06BD01",
            "display" : "palivizumab"
          },
          {
            "code" : "J06BD02",
            "display" : "motavizumab"
          },
          {
            "code" : "J06BD03",
            "display" : "tixagevimab and cilgavimab"
          },
          {
            "code" : "J06BD04",
            "display" : "ansuvimab"
          },
          {
            "code" : "J06BD05",
            "display" : "sotrovimab"
          },
          {
            "code" : "J06BD06",
            "display" : "regdanvimab"
          },
          {
            "code" : "J06BD07",
            "display" : "casirivimab and imdevimab"
          },
          {
            "code" : "J06BD08",
            "display" : "nirsevimab"
          },
          {
            "code" : "J06BD09",
            "display" : "sipavibart"
          },
          {
            "code" : "J07",
            "display" : "VACCINES"
          },
          {
            "code" : "J07A",
            "display" : "BACTERIAL VACCINES"
          },
          {
            "code" : "J07AC",
            "display" : "Anthrax vaccines"
          },
          {
            "code" : "J07AC01",
            "display" : "anthrax antigen"
          },
          {
            "code" : "J07AD",
            "display" : "Brucellosis vaccines"
          },
          {
            "code" : "J07AD01",
            "display" : "brucella antigen"
          },
          {
            "code" : "J07AE",
            "display" : "Cholera vaccines"
          },
          {
            "code" : "J07AE01",
            "display" : "cholera, inactivated, whole cell"
          },
          {
            "code" : "J07AE02",
            "display" : "cholera, live attenuated"
          },
          {
            "code" : "J07AE51",
            "display" : "cholera, combinations with typhoid vaccine, inactivated, whole cell"
          },
          {
            "code" : "J07AF",
            "display" : "Diphtheria vaccines"
          },
          {
            "code" : "J07AF01",
            "display" : "diphtheria toxoid"
          },
          {
            "code" : "J07AG",
            "display" : "Haemophilus influenzae B vaccines"
          },
          {
            "code" : "J07AG01",
            "display" : "haemophilus influenzae B, purified antigen conjugated"
          },
          {
            "code" : "J07AG51",
            "display" : "haemophilus influenzae B, combinations with toxoids"
          },
          {
            "code" : "J07AG52",
            "display" : "haemophilus influenzae B, combinations with pertussis and toxoids"
          },
          {
            "code" : "J07AG53",
            "display" : "haemophilus influenzae B, combinations with meningococcus C, conjugated"
          },
          {
            "code" : "J07AG54",
            "display" : "haemophilus influenza B, combinations with meningococcus C,Y, conjugated"
          },
          {
            "code" : "J07AH",
            "display" : "Meningococcal vaccines"
          },
          {
            "code" : "J07AH01",
            "display" : "meningococcus A, purified polysaccharides antigen"
          },
          {
            "code" : "J07AH02",
            "display" : "other meningococcal monovalent purified polysaccharides antigen"
          },
          {
            "code" : "J07AH03",
            "display" : "meningococcus A,C, bivalent purified polysaccharides antigen"
          },
          {
            "code" : "J07AH04",
            "display" : "meningococcus A,C,Y,W-135, tetravalent purified polysaccharides antigen"
          },
          {
            "code" : "J07AH05",
            "display" : "other meningococcal polyvalent purified polysaccharides antigen"
          },
          {
            "code" : "J07AH06",
            "display" : "meningococcus B, outer membrane vesicle vaccine"
          },
          {
            "code" : "J07AH07",
            "display" : "meningococcus C, purified polysaccharides antigen conjugated"
          },
          {
            "code" : "J07AH08",
            "display" : "meningococcus A,C,Y,W-135, tetravalent purified polysaccharides antigen conjugated"
          },
          {
            "code" : "J07AH09",
            "display" : "meningococcus B, multicomponent vaccine"
          },
          {
            "code" : "J07AH10",
            "display" : "meningococcus A, purified polysaccharides antigen conjugated"
          },
          {
            "code" : "J07AH11",
            "display" : "meningococcus A,B,C,Y,W-135, pentavalent purified polysaccharides antigen conjugated and factor H binding protein"
          },
          {
            "code" : "J07AJ",
            "display" : "Pertussis vaccines"
          },
          {
            "code" : "J07AJ01",
            "display" : "pertussis, inactivated, whole cell"
          },
          {
            "code" : "J07AJ02",
            "display" : "pertussis, purified antigen"
          },
          {
            "code" : "J07AJ51",
            "display" : "pertussis, inactivated, whole cell, combinations with toxoids"
          },
          {
            "code" : "J07AJ52",
            "display" : "pertussis, purified antigen, combinations with toxoids"
          },
          {
            "code" : "J07AK",
            "display" : "Plague vaccines"
          },
          {
            "code" : "J07AK01",
            "display" : "plague, inactivated, whole cell"
          },
          {
            "code" : "J07AL",
            "display" : "Pneumococcal vaccines"
          },
          {
            "code" : "J07AL01",
            "display" : "pneumococcus, purified polysaccharides antigen"
          },
          {
            "code" : "J07AL02",
            "display" : "pneumococcus, purified polysaccharides antigen conjugated"
          },
          {
            "code" : "J07AL52",
            "display" : "pneumococcus purified polysaccharides antigen and haemophilus influenzae, conjugated"
          },
          {
            "code" : "J07AM",
            "display" : "Tetanus vaccines"
          },
          {
            "code" : "J07AM01",
            "display" : "tetanus toxoid"
          },
          {
            "code" : "J07AM51",
            "display" : "tetanus toxoid, combinations with diphtheria toxoid"
          },
          {
            "code" : "J07AM52",
            "display" : "tetanus toxoid, combinations with tetanus immunoglobulin"
          },
          {
            "code" : "J07AN",
            "display" : "Tuberculosis vaccines"
          },
          {
            "code" : "J07AN01",
            "display" : "tuberculosis, live attenuated"
          },
          {
            "code" : "J07AP",
            "display" : "Typhoid vaccines"
          },
          {
            "code" : "J07AP01",
            "display" : "typhoid, oral, live attenuated"
          },
          {
            "code" : "J07AP02",
            "display" : "typhoid, inactivated, whole cell"
          },
          {
            "code" : "J07AP03",
            "display" : "typhoid, purified polysaccharide antigen"
          },
          {
            "code" : "J07AP10",
            "display" : "typhoid, combinations with paratyphi types"
          },
          {
            "code" : "J07AR",
            "display" : "Typhus (exanthematicus) vaccines"
          },
          {
            "code" : "J07AR01",
            "display" : "typhus exanthematicus, inactivated, whole cell"
          },
          {
            "code" : "J07AX",
            "display" : "Other bacterial vaccines"
          },
          {
            "code" : "J07AX01",
            "display" : "leptospira vaccines"
          },
          {
            "code" : "J07B",
            "display" : "VIRAL VACCINES"
          },
          {
            "code" : "J07BA",
            "display" : "Encephalitis vaccines"
          },
          {
            "code" : "J07BA01",
            "display" : "encephalitis, tick borne, inactivated, whole virus"
          },
          {
            "code" : "J07BA02",
            "display" : "encephalitis, Japanese, inactivated, whole virus"
          },
          {
            "code" : "J07BA03",
            "display" : "encephalitis, Japanese, live attenuated"
          },
          {
            "code" : "J07BB",
            "display" : "Influenza vaccines"
          },
          {
            "code" : "J07BB01",
            "display" : "influenza, inactivated, whole virus"
          },
          {
            "code" : "J07BB02",
            "display" : "influenza, inactivated, split virus or surface antigen"
          },
          {
            "code" : "J07BB03",
            "display" : "influenza, live attenuated"
          },
          {
            "code" : "J07BB04",
            "display" : "influenza, virus like particles"
          },
          {
            "code" : "J07BB05",
            "display" : "influenza, RNA-based vaccine"
          },
          {
            "code" : "J07BC",
            "display" : "Hepatitis vaccines"
          },
          {
            "code" : "J07BC01",
            "display" : "hepatitis B, purified antigen"
          },
          {
            "code" : "J07BC02",
            "display" : "hepatitis A, inactivated, whole virus"
          },
          {
            "code" : "J07BC20",
            "display" : "combinations"
          },
          {
            "code" : "J07BD",
            "display" : "Measles vaccines"
          },
          {
            "code" : "J07BD01",
            "display" : "measles, live attenuated"
          },
          {
            "code" : "J07BD51",
            "display" : "measles, combinations with mumps, live attenuated"
          },
          {
            "code" : "J07BD52",
            "display" : "measles, combinations with mumps and rubella, live attenuated"
          },
          {
            "code" : "J07BD53",
            "display" : "measles, combinations with rubella, live attenuated"
          },
          {
            "code" : "J07BD54",
            "display" : "measles, combinations with mumps, rubella and varicella, live attenuated"
          },
          {
            "code" : "J07BE",
            "display" : "Mumps vaccines"
          },
          {
            "code" : "J07BE01",
            "display" : "mumps, live attenuated"
          },
          {
            "code" : "J07BF",
            "display" : "Poliomyelitis vaccines"
          },
          {
            "code" : "J07BF01",
            "display" : "poliomyelitis oral, monovalent, live attenuated"
          },
          {
            "code" : "J07BF02",
            "display" : "poliomyelitis oral, trivalent, live attenuated"
          },
          {
            "code" : "J07BF03",
            "display" : "poliomyelitis, trivalent, inactivated, whole virus"
          },
          {
            "code" : "J07BF04",
            "display" : "poliomyelitis oral, bivalent, live attenuated"
          },
          {
            "code" : "J07BG",
            "display" : "Rabies vaccines"
          },
          {
            "code" : "J07BG01",
            "display" : "rabies, inactivated, whole virus"
          },
          {
            "code" : "J07BH",
            "display" : "Rota virus diarrhea vaccines"
          },
          {
            "code" : "J07BH01",
            "display" : "rota virus, live attenuated"
          },
          {
            "code" : "J07BH02",
            "display" : "rota virus, pentavalent, live, reassorted"
          },
          {
            "code" : "J07BJ",
            "display" : "Rubella vaccines"
          },
          {
            "code" : "J07BJ01",
            "display" : "rubella, live attenuated"
          },
          {
            "code" : "J07BJ51",
            "display" : "rubella, combinations with mumps, live attenuated"
          },
          {
            "code" : "J07BK",
            "display" : "Varicella zoster vaccines"
          },
          {
            "code" : "J07BK01",
            "display" : "varicella, live attenuated"
          },
          {
            "code" : "J07BK02",
            "display" : "zoster, live attenuated"
          },
          {
            "code" : "J07BK03",
            "display" : "zoster, purified antigen"
          },
          {
            "code" : "J07BL",
            "display" : "Yellow fever vaccines"
          },
          {
            "code" : "J07BL01",
            "display" : "yellow fever, live attenuated"
          },
          {
            "code" : "J07BM",
            "display" : "Papillomavirus vaccines"
          },
          {
            "code" : "J07BM01",
            "display" : "papillomavirus (human types 6, 11, 16, 18)"
          },
          {
            "code" : "J07BM02",
            "display" : "papillomavirus (human types 16, 18)"
          },
          {
            "code" : "J07BM03",
            "display" : "papillomavirus (human types 6, 11, 16, 18, 31, 33, 45, 52, 58)"
          },
          {
            "code" : "J07BN",
            "display" : "Covid-19 vaccines"
          },
          {
            "code" : "J07BN01",
            "display" : "covid-19, RNA-based vaccine"
          },
          {
            "code" : "J07BN02",
            "display" : "covid-19, viral vector, non-replicating"
          },
          {
            "code" : "J07BN03",
            "display" : "covid-19, inactivated virus"
          },
          {
            "code" : "J07BN04",
            "display" : "covid-19, protein subunit"
          },
          {
            "code" : "J07BN05",
            "display" : "covid-19, virus-like particles"
          },
          {
            "code" : "J07BX",
            "display" : "Other viral vaccines"
          },
          {
            "code" : "J07BX01",
            "display" : "smallpox and monkeypox vaccines"
          },
          {
            "code" : "J07BX02",
            "display" : "ebola vaccines"
          },
          {
            "code" : "J07BX04",
            "display" : "dengue virus vaccines"
          },
          {
            "code" : "J07BX05",
            "display" : "respiratory syncytial virus vaccines"
          },
          {
            "code" : "J07BX06",
            "display" : "enterovirus 71 vaccines"
          },
          {
            "code" : "J07C",
            "display" : "BACTERIAL AND VIRAL VACCINES, COMBINED"
          },
          {
            "code" : "J07CA",
            "display" : "Bacterial and viral vaccines, combined"
          },
          {
            "code" : "J07CA01",
            "display" : "diphtheria-poliomyelitis-tetanus"
          },
          {
            "code" : "J07CA02",
            "display" : "diphtheria-pertussis-poliomyelitis-tetanus"
          },
          {
            "code" : "J07CA03",
            "display" : "diphtheria-rubella-tetanus"
          },
          {
            "code" : "J07CA04",
            "display" : "haemophilus influenzae B and poliomyelitis"
          },
          {
            "code" : "J07CA05",
            "display" : "diphtheria-hepatitis B-pertussis-tetanus"
          },
          {
            "code" : "J07CA06",
            "display" : "diphtheria-haemophilus influenzae B-pertussis-poliomyelitis-tetanus"
          },
          {
            "code" : "J07CA07",
            "display" : "diphtheria-hepatitis B-tetanus"
          },
          {
            "code" : "J07CA08",
            "display" : "haemophilus influenzae B and hepatitis B"
          },
          {
            "code" : "J07CA09",
            "display" : "diphtheria-haemophilus influenzae B-pertussis-poliomyelitis-tetanus-hepatitis B"
          },
          {
            "code" : "J07CA10",
            "display" : "typhoid-hepatitis A"
          },
          {
            "code" : "J07CA11",
            "display" : "diphtheria-haemophilus influenzae B-pertussis-tetanus-hepatitis B"
          },
          {
            "code" : "J07CA12",
            "display" : "diphtheria-pertussis-poliomyelitis-tetanus-hepatitis B"
          },
          {
            "code" : "J07CA13",
            "display" : "diphtheria-haemophilus influenzae B-pertussis-tetanus-hepatitis B-meningococcus A + C"
          },
          {
            "code" : "J07X",
            "display" : "OTHER VACCINES"
          },
          {
            "code" : "J07XA",
            "display" : "Parasitic vaccines"
          },
          {
            "code" : "J07XA01",
            "display" : "malaria vaccines"
          },
          {
            "code" : "L",
            "display" : "ANTINEOPLASTIC AND IMMUNOMODULATING AGENTS"
          },
          {
            "code" : "L01",
            "display" : "ANTINEOPLASTIC AGENTS"
          },
          {
            "code" : "L01A",
            "display" : "ALKYLATING AGENTS"
          },
          {
            "code" : "L01AA",
            "display" : "Nitrogen mustard analogues"
          },
          {
            "code" : "L01AA01",
            "display" : "cyclophosphamide"
          },
          {
            "code" : "L01AA02",
            "display" : "chlorambucil"
          },
          {
            "code" : "L01AA03",
            "display" : "melphalan"
          },
          {
            "code" : "L01AA05",
            "display" : "chlormethine"
          },
          {
            "code" : "L01AA06",
            "display" : "ifosfamide"
          },
          {
            "code" : "L01AA07",
            "display" : "trofosfamide"
          },
          {
            "code" : "L01AA08",
            "display" : "prednimustine"
          },
          {
            "code" : "L01AA09",
            "display" : "bendamustine"
          },
          {
            "code" : "L01AA10",
            "display" : "melphalan flufenamide"
          },
          {
            "code" : "L01AB",
            "display" : "Alkyl sulfonates"
          },
          {
            "code" : "L01AB01",
            "display" : "busulfan"
          },
          {
            "code" : "L01AB02",
            "display" : "treosulfan"
          },
          {
            "code" : "L01AB03",
            "display" : "mannosulfan"
          },
          {
            "code" : "L01AC",
            "display" : "Ethylene imines"
          },
          {
            "code" : "L01AC01",
            "display" : "thiotepa"
          },
          {
            "code" : "L01AC02",
            "display" : "triaziquone"
          },
          {
            "code" : "L01AC03",
            "display" : "carboquone"
          },
          {
            "code" : "L01AD",
            "display" : "Nitrosoureas"
          },
          {
            "code" : "L01AD01",
            "display" : "carmustine"
          },
          {
            "code" : "L01AD02",
            "display" : "lomustine"
          },
          {
            "code" : "L01AD03",
            "display" : "semustine"
          },
          {
            "code" : "L01AD04",
            "display" : "streptozocin"
          },
          {
            "code" : "L01AD05",
            "display" : "fotemustine"
          },
          {
            "code" : "L01AD06",
            "display" : "nimustine"
          },
          {
            "code" : "L01AD07",
            "display" : "ranimustine"
          },
          {
            "code" : "L01AD08",
            "display" : "uramustine"
          },
          {
            "code" : "L01AG",
            "display" : "Epoxides"
          },
          {
            "code" : "L01AG01",
            "display" : "etoglucid"
          },
          {
            "code" : "L01AX",
            "display" : "Other alkylating agents"
          },
          {
            "code" : "L01AX01",
            "display" : "mitobronitol"
          },
          {
            "code" : "L01AX02",
            "display" : "pipobroman"
          },
          {
            "code" : "L01AX03",
            "display" : "temozolomide"
          },
          {
            "code" : "L01AX04",
            "display" : "dacarbazine"
          },
          {
            "code" : "L01B",
            "display" : "ANTIMETABOLITES"
          },
          {
            "code" : "L01BA",
            "display" : "Folic acid analogues"
          },
          {
            "code" : "L01BA01",
            "display" : "methotrexate"
          },
          {
            "code" : "L01BA03",
            "display" : "raltitrexed"
          },
          {
            "code" : "L01BA04",
            "display" : "pemetrexed"
          },
          {
            "code" : "L01BA05",
            "display" : "pralatrexate"
          },
          {
            "code" : "L01BB",
            "display" : "Purine analogues"
          },
          {
            "code" : "L01BB02",
            "display" : "mercaptopurine"
          },
          {
            "code" : "L01BB03",
            "display" : "tioguanine"
          },
          {
            "code" : "L01BB04",
            "display" : "cladribine"
          },
          {
            "code" : "L01BB05",
            "display" : "fludarabine"
          },
          {
            "code" : "L01BB06",
            "display" : "clofarabine"
          },
          {
            "code" : "L01BB07",
            "display" : "nelarabine"
          },
          {
            "code" : "L01BC",
            "display" : "Pyrimidine analogues"
          },
          {
            "code" : "L01BC01",
            "display" : "cytarabine"
          },
          {
            "code" : "L01BC02",
            "display" : "fluorouracil"
          },
          {
            "code" : "L01BC03",
            "display" : "tegafur"
          },
          {
            "code" : "L01BC04",
            "display" : "carmofur"
          },
          {
            "code" : "L01BC05",
            "display" : "gemcitabine"
          },
          {
            "code" : "L01BC06",
            "display" : "capecitabine"
          },
          {
            "code" : "L01BC07",
            "display" : "azacitidine"
          },
          {
            "code" : "L01BC08",
            "display" : "decitabine"
          },
          {
            "code" : "L01BC09",
            "display" : "floxuridine"
          },
          {
            "code" : "L01BC52",
            "display" : "fluorouracil, combinations"
          },
          {
            "code" : "L01BC53",
            "display" : "tegafur, combinations"
          },
          {
            "code" : "L01BC58",
            "display" : "decitabine, combinations"
          },
          {
            "code" : "L01BC59",
            "display" : "trifluridine, combinations"
          },
          {
            "code" : "L01C",
            "display" : "PLANT ALKALOIDS AND OTHER NATURAL PRODUCTS"
          },
          {
            "code" : "L01CA",
            "display" : "Vinca alkaloids and analogues"
          },
          {
            "code" : "L01CA01",
            "display" : "vinblastine"
          },
          {
            "code" : "L01CA02",
            "display" : "vincristine"
          },
          {
            "code" : "L01CA03",
            "display" : "vindesine"
          },
          {
            "code" : "L01CA04",
            "display" : "vinorelbine"
          },
          {
            "code" : "L01CA05",
            "display" : "vinflunine"
          },
          {
            "code" : "L01CA06",
            "display" : "vintafolide"
          },
          {
            "code" : "L01CB",
            "display" : "Podophyllotoxin derivatives"
          },
          {
            "code" : "L01CB01",
            "display" : "etoposide"
          },
          {
            "code" : "L01CB02",
            "display" : "teniposide"
          },
          {
            "code" : "L01CC",
            "display" : "Colchicine derivatives"
          },
          {
            "code" : "L01CC01",
            "display" : "demecolcine"
          },
          {
            "code" : "L01CD",
            "display" : "Taxanes"
          },
          {
            "code" : "L01CD01",
            "display" : "paclitaxel"
          },
          {
            "code" : "L01CD02",
            "display" : "docetaxel"
          },
          {
            "code" : "L01CD03",
            "display" : "paclitaxel poliglumex"
          },
          {
            "code" : "L01CD04",
            "display" : "cabazitaxel"
          },
          {
            "code" : "L01CD51",
            "display" : "paclitaxel and encequidar"
          },
          {
            "code" : "L01CE",
            "display" : "Topoisomerase 1 (TOP1) inhibitors"
          },
          {
            "code" : "L01CE01",
            "display" : "topotecan"
          },
          {
            "code" : "L01CE02",
            "display" : "irinotecan"
          },
          {
            "code" : "L01CE03",
            "display" : "etirinotecan pegol"
          },
          {
            "code" : "L01CE04",
            "display" : "belotecan"
          },
          {
            "code" : "L01CX",
            "display" : "Other plant alkaloids and natural products"
          },
          {
            "code" : "L01CX01",
            "display" : "trabectedin"
          },
          {
            "code" : "L01D",
            "display" : "CYTOTOXIC ANTIBIOTICS AND RELATED SUBSTANCES"
          },
          {
            "code" : "L01DA",
            "display" : "Actinomycines"
          },
          {
            "code" : "L01DA01",
            "display" : "dactinomycin"
          },
          {
            "code" : "L01DB",
            "display" : "Anthracyclines and related substances"
          },
          {
            "code" : "L01DB01",
            "display" : "doxorubicin"
          },
          {
            "code" : "L01DB02",
            "display" : "daunorubicin"
          },
          {
            "code" : "L01DB03",
            "display" : "epirubicin"
          },
          {
            "code" : "L01DB04",
            "display" : "aclarubicin"
          },
          {
            "code" : "L01DB05",
            "display" : "zorubicin"
          },
          {
            "code" : "L01DB06",
            "display" : "idarubicin"
          },
          {
            "code" : "L01DB07",
            "display" : "mitoxantrone"
          },
          {
            "code" : "L01DB08",
            "display" : "pirarubicin"
          },
          {
            "code" : "L01DB09",
            "display" : "valrubicin"
          },
          {
            "code" : "L01DB10",
            "display" : "amrubicin"
          },
          {
            "code" : "L01DB11",
            "display" : "pixantrone"
          },
          {
            "code" : "L01DC",
            "display" : "Other cytotoxic antibiotics"
          },
          {
            "code" : "L01DC01",
            "display" : "bleomycin"
          },
          {
            "code" : "L01DC02",
            "display" : "plicamycin"
          },
          {
            "code" : "L01DC03",
            "display" : "mitomycin"
          },
          {
            "code" : "L01DC04",
            "display" : "ixabepilone"
          },
          {
            "code" : "L01DC05",
            "display" : "utidelone"
          },
          {
            "code" : "L01E",
            "display" : "PROTEIN KINASE INHIBITORS"
          },
          {
            "code" : "L01EA",
            "display" : "BCR-ABL tyrosine kinase inhibitors"
          },
          {
            "code" : "L01EA01",
            "display" : "imatinib"
          },
          {
            "code" : "L01EA02",
            "display" : "dasatinib"
          },
          {
            "code" : "L01EA03",
            "display" : "nilotinib"
          },
          {
            "code" : "L01EA04",
            "display" : "bosutinib"
          },
          {
            "code" : "L01EA05",
            "display" : "ponatinib"
          },
          {
            "code" : "L01EA06",
            "display" : "asciminib"
          },
          {
            "code" : "L01EB",
            "display" : "Epidermal growth factor receptor (EGFR) tyrosine kinase inhibitors"
          },
          {
            "code" : "L01EB01",
            "display" : "gefitinib"
          },
          {
            "code" : "L01EB02",
            "display" : "erlotinib"
          },
          {
            "code" : "L01EB03",
            "display" : "afatinib"
          },
          {
            "code" : "L01EB04",
            "display" : "osimertinib"
          },
          {
            "code" : "L01EB05",
            "display" : "rociletinib"
          },
          {
            "code" : "L01EB06",
            "display" : "olmutinib"
          },
          {
            "code" : "L01EB07",
            "display" : "dacomitinib"
          },
          {
            "code" : "L01EB08",
            "display" : "icotinib"
          },
          {
            "code" : "L01EB09",
            "display" : "lazertinib"
          },
          {
            "code" : "L01EB10",
            "display" : "mobocertinib"
          },
          {
            "code" : "L01EB11",
            "display" : "aumolertinib"
          },
          {
            "code" : "L01EC",
            "display" : "B-Raf serine-threonine kinase (BRAF) inhibitors"
          },
          {
            "code" : "L01EC01",
            "display" : "vemurafenib"
          },
          {
            "code" : "L01EC02",
            "display" : "dabrafenib"
          },
          {
            "code" : "L01EC03",
            "display" : "encorafenib"
          },
          {
            "code" : "L01ED",
            "display" : "Anaplastic lymphoma kinase (ALK) inhibitors"
          },
          {
            "code" : "L01ED01",
            "display" : "crizotinib"
          },
          {
            "code" : "L01ED02",
            "display" : "ceritinib"
          },
          {
            "code" : "L01ED03",
            "display" : "alectinib"
          },
          {
            "code" : "L01ED04",
            "display" : "brigatinib"
          },
          {
            "code" : "L01ED05",
            "display" : "lorlatinib"
          },
          {
            "code" : "L01EE",
            "display" : "Mitogen-activated protein kinase (MEK) inhibitors"
          },
          {
            "code" : "L01EE01",
            "display" : "trametinib"
          },
          {
            "code" : "L01EE02",
            "display" : "cobimetinib"
          },
          {
            "code" : "L01EE03",
            "display" : "binimetinib"
          },
          {
            "code" : "L01EE04",
            "display" : "selumetinib"
          },
          {
            "code" : "L01EE05",
            "display" : "mirdametinib"
          },
          {
            "code" : "L01EF",
            "display" : "Cyclin-dependent kinase (CDK) inhibitors"
          },
          {
            "code" : "L01EF01",
            "display" : "palbociclib"
          },
          {
            "code" : "L01EF02",
            "display" : "ribociclib"
          },
          {
            "code" : "L01EF03",
            "display" : "abemaciclib"
          },
          {
            "code" : "L01EG",
            "display" : "Mammalian target of rapamycin (mTOR) kinase inhibitors"
          },
          {
            "code" : "L01EG01",
            "display" : "temsirolimus"
          },
          {
            "code" : "L01EG02",
            "display" : "everolimus"
          },
          {
            "code" : "L01EG03",
            "display" : "ridaforolimus"
          },
          {
            "code" : "L01EG04",
            "display" : "sirolimus"
          },
          {
            "code" : "L01EH",
            "display" : "Human epidermal growth factor receptor 2 (HER2) tyrosine kinase inhibitors"
          },
          {
            "code" : "L01EH01",
            "display" : "lapatinib"
          },
          {
            "code" : "L01EH02",
            "display" : "neratinib"
          },
          {
            "code" : "L01EH03",
            "display" : "tucatinib"
          },
          {
            "code" : "L01EJ",
            "display" : "Janus-associated kinase (JAK) inhibitors"
          },
          {
            "code" : "L01EJ01",
            "display" : "ruxolitinib"
          },
          {
            "code" : "L01EJ02",
            "display" : "fedratinib"
          },
          {
            "code" : "L01EJ03",
            "display" : "pacritinib"
          },
          {
            "code" : "L01EJ04",
            "display" : "momelotinib"
          },
          {
            "code" : "L01EK",
            "display" : "Vascular endothelial growth factor receptor (VEGFR) tyrosine kinase inhibitors"
          },
          {
            "code" : "L01EK01",
            "display" : "axitinib"
          },
          {
            "code" : "L01EK02",
            "display" : "cediranib"
          },
          {
            "code" : "L01EK03",
            "display" : "tivozanib"
          },
          {
            "code" : "L01EK04",
            "display" : "fruquintinib"
          },
          {
            "code" : "L01EL",
            "display" : "Bruton's tyrosine kinase (BTK) inhibitors"
          },
          {
            "code" : "L01EL01",
            "display" : "ibrutinib"
          },
          {
            "code" : "L01EL02",
            "display" : "acalabrutinib"
          },
          {
            "code" : "L01EL03",
            "display" : "zanubrutinib"
          },
          {
            "code" : "L01EL04",
            "display" : "orelabrutinib"
          },
          {
            "code" : "L01EL05",
            "display" : "pirtobrutinib"
          },
          {
            "code" : "L01EL06",
            "display" : "tirabrutinib"
          },
          {
            "code" : "L01EM",
            "display" : "Phosphatidylinositol-3-kinase (Pi3K) inhibitors"
          },
          {
            "code" : "L01EM01",
            "display" : "idelalisib"
          },
          {
            "code" : "L01EM02",
            "display" : "copanlisib"
          },
          {
            "code" : "L01EM03",
            "display" : "alpelisib"
          },
          {
            "code" : "L01EM04",
            "display" : "duvelisib"
          },
          {
            "code" : "L01EM05",
            "display" : "parsaclisib"
          },
          {
            "code" : "L01EN",
            "display" : "Fibroblast growth factor receptor (FGFR) tyrosine kinase inhibitors"
          },
          {
            "code" : "L01EN01",
            "display" : "erdafitinib"
          },
          {
            "code" : "L01EN02",
            "display" : "pemigatinib"
          },
          {
            "code" : "L01EN03",
            "display" : "infigratinib"
          },
          {
            "code" : "L01EN04",
            "display" : "futibatinib"
          },
          {
            "code" : "L01EX",
            "display" : "Other protein kinase inhibitors"
          },
          {
            "code" : "L01EX01",
            "display" : "sunitinib"
          },
          {
            "code" : "L01EX02",
            "display" : "sorafenib"
          },
          {
            "code" : "L01EX03",
            "display" : "pazopanib"
          },
          {
            "code" : "L01EX04",
            "display" : "vandetanib"
          },
          {
            "code" : "L01EX05",
            "display" : "regorafenib"
          },
          {
            "code" : "L01EX06",
            "display" : "masitinib"
          },
          {
            "code" : "L01EX07",
            "display" : "cabozantinib"
          },
          {
            "code" : "L01EX08",
            "display" : "lenvatinib"
          },
          {
            "code" : "L01EX09",
            "display" : "nintedanib"
          },
          {
            "code" : "L01EX10",
            "display" : "midostaurin"
          },
          {
            "code" : "L01EX11",
            "display" : "quizartinib"
          },
          {
            "code" : "L01EX12",
            "display" : "larotrectinib"
          },
          {
            "code" : "L01EX13",
            "display" : "gilteritinib"
          },
          {
            "code" : "L01EX14",
            "display" : "entrectinib"
          },
          {
            "code" : "L01EX15",
            "display" : "pexidartinib"
          },
          {
            "code" : "L01EX17",
            "display" : "capmatinib"
          },
          {
            "code" : "L01EX18",
            "display" : "avapritinib"
          },
          {
            "code" : "L01EX19",
            "display" : "ripretinib"
          },
          {
            "code" : "L01EX21",
            "display" : "tepotinib"
          },
          {
            "code" : "L01EX22",
            "display" : "selpercatinib"
          },
          {
            "code" : "L01EX23",
            "display" : "pralsetinib"
          },
          {
            "code" : "L01EX24",
            "display" : "surufatinib"
          },
          {
            "code" : "L01EX25",
            "display" : "umbralisib"
          },
          {
            "code" : "L01EX26",
            "display" : "sitravatinib"
          },
          {
            "code" : "L01EX27",
            "display" : "capivasertib"
          },
          {
            "code" : "L01EX28",
            "display" : "repotrectinib"
          },
          {
            "code" : "L01F",
            "display" : "MONOCLONAL ANTIBODIES AND ANTIBODY DRUG CONJUGATES"
          },
          {
            "code" : "L01FA",
            "display" : "CD20 (Clusters of Differentiation 20) inhibitors"
          },
          {
            "code" : "L01FA01",
            "display" : "rituximab"
          },
          {
            "code" : "L01FA02",
            "display" : "ofatumumab"
          },
          {
            "code" : "L01FA03",
            "display" : "obinutuzumab"
          },
          {
            "code" : "L01FB",
            "display" : "CD22 (Clusters of Differentiation 22) inhibitors"
          },
          {
            "code" : "L01FB01",
            "display" : "inotuzumab ozogamicin"
          },
          {
            "code" : "L01FB02",
            "display" : "moxetumomab pasudotox"
          },
          {
            "code" : "L01FC",
            "display" : "CD38 (Clusters of Differentiation 38) inhibitors"
          },
          {
            "code" : "L01FC01",
            "display" : "daratumumab"
          },
          {
            "code" : "L01FC02",
            "display" : "isatuximab"
          },
          {
            "code" : "L01FD",
            "display" : "HER2 (Human Epidermal Growth Factor Receptor 2) inhibitors"
          },
          {
            "code" : "L01FD01",
            "display" : "trastuzumab"
          },
          {
            "code" : "L01FD02",
            "display" : "pertuzumab"
          },
          {
            "code" : "L01FD03",
            "display" : "trastuzumab emtansine"
          },
          {
            "code" : "L01FD04",
            "display" : "trastuzumab deruxtecan"
          },
          {
            "code" : "L01FD05",
            "display" : "trastuzumab duocarmazine"
          },
          {
            "code" : "L01FD06",
            "display" : "margetuximab"
          },
          {
            "code" : "L01FD07",
            "display" : "zanidatamab"
          },
          {
            "code" : "L01FE",
            "display" : "EGFR (Epidermal Growth Factor Receptor) inhibitors"
          },
          {
            "code" : "L01FE01",
            "display" : "cetuximab"
          },
          {
            "code" : "L01FE02",
            "display" : "panitumumab"
          },
          {
            "code" : "L01FE03",
            "display" : "necitumumab"
          },
          {
            "code" : "L01FF",
            "display" : "PD-1/PD-L1 (Programmed cell death protein 1/death ligand 1) inhibitors"
          },
          {
            "code" : "L01FF01",
            "display" : "nivolumab"
          },
          {
            "code" : "L01FF02",
            "display" : "pembrolizumab"
          },
          {
            "code" : "L01FF03",
            "display" : "durvalumab"
          },
          {
            "code" : "L01FF04",
            "display" : "avelumab"
          },
          {
            "code" : "L01FF05",
            "display" : "atezolizumab"
          },
          {
            "code" : "L01FF06",
            "display" : "cemiplimab"
          },
          {
            "code" : "L01FF07",
            "display" : "dostarlimab"
          },
          {
            "code" : "L01FF08",
            "display" : "prolgolimab"
          },
          {
            "code" : "L01FF09",
            "display" : "tislelizumab"
          },
          {
            "code" : "L01FF10",
            "display" : "retifanlimab"
          },
          {
            "code" : "L01FF11",
            "display" : "sugemalimab"
          },
          {
            "code" : "L01FF12",
            "display" : "serplulimab"
          },
          {
            "code" : "L01FF13",
            "display" : "toripalimab"
          },
          {
            "code" : "L01FG",
            "display" : "VEGF/VEGFR (Vascular Endothelial Growth Factor / -Receptor) inhibitors"
          },
          {
            "code" : "L01FG01",
            "display" : "bevacizumab"
          },
          {
            "code" : "L01FG02",
            "display" : "ramucirumab"
          },
          {
            "code" : "L01FX",
            "display" : "Other monoclonal antibodies and antibody drug conjugates"
          },
          {
            "code" : "L01FX01",
            "display" : "edrecolomab"
          },
          {
            "code" : "L01FX02",
            "display" : "gemtuzumab ozogamicin"
          },
          {
            "code" : "L01FX03",
            "display" : "catumaxomab"
          },
          {
            "code" : "L01FX04",
            "display" : "ipilimumab"
          },
          {
            "code" : "L01FX05",
            "display" : "brentuximab vedotin"
          },
          {
            "code" : "L01FX06",
            "display" : "dinutuximab beta"
          },
          {
            "code" : "L01FX07",
            "display" : "blinatumomab"
          },
          {
            "code" : "L01FX08",
            "display" : "elotuzumab"
          },
          {
            "code" : "L01FX09",
            "display" : "mogamulizumab"
          },
          {
            "code" : "L01FX10",
            "display" : "olaratumab"
          },
          {
            "code" : "L01FX11",
            "display" : "bermekimab"
          },
          {
            "code" : "L01FX12",
            "display" : "tafasitamab"
          },
          {
            "code" : "L01FX13",
            "display" : "enfortumab vedotin"
          },
          {
            "code" : "L01FX14",
            "display" : "polatuzumab vedotin"
          },
          {
            "code" : "L01FX15",
            "display" : "belantamab mafodotin"
          },
          {
            "code" : "L01FX16",
            "display" : "oportuzumab monatox"
          },
          {
            "code" : "L01FX17",
            "display" : "sacituzumab govitecan"
          },
          {
            "code" : "L01FX18",
            "display" : "amivantamab"
          },
          {
            "code" : "L01FX19",
            "display" : "sabatolimab"
          },
          {
            "code" : "L01FX20",
            "display" : "tremelimumab"
          },
          {
            "code" : "L01FX21",
            "display" : "naxitamab"
          },
          {
            "code" : "L01FX22",
            "display" : "loncastuximab tesirine"
          },
          {
            "code" : "L01FX23",
            "display" : "tisotumab vedotin"
          },
          {
            "code" : "L01FX24",
            "display" : "teclistamab"
          },
          {
            "code" : "L01FX25",
            "display" : "mosunetuzumab"
          },
          {
            "code" : "L01FX26",
            "display" : "mirvetuximab soravtansine"
          },
          {
            "code" : "L01FX27",
            "display" : "epcoritamab"
          },
          {
            "code" : "L01FX28",
            "display" : "glofitamab"
          },
          {
            "code" : "L01FX29",
            "display" : "talquetamab"
          },
          {
            "code" : "L01FX31",
            "display" : "zolbetuximab"
          },
          {
            "code" : "L01FX32",
            "display" : "elranatamab"
          },
          {
            "code" : "L01FX33",
            "display" : "tarlatamab"
          },
          {
            "code" : "L01FX34",
            "display" : "odronextamab"
          },
          {
            "code" : "L01FX35",
            "display" : "datopotamab deruxtecan"
          },
          {
            "code" : "L01FX36",
            "display" : "patritumab deruxtecan"
          },
          {
            "code" : "L01FY",
            "display" : "Combinations of monoclonal antibodies and antibody drug conjugates"
          },
          {
            "code" : "L01FY01",
            "display" : "pertuzumab and trastuzumab"
          },
          {
            "code" : "L01FY02",
            "display" : "nivolumab and relatlimab"
          },
          {
            "code" : "L01FY03",
            "display" : "prolgolimab and nurulimab"
          },
          {
            "code" : "L01X",
            "display" : "OTHER ANTINEOPLASTIC AGENTS"
          },
          {
            "code" : "L01XA",
            "display" : "Platinum compounds"
          },
          {
            "code" : "L01XA01",
            "display" : "cisplatin"
          },
          {
            "code" : "L01XA02",
            "display" : "carboplatin"
          },
          {
            "code" : "L01XA03",
            "display" : "oxaliplatin"
          },
          {
            "code" : "L01XA04",
            "display" : "satraplatin"
          },
          {
            "code" : "L01XA05",
            "display" : "polyplatillen"
          },
          {
            "code" : "L01XB",
            "display" : "Methylhydrazines"
          },
          {
            "code" : "L01XB01",
            "display" : "procarbazine"
          },
          {
            "code" : "L01XD",
            "display" : "Sensitizers used in photodynamic/radiation therapy"
          },
          {
            "code" : "L01XD01",
            "display" : "porfimer sodium"
          },
          {
            "code" : "L01XD03",
            "display" : "methyl aminolevulinate"
          },
          {
            "code" : "L01XD04",
            "display" : "aminolevulinic acid"
          },
          {
            "code" : "L01XD05",
            "display" : "temoporfin"
          },
          {
            "code" : "L01XD06",
            "display" : "efaproxiral"
          },
          {
            "code" : "L01XD07",
            "display" : "padeliporfin"
          },
          {
            "code" : "L01XF",
            "display" : "Retinoids for cancer treatment"
          },
          {
            "code" : "L01XF01",
            "display" : "tretinoin"
          },
          {
            "code" : "L01XF02",
            "display" : "alitretinoin"
          },
          {
            "code" : "L01XF03",
            "display" : "bexarotene"
          },
          {
            "code" : "L01XG",
            "display" : "Proteasome inhibitors"
          },
          {
            "code" : "L01XG01",
            "display" : "bortezomib"
          },
          {
            "code" : "L01XG02",
            "display" : "carfilzomib"
          },
          {
            "code" : "L01XG03",
            "display" : "ixazomib"
          },
          {
            "code" : "L01XH",
            "display" : "Histone deacetylase (HDAC) inhibitors"
          },
          {
            "code" : "L01XH01",
            "display" : "vorinostat"
          },
          {
            "code" : "L01XH02",
            "display" : "romidepsin"
          },
          {
            "code" : "L01XH03",
            "display" : "panobinostat"
          },
          {
            "code" : "L01XH04",
            "display" : "belinostat"
          },
          {
            "code" : "L01XH05",
            "display" : "entinostat"
          },
          {
            "code" : "L01XH06",
            "display" : "tucidinostat"
          },
          {
            "code" : "L01XH07",
            "display" : "resminostat"
          },
          {
            "code" : "L01XJ",
            "display" : "Hedgehog pathway inhibitors"
          },
          {
            "code" : "L01XJ01",
            "display" : "vismodegib"
          },
          {
            "code" : "L01XJ02",
            "display" : "sonidegib"
          },
          {
            "code" : "L01XJ03",
            "display" : "glasdegib"
          },
          {
            "code" : "L01XK",
            "display" : "Poly (ADP-ribose) polymerase (PARP) inhibitors"
          },
          {
            "code" : "L01XK01",
            "display" : "olaparib"
          },
          {
            "code" : "L01XK02",
            "display" : "niraparib"
          },
          {
            "code" : "L01XK03",
            "display" : "rucaparib"
          },
          {
            "code" : "L01XK04",
            "display" : "talazoparib"
          },
          {
            "code" : "L01XK05",
            "display" : "veliparib"
          },
          {
            "code" : "L01XK06",
            "display" : "pamiparib"
          },
          {
            "code" : "L01XK52",
            "display" : "niraparib and abiraterone"
          },
          {
            "code" : "L01XL",
            "display" : "Antineoplastic cell and gene therapy"
          },
          {
            "code" : "L01XL01",
            "display" : "sitimagene ceradenovec"
          },
          {
            "code" : "L01XL02",
            "display" : "talimogene laherparepvec"
          },
          {
            "code" : "L01XL03",
            "display" : "axicabtagene ciloleucel"
          },
          {
            "code" : "L01XL04",
            "display" : "tisagenlecleucel"
          },
          {
            "code" : "L01XL05",
            "display" : "ciltacabtagene autoleucel"
          },
          {
            "code" : "L01XL06",
            "display" : "brexucabtagene autoleucel"
          },
          {
            "code" : "L01XL07",
            "display" : "idecabtagene vicleucel"
          },
          {
            "code" : "L01XL08",
            "display" : "lisocabtagene maraleucel"
          },
          {
            "code" : "L01XL09",
            "display" : "tabelecleucel"
          },
          {
            "code" : "L01XL10",
            "display" : "nadofaragene firadenovec"
          },
          {
            "code" : "L01XL11",
            "display" : "lifileucel"
          },
          {
            "code" : "L01XL12",
            "display" : "obecabtagene autoleucel"
          },
          {
            "code" : "L01XM",
            "display" : "Isocitrate dehydrogenase (IDH) inhibitors"
          },
          {
            "code" : "L01XM01",
            "display" : "enasidenib"
          },
          {
            "code" : "L01XM02",
            "display" : "ivosidenib"
          },
          {
            "code" : "L01XM03",
            "display" : "olutasidenib"
          },
          {
            "code" : "L01XM04",
            "display" : "vorasidenib"
          },
          {
            "code" : "L01XU",
            "display" : "Other antineoplastic agents (cont.)"
          },
          {
            "code" : "L01XX",
            "display" : "Other antineoplastic agents"
          },
          {
            "code" : "L01XX01",
            "display" : "amsacrine"
          },
          {
            "code" : "L01XX02",
            "display" : "asparaginase"
          },
          {
            "code" : "L01XX03",
            "display" : "altretamine"
          },
          {
            "code" : "L01XX05",
            "display" : "hydroxycarbamide"
          },
          {
            "code" : "L01XX07",
            "display" : "lonidamine"
          },
          {
            "code" : "L01XX08",
            "display" : "pentostatin"
          },
          {
            "code" : "L01XX10",
            "display" : "masoprocol"
          },
          {
            "code" : "L01XX11",
            "display" : "estramustine"
          },
          {
            "code" : "L01XX16",
            "display" : "mitoguazone"
          },
          {
            "code" : "L01XX18",
            "display" : "tiazofurine"
          },
          {
            "code" : "L01XX23",
            "display" : "mitotane"
          },
          {
            "code" : "L01XX24",
            "display" : "pegaspargase"
          },
          {
            "code" : "L01XX27",
            "display" : "arsenic trioxide"
          },
          {
            "code" : "L01XX29",
            "display" : "denileukin diftitox"
          },
          {
            "code" : "L01XX33",
            "display" : "celecoxib"
          },
          {
            "code" : "L01XX35",
            "display" : "anagrelide"
          },
          {
            "code" : "L01XX36",
            "display" : "oblimersen"
          },
          {
            "code" : "L01XX40",
            "display" : "omacetaxine mepesuccinate"
          },
          {
            "code" : "L01XX41",
            "display" : "eribulin"
          },
          {
            "code" : "L01XX44",
            "display" : "aflibercept"
          },
          {
            "code" : "L01XX52",
            "display" : "venetoclax"
          },
          {
            "code" : "L01XX53",
            "display" : "vosaroxin"
          },
          {
            "code" : "L01XX57",
            "display" : "plitidepsin"
          },
          {
            "code" : "L01XX58",
            "display" : "epacadostat"
          },
          {
            "code" : "L01XX66",
            "display" : "selinexor"
          },
          {
            "code" : "L01XX67",
            "display" : "tagraxofusp"
          },
          {
            "code" : "L01XX69",
            "display" : "lurbinectedin"
          },
          {
            "code" : "L01XX72",
            "display" : "tazemetostat"
          },
          {
            "code" : "L01XX73",
            "display" : "sotorasib"
          },
          {
            "code" : "L01XX74",
            "display" : "belzutifan"
          },
          {
            "code" : "L01XX75",
            "display" : "tebentafusp"
          },
          {
            "code" : "L01XX77",
            "display" : "adagrasib"
          },
          {
            "code" : "L01XX78",
            "display" : "navitoclax"
          },
          {
            "code" : "L01XX79",
            "display" : "eflornithine"
          },
          {
            "code" : "L01XX80",
            "display" : "imetelstat"
          },
          {
            "code" : "L01XX81",
            "display" : "nirogacestat"
          },
          {
            "code" : "L01XX82",
            "display" : "darinaparsin"
          },
          {
            "code" : "L01XX83",
            "display" : "para-toluenesulfonamide"
          },
          {
            "code" : "L01XX84",
            "display" : "pelabresib"
          },
          {
            "code" : "L01XX85",
            "display" : "idroxioleic acid"
          },
          {
            "code" : "L01XX86",
            "display" : "calaspargase pegol"
          },
          {
            "code" : "L01XY",
            "display" : "Combinations of antineoplastic agents"
          },
          {
            "code" : "L01XY01",
            "display" : "cytarabine and daunorubicin"
          },
          {
            "code" : "L01XY04",
            "display" : "bifikafusp alfa and onfekafusp alfa"
          },
          {
            "code" : "L02",
            "display" : "ENDOCRINE THERAPY"
          },
          {
            "code" : "L02A",
            "display" : "HORMONES AND RELATED AGENTS"
          },
          {
            "code" : "L02AA",
            "display" : "Estrogens"
          },
          {
            "code" : "L02AA01",
            "display" : "diethylstilbestrol"
          },
          {
            "code" : "L02AA02",
            "display" : "polyestradiol phosphate"
          },
          {
            "code" : "L02AA03",
            "display" : "ethinylestradiol"
          },
          {
            "code" : "L02AA04",
            "display" : "fosfestrol"
          },
          {
            "code" : "L02AB",
            "display" : "Progestogens"
          },
          {
            "code" : "L02AB01",
            "display" : "megestrol"
          },
          {
            "code" : "L02AB02",
            "display" : "medroxyprogesterone"
          },
          {
            "code" : "L02AB03",
            "display" : "gestonorone"
          },
          {
            "code" : "L02AE",
            "display" : "Gonadotropin releasing hormone analogues"
          },
          {
            "code" : "L02AE01",
            "display" : "buserelin"
          },
          {
            "code" : "L02AE02",
            "display" : "leuprorelin"
          },
          {
            "code" : "L02AE03",
            "display" : "goserelin"
          },
          {
            "code" : "L02AE04",
            "display" : "triptorelin"
          },
          {
            "code" : "L02AE05",
            "display" : "histrelin"
          },
          {
            "code" : "L02AE51",
            "display" : "leuprorelin and bicalutamide"
          },
          {
            "code" : "L02AX",
            "display" : "Other hormones"
          },
          {
            "code" : "L02B",
            "display" : "HORMONE ANTAGONISTS AND RELATED AGENTS"
          },
          {
            "code" : "L02BA",
            "display" : "Anti-estrogens"
          },
          {
            "code" : "L02BA01",
            "display" : "tamoxifen"
          },
          {
            "code" : "L02BA02",
            "display" : "toremifene"
          },
          {
            "code" : "L02BA03",
            "display" : "fulvestrant"
          },
          {
            "code" : "L02BA04",
            "display" : "elacestrant"
          },
          {
            "code" : "L02BB",
            "display" : "Anti-androgens"
          },
          {
            "code" : "L02BB01",
            "display" : "flutamide"
          },
          {
            "code" : "L02BB02",
            "display" : "nilutamide"
          },
          {
            "code" : "L02BB03",
            "display" : "bicalutamide"
          },
          {
            "code" : "L02BB04",
            "display" : "enzalutamide"
          },
          {
            "code" : "L02BB05",
            "display" : "apalutamide"
          },
          {
            "code" : "L02BB06",
            "display" : "darolutamide"
          },
          {
            "code" : "L02BG",
            "display" : "Aromatase inhibitors"
          },
          {
            "code" : "L02BG01",
            "display" : "aminoglutethimide"
          },
          {
            "code" : "L02BG02",
            "display" : "formestane"
          },
          {
            "code" : "L02BG03",
            "display" : "anastrozole"
          },
          {
            "code" : "L02BG04",
            "display" : "letrozole"
          },
          {
            "code" : "L02BG05",
            "display" : "vorozole"
          },
          {
            "code" : "L02BG06",
            "display" : "exemestane"
          },
          {
            "code" : "L02BX",
            "display" : "Other hormone antagonists and related agents"
          },
          {
            "code" : "L02BX01",
            "display" : "abarelix"
          },
          {
            "code" : "L02BX02",
            "display" : "degarelix"
          },
          {
            "code" : "L02BX03",
            "display" : "abiraterone"
          },
          {
            "code" : "L02BX04",
            "display" : "relugolix"
          },
          {
            "code" : "L02BX53",
            "display" : "abiraterone and corticosteroids"
          },
          {
            "code" : "L03",
            "display" : "IMMUNOSTIMULANTS"
          },
          {
            "code" : "L03A",
            "display" : "IMMUNOSTIMULANTS"
          },
          {
            "code" : "L03AA",
            "display" : "Colony stimulating factors"
          },
          {
            "code" : "L03AA02",
            "display" : "filgrastim"
          },
          {
            "code" : "L03AA03",
            "display" : "molgramostim"
          },
          {
            "code" : "L03AA09",
            "display" : "sargramostim"
          },
          {
            "code" : "L03AA10",
            "display" : "lenograstim"
          },
          {
            "code" : "L03AA12",
            "display" : "ancestim"
          },
          {
            "code" : "L03AA13",
            "display" : "pegfilgrastim"
          },
          {
            "code" : "L03AA14",
            "display" : "lipegfilgrastim"
          },
          {
            "code" : "L03AA15",
            "display" : "balugrastim"
          },
          {
            "code" : "L03AA16",
            "display" : "empegfilgrastim"
          },
          {
            "code" : "L03AA17",
            "display" : "pegteograstim"
          },
          {
            "code" : "L03AA18",
            "display" : "efbemalenograstim alfa"
          },
          {
            "code" : "L03AA19",
            "display" : "eflapegrastim"
          },
          {
            "code" : "L03AB",
            "display" : "Interferons"
          },
          {
            "code" : "L03AB01",
            "display" : "interferon alfa natural"
          },
          {
            "code" : "L03AB02",
            "display" : "interferon beta natural"
          },
          {
            "code" : "L03AB03",
            "display" : "interferon gamma"
          },
          {
            "code" : "L03AB04",
            "display" : "interferon alfa-2a"
          },
          {
            "code" : "L03AB05",
            "display" : "interferon alfa-2b"
          },
          {
            "code" : "L03AB06",
            "display" : "interferon alfa-n1"
          },
          {
            "code" : "L03AB07",
            "display" : "interferon beta-1a"
          },
          {
            "code" : "L03AB08",
            "display" : "interferon beta-1b"
          },
          {
            "code" : "L03AB09",
            "display" : "interferon alfacon-1"
          },
          {
            "code" : "L03AB10",
            "display" : "peginterferon alfa-2b"
          },
          {
            "code" : "L03AB11",
            "display" : "peginterferon alfa-2a"
          },
          {
            "code" : "L03AB12",
            "display" : "albinterferon alfa-2b"
          },
          {
            "code" : "L03AB13",
            "display" : "peginterferon beta-1a"
          },
          {
            "code" : "L03AB14",
            "display" : "cepeginterferon alfa-2b"
          },
          {
            "code" : "L03AB15",
            "display" : "ropeginterferon alfa-2b"
          },
          {
            "code" : "L03AB16",
            "display" : "peginterferon alfacon-2"
          },
          {
            "code" : "L03AB17",
            "display" : "sampeginterferon beta-1a"
          },
          {
            "code" : "L03AB60",
            "display" : "peginterferon alfa-2b, combinations"
          },
          {
            "code" : "L03AB61",
            "display" : "peginterferon alfa-2a, combinations"
          },
          {
            "code" : "L03AC",
            "display" : "Interleukins"
          },
          {
            "code" : "L03AC01",
            "display" : "aldesleukin"
          },
          {
            "code" : "L03AC02",
            "display" : "oprelvekin"
          },
          {
            "code" : "L03AX",
            "display" : "Other immunostimulants"
          },
          {
            "code" : "L03AX01",
            "display" : "lentinan"
          },
          {
            "code" : "L03AX02",
            "display" : "roquinimex"
          },
          {
            "code" : "L03AX03",
            "display" : "BCG vaccine"
          },
          {
            "code" : "L03AX04",
            "display" : "pegademase"
          },
          {
            "code" : "L03AX05",
            "display" : "pidotimod"
          },
          {
            "code" : "L03AX07",
            "display" : "poly I:C"
          },
          {
            "code" : "L03AX08",
            "display" : "poly ICLC"
          },
          {
            "code" : "L03AX09",
            "display" : "thymopentin"
          },
          {
            "code" : "L03AX10",
            "display" : "immunocyanin"
          },
          {
            "code" : "L03AX11",
            "display" : "tasonermin"
          },
          {
            "code" : "L03AX12",
            "display" : "melanoma vaccine"
          },
          {
            "code" : "L03AX13",
            "display" : "glatiramer acetate"
          },
          {
            "code" : "L03AX14",
            "display" : "histamine dihydrochloride"
          },
          {
            "code" : "L03AX15",
            "display" : "mifamurtide"
          },
          {
            "code" : "L03AX16",
            "display" : "plerixafor"
          },
          {
            "code" : "L03AX17",
            "display" : "sipuleucel-T"
          },
          {
            "code" : "L03AX18",
            "display" : "cridanimod"
          },
          {
            "code" : "L03AX19",
            "display" : "dasiprotimut-T"
          },
          {
            "code" : "L03AX21",
            "display" : "elapegademase"
          },
          {
            "code" : "L03AX22",
            "display" : "leniolisib"
          },
          {
            "code" : "L03AX23",
            "display" : "motixafortide"
          },
          {
            "code" : "L03AX24",
            "display" : "mavorixafor"
          },
          {
            "code" : "L04",
            "display" : "IMMUNOSUPPRESSANTS"
          },
          {
            "code" : "L04A",
            "display" : "IMMUNOSUPPRESSANTS"
          },
          {
            "code" : "L04AA",
            "display" : "Selective immunosuppressants"
          },
          {
            "code" : "L04AA03",
            "display" : "antilymphocyte immunoglobulin (horse)"
          },
          {
            "code" : "L04AA04",
            "display" : "antithymocyte immunoglobulin (rabbit)"
          },
          {
            "code" : "L04AA06",
            "display" : "mycophenolic acid"
          },
          {
            "code" : "L04AA15",
            "display" : "alefacept"
          },
          {
            "code" : "L04AA19",
            "display" : "gusperimus"
          },
          {
            "code" : "L04AA22",
            "display" : "abetimus"
          },
          {
            "code" : "L04AA24",
            "display" : "abatacept"
          },
          {
            "code" : "L04AA28",
            "display" : "belatacept"
          },
          {
            "code" : "L04AA32",
            "display" : "apremilast"
          },
          {
            "code" : "L04AA40",
            "display" : "cladribine"
          },
          {
            "code" : "L04AA41",
            "display" : "imlifidase"
          },
          {
            "code" : "L04AA48",
            "display" : "belumosudil"
          },
          {
            "code" : "L04AA58",
            "display" : "efgartigimod alfa"
          },
          {
            "code" : "L04AA60",
            "display" : "remibrutinib"
          },
          {
            "code" : "L04AB",
            "display" : "Tumor necrosis factor alpha (TNF-alpha) inhibitors"
          },
          {
            "code" : "L04AB01",
            "display" : "etanercept"
          },
          {
            "code" : "L04AB02",
            "display" : "infliximab"
          },
          {
            "code" : "L04AB03",
            "display" : "afelimomab"
          },
          {
            "code" : "L04AB04",
            "display" : "adalimumab"
          },
          {
            "code" : "L04AB05",
            "display" : "certolizumab pegol"
          },
          {
            "code" : "L04AB06",
            "display" : "golimumab"
          },
          {
            "code" : "L04AB07",
            "display" : "opinercept"
          },
          {
            "code" : "L04AC",
            "display" : "Interleukin inhibitors"
          },
          {
            "code" : "L04AC01",
            "display" : "daclizumab"
          },
          {
            "code" : "L04AC02",
            "display" : "basiliximab"
          },
          {
            "code" : "L04AC03",
            "display" : "anakinra"
          },
          {
            "code" : "L04AC04",
            "display" : "rilonacept"
          },
          {
            "code" : "L04AC05",
            "display" : "ustekinumab"
          },
          {
            "code" : "L04AC07",
            "display" : "tocilizumab"
          },
          {
            "code" : "L04AC08",
            "display" : "canakinumab"
          },
          {
            "code" : "L04AC09",
            "display" : "briakinumab"
          },
          {
            "code" : "L04AC10",
            "display" : "secukinumab"
          },
          {
            "code" : "L04AC11",
            "display" : "siltuximab"
          },
          {
            "code" : "L04AC12",
            "display" : "brodalumab"
          },
          {
            "code" : "L04AC13",
            "display" : "ixekizumab"
          },
          {
            "code" : "L04AC14",
            "display" : "sarilumab"
          },
          {
            "code" : "L04AC15",
            "display" : "sirukumab"
          },
          {
            "code" : "L04AC16",
            "display" : "guselkumab"
          },
          {
            "code" : "L04AC17",
            "display" : "tildrakizumab"
          },
          {
            "code" : "L04AC18",
            "display" : "risankizumab"
          },
          {
            "code" : "L04AC19",
            "display" : "satralizumab"
          },
          {
            "code" : "L04AC20",
            "display" : "netakimab"
          },
          {
            "code" : "L04AC21",
            "display" : "bimekizumab"
          },
          {
            "code" : "L04AC22",
            "display" : "spesolimab"
          },
          {
            "code" : "L04AC23",
            "display" : "olokizumab"
          },
          {
            "code" : "L04AC24",
            "display" : "mirikizumab"
          },
          {
            "code" : "L04AC25",
            "display" : "levilimab"
          },
          {
            "code" : "L04AC26",
            "display" : "goflikicept"
          },
          {
            "code" : "L04AD",
            "display" : "Calcineurin inhibitors"
          },
          {
            "code" : "L04AD01",
            "display" : "ciclosporin"
          },
          {
            "code" : "L04AD02",
            "display" : "tacrolimus"
          },
          {
            "code" : "L04AD03",
            "display" : "voclosporin"
          },
          {
            "code" : "L04AE",
            "display" : "Sphingosine-1-phosphate (S1P) receptor modulators"
          },
          {
            "code" : "L04AE01",
            "display" : "fingolimod"
          },
          {
            "code" : "L04AE02",
            "display" : "ozanimod"
          },
          {
            "code" : "L04AE03",
            "display" : "siponimod"
          },
          {
            "code" : "L04AE04",
            "display" : "ponesimod"
          },
          {
            "code" : "L04AE05",
            "display" : "etrasimod"
          },
          {
            "code" : "L04AF",
            "display" : "Janus-associated kinase (JAK) inhibitors"
          },
          {
            "code" : "L04AF01",
            "display" : "tofacitinib"
          },
          {
            "code" : "L04AF02",
            "display" : "baricitinib"
          },
          {
            "code" : "L04AF03",
            "display" : "upadacitinib"
          },
          {
            "code" : "L04AF04",
            "display" : "filgotinib"
          },
          {
            "code" : "L04AF05",
            "display" : "itacitinib"
          },
          {
            "code" : "L04AF06",
            "display" : "peficitinib"
          },
          {
            "code" : "L04AF07",
            "display" : "deucravacitinib"
          },
          {
            "code" : "L04AF08",
            "display" : "ritlecitinib"
          },
          {
            "code" : "L04AG",
            "display" : "Monoclonal antibodies"
          },
          {
            "code" : "L04AG01",
            "display" : "muromonab-CD3"
          },
          {
            "code" : "L04AG02",
            "display" : "efalizumab"
          },
          {
            "code" : "L04AG03",
            "display" : "natalizumab"
          },
          {
            "code" : "L04AG04",
            "display" : "belimumab"
          },
          {
            "code" : "L04AG05",
            "display" : "vedolizumab"
          },
          {
            "code" : "L04AG06",
            "display" : "alemtuzumab"
          },
          {
            "code" : "L04AG07",
            "display" : "begelomab"
          },
          {
            "code" : "L04AG08",
            "display" : "ocrelizumab"
          },
          {
            "code" : "L04AG09",
            "display" : "emapalumab"
          },
          {
            "code" : "L04AG10",
            "display" : "inebilizumab"
          },
          {
            "code" : "L04AG11",
            "display" : "anifrolumab"
          },
          {
            "code" : "L04AG12",
            "display" : "ofatumumab"
          },
          {
            "code" : "L04AG13",
            "display" : "teprotumumab"
          },
          {
            "code" : "L04AG14",
            "display" : "ublituximab"
          },
          {
            "code" : "L04AG15",
            "display" : "divozilimab"
          },
          {
            "code" : "L04AG16",
            "display" : "rozanolixizumab"
          },
          {
            "code" : "L04AG17",
            "display" : "seniprutug"
          },
          {
            "code" : "L04AH",
            "display" : "Mammalian target of rapamycin (mTOR) kinase inhibitors"
          },
          {
            "code" : "L04AH01",
            "display" : "sirolimus"
          },
          {
            "code" : "L04AH02",
            "display" : "everolimus"
          },
          {
            "code" : "L04AJ",
            "display" : "Complement inhibitors"
          },
          {
            "code" : "L04AJ01",
            "display" : "eculizumab"
          },
          {
            "code" : "L04AJ02",
            "display" : "ravulizumab"
          },
          {
            "code" : "L04AJ03",
            "display" : "pegcetacoplan"
          },
          {
            "code" : "L04AJ04",
            "display" : "sutimlimab"
          },
          {
            "code" : "L04AJ05",
            "display" : "avacopan"
          },
          {
            "code" : "L04AJ06",
            "display" : "zilucoplan"
          },
          {
            "code" : "L04AJ07",
            "display" : "crovalimab"
          },
          {
            "code" : "L04AJ08",
            "display" : "iptacopan"
          },
          {
            "code" : "L04AJ09",
            "display" : "danicopan"
          },
          {
            "code" : "L04AJ10",
            "display" : "vilobelimab"
          },
          {
            "code" : "L04AJ11",
            "display" : "pozelimab"
          },
          {
            "code" : "L04AK",
            "display" : "Dihydroorotate dehydrogenase (DHODH) inhibitors"
          },
          {
            "code" : "L04AK01",
            "display" : "leflunomide"
          },
          {
            "code" : "L04AK02",
            "display" : "teriflunomide"
          },
          {
            "code" : "L04AX",
            "display" : "Other immunosuppressants"
          },
          {
            "code" : "L04AX01",
            "display" : "azathioprine"
          },
          {
            "code" : "L04AX02",
            "display" : "thalidomide"
          },
          {
            "code" : "L04AX03",
            "display" : "methotrexate"
          },
          {
            "code" : "L04AX04",
            "display" : "lenalidomide"
          },
          {
            "code" : "L04AX05",
            "display" : "pirfenidone"
          },
          {
            "code" : "L04AX06",
            "display" : "pomalidomide"
          },
          {
            "code" : "L04AX07",
            "display" : "dimethyl fumarate"
          },
          {
            "code" : "L04AX08",
            "display" : "darvadstrocel"
          },
          {
            "code" : "L04AX09",
            "display" : "diroximel fumarate"
          },
          {
            "code" : "L04AX10",
            "display" : "tegomil fumarate"
          },
          {
            "code" : "M",
            "display" : "MUSCULO-SKELETAL SYSTEM"
          },
          {
            "code" : "M01",
            "display" : "ANTIINFLAMMATORY AND ANTIRHEUMATIC PRODUCTS"
          },
          {
            "code" : "M01A",
            "display" : "ANTIINFLAMMATORY AND ANTIRHEUMATIC PRODUCTS, NON-STEROIDS"
          },
          {
            "code" : "M01AA",
            "display" : "Butylpyrazolidines"
          },
          {
            "code" : "M01AA01",
            "display" : "phenylbutazone"
          },
          {
            "code" : "M01AA02",
            "display" : "mofebutazone"
          },
          {
            "code" : "M01AA03",
            "display" : "oxyphenbutazone"
          },
          {
            "code" : "M01AA05",
            "display" : "clofezone"
          },
          {
            "code" : "M01AA06",
            "display" : "kebuzone"
          },
          {
            "code" : "M01AB",
            "display" : "Acetic acid derivatives and related substances"
          },
          {
            "code" : "M01AB01",
            "display" : "indometacin"
          },
          {
            "code" : "M01AB02",
            "display" : "sulindac"
          },
          {
            "code" : "M01AB03",
            "display" : "tolmetin"
          },
          {
            "code" : "M01AB04",
            "display" : "zomepirac"
          },
          {
            "code" : "M01AB05",
            "display" : "diclofenac"
          },
          {
            "code" : "M01AB06",
            "display" : "alclofenac"
          },
          {
            "code" : "M01AB07",
            "display" : "bumadizone"
          },
          {
            "code" : "M01AB08",
            "display" : "etodolac"
          },
          {
            "code" : "M01AB09",
            "display" : "lonazolac"
          },
          {
            "code" : "M01AB10",
            "display" : "fentiazac"
          },
          {
            "code" : "M01AB11",
            "display" : "acemetacin"
          },
          {
            "code" : "M01AB12",
            "display" : "difenpiramide"
          },
          {
            "code" : "M01AB13",
            "display" : "oxametacin"
          },
          {
            "code" : "M01AB14",
            "display" : "proglumetacin"
          },
          {
            "code" : "M01AB15",
            "display" : "ketorolac"
          },
          {
            "code" : "M01AB16",
            "display" : "aceclofenac"
          },
          {
            "code" : "M01AB17",
            "display" : "bufexamac"
          },
          {
            "code" : "M01AB51",
            "display" : "indometacin, combinations"
          },
          {
            "code" : "M01AB55",
            "display" : "diclofenac, combinations"
          },
          {
            "code" : "M01AC",
            "display" : "Oxicams"
          },
          {
            "code" : "M01AC01",
            "display" : "piroxicam"
          },
          {
            "code" : "M01AC02",
            "display" : "tenoxicam"
          },
          {
            "code" : "M01AC04",
            "display" : "droxicam"
          },
          {
            "code" : "M01AC05",
            "display" : "lornoxicam"
          },
          {
            "code" : "M01AC06",
            "display" : "meloxicam"
          },
          {
            "code" : "M01AC56",
            "display" : "meloxicam, combinations"
          },
          {
            "code" : "M01AE",
            "display" : "Propionic acid derivatives"
          },
          {
            "code" : "M01AE01",
            "display" : "ibuprofen"
          },
          {
            "code" : "M01AE02",
            "display" : "naproxen"
          },
          {
            "code" : "M01AE03",
            "display" : "ketoprofen"
          },
          {
            "code" : "M01AE04",
            "display" : "fenoprofen"
          },
          {
            "code" : "M01AE05",
            "display" : "fenbufen"
          },
          {
            "code" : "M01AE06",
            "display" : "benoxaprofen"
          },
          {
            "code" : "M01AE07",
            "display" : "suprofen"
          },
          {
            "code" : "M01AE08",
            "display" : "pirprofen"
          },
          {
            "code" : "M01AE09",
            "display" : "flurbiprofen"
          },
          {
            "code" : "M01AE10",
            "display" : "indoprofen"
          },
          {
            "code" : "M01AE11",
            "display" : "tiaprofenic acid"
          },
          {
            "code" : "M01AE12",
            "display" : "oxaprozin"
          },
          {
            "code" : "M01AE13",
            "display" : "ibuproxam"
          },
          {
            "code" : "M01AE14",
            "display" : "dexibuprofen"
          },
          {
            "code" : "M01AE15",
            "display" : "flunoxaprofen"
          },
          {
            "code" : "M01AE16",
            "display" : "alminoprofen"
          },
          {
            "code" : "M01AE17",
            "display" : "dexketoprofen"
          },
          {
            "code" : "M01AE18",
            "display" : "naproxcinod"
          },
          {
            "code" : "M01AE19",
            "display" : "loxoprofen"
          },
          {
            "code" : "M01AE20",
            "display" : "pelubiprofen"
          },
          {
            "code" : "M01AE51",
            "display" : "ibuprofen, combinations"
          },
          {
            "code" : "M01AE52",
            "display" : "naproxen and esomeprazole"
          },
          {
            "code" : "M01AE53",
            "display" : "ketoprofen, combinations"
          },
          {
            "code" : "M01AE56",
            "display" : "naproxen and misoprostol"
          },
          {
            "code" : "M01AE57",
            "display" : "naproxen and diphenhydramine"
          },
          {
            "code" : "M01AG",
            "display" : "Fenamates"
          },
          {
            "code" : "M01AG01",
            "display" : "mefenamic acid"
          },
          {
            "code" : "M01AG02",
            "display" : "tolfenamic acid"
          },
          {
            "code" : "M01AG03",
            "display" : "flufenamic acid"
          },
          {
            "code" : "M01AG04",
            "display" : "meclofenamic acid"
          },
          {
            "code" : "M01AH",
            "display" : "Coxibs"
          },
          {
            "code" : "M01AH01",
            "display" : "celecoxib"
          },
          {
            "code" : "M01AH02",
            "display" : "rofecoxib"
          },
          {
            "code" : "M01AH03",
            "display" : "valdecoxib"
          },
          {
            "code" : "M01AH04",
            "display" : "parecoxib"
          },
          {
            "code" : "M01AH05",
            "display" : "etoricoxib"
          },
          {
            "code" : "M01AH06",
            "display" : "lumiracoxib"
          },
          {
            "code" : "M01AH07",
            "display" : "polmacoxib"
          },
          {
            "code" : "M01AX",
            "display" : "Other antiinflammatory and antirheumatic agents, non-steroids"
          },
          {
            "code" : "M01AX01",
            "display" : "nabumetone"
          },
          {
            "code" : "M01AX02",
            "display" : "niflumic acid"
          },
          {
            "code" : "M01AX04",
            "display" : "azapropazone"
          },
          {
            "code" : "M01AX05",
            "display" : "glucosamine"
          },
          {
            "code" : "M01AX07",
            "display" : "benzydamine"
          },
          {
            "code" : "M01AX12",
            "display" : "glucosaminoglycan polysulfate"
          },
          {
            "code" : "M01AX13",
            "display" : "proquazone"
          },
          {
            "code" : "M01AX14",
            "display" : "orgotein"
          },
          {
            "code" : "M01AX17",
            "display" : "nimesulide"
          },
          {
            "code" : "M01AX18",
            "display" : "feprazone"
          },
          {
            "code" : "M01AX21",
            "display" : "diacerein"
          },
          {
            "code" : "M01AX22",
            "display" : "morniflumate"
          },
          {
            "code" : "M01AX23",
            "display" : "tenidap"
          },
          {
            "code" : "M01AX24",
            "display" : "oxaceprol"
          },
          {
            "code" : "M01AX25",
            "display" : "chondroitin sulfate"
          },
          {
            "code" : "M01AX26",
            "display" : "avocado and soyabean oil, unsaponifiables"
          },
          {
            "code" : "M01AX68",
            "display" : "feprazone, combinations"
          },
          {
            "code" : "M01B",
            "display" : "ANTIINFLAMMATORY/ANTIRHEUMATIC AGENTS IN COMBINATION"
          },
          {
            "code" : "M01BA",
            "display" : "Antiinflammatory/antirheumatic agents in combination with corticosteroids"
          },
          {
            "code" : "M01BA01",
            "display" : "phenylbutazone and corticosteroids"
          },
          {
            "code" : "M01BA02",
            "display" : "dipyrocetyl and corticosteroids"
          },
          {
            "code" : "M01BA03",
            "display" : "acetylsalicylic acid and corticosteroids"
          },
          {
            "code" : "M01BX",
            "display" : "Other antiinflammatory/antirheumatic agents in combination with other drugs"
          },
          {
            "code" : "M01C",
            "display" : "SPECIFIC ANTIRHEUMATIC AGENTS"
          },
          {
            "code" : "M01CA",
            "display" : "Quinolines"
          },
          {
            "code" : "M01CA03",
            "display" : "oxycinchophen"
          },
          {
            "code" : "M01CB",
            "display" : "Gold preparations"
          },
          {
            "code" : "M01CB01",
            "display" : "sodium aurothiomalate"
          },
          {
            "code" : "M01CB02",
            "display" : "sodium aurotiosulfate"
          },
          {
            "code" : "M01CB03",
            "display" : "auranofin"
          },
          {
            "code" : "M01CB04",
            "display" : "aurothioglucose"
          },
          {
            "code" : "M01CB05",
            "display" : "aurotioprol"
          },
          {
            "code" : "M01CC",
            "display" : "Penicillamine and similar agents"
          },
          {
            "code" : "M01CC01",
            "display" : "penicillamine"
          },
          {
            "code" : "M01CC02",
            "display" : "bucillamine"
          },
          {
            "code" : "M01CX",
            "display" : "Other specific antirheumatic agents"
          },
          {
            "code" : "M02",
            "display" : "TOPICAL PRODUCTS FOR JOINT AND MUSCULAR PAIN"
          },
          {
            "code" : "M02A",
            "display" : "TOPICAL PRODUCTS FOR JOINT AND MUSCULAR PAIN"
          },
          {
            "code" : "M02AA",
            "display" : "Antiinflammatory preparations, non-steroids for topical use"
          },
          {
            "code" : "M02AA01",
            "display" : "phenylbutazone"
          },
          {
            "code" : "M02AA02",
            "display" : "mofebutazone"
          },
          {
            "code" : "M02AA03",
            "display" : "clofezone"
          },
          {
            "code" : "M02AA04",
            "display" : "oxyphenbutazone"
          },
          {
            "code" : "M02AA05",
            "display" : "benzydamine"
          },
          {
            "code" : "M02AA06",
            "display" : "etofenamate"
          },
          {
            "code" : "M02AA07",
            "display" : "piroxicam"
          },
          {
            "code" : "M02AA08",
            "display" : "felbinac"
          },
          {
            "code" : "M02AA09",
            "display" : "bufexamac"
          },
          {
            "code" : "M02AA10",
            "display" : "ketoprofen"
          },
          {
            "code" : "M02AA11",
            "display" : "bendazac"
          },
          {
            "code" : "M02AA12",
            "display" : "naproxen"
          },
          {
            "code" : "M02AA13",
            "display" : "ibuprofen"
          },
          {
            "code" : "M02AA14",
            "display" : "fentiazac"
          },
          {
            "code" : "M02AA15",
            "display" : "diclofenac"
          },
          {
            "code" : "M02AA16",
            "display" : "feprazone"
          },
          {
            "code" : "M02AA17",
            "display" : "niflumic acid"
          },
          {
            "code" : "M02AA18",
            "display" : "meclofenamic acid"
          },
          {
            "code" : "M02AA19",
            "display" : "flurbiprofen"
          },
          {
            "code" : "M02AA21",
            "display" : "tolmetin"
          },
          {
            "code" : "M02AA22",
            "display" : "suxibuzone"
          },
          {
            "code" : "M02AA23",
            "display" : "indometacin"
          },
          {
            "code" : "M02AA24",
            "display" : "nifenazone"
          },
          {
            "code" : "M02AA25",
            "display" : "aceclofenac"
          },
          {
            "code" : "M02AA26",
            "display" : "nimesulide"
          },
          {
            "code" : "M02AA27",
            "display" : "dexketoprofen"
          },
          {
            "code" : "M02AA28",
            "display" : "piketoprofen"
          },
          {
            "code" : "M02AA29",
            "display" : "esflurbiprofen"
          },
          {
            "code" : "M02AA31",
            "display" : "loxoprofen"
          },
          {
            "code" : "M02AB",
            "display" : "Capsaicin and similar agents"
          },
          {
            "code" : "M02AB01",
            "display" : "capsaicin"
          },
          {
            "code" : "M02AB02",
            "display" : "zucapsaicin"
          },
          {
            "code" : "M02AC",
            "display" : "Preparations with salicylic acid derivatives"
          },
          {
            "code" : "M02AX",
            "display" : "Other topical products for joint and muscular pain"
          },
          {
            "code" : "M02AX02",
            "display" : "tolazoline"
          },
          {
            "code" : "M02AX03",
            "display" : "dimethyl sulfoxide"
          },
          {
            "code" : "M02AX05",
            "display" : "idrocilamide"
          },
          {
            "code" : "M02AX06",
            "display" : "tolperisone"
          },
          {
            "code" : "M02AX10",
            "display" : "various"
          },
          {
            "code" : "M03",
            "display" : "MUSCLE RELAXANTS"
          },
          {
            "code" : "M03A",
            "display" : "MUSCLE RELAXANTS, PERIPHERALLY ACTING AGENTS"
          },
          {
            "code" : "M03AA",
            "display" : "Curare alkaloids"
          },
          {
            "code" : "M03AA01",
            "display" : "alcuronium"
          },
          {
            "code" : "M03AA02",
            "display" : "tubocurarine"
          },
          {
            "code" : "M03AA04",
            "display" : "dimethyltubocurarine"
          },
          {
            "code" : "M03AB",
            "display" : "Choline derivatives"
          },
          {
            "code" : "M03AB01",
            "display" : "suxamethonium"
          },
          {
            "code" : "M03AC",
            "display" : "Other quaternary ammonium compounds"
          },
          {
            "code" : "M03AC01",
            "display" : "pancuronium"
          },
          {
            "code" : "M03AC02",
            "display" : "gallamine"
          },
          {
            "code" : "M03AC03",
            "display" : "vecuronium"
          },
          {
            "code" : "M03AC04",
            "display" : "atracurium"
          },
          {
            "code" : "M03AC05",
            "display" : "hexafluronium"
          },
          {
            "code" : "M03AC06",
            "display" : "pipecuronium bromide"
          },
          {
            "code" : "M03AC07",
            "display" : "doxacurium chloride"
          },
          {
            "code" : "M03AC08",
            "display" : "fazadinium bromide"
          },
          {
            "code" : "M03AC09",
            "display" : "rocuronium bromide"
          },
          {
            "code" : "M03AC10",
            "display" : "mivacurium chloride"
          },
          {
            "code" : "M03AC11",
            "display" : "cisatracurium"
          },
          {
            "code" : "M03AX",
            "display" : "Other muscle relaxants, peripherally acting agents"
          },
          {
            "code" : "M03AX01",
            "display" : "botulinum toxin"
          },
          {
            "code" : "M03B",
            "display" : "MUSCLE RELAXANTS, CENTRALLY ACTING AGENTS"
          },
          {
            "code" : "M03BA",
            "display" : "Carbamic acid esters"
          },
          {
            "code" : "M03BA01",
            "display" : "phenprobamate"
          },
          {
            "code" : "M03BA02",
            "display" : "carisoprodol"
          },
          {
            "code" : "M03BA03",
            "display" : "methocarbamol"
          },
          {
            "code" : "M03BA04",
            "display" : "styramate"
          },
          {
            "code" : "M03BA05",
            "display" : "febarbamate"
          },
          {
            "code" : "M03BA51",
            "display" : "phenprobamate, combinations excl. psycholeptics"
          },
          {
            "code" : "M03BA52",
            "display" : "carisoprodol, combinations excl. psycholeptics"
          },
          {
            "code" : "M03BA53",
            "display" : "methocarbamol, combinations excl. psycholeptics"
          },
          {
            "code" : "M03BA71",
            "display" : "phenprobamate, combinations with psycholeptics"
          },
          {
            "code" : "M03BA72",
            "display" : "carisoprodol, combinations with psycholeptics"
          },
          {
            "code" : "M03BA73",
            "display" : "methocarbamol, combinations with psycholeptics"
          },
          {
            "code" : "M03BB",
            "display" : "Oxazol, thiazine, and triazine derivatives"
          },
          {
            "code" : "M03BB02",
            "display" : "chlormezanone"
          },
          {
            "code" : "M03BB03",
            "display" : "chlorzoxazone"
          },
          {
            "code" : "M03BB52",
            "display" : "chlormezanone, combinations excl. psycholeptics"
          },
          {
            "code" : "M03BB53",
            "display" : "chlorzoxazone, combinations excl. psycholeptics"
          },
          {
            "code" : "M03BB72",
            "display" : "chlormezanone, combinations with psycholeptics"
          },
          {
            "code" : "M03BB73",
            "display" : "chlorzoxazone, combinations with psycholeptics"
          },
          {
            "code" : "M03BC",
            "display" : "Ethers, chemically close to antihistamines"
          },
          {
            "code" : "M03BC01",
            "display" : "orphenadrine (citrate)"
          },
          {
            "code" : "M03BC51",
            "display" : "orphenadrine, combinations"
          },
          {
            "code" : "M03BX",
            "display" : "Other centrally acting agents"
          },
          {
            "code" : "M03BX01",
            "display" : "baclofen"
          },
          {
            "code" : "M03BX02",
            "display" : "tizanidine"
          },
          {
            "code" : "M03BX03",
            "display" : "pridinol"
          },
          {
            "code" : "M03BX04",
            "display" : "tolperisone"
          },
          {
            "code" : "M03BX05",
            "display" : "thiocolchicoside"
          },
          {
            "code" : "M03BX06",
            "display" : "mephenesin"
          },
          {
            "code" : "M03BX07",
            "display" : "tetrazepam"
          },
          {
            "code" : "M03BX08",
            "display" : "cyclobenzaprine"
          },
          {
            "code" : "M03BX09",
            "display" : "eperisone"
          },
          {
            "code" : "M03BX30",
            "display" : "fenyramidol"
          },
          {
            "code" : "M03BX53",
            "display" : "pridinol, combinations"
          },
          {
            "code" : "M03BX55",
            "display" : "thiocolchicoside, combinations"
          },
          {
            "code" : "M03C",
            "display" : "MUSCLE RELAXANTS, DIRECTLY ACTING AGENTS"
          },
          {
            "code" : "M03CA",
            "display" : "Dantrolene and derivatives"
          },
          {
            "code" : "M03CA01",
            "display" : "dantrolene"
          },
          {
            "code" : "M04",
            "display" : "ANTIGOUT PREPARATIONS"
          },
          {
            "code" : "M04A",
            "display" : "ANTIGOUT PREPARATIONS"
          },
          {
            "code" : "M04AA",
            "display" : "Preparations inhibiting uric acid production"
          },
          {
            "code" : "M04AA01",
            "display" : "allopurinol"
          },
          {
            "code" : "M04AA02",
            "display" : "tisopurine"
          },
          {
            "code" : "M04AA03",
            "display" : "febuxostat"
          },
          {
            "code" : "M04AA51",
            "display" : "allopurinol, combinations"
          },
          {
            "code" : "M04AB",
            "display" : "Preparations increasing uric acid excretion"
          },
          {
            "code" : "M04AB01",
            "display" : "probenecid"
          },
          {
            "code" : "M04AB02",
            "display" : "sulfinpyrazone"
          },
          {
            "code" : "M04AB03",
            "display" : "benzbromarone"
          },
          {
            "code" : "M04AB04",
            "display" : "isobromindione"
          },
          {
            "code" : "M04AB05",
            "display" : "lesinurad"
          },
          {
            "code" : "M04AC",
            "display" : "Preparations with no effect on uric acid metabolism"
          },
          {
            "code" : "M04AC01",
            "display" : "colchicine"
          },
          {
            "code" : "M04AC02",
            "display" : "cinchophen"
          },
          {
            "code" : "M04AC51",
            "display" : "colchicine and probenecid"
          },
          {
            "code" : "M04AX",
            "display" : "Other antigout preparations"
          },
          {
            "code" : "M04AX01",
            "display" : "urate oxidase"
          },
          {
            "code" : "M04AX02",
            "display" : "pegloticase"
          },
          {
            "code" : "M05",
            "display" : "DRUGS FOR TREATMENT OF BONE DISEASES"
          },
          {
            "code" : "M05B",
            "display" : "DRUGS AFFECTING BONE STRUCTURE AND MINERALIZATION"
          },
          {
            "code" : "M05BA",
            "display" : "Bisphosphonates"
          },
          {
            "code" : "M05BA01",
            "display" : "etidronic acid"
          },
          {
            "code" : "M05BA02",
            "display" : "clodronic acid"
          },
          {
            "code" : "M05BA03",
            "display" : "pamidronic acid"
          },
          {
            "code" : "M05BA04",
            "display" : "alendronic acid"
          },
          {
            "code" : "M05BA05",
            "display" : "tiludronic acid"
          },
          {
            "code" : "M05BA06",
            "display" : "ibandronic acid"
          },
          {
            "code" : "M05BA07",
            "display" : "risedronic acid"
          },
          {
            "code" : "M05BA08",
            "display" : "zoledronic acid"
          },
          {
            "code" : "M05BB",
            "display" : "Bisphosphonates, combinations"
          },
          {
            "code" : "M05BB01",
            "display" : "etidronic acid and calcium, sequential"
          },
          {
            "code" : "M05BB02",
            "display" : "risedronic acid and calcium, sequential"
          },
          {
            "code" : "M05BB03",
            "display" : "alendronic acid and colecalciferol"
          },
          {
            "code" : "M05BB04",
            "display" : "risedronic acid, calcium and colecalciferol, sequential"
          },
          {
            "code" : "M05BB05",
            "display" : "alendronic acid, calcium and colecalciferol, sequential"
          },
          {
            "code" : "M05BB06",
            "display" : "alendronic acid and alfacalcidol, sequential"
          },
          {
            "code" : "M05BB07",
            "display" : "risedronic acid and colecalciferol"
          },
          {
            "code" : "M05BB08",
            "display" : "zoledronic acid, calcium and colecalciferol, sequential"
          },
          {
            "code" : "M05BB09",
            "display" : "ibandronic acid and colecalciferol"
          },
          {
            "code" : "M05BC",
            "display" : "Bone morphogenetic proteins"
          },
          {
            "code" : "M05BC01",
            "display" : "dibotermin alfa"
          },
          {
            "code" : "M05BC02",
            "display" : "eptotermin alfa"
          },
          {
            "code" : "M05BX",
            "display" : "Other drugs affecting bone structure and mineralization"
          },
          {
            "code" : "M05BX01",
            "display" : "ipriflavone"
          },
          {
            "code" : "M05BX02",
            "display" : "aluminium chlorohydrate"
          },
          {
            "code" : "M05BX03",
            "display" : "strontium ranelate"
          },
          {
            "code" : "M05BX04",
            "display" : "denosumab"
          },
          {
            "code" : "M05BX05",
            "display" : "burosumab"
          },
          {
            "code" : "M05BX06",
            "display" : "romosozumab"
          },
          {
            "code" : "M05BX07",
            "display" : "vosoritide"
          },
          {
            "code" : "M05BX08",
            "display" : "menatetrenone"
          },
          {
            "code" : "M05BX53",
            "display" : "strontium ranelate and colecalciferol"
          },
          {
            "code" : "M09",
            "display" : "OTHER DRUGS FOR DISORDERS OF THE MUSCULO-SKELETAL SYSTEM"
          },
          {
            "code" : "M09A",
            "display" : "OTHER DRUGS FOR DISORDERS OF THE MUSCULO-SKELETAL SYSTEM"
          },
          {
            "code" : "M09AA",
            "display" : "Quinine and derivatives"
          },
          {
            "code" : "M09AA01",
            "display" : "hydroquinine"
          },
          {
            "code" : "M09AA72",
            "display" : "quinine, combinations with psycholeptics"
          },
          {
            "code" : "M09AB",
            "display" : "Enzymes"
          },
          {
            "code" : "M09AB01",
            "display" : "chymopapain"
          },
          {
            "code" : "M09AB02",
            "display" : "collagenase clostridium histolyticum"
          },
          {
            "code" : "M09AB03",
            "display" : "bromelains"
          },
          {
            "code" : "M09AB52",
            "display" : "trypsin, combinations"
          },
          {
            "code" : "M09AX",
            "display" : "Other drugs for disorders of the musculo-skeletal system"
          },
          {
            "code" : "M09AX01",
            "display" : "hyaluronic acid"
          },
          {
            "code" : "M09AX02",
            "display" : "chondrocytes, autologous"
          },
          {
            "code" : "M09AX03",
            "display" : "ataluren"
          },
          {
            "code" : "M09AX04",
            "display" : "drisapersen"
          },
          {
            "code" : "M09AX05",
            "display" : "aceneuramic acid"
          },
          {
            "code" : "M09AX06",
            "display" : "eteplirsen"
          },
          {
            "code" : "M09AX07",
            "display" : "nusinersen"
          },
          {
            "code" : "M09AX08",
            "display" : "golodirsen"
          },
          {
            "code" : "M09AX09",
            "display" : "onasemnogene abeparvovec"
          },
          {
            "code" : "M09AX10",
            "display" : "risdiplam"
          },
          {
            "code" : "M09AX11",
            "display" : "palovarotene"
          },
          {
            "code" : "M09AX12",
            "display" : "viltolarsen"
          },
          {
            "code" : "M09AX13",
            "display" : "casimersen"
          },
          {
            "code" : "M09AX14",
            "display" : "givinostat"
          },
          {
            "code" : "M09AX15",
            "display" : "delandistrogene moxeparvovec"
          },
          {
            "code" : "N",
            "display" : "NERVOUS SYSTEM"
          },
          {
            "code" : "N01",
            "display" : "ANESTHETICS"
          },
          {
            "code" : "N01A",
            "display" : "ANESTHETICS, GENERAL"
          },
          {
            "code" : "N01AA",
            "display" : "Ethers"
          },
          {
            "code" : "N01AA01",
            "display" : "diethyl ether"
          },
          {
            "code" : "N01AA02",
            "display" : "vinyl ether"
          },
          {
            "code" : "N01AB",
            "display" : "Halogenated hydrocarbons"
          },
          {
            "code" : "N01AB01",
            "display" : "halothane"
          },
          {
            "code" : "N01AB02",
            "display" : "chloroform"
          },
          {
            "code" : "N01AB04",
            "display" : "enflurane"
          },
          {
            "code" : "N01AB05",
            "display" : "trichloroethylene"
          },
          {
            "code" : "N01AB06",
            "display" : "isoflurane"
          },
          {
            "code" : "N01AB07",
            "display" : "desflurane"
          },
          {
            "code" : "N01AB08",
            "display" : "sevoflurane"
          },
          {
            "code" : "N01AF",
            "display" : "Barbiturates, plain"
          },
          {
            "code" : "N01AF01",
            "display" : "methohexital"
          },
          {
            "code" : "N01AF02",
            "display" : "hexobarbital"
          },
          {
            "code" : "N01AF03",
            "display" : "thiopental"
          },
          {
            "code" : "N01AG",
            "display" : "Barbiturates in combination with other drugs"
          },
          {
            "code" : "N01AG01",
            "display" : "narcobarbital"
          },
          {
            "code" : "N01AH",
            "display" : "Opioid anesthetics"
          },
          {
            "code" : "N01AH01",
            "display" : "fentanyl"
          },
          {
            "code" : "N01AH02",
            "display" : "alfentanil"
          },
          {
            "code" : "N01AH03",
            "display" : "sufentanil"
          },
          {
            "code" : "N01AH04",
            "display" : "phenoperidine"
          },
          {
            "code" : "N01AH05",
            "display" : "anileridine"
          },
          {
            "code" : "N01AH06",
            "display" : "remifentanil"
          },
          {
            "code" : "N01AH51",
            "display" : "fentanyl, combinations"
          },
          {
            "code" : "N01AX",
            "display" : "Other general anesthetics"
          },
          {
            "code" : "N01AX03",
            "display" : "ketamine"
          },
          {
            "code" : "N01AX04",
            "display" : "propanidid"
          },
          {
            "code" : "N01AX05",
            "display" : "alfaxalone"
          },
          {
            "code" : "N01AX07",
            "display" : "etomidate"
          },
          {
            "code" : "N01AX10",
            "display" : "propofol"
          },
          {
            "code" : "N01AX11",
            "display" : "sodium oxybate"
          },
          {
            "code" : "N01AX13",
            "display" : "nitrous oxide"
          },
          {
            "code" : "N01AX14",
            "display" : "esketamine"
          },
          {
            "code" : "N01AX15",
            "display" : "xenon"
          },
          {
            "code" : "N01AX63",
            "display" : "nitrous oxide, combinations"
          },
          {
            "code" : "N01B",
            "display" : "ANESTHETICS, LOCAL"
          },
          {
            "code" : "N01BA",
            "display" : "Esters of aminobenzoic acid"
          },
          {
            "code" : "N01BA01",
            "display" : "metabutethamine"
          },
          {
            "code" : "N01BA02",
            "display" : "procaine"
          },
          {
            "code" : "N01BA03",
            "display" : "tetracaine"
          },
          {
            "code" : "N01BA04",
            "display" : "chloroprocaine"
          },
          {
            "code" : "N01BA05",
            "display" : "benzocaine"
          },
          {
            "code" : "N01BA52",
            "display" : "procaine, combinations"
          },
          {
            "code" : "N01BA53",
            "display" : "tetracaine, combinations"
          },
          {
            "code" : "N01BB",
            "display" : "Amides"
          },
          {
            "code" : "N01BB01",
            "display" : "bupivacaine"
          },
          {
            "code" : "N01BB02",
            "display" : "lidocaine"
          },
          {
            "code" : "N01BB03",
            "display" : "mepivacaine"
          },
          {
            "code" : "N01BB04",
            "display" : "prilocaine"
          },
          {
            "code" : "N01BB05",
            "display" : "butanilicaine"
          },
          {
            "code" : "N01BB06",
            "display" : "cinchocaine"
          },
          {
            "code" : "N01BB07",
            "display" : "etidocaine"
          },
          {
            "code" : "N01BB08",
            "display" : "articaine"
          },
          {
            "code" : "N01BB09",
            "display" : "ropivacaine"
          },
          {
            "code" : "N01BB10",
            "display" : "levobupivacaine"
          },
          {
            "code" : "N01BB20",
            "display" : "combinations"
          },
          {
            "code" : "N01BB51",
            "display" : "bupivacaine, combinations"
          },
          {
            "code" : "N01BB52",
            "display" : "lidocaine, combinations"
          },
          {
            "code" : "N01BB53",
            "display" : "mepivacaine, combinations"
          },
          {
            "code" : "N01BB54",
            "display" : "prilocaine, combinations"
          },
          {
            "code" : "N01BB57",
            "display" : "etidocaine, combinations"
          },
          {
            "code" : "N01BB58",
            "display" : "articaine, combinations"
          },
          {
            "code" : "N01BB59",
            "display" : "bupivacaine and meloxicam"
          },
          {
            "code" : "N01BC",
            "display" : "Esters of benzoic acid"
          },
          {
            "code" : "N01BC01",
            "display" : "cocaine"
          },
          {
            "code" : "N01BX",
            "display" : "Other local anesthetics"
          },
          {
            "code" : "N01BX01",
            "display" : "ethyl chloride"
          },
          {
            "code" : "N01BX02",
            "display" : "dyclonine"
          },
          {
            "code" : "N01BX03",
            "display" : "phenol"
          },
          {
            "code" : "N01BX04",
            "display" : "capsaicin"
          },
          {
            "code" : "N02",
            "display" : "ANALGESICS"
          },
          {
            "code" : "N02A",
            "display" : "OPIOIDS"
          },
          {
            "code" : "N02AA",
            "display" : "Natural opium alkaloids"
          },
          {
            "code" : "N02AA01",
            "display" : "morphine"
          },
          {
            "code" : "N02AA02",
            "display" : "opium"
          },
          {
            "code" : "N02AA03",
            "display" : "hydromorphone"
          },
          {
            "code" : "N02AA04",
            "display" : "nicomorphine"
          },
          {
            "code" : "N02AA05",
            "display" : "oxycodone"
          },
          {
            "code" : "N02AA08",
            "display" : "dihydrocodeine"
          },
          {
            "code" : "N02AA10",
            "display" : "papaveretum"
          },
          {
            "code" : "N02AA11",
            "display" : "oxymorphone"
          },
          {
            "code" : "N02AA51",
            "display" : "morphine, combinations"
          },
          {
            "code" : "N02AA53",
            "display" : "hydromorphone and naloxone"
          },
          {
            "code" : "N02AA55",
            "display" : "oxycodone and naloxone"
          },
          {
            "code" : "N02AA56",
            "display" : "oxycodone and naltrexone"
          },
          {
            "code" : "N02AA58",
            "display" : "dihydrocodeine, combinations"
          },
          {
            "code" : "N02AA59",
            "display" : "codeine, combinations excl. psycholeptics"
          },
          {
            "code" : "N02AA79",
            "display" : "codeine, combinations with psycholeptics"
          },
          {
            "code" : "N02AB",
            "display" : "Phenylpiperidine derivatives"
          },
          {
            "code" : "N02AB01",
            "display" : "ketobemidone"
          },
          {
            "code" : "N02AB02",
            "display" : "pethidine"
          },
          {
            "code" : "N02AB03",
            "display" : "fentanyl"
          },
          {
            "code" : "N02AB52",
            "display" : "pethidine, combinations excl. psycholeptics"
          },
          {
            "code" : "N02AB72",
            "display" : "pethidine, combinations with psycholeptics"
          },
          {
            "code" : "N02AC",
            "display" : "Diphenylpropylamine derivatives"
          },
          {
            "code" : "N02AC01",
            "display" : "dextromoramide"
          },
          {
            "code" : "N02AC03",
            "display" : "piritramide"
          },
          {
            "code" : "N02AC04",
            "display" : "dextropropoxyphene"
          },
          {
            "code" : "N02AC05",
            "display" : "bezitramide"
          },
          {
            "code" : "N02AC52",
            "display" : "methadone, combinations excl. psycholeptics"
          },
          {
            "code" : "N02AC54",
            "display" : "dextropropoxyphene, combinations excl. psycholeptics"
          },
          {
            "code" : "N02AC74",
            "display" : "dextropropoxyphene, combinations with psycholeptics"
          },
          {
            "code" : "N02AD",
            "display" : "Benzomorphan derivatives"
          },
          {
            "code" : "N02AD01",
            "display" : "pentazocine"
          },
          {
            "code" : "N02AD02",
            "display" : "phenazocine"
          },
          {
            "code" : "N02AD51",
            "display" : "pentazocine and naloxone"
          },
          {
            "code" : "N02AE",
            "display" : "Oripavine derivatives"
          },
          {
            "code" : "N02AE01",
            "display" : "buprenorphine"
          },
          {
            "code" : "N02AF",
            "display" : "Morphinan derivatives"
          },
          {
            "code" : "N02AF01",
            "display" : "butorphanol"
          },
          {
            "code" : "N02AF02",
            "display" : "nalbuphine"
          },
          {
            "code" : "N02AG",
            "display" : "Opioids in combination with antispasmodics"
          },
          {
            "code" : "N02AG01",
            "display" : "morphine and antispasmodics"
          },
          {
            "code" : "N02AG02",
            "display" : "ketobemidone and antispasmodics"
          },
          {
            "code" : "N02AG03",
            "display" : "pethidine and antispasmodics"
          },
          {
            "code" : "N02AG04",
            "display" : "hydromorphone and antispasmodics"
          },
          {
            "code" : "N02AJ",
            "display" : "Opioids in combination with non-opioid analgesics"
          },
          {
            "code" : "N02AJ01",
            "display" : "dihydrocodeine and paracetamol"
          },
          {
            "code" : "N02AJ02",
            "display" : "dihydrocodeine and acetylsalicylic acid"
          },
          {
            "code" : "N02AJ03",
            "display" : "dihydrocodeine and other non-opioid analgesics"
          },
          {
            "code" : "N02AJ06",
            "display" : "codeine and paracetamol"
          },
          {
            "code" : "N02AJ07",
            "display" : "codeine and acetylsalicylic acid"
          },
          {
            "code" : "N02AJ08",
            "display" : "codeine and ibuprofen"
          },
          {
            "code" : "N02AJ09",
            "display" : "codeine and other non-opioid analgesics"
          },
          {
            "code" : "N02AJ13",
            "display" : "tramadol and paracetamol"
          },
          {
            "code" : "N02AJ14",
            "display" : "tramadol and dexketoprofen"
          },
          {
            "code" : "N02AJ15",
            "display" : "tramadol and other non-opioid analgesics"
          },
          {
            "code" : "N02AJ16",
            "display" : "tramadol and celecoxib"
          },
          {
            "code" : "N02AJ17",
            "display" : "oxycodone and paracetamol"
          },
          {
            "code" : "N02AJ18",
            "display" : "oxycodone and acetylsalicylic acid"
          },
          {
            "code" : "N02AJ19",
            "display" : "oxycodone and ibuprofen"
          },
          {
            "code" : "N02AJ22",
            "display" : "hydrocodone and paracetamol"
          },
          {
            "code" : "N02AJ23",
            "display" : "hydrocodone and ibuprofen"
          },
          {
            "code" : "N02AX",
            "display" : "Other opioids"
          },
          {
            "code" : "N02AX01",
            "display" : "tilidine"
          },
          {
            "code" : "N02AX02",
            "display" : "tramadol"
          },
          {
            "code" : "N02AX03",
            "display" : "dezocine"
          },
          {
            "code" : "N02AX05",
            "display" : "meptazinol"
          },
          {
            "code" : "N02AX06",
            "display" : "tapentadol"
          },
          {
            "code" : "N02AX07",
            "display" : "oliceridine"
          },
          {
            "code" : "N02AX51",
            "display" : "tilidine and naloxone"
          },
          {
            "code" : "N02B",
            "display" : "OTHER ANALGESICS AND ANTIPYRETICS"
          },
          {
            "code" : "N02BA",
            "display" : "Salicylic acid and derivatives"
          },
          {
            "code" : "N02BA01",
            "display" : "acetylsalicylic acid"
          },
          {
            "code" : "N02BA02",
            "display" : "aloxiprin"
          },
          {
            "code" : "N02BA03",
            "display" : "choline salicylate"
          },
          {
            "code" : "N02BA04",
            "display" : "sodium salicylate"
          },
          {
            "code" : "N02BA05",
            "display" : "salicylamide"
          },
          {
            "code" : "N02BA06",
            "display" : "salsalate"
          },
          {
            "code" : "N02BA07",
            "display" : "ethenzamide"
          },
          {
            "code" : "N02BA08",
            "display" : "morpholine salicylate"
          },
          {
            "code" : "N02BA09",
            "display" : "dipyrocetyl"
          },
          {
            "code" : "N02BA10",
            "display" : "benorilate"
          },
          {
            "code" : "N02BA11",
            "display" : "diflunisal"
          },
          {
            "code" : "N02BA12",
            "display" : "potassium salicylate"
          },
          {
            "code" : "N02BA14",
            "display" : "guacetisal"
          },
          {
            "code" : "N02BA15",
            "display" : "carbasalate calcium"
          },
          {
            "code" : "N02BA16",
            "display" : "imidazole salicylate"
          },
          {
            "code" : "N02BA51",
            "display" : "acetylsalicylic acid, combinations excl. psycholeptics"
          },
          {
            "code" : "N02BA55",
            "display" : "salicylamide, combinations excl. psycholeptics"
          },
          {
            "code" : "N02BA57",
            "display" : "ethenzamide, combinations excl. psycholeptics"
          },
          {
            "code" : "N02BA59",
            "display" : "dipyrocetyl, combinations excl. psycholeptics"
          },
          {
            "code" : "N02BA65",
            "display" : "carbasalate calcium combinations excl. psycholeptics"
          },
          {
            "code" : "N02BA67",
            "display" : "magnesium salicylate, combinations excl. psycholeptics"
          },
          {
            "code" : "N02BA71",
            "display" : "acetylsalicylic acid, combinations with psycholeptics"
          },
          {
            "code" : "N02BA75",
            "display" : "salicylamide, combinations with psycholeptics"
          },
          {
            "code" : "N02BA77",
            "display" : "ethenzamide, combinations with psycholeptics"
          },
          {
            "code" : "N02BA79",
            "display" : "dipyrocetyl, combinations with psycholeptics"
          },
          {
            "code" : "N02BB",
            "display" : "Pyrazolones"
          },
          {
            "code" : "N02BB01",
            "display" : "phenazone"
          },
          {
            "code" : "N02BB02",
            "display" : "metamizole sodium"
          },
          {
            "code" : "N02BB03",
            "display" : "aminophenazone"
          },
          {
            "code" : "N02BB04",
            "display" : "propyphenazone"
          },
          {
            "code" : "N02BB05",
            "display" : "nifenazone"
          },
          {
            "code" : "N02BB51",
            "display" : "phenazone, combinations excl. psycholeptics"
          },
          {
            "code" : "N02BB52",
            "display" : "metamizole sodium, combinations excl. psycholeptics"
          },
          {
            "code" : "N02BB53",
            "display" : "aminophenazone, combinations excl. psycholeptics"
          },
          {
            "code" : "N02BB54",
            "display" : "propyphenazone, combinations excl. psycholeptics"
          },
          {
            "code" : "N02BB71",
            "display" : "phenazone, combinations with psycholeptics"
          },
          {
            "code" : "N02BB72",
            "display" : "metamizole sodium, combinations with psycholeptics"
          },
          {
            "code" : "N02BB73",
            "display" : "aminophenazone, combinations with psycholeptics"
          },
          {
            "code" : "N02BB74",
            "display" : "propyphenazone, combinations with psycholeptics"
          },
          {
            "code" : "N02BE",
            "display" : "Anilides"
          },
          {
            "code" : "N02BE01",
            "display" : "paracetamol"
          },
          {
            "code" : "N02BE03",
            "display" : "phenacetin"
          },
          {
            "code" : "N02BE04",
            "display" : "bucetin"
          },
          {
            "code" : "N02BE05",
            "display" : "propacetamol"
          },
          {
            "code" : "N02BE51",
            "display" : "paracetamol, combinations excl. psycholeptics"
          },
          {
            "code" : "N02BE53",
            "display" : "phenacetin, combinations excl. psycholeptics"
          },
          {
            "code" : "N02BE54",
            "display" : "bucetin, combinations excl. psycholeptics"
          },
          {
            "code" : "N02BE71",
            "display" : "paracetamol, combinations with psycholeptics"
          },
          {
            "code" : "N02BE73",
            "display" : "phenacetin, combinations with psycholeptics"
          },
          {
            "code" : "N02BE74",
            "display" : "bucetin, combinations with psycholeptics"
          },
          {
            "code" : "N02BF",
            "display" : "Gabapentinoids"
          },
          {
            "code" : "N02BF01",
            "display" : "gabapentin"
          },
          {
            "code" : "N02BF02",
            "display" : "pregabalin"
          },
          {
            "code" : "N02BF03",
            "display" : "mirogabalin"
          },
          {
            "code" : "N02BG",
            "display" : "Other analgesics and antipyretics"
          },
          {
            "code" : "N02BG02",
            "display" : "rimazolium"
          },
          {
            "code" : "N02BG03",
            "display" : "glafenine"
          },
          {
            "code" : "N02BG04",
            "display" : "floctafenine"
          },
          {
            "code" : "N02BG05",
            "display" : "viminol"
          },
          {
            "code" : "N02BG06",
            "display" : "nefopam"
          },
          {
            "code" : "N02BG07",
            "display" : "flupirtine"
          },
          {
            "code" : "N02BG08",
            "display" : "ziconotide"
          },
          {
            "code" : "N02BG09",
            "display" : "methoxyflurane"
          },
          {
            "code" : "N02BG10",
            "display" : "cannabinoids"
          },
          {
            "code" : "N02BG12",
            "display" : "tanezumab"
          },
          {
            "code" : "N02C",
            "display" : "ANTIMIGRAINE PREPARATIONS"
          },
          {
            "code" : "N02CA",
            "display" : "Ergot alkaloids"
          },
          {
            "code" : "N02CA01",
            "display" : "dihydroergotamine"
          },
          {
            "code" : "N02CA02",
            "display" : "ergotamine"
          },
          {
            "code" : "N02CA04",
            "display" : "methysergide"
          },
          {
            "code" : "N02CA07",
            "display" : "lisuride"
          },
          {
            "code" : "N02CA51",
            "display" : "dihydroergotamine, combinations"
          },
          {
            "code" : "N02CA52",
            "display" : "ergotamine, combinations excl. psycholeptics"
          },
          {
            "code" : "N02CA72",
            "display" : "ergotamine, combinations with psycholeptics"
          },
          {
            "code" : "N02CB",
            "display" : "Corticosteroid derivatives"
          },
          {
            "code" : "N02CB01",
            "display" : "flumedroxone"
          },
          {
            "code" : "N02CC",
            "display" : "Selective serotonin (5HT1) agonists"
          },
          {
            "code" : "N02CC01",
            "display" : "sumatriptan"
          },
          {
            "code" : "N02CC02",
            "display" : "naratriptan"
          },
          {
            "code" : "N02CC03",
            "display" : "zolmitriptan"
          },
          {
            "code" : "N02CC04",
            "display" : "rizatriptan"
          },
          {
            "code" : "N02CC05",
            "display" : "almotriptan"
          },
          {
            "code" : "N02CC06",
            "display" : "eletriptan"
          },
          {
            "code" : "N02CC07",
            "display" : "frovatriptan"
          },
          {
            "code" : "N02CC08",
            "display" : "lasmiditan"
          },
          {
            "code" : "N02CC51",
            "display" : "sumatriptan and naproxen"
          },
          {
            "code" : "N02CD",
            "display" : "Calcitonin gene-related peptide (CGRP) antagonists"
          },
          {
            "code" : "N02CD01",
            "display" : "erenumab"
          },
          {
            "code" : "N02CD02",
            "display" : "galcanezumab"
          },
          {
            "code" : "N02CD03",
            "display" : "fremanezumab"
          },
          {
            "code" : "N02CD04",
            "display" : "ubrogepant"
          },
          {
            "code" : "N02CD05",
            "display" : "eptinezumab"
          },
          {
            "code" : "N02CD06",
            "display" : "rimegepant"
          },
          {
            "code" : "N02CD07",
            "display" : "atogepant"
          },
          {
            "code" : "N02CD08",
            "display" : "zavegepant"
          },
          {
            "code" : "N02CX",
            "display" : "Other antimigraine preparations"
          },
          {
            "code" : "N02CX01",
            "display" : "pizotifen"
          },
          {
            "code" : "N02CX02",
            "display" : "clonidine"
          },
          {
            "code" : "N02CX03",
            "display" : "iprazochrome"
          },
          {
            "code" : "N02CX05",
            "display" : "dimetotiazine"
          },
          {
            "code" : "N02CX06",
            "display" : "oxetorone"
          },
          {
            "code" : "N03",
            "display" : "ANTIEPILEPTICS"
          },
          {
            "code" : "N03A",
            "display" : "ANTIEPILEPTICS"
          },
          {
            "code" : "N03AA",
            "display" : "Barbiturates and derivatives"
          },
          {
            "code" : "N03AA01",
            "display" : "methylphenobarbital"
          },
          {
            "code" : "N03AA02",
            "display" : "phenobarbital"
          },
          {
            "code" : "N03AA03",
            "display" : "primidone"
          },
          {
            "code" : "N03AA04",
            "display" : "barbexaclone"
          },
          {
            "code" : "N03AA30",
            "display" : "metharbital"
          },
          {
            "code" : "N03AB",
            "display" : "Hydantoin derivatives"
          },
          {
            "code" : "N03AB01",
            "display" : "ethotoin"
          },
          {
            "code" : "N03AB02",
            "display" : "phenytoin"
          },
          {
            "code" : "N03AB03",
            "display" : "amino(diphenylhydantoin) valeric acid"
          },
          {
            "code" : "N03AB04",
            "display" : "mephenytoin"
          },
          {
            "code" : "N03AB05",
            "display" : "fosphenytoin"
          },
          {
            "code" : "N03AB52",
            "display" : "phenytoin, combinations"
          },
          {
            "code" : "N03AB54",
            "display" : "mephenytoin, combinations"
          },
          {
            "code" : "N03AC",
            "display" : "Oxazolidine derivatives"
          },
          {
            "code" : "N03AC01",
            "display" : "paramethadione"
          },
          {
            "code" : "N03AC02",
            "display" : "trimethadione"
          },
          {
            "code" : "N03AC03",
            "display" : "ethadione"
          },
          {
            "code" : "N03AD",
            "display" : "Succinimide derivatives"
          },
          {
            "code" : "N03AD01",
            "display" : "ethosuximide"
          },
          {
            "code" : "N03AD02",
            "display" : "phensuximide"
          },
          {
            "code" : "N03AD03",
            "display" : "mesuximide"
          },
          {
            "code" : "N03AD51",
            "display" : "ethosuximide, combinations"
          },
          {
            "code" : "N03AE",
            "display" : "Benzodiazepine derivatives"
          },
          {
            "code" : "N03AE01",
            "display" : "clonazepam"
          },
          {
            "code" : "N03AF",
            "display" : "Carboxamide derivatives"
          },
          {
            "code" : "N03AF01",
            "display" : "carbamazepine"
          },
          {
            "code" : "N03AF02",
            "display" : "oxcarbazepine"
          },
          {
            "code" : "N03AF03",
            "display" : "rufinamide"
          },
          {
            "code" : "N03AF04",
            "display" : "eslicarbazepine"
          },
          {
            "code" : "N03AG",
            "display" : "Fatty acid derivatives"
          },
          {
            "code" : "N03AG01",
            "display" : "valproic acid"
          },
          {
            "code" : "N03AG02",
            "display" : "valpromide"
          },
          {
            "code" : "N03AG03",
            "display" : "aminobutyric acid"
          },
          {
            "code" : "N03AG04",
            "display" : "vigabatrin"
          },
          {
            "code" : "N03AG05",
            "display" : "progabide"
          },
          {
            "code" : "N03AG06",
            "display" : "tiagabine"
          },
          {
            "code" : "N03AX",
            "display" : "Other antiepileptics"
          },
          {
            "code" : "N03AX03",
            "display" : "sultiame"
          },
          {
            "code" : "N03AX07",
            "display" : "phenacemide"
          },
          {
            "code" : "N03AX09",
            "display" : "lamotrigine"
          },
          {
            "code" : "N03AX10",
            "display" : "felbamate"
          },
          {
            "code" : "N03AX11",
            "display" : "topiramate"
          },
          {
            "code" : "N03AX13",
            "display" : "pheneturide"
          },
          {
            "code" : "N03AX14",
            "display" : "levetiracetam"
          },
          {
            "code" : "N03AX15",
            "display" : "zonisamide"
          },
          {
            "code" : "N03AX17",
            "display" : "stiripentol"
          },
          {
            "code" : "N03AX18",
            "display" : "lacosamide"
          },
          {
            "code" : "N03AX19",
            "display" : "carisbamate"
          },
          {
            "code" : "N03AX21",
            "display" : "retigabine"
          },
          {
            "code" : "N03AX22",
            "display" : "perampanel"
          },
          {
            "code" : "N03AX23",
            "display" : "brivaracetam"
          },
          {
            "code" : "N03AX24",
            "display" : "cannabidiol"
          },
          {
            "code" : "N03AX25",
            "display" : "cenobamate"
          },
          {
            "code" : "N03AX26",
            "display" : "fenfluramine"
          },
          {
            "code" : "N03AX27",
            "display" : "ganaxolone"
          },
          {
            "code" : "N03AX30",
            "display" : "beclamide"
          },
          {
            "code" : "N04",
            "display" : "ANTI-PARKINSON DRUGS"
          },
          {
            "code" : "N04A",
            "display" : "ANTICHOLINERGIC AGENTS"
          },
          {
            "code" : "N04AA",
            "display" : "Tertiary amines"
          },
          {
            "code" : "N04AA01",
            "display" : "trihexyphenidyl"
          },
          {
            "code" : "N04AA02",
            "display" : "biperiden"
          },
          {
            "code" : "N04AA03",
            "display" : "metixene"
          },
          {
            "code" : "N04AA04",
            "display" : "procyclidine"
          },
          {
            "code" : "N04AA05",
            "display" : "profenamine"
          },
          {
            "code" : "N04AA08",
            "display" : "dexetimide"
          },
          {
            "code" : "N04AA09",
            "display" : "phenglutarimide"
          },
          {
            "code" : "N04AA10",
            "display" : "mazaticol"
          },
          {
            "code" : "N04AA11",
            "display" : "bornaprine"
          },
          {
            "code" : "N04AA12",
            "display" : "tropatepine"
          },
          {
            "code" : "N04AB",
            "display" : "Ethers chemically close to antihistamines"
          },
          {
            "code" : "N04AB01",
            "display" : "etanautine"
          },
          {
            "code" : "N04AB02",
            "display" : "orphenadrine (chloride)"
          },
          {
            "code" : "N04AC",
            "display" : "Ethers of tropine or tropine derivatives"
          },
          {
            "code" : "N04AC01",
            "display" : "benzatropine"
          },
          {
            "code" : "N04AC30",
            "display" : "etybenzatropine"
          },
          {
            "code" : "N04B",
            "display" : "DOPAMINERGIC AGENTS"
          },
          {
            "code" : "N04BA",
            "display" : "Dopa and dopa derivatives"
          },
          {
            "code" : "N04BA01",
            "display" : "levodopa"
          },
          {
            "code" : "N04BA02",
            "display" : "levodopa and decarboxylase inhibitor"
          },
          {
            "code" : "N04BA03",
            "display" : "levodopa, decarboxylase inhibitor and COMT inhibitor"
          },
          {
            "code" : "N04BA04",
            "display" : "melevodopa"
          },
          {
            "code" : "N04BA05",
            "display" : "melevodopa and decarboxylase inhibitor"
          },
          {
            "code" : "N04BA06",
            "display" : "etilevodopa and decarboxylase inhibitor"
          },
          {
            "code" : "N04BA07",
            "display" : "foslevodopa and decarboxylase inhibitor"
          },
          {
            "code" : "N04BB",
            "display" : "Adamantane derivatives"
          },
          {
            "code" : "N04BB01",
            "display" : "amantadine"
          },
          {
            "code" : "N04BC",
            "display" : "Dopamine agonists"
          },
          {
            "code" : "N04BC01",
            "display" : "bromocriptine"
          },
          {
            "code" : "N04BC02",
            "display" : "pergolide"
          },
          {
            "code" : "N04BC03",
            "display" : "dihydroergocryptine mesylate"
          },
          {
            "code" : "N04BC04",
            "display" : "ropinirole"
          },
          {
            "code" : "N04BC05",
            "display" : "pramipexole"
          },
          {
            "code" : "N04BC06",
            "display" : "cabergoline"
          },
          {
            "code" : "N04BC07",
            "display" : "apomorphine"
          },
          {
            "code" : "N04BC08",
            "display" : "piribedil"
          },
          {
            "code" : "N04BC09",
            "display" : "rotigotine"
          },
          {
            "code" : "N04BD",
            "display" : "Monoamine oxidase B inhibitors"
          },
          {
            "code" : "N04BD01",
            "display" : "selegiline"
          },
          {
            "code" : "N04BD02",
            "display" : "rasagiline"
          },
          {
            "code" : "N04BD03",
            "display" : "safinamide"
          },
          {
            "code" : "N04BX",
            "display" : "Other dopaminergic agents"
          },
          {
            "code" : "N04BX01",
            "display" : "tolcapone"
          },
          {
            "code" : "N04BX02",
            "display" : "entacapone"
          },
          {
            "code" : "N04BX03",
            "display" : "budipine"
          },
          {
            "code" : "N04BX04",
            "display" : "opicapone"
          },
          {
            "code" : "N04C",
            "display" : "OTHER ANTIPARKINSON DRUGS"
          },
          {
            "code" : "N04CX",
            "display" : "Other antiparkinson drugs"
          },
          {
            "code" : "N04CX01",
            "display" : "istradefylline"
          },
          {
            "code" : "N05",
            "display" : "PSYCHOLEPTICS"
          },
          {
            "code" : "N05A",
            "display" : "ANTIPSYCHOTICS"
          },
          {
            "code" : "N05AA",
            "display" : "Phenothiazines with aliphatic side-chain"
          },
          {
            "code" : "N05AA01",
            "display" : "chlorpromazine"
          },
          {
            "code" : "N05AA02",
            "display" : "levomepromazine"
          },
          {
            "code" : "N05AA03",
            "display" : "promazine"
          },
          {
            "code" : "N05AA04",
            "display" : "acepromazine"
          },
          {
            "code" : "N05AA05",
            "display" : "triflupromazine"
          },
          {
            "code" : "N05AA06",
            "display" : "cyamemazine"
          },
          {
            "code" : "N05AA07",
            "display" : "chlorproethazine"
          },
          {
            "code" : "N05AB",
            "display" : "Phenothiazines with piperazine structure"
          },
          {
            "code" : "N05AB01",
            "display" : "dixyrazine"
          },
          {
            "code" : "N05AB02",
            "display" : "fluphenazine"
          },
          {
            "code" : "N05AB03",
            "display" : "perphenazine"
          },
          {
            "code" : "N05AB04",
            "display" : "prochlorperazine"
          },
          {
            "code" : "N05AB05",
            "display" : "thiopropazate"
          },
          {
            "code" : "N05AB06",
            "display" : "trifluoperazine"
          },
          {
            "code" : "N05AB07",
            "display" : "acetophenazine"
          },
          {
            "code" : "N05AB08",
            "display" : "thioproperazine"
          },
          {
            "code" : "N05AB09",
            "display" : "butaperazine"
          },
          {
            "code" : "N05AB10",
            "display" : "perazine"
          },
          {
            "code" : "N05AC",
            "display" : "Phenothiazines with piperidine structure"
          },
          {
            "code" : "N05AC01",
            "display" : "periciazine"
          },
          {
            "code" : "N05AC02",
            "display" : "thioridazine"
          },
          {
            "code" : "N05AC03",
            "display" : "mesoridazine"
          },
          {
            "code" : "N05AC04",
            "display" : "pipotiazine"
          },
          {
            "code" : "N05AD",
            "display" : "Butyrophenone derivatives"
          },
          {
            "code" : "N05AD01",
            "display" : "haloperidol"
          },
          {
            "code" : "N05AD02",
            "display" : "trifluperidol"
          },
          {
            "code" : "N05AD03",
            "display" : "melperone"
          },
          {
            "code" : "N05AD04",
            "display" : "moperone"
          },
          {
            "code" : "N05AD05",
            "display" : "pipamperone"
          },
          {
            "code" : "N05AD06",
            "display" : "bromperidol"
          },
          {
            "code" : "N05AD07",
            "display" : "benperidol"
          },
          {
            "code" : "N05AD08",
            "display" : "droperidol"
          },
          {
            "code" : "N05AD09",
            "display" : "fluanisone"
          },
          {
            "code" : "N05AD10",
            "display" : "lumateperone"
          },
          {
            "code" : "N05AE",
            "display" : "Indole derivatives"
          },
          {
            "code" : "N05AE01",
            "display" : "oxypertine"
          },
          {
            "code" : "N05AE02",
            "display" : "molindone"
          },
          {
            "code" : "N05AE03",
            "display" : "sertindole"
          },
          {
            "code" : "N05AE04",
            "display" : "ziprasidone"
          },
          {
            "code" : "N05AE05",
            "display" : "lurasidone"
          },
          {
            "code" : "N05AF",
            "display" : "Thioxanthene derivatives"
          },
          {
            "code" : "N05AF01",
            "display" : "flupentixol"
          },
          {
            "code" : "N05AF02",
            "display" : "clopenthixol"
          },
          {
            "code" : "N05AF03",
            "display" : "chlorprothixene"
          },
          {
            "code" : "N05AF04",
            "display" : "tiotixene"
          },
          {
            "code" : "N05AF05",
            "display" : "zuclopenthixol"
          },
          {
            "code" : "N05AG",
            "display" : "Diphenylbutylpiperidine derivatives"
          },
          {
            "code" : "N05AG01",
            "display" : "fluspirilene"
          },
          {
            "code" : "N05AG02",
            "display" : "pimozide"
          },
          {
            "code" : "N05AG03",
            "display" : "penfluridol"
          },
          {
            "code" : "N05AH",
            "display" : "Diazepines, oxazepines, thiazepines and oxepines"
          },
          {
            "code" : "N05AH01",
            "display" : "loxapine"
          },
          {
            "code" : "N05AH02",
            "display" : "clozapine"
          },
          {
            "code" : "N05AH03",
            "display" : "olanzapine"
          },
          {
            "code" : "N05AH04",
            "display" : "quetiapine"
          },
          {
            "code" : "N05AH05",
            "display" : "asenapine"
          },
          {
            "code" : "N05AH06",
            "display" : "clotiapine"
          },
          {
            "code" : "N05AH53",
            "display" : "olanzapine and samidorphan"
          },
          {
            "code" : "N05AL",
            "display" : "Benzamides"
          },
          {
            "code" : "N05AL01",
            "display" : "sulpiride"
          },
          {
            "code" : "N05AL02",
            "display" : "sultopride"
          },
          {
            "code" : "N05AL03",
            "display" : "tiapride"
          },
          {
            "code" : "N05AL04",
            "display" : "remoxipride"
          },
          {
            "code" : "N05AL05",
            "display" : "amisulpride"
          },
          {
            "code" : "N05AL06",
            "display" : "veralipride"
          },
          {
            "code" : "N05AL07",
            "display" : "levosulpiride"
          },
          {
            "code" : "N05AN",
            "display" : "Lithium"
          },
          {
            "code" : "N05AN01",
            "display" : "lithium"
          },
          {
            "code" : "N05AX",
            "display" : "Other antipsychotics"
          },
          {
            "code" : "N05AX07",
            "display" : "prothipendyl"
          },
          {
            "code" : "N05AX08",
            "display" : "risperidone"
          },
          {
            "code" : "N05AX10",
            "display" : "mosapramine"
          },
          {
            "code" : "N05AX11",
            "display" : "zotepine"
          },
          {
            "code" : "N05AX12",
            "display" : "aripiprazole"
          },
          {
            "code" : "N05AX13",
            "display" : "paliperidone"
          },
          {
            "code" : "N05AX14",
            "display" : "iloperidone"
          },
          {
            "code" : "N05AX15",
            "display" : "cariprazine"
          },
          {
            "code" : "N05AX16",
            "display" : "brexpiprazole"
          },
          {
            "code" : "N05AX17",
            "display" : "pimavanserin"
          },
          {
            "code" : "N05B",
            "display" : "ANXIOLYTICS"
          },
          {
            "code" : "N05BA",
            "display" : "Benzodiazepine derivatives"
          },
          {
            "code" : "N05BA01",
            "display" : "diazepam"
          },
          {
            "code" : "N05BA02",
            "display" : "chlordiazepoxide"
          },
          {
            "code" : "N05BA03",
            "display" : "medazepam"
          },
          {
            "code" : "N05BA04",
            "display" : "oxazepam"
          },
          {
            "code" : "N05BA05",
            "display" : "potassium clorazepate"
          },
          {
            "code" : "N05BA06",
            "display" : "lorazepam"
          },
          {
            "code" : "N05BA07",
            "display" : "adinazolam"
          },
          {
            "code" : "N05BA08",
            "display" : "bromazepam"
          },
          {
            "code" : "N05BA09",
            "display" : "clobazam"
          },
          {
            "code" : "N05BA10",
            "display" : "ketazolam"
          },
          {
            "code" : "N05BA11",
            "display" : "prazepam"
          },
          {
            "code" : "N05BA12",
            "display" : "alprazolam"
          },
          {
            "code" : "N05BA13",
            "display" : "halazepam"
          },
          {
            "code" : "N05BA14",
            "display" : "pinazepam"
          },
          {
            "code" : "N05BA15",
            "display" : "camazepam"
          },
          {
            "code" : "N05BA16",
            "display" : "nordazepam"
          },
          {
            "code" : "N05BA17",
            "display" : "fludiazepam"
          },
          {
            "code" : "N05BA18",
            "display" : "ethyl loflazepate"
          },
          {
            "code" : "N05BA19",
            "display" : "etizolam"
          },
          {
            "code" : "N05BA21",
            "display" : "clotiazepam"
          },
          {
            "code" : "N05BA22",
            "display" : "cloxazolam"
          },
          {
            "code" : "N05BA23",
            "display" : "tofisopam"
          },
          {
            "code" : "N05BA24",
            "display" : "bentazepam"
          },
          {
            "code" : "N05BA25",
            "display" : "mexazolam"
          },
          {
            "code" : "N05BA56",
            "display" : "lorazepam, combinations"
          },
          {
            "code" : "N05BB",
            "display" : "Diphenylmethane derivatives"
          },
          {
            "code" : "N05BB01",
            "display" : "hydroxyzine"
          },
          {
            "code" : "N05BB02",
            "display" : "captodiame"
          },
          {
            "code" : "N05BB51",
            "display" : "hydroxyzine, combinations"
          },
          {
            "code" : "N05BC",
            "display" : "Carbamates"
          },
          {
            "code" : "N05BC01",
            "display" : "meprobamate"
          },
          {
            "code" : "N05BC03",
            "display" : "emylcamate"
          },
          {
            "code" : "N05BC04",
            "display" : "mebutamate"
          },
          {
            "code" : "N05BC51",
            "display" : "meprobamate, combinations"
          },
          {
            "code" : "N05BD",
            "display" : "Dibenzo-bicyclo-octadiene derivatives"
          },
          {
            "code" : "N05BD01",
            "display" : "benzoctamine"
          },
          {
            "code" : "N05BE",
            "display" : "Azaspirodecanedione derivatives"
          },
          {
            "code" : "N05BE01",
            "display" : "buspirone"
          },
          {
            "code" : "N05BX",
            "display" : "Other anxiolytics"
          },
          {
            "code" : "N05BX01",
            "display" : "mephenoxalone"
          },
          {
            "code" : "N05BX02",
            "display" : "gedocarnil"
          },
          {
            "code" : "N05BX03",
            "display" : "etifoxine"
          },
          {
            "code" : "N05BX04",
            "display" : "fabomotizole"
          },
          {
            "code" : "N05BX05",
            "display" : "Lavandulae aetheroleum"
          },
          {
            "code" : "N05C",
            "display" : "HYPNOTICS AND SEDATIVES"
          },
          {
            "code" : "N05CA",
            "display" : "Barbiturates, plain"
          },
          {
            "code" : "N05CA01",
            "display" : "pentobarbital"
          },
          {
            "code" : "N05CA02",
            "display" : "amobarbital"
          },
          {
            "code" : "N05CA03",
            "display" : "butobarbital"
          },
          {
            "code" : "N05CA04",
            "display" : "barbital"
          },
          {
            "code" : "N05CA05",
            "display" : "aprobarbital"
          },
          {
            "code" : "N05CA06",
            "display" : "secobarbital"
          },
          {
            "code" : "N05CA07",
            "display" : "talbutal"
          },
          {
            "code" : "N05CA08",
            "display" : "vinylbital"
          },
          {
            "code" : "N05CA09",
            "display" : "vinbarbital"
          },
          {
            "code" : "N05CA10",
            "display" : "cyclobarbital"
          },
          {
            "code" : "N05CA11",
            "display" : "heptabarbital"
          },
          {
            "code" : "N05CA12",
            "display" : "reposal"
          },
          {
            "code" : "N05CA15",
            "display" : "methohexital"
          },
          {
            "code" : "N05CA16",
            "display" : "hexobarbital"
          },
          {
            "code" : "N05CA19",
            "display" : "thiopental"
          },
          {
            "code" : "N05CA20",
            "display" : "etallobarbital"
          },
          {
            "code" : "N05CA21",
            "display" : "allobarbital"
          },
          {
            "code" : "N05CA22",
            "display" : "proxibarbal"
          },
          {
            "code" : "N05CB",
            "display" : "Barbiturates, combinations"
          },
          {
            "code" : "N05CB01",
            "display" : "combinations of barbiturates"
          },
          {
            "code" : "N05CB02",
            "display" : "barbiturates in combination with other drugs"
          },
          {
            "code" : "N05CC",
            "display" : "Aldehydes and derivatives"
          },
          {
            "code" : "N05CC01",
            "display" : "chloral hydrate"
          },
          {
            "code" : "N05CC02",
            "display" : "chloralodol"
          },
          {
            "code" : "N05CC03",
            "display" : "acetylglycinamide chloral hydrate"
          },
          {
            "code" : "N05CC04",
            "display" : "dichloralphenazone"
          },
          {
            "code" : "N05CC05",
            "display" : "paraldehyde"
          },
          {
            "code" : "N05CD",
            "display" : "Benzodiazepine derivatives"
          },
          {
            "code" : "N05CD01",
            "display" : "flurazepam"
          },
          {
            "code" : "N05CD02",
            "display" : "nitrazepam"
          },
          {
            "code" : "N05CD03",
            "display" : "flunitrazepam"
          },
          {
            "code" : "N05CD04",
            "display" : "estazolam"
          },
          {
            "code" : "N05CD05",
            "display" : "triazolam"
          },
          {
            "code" : "N05CD06",
            "display" : "lormetazepam"
          },
          {
            "code" : "N05CD07",
            "display" : "temazepam"
          },
          {
            "code" : "N05CD08",
            "display" : "midazolam"
          },
          {
            "code" : "N05CD09",
            "display" : "brotizolam"
          },
          {
            "code" : "N05CD10",
            "display" : "quazepam"
          },
          {
            "code" : "N05CD11",
            "display" : "loprazolam"
          },
          {
            "code" : "N05CD12",
            "display" : "doxefazepam"
          },
          {
            "code" : "N05CD13",
            "display" : "cinolazepam"
          },
          {
            "code" : "N05CD14",
            "display" : "remimazolam"
          },
          {
            "code" : "N05CD15",
            "display" : "nimetazepam"
          },
          {
            "code" : "N05CE",
            "display" : "Piperidinedione derivatives"
          },
          {
            "code" : "N05CE01",
            "display" : "glutethimide"
          },
          {
            "code" : "N05CE02",
            "display" : "methyprylon"
          },
          {
            "code" : "N05CE03",
            "display" : "pyrithyldione"
          },
          {
            "code" : "N05CF",
            "display" : "Benzodiazepine related drugs"
          },
          {
            "code" : "N05CF01",
            "display" : "zopiclone"
          },
          {
            "code" : "N05CF02",
            "display" : "zolpidem"
          },
          {
            "code" : "N05CF03",
            "display" : "zaleplon"
          },
          {
            "code" : "N05CF04",
            "display" : "eszopiclone"
          },
          {
            "code" : "N05CH",
            "display" : "Melatonin receptor agonists"
          },
          {
            "code" : "N05CH01",
            "display" : "melatonin"
          },
          {
            "code" : "N05CH02",
            "display" : "ramelteon"
          },
          {
            "code" : "N05CH03",
            "display" : "tasimelteon"
          },
          {
            "code" : "N05CJ",
            "display" : "Orexin receptor antagonists"
          },
          {
            "code" : "N05CJ01",
            "display" : "suvorexant"
          },
          {
            "code" : "N05CJ02",
            "display" : "lemborexant"
          },
          {
            "code" : "N05CJ03",
            "display" : "daridorexant"
          },
          {
            "code" : "N05CM",
            "display" : "Other hypnotics and sedatives"
          },
          {
            "code" : "N05CM01",
            "display" : "methaqualone"
          },
          {
            "code" : "N05CM02",
            "display" : "clomethiazole"
          },
          {
            "code" : "N05CM03",
            "display" : "bromisoval"
          },
          {
            "code" : "N05CM04",
            "display" : "carbromal"
          },
          {
            "code" : "N05CM05",
            "display" : "scopolamine"
          },
          {
            "code" : "N05CM06",
            "display" : "propiomazine"
          },
          {
            "code" : "N05CM07",
            "display" : "triclofos"
          },
          {
            "code" : "N05CM08",
            "display" : "ethchlorvynol"
          },
          {
            "code" : "N05CM09",
            "display" : "Valerianae radix"
          },
          {
            "code" : "N05CM10",
            "display" : "hexapropymate"
          },
          {
            "code" : "N05CM11",
            "display" : "bromides"
          },
          {
            "code" : "N05CM12",
            "display" : "apronal"
          },
          {
            "code" : "N05CM13",
            "display" : "valnoctamide"
          },
          {
            "code" : "N05CM15",
            "display" : "methylpentynol"
          },
          {
            "code" : "N05CM16",
            "display" : "niaprazine"
          },
          {
            "code" : "N05CM18",
            "display" : "dexmedetomidine"
          },
          {
            "code" : "N05CX",
            "display" : "Hypnotics and sedatives in combination, excl. barbiturates"
          },
          {
            "code" : "N05CX01",
            "display" : "meprobamate, combinations"
          },
          {
            "code" : "N05CX02",
            "display" : "methaqualone, combinations"
          },
          {
            "code" : "N05CX03",
            "display" : "methylpentynol, combinations"
          },
          {
            "code" : "N05CX04",
            "display" : "clomethiazole, combinations"
          },
          {
            "code" : "N05CX05",
            "display" : "emepronium, combinations"
          },
          {
            "code" : "N05CX06",
            "display" : "dipiperonylaminoethanol, combinations"
          },
          {
            "code" : "N06",
            "display" : "PSYCHOANALEPTICS"
          },
          {
            "code" : "N06A",
            "display" : "ANTIDEPRESSANTS"
          },
          {
            "code" : "N06AA",
            "display" : "Non-selective monoamine reuptake inhibitors"
          },
          {
            "code" : "N06AA01",
            "display" : "desipramine"
          },
          {
            "code" : "N06AA02",
            "display" : "imipramine"
          },
          {
            "code" : "N06AA03",
            "display" : "imipramine oxide"
          },
          {
            "code" : "N06AA04",
            "display" : "clomipramine"
          },
          {
            "code" : "N06AA05",
            "display" : "opipramol"
          },
          {
            "code" : "N06AA06",
            "display" : "trimipramine"
          },
          {
            "code" : "N06AA07",
            "display" : "lofepramine"
          },
          {
            "code" : "N06AA08",
            "display" : "dibenzepin"
          },
          {
            "code" : "N06AA09",
            "display" : "amitriptyline"
          },
          {
            "code" : "N06AA10",
            "display" : "nortriptyline"
          },
          {
            "code" : "N06AA11",
            "display" : "protriptyline"
          },
          {
            "code" : "N06AA12",
            "display" : "doxepin"
          },
          {
            "code" : "N06AA13",
            "display" : "iprindole"
          },
          {
            "code" : "N06AA14",
            "display" : "melitracen"
          },
          {
            "code" : "N06AA15",
            "display" : "butriptyline"
          },
          {
            "code" : "N06AA16",
            "display" : "dosulepin"
          },
          {
            "code" : "N06AA17",
            "display" : "amoxapine"
          },
          {
            "code" : "N06AA18",
            "display" : "dimetacrine"
          },
          {
            "code" : "N06AA19",
            "display" : "amineptine"
          },
          {
            "code" : "N06AA21",
            "display" : "maprotiline"
          },
          {
            "code" : "N06AA23",
            "display" : "quinupramine"
          },
          {
            "code" : "N06AB",
            "display" : "Selective serotonin reuptake inhibitors"
          },
          {
            "code" : "N06AB02",
            "display" : "zimeldine"
          },
          {
            "code" : "N06AB03",
            "display" : "fluoxetine"
          },
          {
            "code" : "N06AB04",
            "display" : "citalopram"
          },
          {
            "code" : "N06AB05",
            "display" : "paroxetine"
          },
          {
            "code" : "N06AB06",
            "display" : "sertraline"
          },
          {
            "code" : "N06AB07",
            "display" : "alaproclate"
          },
          {
            "code" : "N06AB08",
            "display" : "fluvoxamine"
          },
          {
            "code" : "N06AB09",
            "display" : "etoperidone"
          },
          {
            "code" : "N06AB10",
            "display" : "escitalopram"
          },
          {
            "code" : "N06AF",
            "display" : "Monoamine oxidase inhibitors, non-selective"
          },
          {
            "code" : "N06AF01",
            "display" : "isocarboxazid"
          },
          {
            "code" : "N06AF02",
            "display" : "nialamide"
          },
          {
            "code" : "N06AF03",
            "display" : "phenelzine"
          },
          {
            "code" : "N06AF04",
            "display" : "tranylcypromine"
          },
          {
            "code" : "N06AF05",
            "display" : "iproniazide"
          },
          {
            "code" : "N06AF06",
            "display" : "iproclozide"
          },
          {
            "code" : "N06AG",
            "display" : "Monoamine oxidase A inhibitors"
          },
          {
            "code" : "N06AG02",
            "display" : "moclobemide"
          },
          {
            "code" : "N06AG03",
            "display" : "toloxatone"
          },
          {
            "code" : "N06AX",
            "display" : "Other antidepressants"
          },
          {
            "code" : "N06AX01",
            "display" : "oxitriptan"
          },
          {
            "code" : "N06AX02",
            "display" : "tryptophan"
          },
          {
            "code" : "N06AX03",
            "display" : "mianserin"
          },
          {
            "code" : "N06AX04",
            "display" : "nomifensine"
          },
          {
            "code" : "N06AX05",
            "display" : "trazodone"
          },
          {
            "code" : "N06AX06",
            "display" : "nefazodone"
          },
          {
            "code" : "N06AX07",
            "display" : "minaprine"
          },
          {
            "code" : "N06AX08",
            "display" : "bifemelane"
          },
          {
            "code" : "N06AX09",
            "display" : "viloxazine"
          },
          {
            "code" : "N06AX10",
            "display" : "oxaflozane"
          },
          {
            "code" : "N06AX11",
            "display" : "mirtazapine"
          },
          {
            "code" : "N06AX12",
            "display" : "bupropion"
          },
          {
            "code" : "N06AX13",
            "display" : "medifoxamine"
          },
          {
            "code" : "N06AX14",
            "display" : "tianeptine"
          },
          {
            "code" : "N06AX15",
            "display" : "pivagabine"
          },
          {
            "code" : "N06AX16",
            "display" : "venlafaxine"
          },
          {
            "code" : "N06AX17",
            "display" : "milnacipran"
          },
          {
            "code" : "N06AX18",
            "display" : "reboxetine"
          },
          {
            "code" : "N06AX19",
            "display" : "gepirone"
          },
          {
            "code" : "N06AX21",
            "display" : "duloxetine"
          },
          {
            "code" : "N06AX22",
            "display" : "agomelatine"
          },
          {
            "code" : "N06AX23",
            "display" : "desvenlafaxine"
          },
          {
            "code" : "N06AX24",
            "display" : "vilazodone"
          },
          {
            "code" : "N06AX25",
            "display" : "Hyperici herba"
          },
          {
            "code" : "N06AX26",
            "display" : "vortioxetine"
          },
          {
            "code" : "N06AX27",
            "display" : "esketamine"
          },
          {
            "code" : "N06AX28",
            "display" : "levomilnacipran"
          },
          {
            "code" : "N06AX29",
            "display" : "brexanolone"
          },
          {
            "code" : "N06AX31",
            "display" : "zuranolone"
          },
          {
            "code" : "N06AX62",
            "display" : "bupropion and dextromethorphan"
          },
          {
            "code" : "N06B",
            "display" : "PSYCHOSTIMULANTS, AGENTS USED FOR ADHD AND NOOTROPICS"
          },
          {
            "code" : "N06BA",
            "display" : "Centrally acting sympathomimetics"
          },
          {
            "code" : "N06BA01",
            "display" : "amfetamine"
          },
          {
            "code" : "N06BA02",
            "display" : "dexamfetamine"
          },
          {
            "code" : "N06BA03",
            "display" : "metamfetamine"
          },
          {
            "code" : "N06BA04",
            "display" : "methylphenidate"
          },
          {
            "code" : "N06BA05",
            "display" : "pemoline"
          },
          {
            "code" : "N06BA06",
            "display" : "fencamfamin"
          },
          {
            "code" : "N06BA07",
            "display" : "modafinil"
          },
          {
            "code" : "N06BA08",
            "display" : "fenozolone"
          },
          {
            "code" : "N06BA09",
            "display" : "atomoxetine"
          },
          {
            "code" : "N06BA10",
            "display" : "fenetylline"
          },
          {
            "code" : "N06BA11",
            "display" : "dexmethylphenidate"
          },
          {
            "code" : "N06BA12",
            "display" : "lisdexamfetamine"
          },
          {
            "code" : "N06BA13",
            "display" : "armodafinil"
          },
          {
            "code" : "N06BA14",
            "display" : "solriamfetol"
          },
          {
            "code" : "N06BA15",
            "display" : "dexmethylphenidate and serdexmethylphenidate"
          },
          {
            "code" : "N06BC",
            "display" : "Xanthine derivatives"
          },
          {
            "code" : "N06BC01",
            "display" : "caffeine"
          },
          {
            "code" : "N06BC02",
            "display" : "propentofylline"
          },
          {
            "code" : "N06BX",
            "display" : "Other psychostimulants and nootropics"
          },
          {
            "code" : "N06BX01",
            "display" : "meclofenoxate"
          },
          {
            "code" : "N06BX02",
            "display" : "pyritinol"
          },
          {
            "code" : "N06BX03",
            "display" : "piracetam"
          },
          {
            "code" : "N06BX04",
            "display" : "deanol"
          },
          {
            "code" : "N06BX05",
            "display" : "fipexide"
          },
          {
            "code" : "N06BX06",
            "display" : "citicoline"
          },
          {
            "code" : "N06BX07",
            "display" : "oxiracetam"
          },
          {
            "code" : "N06BX08",
            "display" : "pirisudanol"
          },
          {
            "code" : "N06BX09",
            "display" : "linopirdine"
          },
          {
            "code" : "N06BX10",
            "display" : "nizofenone"
          },
          {
            "code" : "N06BX11",
            "display" : "aniracetam"
          },
          {
            "code" : "N06BX12",
            "display" : "acetylcarnitine"
          },
          {
            "code" : "N06BX13",
            "display" : "idebenone"
          },
          {
            "code" : "N06BX14",
            "display" : "prolintane"
          },
          {
            "code" : "N06BX15",
            "display" : "pipradrol"
          },
          {
            "code" : "N06BX16",
            "display" : "pramiracetam"
          },
          {
            "code" : "N06BX17",
            "display" : "adrafinil"
          },
          {
            "code" : "N06BX18",
            "display" : "vinpocetine"
          },
          {
            "code" : "N06BX21",
            "display" : "temgicoluril"
          },
          {
            "code" : "N06BX22",
            "display" : "phenibut"
          },
          {
            "code" : "N06C",
            "display" : "PSYCHOLEPTICS AND PSYCHOANALEPTICS IN COMBINATION"
          },
          {
            "code" : "N06CA",
            "display" : "Antidepressants in combination with psycholeptics"
          },
          {
            "code" : "N06CA01",
            "display" : "amitriptyline and psycholeptics"
          },
          {
            "code" : "N06CA02",
            "display" : "melitracen and psycholeptics"
          },
          {
            "code" : "N06CA03",
            "display" : "fluoxetine and psycholeptics"
          },
          {
            "code" : "N06CB",
            "display" : "Psychostimulants in combination with psycholeptics"
          },
          {
            "code" : "N06D",
            "display" : "ANTI-DEMENTIA DRUGS"
          },
          {
            "code" : "N06DA",
            "display" : "Anticholinesterases"
          },
          {
            "code" : "N06DA01",
            "display" : "tacrine"
          },
          {
            "code" : "N06DA02",
            "display" : "donepezil"
          },
          {
            "code" : "N06DA03",
            "display" : "rivastigmine"
          },
          {
            "code" : "N06DA04",
            "display" : "galantamine"
          },
          {
            "code" : "N06DA05",
            "display" : "ipidacrine"
          },
          {
            "code" : "N06DA52",
            "display" : "donepezil and memantine"
          },
          {
            "code" : "N06DA53",
            "display" : "donepezil, memantine and Ginkgo folium"
          },
          {
            "code" : "N06DX",
            "display" : "Other anti-dementia drugs"
          },
          {
            "code" : "N06DX01",
            "display" : "memantine"
          },
          {
            "code" : "N06DX02",
            "display" : "Ginkgo folium"
          },
          {
            "code" : "N06DX03",
            "display" : "aducanumab"
          },
          {
            "code" : "N06DX04",
            "display" : "lecanemab"
          },
          {
            "code" : "N06DX05",
            "display" : "donanemab"
          },
          {
            "code" : "N06DX30",
            "display" : "combinations"
          },
          {
            "code" : "N07",
            "display" : "OTHER NERVOUS SYSTEM DRUGS"
          },
          {
            "code" : "N07A",
            "display" : "PARASYMPATHOMIMETICS"
          },
          {
            "code" : "N07AA",
            "display" : "Anticholinesterases"
          },
          {
            "code" : "N07AA01",
            "display" : "neostigmine"
          },
          {
            "code" : "N07AA02",
            "display" : "pyridostigmine"
          },
          {
            "code" : "N07AA03",
            "display" : "distigmine"
          },
          {
            "code" : "N07AA30",
            "display" : "ambenonium"
          },
          {
            "code" : "N07AA51",
            "display" : "neostigmine, combinations"
          },
          {
            "code" : "N07AB",
            "display" : "Choline esters"
          },
          {
            "code" : "N07AB01",
            "display" : "carbachol"
          },
          {
            "code" : "N07AB02",
            "display" : "bethanechol"
          },
          {
            "code" : "N07AX",
            "display" : "Other parasympathomimetics"
          },
          {
            "code" : "N07AX01",
            "display" : "pilocarpine"
          },
          {
            "code" : "N07AX02",
            "display" : "choline alfoscerate"
          },
          {
            "code" : "N07AX03",
            "display" : "cevimeline"
          },
          {
            "code" : "N07B",
            "display" : "DRUGS USED IN ADDICTIVE DISORDERS"
          },
          {
            "code" : "N07BA",
            "display" : "Drugs used in nicotine dependence"
          },
          {
            "code" : "N07BA01",
            "display" : "nicotine"
          },
          {
            "code" : "N07BA03",
            "display" : "varenicline"
          },
          {
            "code" : "N07BA04",
            "display" : "cytisinicline"
          },
          {
            "code" : "N07BB",
            "display" : "Drugs used in alcohol dependence"
          },
          {
            "code" : "N07BB01",
            "display" : "disulfiram"
          },
          {
            "code" : "N07BB02",
            "display" : "calcium carbimide"
          },
          {
            "code" : "N07BB03",
            "display" : "acamprosate"
          },
          {
            "code" : "N07BB04",
            "display" : "naltrexone"
          },
          {
            "code" : "N07BB05",
            "display" : "nalmefene"
          },
          {
            "code" : "N07BB06",
            "display" : "ondelopran"
          },
          {
            "code" : "N07BC",
            "display" : "Drugs used in opioid dependence"
          },
          {
            "code" : "N07BC01",
            "display" : "buprenorphine"
          },
          {
            "code" : "N07BC02",
            "display" : "methadone"
          },
          {
            "code" : "N07BC03",
            "display" : "levacetylmethadol"
          },
          {
            "code" : "N07BC04",
            "display" : "lofexidine"
          },
          {
            "code" : "N07BC05",
            "display" : "levomethadone"
          },
          {
            "code" : "N07BC06",
            "display" : "diamorphine"
          },
          {
            "code" : "N07BC51",
            "display" : "buprenorphine, combinations"
          },
          {
            "code" : "N07C",
            "display" : "ANTIVERTIGO PREPARATIONS"
          },
          {
            "code" : "N07CA",
            "display" : "Antivertigo preparations"
          },
          {
            "code" : "N07CA01",
            "display" : "betahistine"
          },
          {
            "code" : "N07CA02",
            "display" : "cinnarizine"
          },
          {
            "code" : "N07CA03",
            "display" : "flunarizine"
          },
          {
            "code" : "N07CA04",
            "display" : "acetylleucine"
          },
          {
            "code" : "N07CA52",
            "display" : "cinnarizine, combinations"
          },
          {
            "code" : "N07X",
            "display" : "OTHER NERVOUS SYSTEM DRUGS"
          },
          {
            "code" : "N07XA",
            "display" : "Gangliosides and ganglioside derivatives"
          },
          {
            "code" : "N07XX",
            "display" : "Other nervous system drugs"
          },
          {
            "code" : "N07XX01",
            "display" : "tirilazad"
          },
          {
            "code" : "N07XX02",
            "display" : "riluzole"
          },
          {
            "code" : "N07XX03",
            "display" : "xaliproden"
          },
          {
            "code" : "N07XX04",
            "display" : "sodium oxybate"
          },
          {
            "code" : "N07XX05",
            "display" : "amifampridine"
          },
          {
            "code" : "N07XX06",
            "display" : "tetrabenazine"
          },
          {
            "code" : "N07XX07",
            "display" : "fampridine"
          },
          {
            "code" : "N07XX08",
            "display" : "tafamidis"
          },
          {
            "code" : "N07XX10",
            "display" : "laquinimod"
          },
          {
            "code" : "N07XX11",
            "display" : "pitolisant"
          },
          {
            "code" : "N07XX12",
            "display" : "patisiran"
          },
          {
            "code" : "N07XX13",
            "display" : "valbenazine"
          },
          {
            "code" : "N07XX14",
            "display" : "edaravone"
          },
          {
            "code" : "N07XX15",
            "display" : "inotersen"
          },
          {
            "code" : "N07XX16",
            "display" : "deutetrabenazine"
          },
          {
            "code" : "N07XX17",
            "display" : "arimoclomol"
          },
          {
            "code" : "N07XX18",
            "display" : "vutrisiran"
          },
          {
            "code" : "N07XX19",
            "display" : "sodium phenylbutyrate and ursodoxicoltaurine"
          },
          {
            "code" : "N07XX21",
            "display" : "eplontersen"
          },
          {
            "code" : "N07XX22",
            "display" : "tofersen"
          },
          {
            "code" : "N07XX23",
            "display" : "troriluzole"
          },
          {
            "code" : "N07XX24",
            "display" : "trofinetide"
          },
          {
            "code" : "N07XX25",
            "display" : "omaveloxolone"
          },
          {
            "code" : "N07XX59",
            "display" : "dextromethorphan, combinations"
          },
          {
            "code" : "P",
            "display" : "ANTIPARASITIC PRODUCTS, INSECTICIDES AND REPELLENTS"
          },
          {
            "code" : "P01",
            "display" : "ANTIPROTOZOALS"
          },
          {
            "code" : "P01A",
            "display" : "AGENTS AGAINST AMOEBIASIS AND OTHER PROTOZOAL DISEASES"
          },
          {
            "code" : "P01AA",
            "display" : "Hydroxyquinoline derivatives"
          },
          {
            "code" : "P01AA01",
            "display" : "broxyquinoline"
          },
          {
            "code" : "P01AA02",
            "display" : "clioquinol"
          },
          {
            "code" : "P01AA04",
            "display" : "chlorquinaldol"
          },
          {
            "code" : "P01AA05",
            "display" : "tilbroquinol"
          },
          {
            "code" : "P01AA30",
            "display" : "tilbroquinol and tiliquinol"
          },
          {
            "code" : "P01AA52",
            "display" : "clioquinol, combinations"
          },
          {
            "code" : "P01AB",
            "display" : "Nitroimidazole derivatives"
          },
          {
            "code" : "P01AB01",
            "display" : "metronidazole"
          },
          {
            "code" : "P01AB02",
            "display" : "tinidazole"
          },
          {
            "code" : "P01AB03",
            "display" : "ornidazole"
          },
          {
            "code" : "P01AB04",
            "display" : "azanidazole"
          },
          {
            "code" : "P01AB05",
            "display" : "propenidazole"
          },
          {
            "code" : "P01AB06",
            "display" : "nimorazole"
          },
          {
            "code" : "P01AB07",
            "display" : "secnidazole"
          },
          {
            "code" : "P01AB08",
            "display" : "satranidazole"
          },
          {
            "code" : "P01AB51",
            "display" : "metronidazole and furazolidone"
          },
          {
            "code" : "P01AB52",
            "display" : "metronidazole and diloxanide"
          },
          {
            "code" : "P01AB53",
            "display" : "tinidazole and diloxanide"
          },
          {
            "code" : "P01AC",
            "display" : "Dichloroacetamide derivatives"
          },
          {
            "code" : "P01AC01",
            "display" : "diloxanide"
          },
          {
            "code" : "P01AC02",
            "display" : "clefamide"
          },
          {
            "code" : "P01AC03",
            "display" : "etofamide"
          },
          {
            "code" : "P01AC04",
            "display" : "teclozan"
          },
          {
            "code" : "P01AR",
            "display" : "Arsenic compounds"
          },
          {
            "code" : "P01AR01",
            "display" : "arsthinol"
          },
          {
            "code" : "P01AR02",
            "display" : "difetarsone"
          },
          {
            "code" : "P01AR03",
            "display" : "glycobiarsol"
          },
          {
            "code" : "P01AR53",
            "display" : "glycobiarsol, combinations"
          },
          {
            "code" : "P01AX",
            "display" : "Other agents against amoebiasis and other protozoal diseases"
          },
          {
            "code" : "P01AX01",
            "display" : "chiniofon"
          },
          {
            "code" : "P01AX02",
            "display" : "emetine"
          },
          {
            "code" : "P01AX04",
            "display" : "phanquinone"
          },
          {
            "code" : "P01AX05",
            "display" : "mepacrine"
          },
          {
            "code" : "P01AX06",
            "display" : "atovaquone"
          },
          {
            "code" : "P01AX07",
            "display" : "trimetrexate"
          },
          {
            "code" : "P01AX08",
            "display" : "tenonitrozole"
          },
          {
            "code" : "P01AX09",
            "display" : "dehydroemetine"
          },
          {
            "code" : "P01AX10",
            "display" : "fumagillin"
          },
          {
            "code" : "P01AX11",
            "display" : "nitazoxanide"
          },
          {
            "code" : "P01AX52",
            "display" : "emetine, combinations"
          },
          {
            "code" : "P01B",
            "display" : "ANTIMALARIALS"
          },
          {
            "code" : "P01BA",
            "display" : "Aminoquinolines"
          },
          {
            "code" : "P01BA01",
            "display" : "chloroquine"
          },
          {
            "code" : "P01BA02",
            "display" : "hydroxychloroquine"
          },
          {
            "code" : "P01BA03",
            "display" : "primaquine"
          },
          {
            "code" : "P01BA06",
            "display" : "amodiaquine"
          },
          {
            "code" : "P01BA07",
            "display" : "tafenoquine"
          },
          {
            "code" : "P01BB",
            "display" : "Biguanides"
          },
          {
            "code" : "P01BB01",
            "display" : "proguanil"
          },
          {
            "code" : "P01BB02",
            "display" : "cycloguanil embonate"
          },
          {
            "code" : "P01BB51",
            "display" : "proguanil and atovaquone"
          },
          {
            "code" : "P01BB52",
            "display" : "chloroquine and proguanil"
          },
          {
            "code" : "P01BC",
            "display" : "Methanolquinolines"
          },
          {
            "code" : "P01BC01",
            "display" : "quinine"
          },
          {
            "code" : "P01BC02",
            "display" : "mefloquine"
          },
          {
            "code" : "P01BD",
            "display" : "Diaminopyrimidines"
          },
          {
            "code" : "P01BD01",
            "display" : "pyrimethamine"
          },
          {
            "code" : "P01BD51",
            "display" : "pyrimethamine, combinations"
          },
          {
            "code" : "P01BE",
            "display" : "Artemisinin and derivatives, plain"
          },
          {
            "code" : "P01BE01",
            "display" : "artemisinin"
          },
          {
            "code" : "P01BE02",
            "display" : "artemether"
          },
          {
            "code" : "P01BE03",
            "display" : "artesunate"
          },
          {
            "code" : "P01BE04",
            "display" : "artemotil"
          },
          {
            "code" : "P01BE05",
            "display" : "artenimol"
          },
          {
            "code" : "P01BF",
            "display" : "Artemisinin and derivatives, combinations"
          },
          {
            "code" : "P01BF01",
            "display" : "artemether and lumefantrine"
          },
          {
            "code" : "P01BF02",
            "display" : "artesunate and mefloquine"
          },
          {
            "code" : "P01BF03",
            "display" : "artesunate and amodiaquine"
          },
          {
            "code" : "P01BF04",
            "display" : "artesunate, sulfalene and pyrimethamine"
          },
          {
            "code" : "P01BF05",
            "display" : "artenimol and piperaquine"
          },
          {
            "code" : "P01BF06",
            "display" : "artesunate and pyronaridine"
          },
          {
            "code" : "P01BF07",
            "display" : "artemisinin and piperaquine"
          },
          {
            "code" : "P01BF08",
            "display" : "artemisinin and naphthoquine"
          },
          {
            "code" : "P01BF09",
            "display" : "artesunate, sulfadoxine and pyrimethamine"
          },
          {
            "code" : "P01BX",
            "display" : "Other antimalarials"
          },
          {
            "code" : "P01BX01",
            "display" : "halofantrine"
          },
          {
            "code" : "P01BX02",
            "display" : "arterolane and piperaquine"
          },
          {
            "code" : "P01C",
            "display" : "AGENTS AGAINST LEISHMANIASIS AND TRYPANOSOMIASIS"
          },
          {
            "code" : "P01CA",
            "display" : "Nitroimidazole derivatives"
          },
          {
            "code" : "P01CA02",
            "display" : "benznidazole"
          },
          {
            "code" : "P01CA03",
            "display" : "fexinidazole"
          },
          {
            "code" : "P01CB",
            "display" : "Antimony compounds"
          },
          {
            "code" : "P01CB01",
            "display" : "meglumine antimonate"
          },
          {
            "code" : "P01CB02",
            "display" : "sodium stibogluconate"
          },
          {
            "code" : "P01CC",
            "display" : "Nitrofuran derivatives"
          },
          {
            "code" : "P01CC01",
            "display" : "nifurtimox"
          },
          {
            "code" : "P01CC02",
            "display" : "nitrofural"
          },
          {
            "code" : "P01CD",
            "display" : "Arsenic compounds"
          },
          {
            "code" : "P01CD01",
            "display" : "melarsoprol"
          },
          {
            "code" : "P01CD02",
            "display" : "acetarsol"
          },
          {
            "code" : "P01CX",
            "display" : "Other agents against leishmaniasis and trypanosomiasis"
          },
          {
            "code" : "P01CX01",
            "display" : "pentamidine isethionate"
          },
          {
            "code" : "P01CX02",
            "display" : "suramin sodium"
          },
          {
            "code" : "P01CX03",
            "display" : "eflornithine"
          },
          {
            "code" : "P01CX04",
            "display" : "miltefosine"
          },
          {
            "code" : "P02",
            "display" : "ANTHELMINTICS"
          },
          {
            "code" : "P02B",
            "display" : "ANTITREMATODALS"
          },
          {
            "code" : "P02BA",
            "display" : "Quinoline derivatives and related substances"
          },
          {
            "code" : "P02BA01",
            "display" : "praziquantel"
          },
          {
            "code" : "P02BA02",
            "display" : "oxamniquine"
          },
          {
            "code" : "P02BA03",
            "display" : "arpraziquantel"
          },
          {
            "code" : "P02BB",
            "display" : "Organophosphorous compounds"
          },
          {
            "code" : "P02BB01",
            "display" : "metrifonate"
          },
          {
            "code" : "P02BX",
            "display" : "Other antitrematodal agents"
          },
          {
            "code" : "P02BX01",
            "display" : "bithionol"
          },
          {
            "code" : "P02BX02",
            "display" : "niridazole"
          },
          {
            "code" : "P02BX03",
            "display" : "stibophen"
          },
          {
            "code" : "P02BX04",
            "display" : "triclabendazole"
          },
          {
            "code" : "P02C",
            "display" : "ANTINEMATODAL AGENTS"
          },
          {
            "code" : "P02CA",
            "display" : "Benzimidazole derivatives"
          },
          {
            "code" : "P02CA01",
            "display" : "mebendazole"
          },
          {
            "code" : "P02CA02",
            "display" : "tiabendazole"
          },
          {
            "code" : "P02CA03",
            "display" : "albendazole"
          },
          {
            "code" : "P02CA04",
            "display" : "ciclobendazole"
          },
          {
            "code" : "P02CA05",
            "display" : "flubendazole"
          },
          {
            "code" : "P02CA06",
            "display" : "fenbendazole"
          },
          {
            "code" : "P02CA51",
            "display" : "mebendazole, combinations"
          },
          {
            "code" : "P02CB",
            "display" : "Piperazine and derivatives"
          },
          {
            "code" : "P02CB01",
            "display" : "piperazine"
          },
          {
            "code" : "P02CB02",
            "display" : "diethylcarbamazine"
          },
          {
            "code" : "P02CC",
            "display" : "Tetrahydropyrimidine derivatives"
          },
          {
            "code" : "P02CC01",
            "display" : "pyrantel"
          },
          {
            "code" : "P02CC02",
            "display" : "oxantel"
          },
          {
            "code" : "P02CE",
            "display" : "Imidazothiazole derivatives"
          },
          {
            "code" : "P02CE01",
            "display" : "levamisole"
          },
          {
            "code" : "P02CF",
            "display" : "Avermectines"
          },
          {
            "code" : "P02CF01",
            "display" : "ivermectin"
          },
          {
            "code" : "P02CX",
            "display" : "Other antinematodals"
          },
          {
            "code" : "P02CX01",
            "display" : "pyrvinium"
          },
          {
            "code" : "P02CX02",
            "display" : "bephenium"
          },
          {
            "code" : "P02CX03",
            "display" : "moxidectin"
          },
          {
            "code" : "P02D",
            "display" : "ANTICESTODALS"
          },
          {
            "code" : "P02DA",
            "display" : "Salicylic acid derivatives"
          },
          {
            "code" : "P02DA01",
            "display" : "niclosamide"
          },
          {
            "code" : "P02DX",
            "display" : "Other anticestodals"
          },
          {
            "code" : "P02DX01",
            "display" : "desaspidin"
          },
          {
            "code" : "P02DX02",
            "display" : "dichlorophen"
          },
          {
            "code" : "P03",
            "display" : "ECTOPARASITICIDES, INCL. SCABICIDES, INSECTICIDES AND REPELLENTS"
          },
          {
            "code" : "P03A",
            "display" : "ECTOPARASITICIDES, INCL. SCABICIDES"
          },
          {
            "code" : "P03AA",
            "display" : "Sulfur containing products"
          },
          {
            "code" : "P03AA01",
            "display" : "dixanthogen"
          },
          {
            "code" : "P03AA02",
            "display" : "potassium polysulfide"
          },
          {
            "code" : "P03AA03",
            "display" : "mesulfen"
          },
          {
            "code" : "P03AA04",
            "display" : "disulfiram"
          },
          {
            "code" : "P03AA05",
            "display" : "thiram"
          },
          {
            "code" : "P03AA54",
            "display" : "disulfiram, combinations"
          },
          {
            "code" : "P03AB",
            "display" : "Chlorine containing products"
          },
          {
            "code" : "P03AB01",
            "display" : "clofenotane"
          },
          {
            "code" : "P03AB02",
            "display" : "lindane"
          },
          {
            "code" : "P03AB51",
            "display" : "clofenotane, combinations"
          },
          {
            "code" : "P03AC",
            "display" : "Pyrethrines, incl. synthetic compounds"
          },
          {
            "code" : "P03AC01",
            "display" : "pyrethrum"
          },
          {
            "code" : "P03AC02",
            "display" : "bioallethrin"
          },
          {
            "code" : "P03AC03",
            "display" : "phenothrin"
          },
          {
            "code" : "P03AC04",
            "display" : "permethrin"
          },
          {
            "code" : "P03AC51",
            "display" : "pyrethrum, combinations"
          },
          {
            "code" : "P03AC52",
            "display" : "bioallethrin, combinations"
          },
          {
            "code" : "P03AC53",
            "display" : "phenothrin, combinations"
          },
          {
            "code" : "P03AC54",
            "display" : "permethrin, combinations"
          },
          {
            "code" : "P03AX",
            "display" : "Other ectoparasiticides, incl. scabicides"
          },
          {
            "code" : "P03AX01",
            "display" : "benzyl benzoate"
          },
          {
            "code" : "P03AX02",
            "display" : "copper oleinate"
          },
          {
            "code" : "P03AX03",
            "display" : "malathion"
          },
          {
            "code" : "P03AX04",
            "display" : "quassia"
          },
          {
            "code" : "P03AX05",
            "display" : "dimeticone"
          },
          {
            "code" : "P03AX06",
            "display" : "benzyl alcohol"
          },
          {
            "code" : "P03AX07",
            "display" : "abametapir"
          },
          {
            "code" : "P03B",
            "display" : "INSECTICIDES AND REPELLENTS"
          },
          {
            "code" : "P03BA",
            "display" : "Pyrethrines"
          },
          {
            "code" : "P03BA01",
            "display" : "cyfluthrin"
          },
          {
            "code" : "P03BA02",
            "display" : "cypermethrin"
          },
          {
            "code" : "P03BA03",
            "display" : "decamethrin"
          },
          {
            "code" : "P03BA04",
            "display" : "tetramethrin"
          },
          {
            "code" : "P03BX",
            "display" : "Other insecticides and repellents"
          },
          {
            "code" : "P03BX01",
            "display" : "diethyltoluamide"
          },
          {
            "code" : "P03BX02",
            "display" : "dimethylphthalate"
          },
          {
            "code" : "P03BX03",
            "display" : "dibutylphthalate"
          },
          {
            "code" : "P03BX04",
            "display" : "dibutylsuccinate"
          },
          {
            "code" : "P03BX05",
            "display" : "dimethylcarbate"
          },
          {
            "code" : "P03BX06",
            "display" : "etohexadiol"
          },
          {
            "code" : "R",
            "display" : "RESPIRATORY SYSTEM"
          },
          {
            "code" : "R01",
            "display" : "NASAL PREPARATIONS"
          },
          {
            "code" : "R01A",
            "display" : "DECONGESTANTS AND OTHER NASAL PREPARATIONS FOR TOPICAL USE"
          },
          {
            "code" : "R01AA",
            "display" : "Sympathomimetics, plain"
          },
          {
            "code" : "R01AA02",
            "display" : "cyclopentamine"
          },
          {
            "code" : "R01AA03",
            "display" : "ephedrine"
          },
          {
            "code" : "R01AA04",
            "display" : "phenylephrine"
          },
          {
            "code" : "R01AA05",
            "display" : "oxymetazoline"
          },
          {
            "code" : "R01AA06",
            "display" : "tetryzoline"
          },
          {
            "code" : "R01AA07",
            "display" : "xylometazoline"
          },
          {
            "code" : "R01AA08",
            "display" : "naphazoline"
          },
          {
            "code" : "R01AA09",
            "display" : "tramazoline"
          },
          {
            "code" : "R01AA10",
            "display" : "metizoline"
          },
          {
            "code" : "R01AA11",
            "display" : "tuaminoheptane"
          },
          {
            "code" : "R01AA12",
            "display" : "fenoxazoline"
          },
          {
            "code" : "R01AA13",
            "display" : "tymazoline"
          },
          {
            "code" : "R01AA14",
            "display" : "epinephrine"
          },
          {
            "code" : "R01AA15",
            "display" : "indanazoline"
          },
          {
            "code" : "R01AB",
            "display" : "Sympathomimetics, combinations excl. corticosteroids"
          },
          {
            "code" : "R01AB01",
            "display" : "phenylephrine"
          },
          {
            "code" : "R01AB02",
            "display" : "naphazoline"
          },
          {
            "code" : "R01AB03",
            "display" : "tetryzoline"
          },
          {
            "code" : "R01AB05",
            "display" : "ephedrine"
          },
          {
            "code" : "R01AB06",
            "display" : "xylometazoline"
          },
          {
            "code" : "R01AB07",
            "display" : "oxymetazoline"
          },
          {
            "code" : "R01AB08",
            "display" : "tuaminoheptane"
          },
          {
            "code" : "R01AC",
            "display" : "Antiallergic agents, excl. corticosteroids"
          },
          {
            "code" : "R01AC01",
            "display" : "cromoglicic acid"
          },
          {
            "code" : "R01AC02",
            "display" : "levocabastine"
          },
          {
            "code" : "R01AC03",
            "display" : "azelastine"
          },
          {
            "code" : "R01AC04",
            "display" : "antazoline"
          },
          {
            "code" : "R01AC05",
            "display" : "spaglumic acid"
          },
          {
            "code" : "R01AC06",
            "display" : "thonzylamine"
          },
          {
            "code" : "R01AC07",
            "display" : "nedocromil"
          },
          {
            "code" : "R01AC08",
            "display" : "olopatadine"
          },
          {
            "code" : "R01AC51",
            "display" : "cromoglicic acid, combinations"
          },
          {
            "code" : "R01AD",
            "display" : "Corticosteroids"
          },
          {
            "code" : "R01AD01",
            "display" : "beclometasone"
          },
          {
            "code" : "R01AD02",
            "display" : "prednisolone"
          },
          {
            "code" : "R01AD03",
            "display" : "dexamethasone"
          },
          {
            "code" : "R01AD04",
            "display" : "flunisolide"
          },
          {
            "code" : "R01AD05",
            "display" : "budesonide"
          },
          {
            "code" : "R01AD06",
            "display" : "betamethasone"
          },
          {
            "code" : "R01AD07",
            "display" : "tixocortol"
          },
          {
            "code" : "R01AD08",
            "display" : "fluticasone"
          },
          {
            "code" : "R01AD09",
            "display" : "mometasone"
          },
          {
            "code" : "R01AD11",
            "display" : "triamcinolone"
          },
          {
            "code" : "R01AD12",
            "display" : "fluticasone furoate"
          },
          {
            "code" : "R01AD13",
            "display" : "ciclesonide"
          },
          {
            "code" : "R01AD52",
            "display" : "prednisolone, combinations"
          },
          {
            "code" : "R01AD53",
            "display" : "dexamethasone, combinations"
          },
          {
            "code" : "R01AD57",
            "display" : "tixocortol, combinations"
          },
          {
            "code" : "R01AD58",
            "display" : "fluticasone, combinations"
          },
          {
            "code" : "R01AD59",
            "display" : "mometasone, combinations"
          },
          {
            "code" : "R01AD60",
            "display" : "hydrocortisone, combinations"
          },
          {
            "code" : "R01AX",
            "display" : "Other nasal preparations"
          },
          {
            "code" : "R01AX01",
            "display" : "calcium hexamine thiocyanate"
          },
          {
            "code" : "R01AX02",
            "display" : "retinol"
          },
          {
            "code" : "R01AX03",
            "display" : "ipratropium bromide"
          },
          {
            "code" : "R01AX05",
            "display" : "ritiometan"
          },
          {
            "code" : "R01AX06",
            "display" : "mupirocin"
          },
          {
            "code" : "R01AX07",
            "display" : "hexamidine"
          },
          {
            "code" : "R01AX08",
            "display" : "framycetin"
          },
          {
            "code" : "R01AX09",
            "display" : "hyaluronic acid"
          },
          {
            "code" : "R01AX10",
            "display" : "various"
          },
          {
            "code" : "R01AX30",
            "display" : "combinations"
          },
          {
            "code" : "R01B",
            "display" : "NASAL DECONGESTANTS FOR SYSTEMIC USE"
          },
          {
            "code" : "R01BA",
            "display" : "Sympathomimetics"
          },
          {
            "code" : "R01BA01",
            "display" : "phenylpropanolamine"
          },
          {
            "code" : "R01BA02",
            "display" : "pseudoephedrine"
          },
          {
            "code" : "R01BA03",
            "display" : "phenylephrine"
          },
          {
            "code" : "R01BA51",
            "display" : "phenylpropanolamine, combinations"
          },
          {
            "code" : "R01BA52",
            "display" : "pseudoephedrine, combinations"
          },
          {
            "code" : "R01BA53",
            "display" : "phenylephrine, combinations"
          },
          {
            "code" : "R02",
            "display" : "THROAT PREPARATIONS"
          },
          {
            "code" : "R02A",
            "display" : "THROAT PREPARATIONS"
          },
          {
            "code" : "R02AA",
            "display" : "Antiseptics"
          },
          {
            "code" : "R02AA01",
            "display" : "ambazone"
          },
          {
            "code" : "R02AA02",
            "display" : "dequalinium"
          },
          {
            "code" : "R02AA03",
            "display" : "dichlorobenzyl alcohol"
          },
          {
            "code" : "R02AA05",
            "display" : "chlorhexidine"
          },
          {
            "code" : "R02AA06",
            "display" : "cetylpyridinium"
          },
          {
            "code" : "R02AA09",
            "display" : "benzethonium"
          },
          {
            "code" : "R02AA10",
            "display" : "myristyl-benzalkonium"
          },
          {
            "code" : "R02AA11",
            "display" : "chlorquinaldol"
          },
          {
            "code" : "R02AA12",
            "display" : "hexylresorcinol"
          },
          {
            "code" : "R02AA13",
            "display" : "acriflavinium chloride"
          },
          {
            "code" : "R02AA14",
            "display" : "oxyquinoline"
          },
          {
            "code" : "R02AA15",
            "display" : "povidone-iodine"
          },
          {
            "code" : "R02AA16",
            "display" : "benzalkonium"
          },
          {
            "code" : "R02AA17",
            "display" : "cetrimonium"
          },
          {
            "code" : "R02AA18",
            "display" : "hexamidine"
          },
          {
            "code" : "R02AA19",
            "display" : "phenol"
          },
          {
            "code" : "R02AA20",
            "display" : "various"
          },
          {
            "code" : "R02AA21",
            "display" : "octenidine"
          },
          {
            "code" : "R02AB",
            "display" : "Antibiotics"
          },
          {
            "code" : "R02AB01",
            "display" : "neomycin"
          },
          {
            "code" : "R02AB02",
            "display" : "tyrothricin"
          },
          {
            "code" : "R02AB03",
            "display" : "fusafungine"
          },
          {
            "code" : "R02AB04",
            "display" : "bacitracin"
          },
          {
            "code" : "R02AB30",
            "display" : "gramicidin"
          },
          {
            "code" : "R02AD",
            "display" : "Anesthetics, local"
          },
          {
            "code" : "R02AD01",
            "display" : "benzocaine"
          },
          {
            "code" : "R02AD02",
            "display" : "lidocaine"
          },
          {
            "code" : "R02AD03",
            "display" : "cocaine"
          },
          {
            "code" : "R02AD04",
            "display" : "dyclonine"
          },
          {
            "code" : "R02AD05",
            "display" : "ambroxol"
          },
          {
            "code" : "R02AX",
            "display" : "Other throat preparations"
          },
          {
            "code" : "R02AX01",
            "display" : "flurbiprofen"
          },
          {
            "code" : "R02AX02",
            "display" : "ibuprofen"
          },
          {
            "code" : "R02AX03",
            "display" : "benzydamine"
          },
          {
            "code" : "R03",
            "display" : "DRUGS FOR OBSTRUCTIVE AIRWAY DISEASES"
          },
          {
            "code" : "R03A",
            "display" : "ADRENERGICS, INHALANTS"
          },
          {
            "code" : "R03AA",
            "display" : "Alpha- and beta-adrenoreceptor agonists"
          },
          {
            "code" : "R03AA01",
            "display" : "epinephrine"
          },
          {
            "code" : "R03AB",
            "display" : "Non-selective beta-adrenoreceptor agonists"
          },
          {
            "code" : "R03AB02",
            "display" : "isoprenaline"
          },
          {
            "code" : "R03AB03",
            "display" : "orciprenaline"
          },
          {
            "code" : "R03AC",
            "display" : "Selective beta-2-adrenoreceptor agonists"
          },
          {
            "code" : "R03AC02",
            "display" : "salbutamol"
          },
          {
            "code" : "R03AC03",
            "display" : "terbutaline"
          },
          {
            "code" : "R03AC04",
            "display" : "fenoterol"
          },
          {
            "code" : "R03AC05",
            "display" : "rimiterol"
          },
          {
            "code" : "R03AC06",
            "display" : "hexoprenaline"
          },
          {
            "code" : "R03AC07",
            "display" : "isoetarine"
          },
          {
            "code" : "R03AC08",
            "display" : "pirbuterol"
          },
          {
            "code" : "R03AC09",
            "display" : "tretoquinol"
          },
          {
            "code" : "R03AC10",
            "display" : "carbuterol"
          },
          {
            "code" : "R03AC11",
            "display" : "tulobuterol"
          },
          {
            "code" : "R03AC12",
            "display" : "salmeterol"
          },
          {
            "code" : "R03AC13",
            "display" : "formoterol"
          },
          {
            "code" : "R03AC14",
            "display" : "clenbuterol"
          },
          {
            "code" : "R03AC15",
            "display" : "reproterol"
          },
          {
            "code" : "R03AC16",
            "display" : "procaterol"
          },
          {
            "code" : "R03AC17",
            "display" : "bitolterol"
          },
          {
            "code" : "R03AC18",
            "display" : "indacaterol"
          },
          {
            "code" : "R03AC19",
            "display" : "olodaterol"
          },
          {
            "code" : "R03AH",
            "display" : "Combinations of adrenergics"
          },
          {
            "code" : "R03AK",
            "display" : "Adrenergics in combination with corticosteroids or other drugs, excl. anticholinergics"
          },
          {
            "code" : "R03AK01",
            "display" : "epinephrine and other drugs for obstructive airway diseases"
          },
          {
            "code" : "R03AK02",
            "display" : "isoprenaline and other drugs for obstructive airway diseases"
          },
          {
            "code" : "R03AK04",
            "display" : "salbutamol and sodium cromoglicate"
          },
          {
            "code" : "R03AK05",
            "display" : "reproterol and sodium cromoglicate"
          },
          {
            "code" : "R03AK06",
            "display" : "salmeterol and fluticasone"
          },
          {
            "code" : "R03AK07",
            "display" : "formoterol and budesonide"
          },
          {
            "code" : "R03AK08",
            "display" : "formoterol and beclometasone"
          },
          {
            "code" : "R03AK09",
            "display" : "formoterol and mometasone"
          },
          {
            "code" : "R03AK10",
            "display" : "vilanterol and fluticasone furoate"
          },
          {
            "code" : "R03AK11",
            "display" : "formoterol and fluticasone"
          },
          {
            "code" : "R03AK12",
            "display" : "salmeterol and budesonide"
          },
          {
            "code" : "R03AK13",
            "display" : "salbutamol and beclometasone"
          },
          {
            "code" : "R03AK14",
            "display" : "indacaterol and mometasone"
          },
          {
            "code" : "R03AK15",
            "display" : "salbutamol and budesonide"
          },
          {
            "code" : "R03AL",
            "display" : "Adrenergics in combination with anticholinergics incl. triple combinations with corticosteroids"
          },
          {
            "code" : "R03AL01",
            "display" : "fenoterol and ipratropium bromide"
          },
          {
            "code" : "R03AL02",
            "display" : "salbutamol and ipratropium bromide"
          },
          {
            "code" : "R03AL03",
            "display" : "vilanterol and umeclidinium bromide"
          },
          {
            "code" : "R03AL04",
            "display" : "indacaterol and glycopyrronium bromide"
          },
          {
            "code" : "R03AL05",
            "display" : "formoterol and aclidinium bromide"
          },
          {
            "code" : "R03AL06",
            "display" : "olodaterol and tiotropium bromide"
          },
          {
            "code" : "R03AL07",
            "display" : "formoterol and glycopyrronium bromide"
          },
          {
            "code" : "R03AL08",
            "display" : "vilanterol, umeclidinium bromide and fluticasone furoate"
          },
          {
            "code" : "R03AL09",
            "display" : "formoterol, glycopyrronium bromide and beclometasone"
          },
          {
            "code" : "R03AL10",
            "display" : "formoterol and tiotropium bromide"
          },
          {
            "code" : "R03AL11",
            "display" : "formoterol, glycopyrronium bromide and budesonide"
          },
          {
            "code" : "R03AL12",
            "display" : "indacaterol, glycopyrronium bromide and mometasone"
          },
          {
            "code" : "R03B",
            "display" : "OTHER DRUGS FOR OBSTRUCTIVE AIRWAY DISEASES, INHALANTS"
          },
          {
            "code" : "R03BA",
            "display" : "Glucocorticoids"
          },
          {
            "code" : "R03BA01",
            "display" : "beclometasone"
          },
          {
            "code" : "R03BA02",
            "display" : "budesonide"
          },
          {
            "code" : "R03BA03",
            "display" : "flunisolide"
          },
          {
            "code" : "R03BA04",
            "display" : "betamethasone"
          },
          {
            "code" : "R03BA05",
            "display" : "fluticasone"
          },
          {
            "code" : "R03BA06",
            "display" : "triamcinolone"
          },
          {
            "code" : "R03BA07",
            "display" : "mometasone"
          },
          {
            "code" : "R03BA08",
            "display" : "ciclesonide"
          },
          {
            "code" : "R03BA09",
            "display" : "fluticasone furoate"
          },
          {
            "code" : "R03BB",
            "display" : "Anticholinergics"
          },
          {
            "code" : "R03BB01",
            "display" : "ipratropium bromide"
          },
          {
            "code" : "R03BB02",
            "display" : "oxitropium bromide"
          },
          {
            "code" : "R03BB03",
            "display" : "stramoni preparations"
          },
          {
            "code" : "R03BB04",
            "display" : "tiotropium bromide"
          },
          {
            "code" : "R03BB05",
            "display" : "aclidinium bromide"
          },
          {
            "code" : "R03BB06",
            "display" : "glycopyrronium bromide"
          },
          {
            "code" : "R03BB07",
            "display" : "umeclidinium bromide"
          },
          {
            "code" : "R03BB08",
            "display" : "revefenacin"
          },
          {
            "code" : "R03BB54",
            "display" : "tiotropium bromide, combinations"
          },
          {
            "code" : "R03BC",
            "display" : "Antiallergic agents, excl. corticosteroids"
          },
          {
            "code" : "R03BC01",
            "display" : "cromoglicic acid"
          },
          {
            "code" : "R03BC03",
            "display" : "nedocromil"
          },
          {
            "code" : "R03BX",
            "display" : "Other drugs for obstructive airway diseases, inhalants"
          },
          {
            "code" : "R03BX01",
            "display" : "fenspiride"
          },
          {
            "code" : "R03C",
            "display" : "ADRENERGICS FOR SYSTEMIC USE"
          },
          {
            "code" : "R03CA",
            "display" : "Alpha- and beta-adrenoreceptor agonists"
          },
          {
            "code" : "R03CA02",
            "display" : "ephedrine"
          },
          {
            "code" : "R03CB",
            "display" : "Non-selective beta-adrenoreceptor agonists"
          },
          {
            "code" : "R03CB01",
            "display" : "isoprenaline"
          },
          {
            "code" : "R03CB02",
            "display" : "methoxyphenamine"
          },
          {
            "code" : "R03CB03",
            "display" : "orciprenaline"
          },
          {
            "code" : "R03CB51",
            "display" : "isoprenaline, combinations"
          },
          {
            "code" : "R03CB53",
            "display" : "orciprenaline, combinations"
          },
          {
            "code" : "R03CC",
            "display" : "Selective beta-2-adrenoreceptor agonists"
          },
          {
            "code" : "R03CC02",
            "display" : "salbutamol"
          },
          {
            "code" : "R03CC03",
            "display" : "terbutaline"
          },
          {
            "code" : "R03CC04",
            "display" : "fenoterol"
          },
          {
            "code" : "R03CC05",
            "display" : "hexoprenaline"
          },
          {
            "code" : "R03CC06",
            "display" : "isoetarine"
          },
          {
            "code" : "R03CC07",
            "display" : "pirbuterol"
          },
          {
            "code" : "R03CC08",
            "display" : "procaterol"
          },
          {
            "code" : "R03CC09",
            "display" : "tretoquinol"
          },
          {
            "code" : "R03CC10",
            "display" : "carbuterol"
          },
          {
            "code" : "R03CC11",
            "display" : "tulobuterol"
          },
          {
            "code" : "R03CC12",
            "display" : "bambuterol"
          },
          {
            "code" : "R03CC13",
            "display" : "clenbuterol"
          },
          {
            "code" : "R03CC14",
            "display" : "reproterol"
          },
          {
            "code" : "R03CC15",
            "display" : "formoterol"
          },
          {
            "code" : "R03CC53",
            "display" : "terbutaline, combinations"
          },
          {
            "code" : "R03CC63",
            "display" : "clenbuterol and ambroxol"
          },
          {
            "code" : "R03CK",
            "display" : "Adrenergics and other drugs for obstructive airway diseases"
          },
          {
            "code" : "R03D",
            "display" : "OTHER SYSTEMIC DRUGS FOR OBSTRUCTIVE AIRWAY DISEASES"
          },
          {
            "code" : "R03DA",
            "display" : "Xanthines"
          },
          {
            "code" : "R03DA01",
            "display" : "diprophylline"
          },
          {
            "code" : "R03DA02",
            "display" : "choline theophyllinate"
          },
          {
            "code" : "R03DA03",
            "display" : "proxyphylline"
          },
          {
            "code" : "R03DA04",
            "display" : "theophylline"
          },
          {
            "code" : "R03DA05",
            "display" : "aminophylline"
          },
          {
            "code" : "R03DA06",
            "display" : "etamiphylline"
          },
          {
            "code" : "R03DA07",
            "display" : "theobromine"
          },
          {
            "code" : "R03DA08",
            "display" : "bamifylline"
          },
          {
            "code" : "R03DA09",
            "display" : "acefylline piperazine"
          },
          {
            "code" : "R03DA10",
            "display" : "bufylline"
          },
          {
            "code" : "R03DA11",
            "display" : "doxofylline"
          },
          {
            "code" : "R03DA12",
            "display" : "mepyramine theophyllinacetate"
          },
          {
            "code" : "R03DA20",
            "display" : "combinations of xanthines"
          },
          {
            "code" : "R03DA51",
            "display" : "diprophylline, combinations"
          },
          {
            "code" : "R03DA54",
            "display" : "theophylline, combinations excl. psycholeptics"
          },
          {
            "code" : "R03DA55",
            "display" : "aminophylline, combinations"
          },
          {
            "code" : "R03DA57",
            "display" : "theobromine, combinations"
          },
          {
            "code" : "R03DA74",
            "display" : "theophylline, combinations with psycholeptics"
          },
          {
            "code" : "R03DB",
            "display" : "Xanthines and adrenergics"
          },
          {
            "code" : "R03DB01",
            "display" : "diprophylline and adrenergics"
          },
          {
            "code" : "R03DB02",
            "display" : "choline theophyllinate and adrenergics"
          },
          {
            "code" : "R03DB03",
            "display" : "proxyphylline and adrenergics"
          },
          {
            "code" : "R03DB04",
            "display" : "theophylline and adrenergics"
          },
          {
            "code" : "R03DB05",
            "display" : "aminophylline and adrenergics"
          },
          {
            "code" : "R03DB06",
            "display" : "etamiphylline and adrenergics"
          },
          {
            "code" : "R03DC",
            "display" : "Leukotriene receptor antagonists"
          },
          {
            "code" : "R03DC01",
            "display" : "zafirlukast"
          },
          {
            "code" : "R03DC02",
            "display" : "pranlukast"
          },
          {
            "code" : "R03DC03",
            "display" : "montelukast"
          },
          {
            "code" : "R03DC04",
            "display" : "ibudilast"
          },
          {
            "code" : "R03DC53",
            "display" : "montelukast, combinations"
          },
          {
            "code" : "R03DX",
            "display" : "Other systemic drugs for obstructive airway diseases"
          },
          {
            "code" : "R03DX01",
            "display" : "amlexanox"
          },
          {
            "code" : "R03DX02",
            "display" : "eprozinol"
          },
          {
            "code" : "R03DX03",
            "display" : "fenspiride"
          },
          {
            "code" : "R03DX05",
            "display" : "omalizumab"
          },
          {
            "code" : "R03DX06",
            "display" : "seratrodast"
          },
          {
            "code" : "R03DX07",
            "display" : "roflumilast"
          },
          {
            "code" : "R03DX08",
            "display" : "reslizumab"
          },
          {
            "code" : "R03DX09",
            "display" : "mepolizumab"
          },
          {
            "code" : "R03DX10",
            "display" : "benralizumab"
          },
          {
            "code" : "R03DX11",
            "display" : "tezepelumab"
          },
          {
            "code" : "R05",
            "display" : "COUGH AND COLD PREPARATIONS"
          },
          {
            "code" : "R05C",
            "display" : "EXPECTORANTS, EXCL. COMBINATIONS WITH COUGH SUPPRESSANTS"
          },
          {
            "code" : "R05CA",
            "display" : "Expectorants"
          },
          {
            "code" : "R05CA01",
            "display" : "tyloxapol"
          },
          {
            "code" : "R05CA02",
            "display" : "potassium iodide"
          },
          {
            "code" : "R05CA03",
            "display" : "guaifenesin"
          },
          {
            "code" : "R05CA04",
            "display" : "ipecacuanha"
          },
          {
            "code" : "R05CA05",
            "display" : "altheae radix"
          },
          {
            "code" : "R05CA06",
            "display" : "senega"
          },
          {
            "code" : "R05CA07",
            "display" : "antimony pentasulfide"
          },
          {
            "code" : "R05CA08",
            "display" : "creosote"
          },
          {
            "code" : "R05CA09",
            "display" : "guaiacolsulfonate"
          },
          {
            "code" : "R05CA10",
            "display" : "combinations"
          },
          {
            "code" : "R05CA11",
            "display" : "levoverbenone"
          },
          {
            "code" : "R05CA12",
            "display" : "Hederae helicis folium"
          },
          {
            "code" : "R05CA13",
            "display" : "cineole"
          },
          {
            "code" : "R05CB",
            "display" : "Mucolytics"
          },
          {
            "code" : "R05CB01",
            "display" : "acetylcysteine"
          },
          {
            "code" : "R05CB02",
            "display" : "bromhexine"
          },
          {
            "code" : "R05CB03",
            "display" : "carbocisteine"
          },
          {
            "code" : "R05CB04",
            "display" : "eprazinone"
          },
          {
            "code" : "R05CB05",
            "display" : "mesna"
          },
          {
            "code" : "R05CB06",
            "display" : "ambroxol"
          },
          {
            "code" : "R05CB07",
            "display" : "sobrerol"
          },
          {
            "code" : "R05CB08",
            "display" : "domiodol"
          },
          {
            "code" : "R05CB09",
            "display" : "letosteine"
          },
          {
            "code" : "R05CB10",
            "display" : "combinations"
          },
          {
            "code" : "R05CB11",
            "display" : "stepronin"
          },
          {
            "code" : "R05CB13",
            "display" : "dornase alfa (desoxyribonuclease)"
          },
          {
            "code" : "R05CB14",
            "display" : "neltenexine"
          },
          {
            "code" : "R05CB15",
            "display" : "erdosteine"
          },
          {
            "code" : "R05CB16",
            "display" : "mannitol"
          },
          {
            "code" : "R05D",
            "display" : "COUGH SUPPRESSANTS, EXCL. COMBINATIONS WITH EXPECTORANTS"
          },
          {
            "code" : "R05DA",
            "display" : "Opium alkaloids and derivatives"
          },
          {
            "code" : "R05DA01",
            "display" : "ethylmorphine"
          },
          {
            "code" : "R05DA03",
            "display" : "hydrocodone"
          },
          {
            "code" : "R05DA04",
            "display" : "codeine"
          },
          {
            "code" : "R05DA05",
            "display" : "opium alkaloids with morphine"
          },
          {
            "code" : "R05DA06",
            "display" : "normethadone"
          },
          {
            "code" : "R05DA07",
            "display" : "noscapine"
          },
          {
            "code" : "R05DA08",
            "display" : "pholcodine"
          },
          {
            "code" : "R05DA09",
            "display" : "dextromethorphan"
          },
          {
            "code" : "R05DA10",
            "display" : "thebacon"
          },
          {
            "code" : "R05DA11",
            "display" : "dimemorfan"
          },
          {
            "code" : "R05DA12",
            "display" : "acetyldihydrocodeine"
          },
          {
            "code" : "R05DA20",
            "display" : "combinations"
          },
          {
            "code" : "R05DB",
            "display" : "Other cough suppressants"
          },
          {
            "code" : "R05DB01",
            "display" : "benzonatate"
          },
          {
            "code" : "R05DB02",
            "display" : "benproperine"
          },
          {
            "code" : "R05DB03",
            "display" : "clobutinol"
          },
          {
            "code" : "R05DB04",
            "display" : "isoaminile"
          },
          {
            "code" : "R05DB05",
            "display" : "pentoxyverine"
          },
          {
            "code" : "R05DB07",
            "display" : "oxolamine"
          },
          {
            "code" : "R05DB09",
            "display" : "oxeladin"
          },
          {
            "code" : "R05DB10",
            "display" : "clofedanol"
          },
          {
            "code" : "R05DB11",
            "display" : "pipazetate"
          },
          {
            "code" : "R05DB12",
            "display" : "bibenzonium bromide"
          },
          {
            "code" : "R05DB13",
            "display" : "butamirate"
          },
          {
            "code" : "R05DB14",
            "display" : "fedrilate"
          },
          {
            "code" : "R05DB15",
            "display" : "zipeprol"
          },
          {
            "code" : "R05DB16",
            "display" : "dibunate"
          },
          {
            "code" : "R05DB17",
            "display" : "droxypropine"
          },
          {
            "code" : "R05DB18",
            "display" : "prenoxdiazine"
          },
          {
            "code" : "R05DB19",
            "display" : "dropropizine"
          },
          {
            "code" : "R05DB20",
            "display" : "combinations"
          },
          {
            "code" : "R05DB21",
            "display" : "cloperastine"
          },
          {
            "code" : "R05DB22",
            "display" : "meprotixol"
          },
          {
            "code" : "R05DB23",
            "display" : "piperidione"
          },
          {
            "code" : "R05DB24",
            "display" : "tipepidine"
          },
          {
            "code" : "R05DB25",
            "display" : "morclofone"
          },
          {
            "code" : "R05DB26",
            "display" : "nepinalone"
          },
          {
            "code" : "R05DB27",
            "display" : "levodropropizine"
          },
          {
            "code" : "R05DB28",
            "display" : "dimethoxanate"
          },
          {
            "code" : "R05DB29",
            "display" : "gefapixant"
          },
          {
            "code" : "R05F",
            "display" : "COUGH SUPPRESSANTS AND EXPECTORANTS, COMBINATIONS"
          },
          {
            "code" : "R05FA",
            "display" : "Opium derivatives and expectorants"
          },
          {
            "code" : "R05FA01",
            "display" : "opium derivatives and mucolytics"
          },
          {
            "code" : "R05FA02",
            "display" : "opium derivatives and expectorants"
          },
          {
            "code" : "R05FB",
            "display" : "Other cough suppressants and expectorants"
          },
          {
            "code" : "R05FB01",
            "display" : "cough suppressants and mucolytics"
          },
          {
            "code" : "R05FB02",
            "display" : "cough suppressants and expectorants"
          },
          {
            "code" : "R05X",
            "display" : "OTHER COLD PREPARATIONS"
          },
          {
            "code" : "R06",
            "display" : "ANTIHISTAMINES FOR SYSTEMIC USE"
          },
          {
            "code" : "R06A",
            "display" : "ANTIHISTAMINES FOR SYSTEMIC USE"
          },
          {
            "code" : "R06AA",
            "display" : "Aminoalkyl ethers"
          },
          {
            "code" : "R06AA01",
            "display" : "bromazine"
          },
          {
            "code" : "R06AA02",
            "display" : "diphenhydramine"
          },
          {
            "code" : "R06AA04",
            "display" : "clemastine"
          },
          {
            "code" : "R06AA06",
            "display" : "chlorphenoxamine"
          },
          {
            "code" : "R06AA07",
            "display" : "diphenylpyraline"
          },
          {
            "code" : "R06AA08",
            "display" : "carbinoxamine"
          },
          {
            "code" : "R06AA09",
            "display" : "doxylamine"
          },
          {
            "code" : "R06AA10",
            "display" : "trimethobenzamide"
          },
          {
            "code" : "R06AA11",
            "display" : "dimenhydrinate"
          },
          {
            "code" : "R06AA52",
            "display" : "diphenhydramine, combinations"
          },
          {
            "code" : "R06AA54",
            "display" : "clemastine, combinations"
          },
          {
            "code" : "R06AA56",
            "display" : "chlorphenoxamine, combinations"
          },
          {
            "code" : "R06AA57",
            "display" : "diphenylpyraline, combinations"
          },
          {
            "code" : "R06AA59",
            "display" : "doxylamine, combinations"
          },
          {
            "code" : "R06AA61",
            "display" : "dimenhydrinate, combinations"
          },
          {
            "code" : "R06AB",
            "display" : "Substituted alkylamines"
          },
          {
            "code" : "R06AB01",
            "display" : "brompheniramine"
          },
          {
            "code" : "R06AB02",
            "display" : "dexchlorpheniramine"
          },
          {
            "code" : "R06AB03",
            "display" : "dimetindene"
          },
          {
            "code" : "R06AB04",
            "display" : "chlorphenamine"
          },
          {
            "code" : "R06AB05",
            "display" : "pheniramine"
          },
          {
            "code" : "R06AB06",
            "display" : "dexbrompheniramine"
          },
          {
            "code" : "R06AB07",
            "display" : "talastine"
          },
          {
            "code" : "R06AB51",
            "display" : "brompheniramine, combinations"
          },
          {
            "code" : "R06AB52",
            "display" : "dexchlorpheniramine, combinations"
          },
          {
            "code" : "R06AB54",
            "display" : "chlorphenamine, combinations"
          },
          {
            "code" : "R06AB56",
            "display" : "dexbrompheniramine, combinations"
          },
          {
            "code" : "R06AC",
            "display" : "Substituted ethylene diamines"
          },
          {
            "code" : "R06AC01",
            "display" : "mepyramine"
          },
          {
            "code" : "R06AC02",
            "display" : "histapyrrodine"
          },
          {
            "code" : "R06AC03",
            "display" : "chloropyramine"
          },
          {
            "code" : "R06AC04",
            "display" : "tripelennamine"
          },
          {
            "code" : "R06AC05",
            "display" : "methapyrilene"
          },
          {
            "code" : "R06AC06",
            "display" : "thonzylamine"
          },
          {
            "code" : "R06AC52",
            "display" : "histapyrrodine, combinations"
          },
          {
            "code" : "R06AC53",
            "display" : "chloropyramine, combinations"
          },
          {
            "code" : "R06AD",
            "display" : "Phenothiazine derivatives"
          },
          {
            "code" : "R06AD01",
            "display" : "alimemazine"
          },
          {
            "code" : "R06AD02",
            "display" : "promethazine"
          },
          {
            "code" : "R06AD03",
            "display" : "thiethylperazine"
          },
          {
            "code" : "R06AD04",
            "display" : "methdilazine"
          },
          {
            "code" : "R06AD05",
            "display" : "hydroxyethylpromethazine"
          },
          {
            "code" : "R06AD06",
            "display" : "thiazinam"
          },
          {
            "code" : "R06AD07",
            "display" : "mequitazine"
          },
          {
            "code" : "R06AD08",
            "display" : "oxomemazine"
          },
          {
            "code" : "R06AD09",
            "display" : "isothipendyl"
          },
          {
            "code" : "R06AD52",
            "display" : "promethazine, combinations"
          },
          {
            "code" : "R06AD55",
            "display" : "hydroxyethylpromethazine, combinations"
          },
          {
            "code" : "R06AE",
            "display" : "Piperazine derivatives"
          },
          {
            "code" : "R06AE01",
            "display" : "buclizine"
          },
          {
            "code" : "R06AE03",
            "display" : "cyclizine"
          },
          {
            "code" : "R06AE04",
            "display" : "chlorcyclizine"
          },
          {
            "code" : "R06AE05",
            "display" : "meclozine"
          },
          {
            "code" : "R06AE06",
            "display" : "oxatomide"
          },
          {
            "code" : "R06AE07",
            "display" : "cetirizine"
          },
          {
            "code" : "R06AE09",
            "display" : "levocetirizine"
          },
          {
            "code" : "R06AE51",
            "display" : "buclizine, combinations"
          },
          {
            "code" : "R06AE53",
            "display" : "cyclizine, combinations"
          },
          {
            "code" : "R06AE55",
            "display" : "meclozine, combinations"
          },
          {
            "code" : "R06AK",
            "display" : "Combinations of antihistamines"
          },
          {
            "code" : "R06AX",
            "display" : "Other antihistamines for systemic use"
          },
          {
            "code" : "R06AX01",
            "display" : "bamipine"
          },
          {
            "code" : "R06AX02",
            "display" : "cyproheptadine"
          },
          {
            "code" : "R06AX03",
            "display" : "thenalidine"
          },
          {
            "code" : "R06AX04",
            "display" : "phenindamine"
          },
          {
            "code" : "R06AX05",
            "display" : "antazoline"
          },
          {
            "code" : "R06AX07",
            "display" : "triprolidine"
          },
          {
            "code" : "R06AX08",
            "display" : "pyrrobutamine"
          },
          {
            "code" : "R06AX09",
            "display" : "azatadine"
          },
          {
            "code" : "R06AX11",
            "display" : "astemizole"
          },
          {
            "code" : "R06AX12",
            "display" : "terfenadine"
          },
          {
            "code" : "R06AX13",
            "display" : "loratadine"
          },
          {
            "code" : "R06AX15",
            "display" : "mebhydrolin"
          },
          {
            "code" : "R06AX16",
            "display" : "deptropine"
          },
          {
            "code" : "R06AX17",
            "display" : "ketotifen"
          },
          {
            "code" : "R06AX18",
            "display" : "acrivastine"
          },
          {
            "code" : "R06AX19",
            "display" : "azelastine"
          },
          {
            "code" : "R06AX21",
            "display" : "tritoqualine"
          },
          {
            "code" : "R06AX22",
            "display" : "ebastine"
          },
          {
            "code" : "R06AX23",
            "display" : "pimethixene"
          },
          {
            "code" : "R06AX24",
            "display" : "epinastine"
          },
          {
            "code" : "R06AX25",
            "display" : "mizolastine"
          },
          {
            "code" : "R06AX26",
            "display" : "fexofenadine"
          },
          {
            "code" : "R06AX27",
            "display" : "desloratadine"
          },
          {
            "code" : "R06AX28",
            "display" : "rupatadine"
          },
          {
            "code" : "R06AX29",
            "display" : "bilastine"
          },
          {
            "code" : "R06AX31",
            "display" : "quifenadine"
          },
          {
            "code" : "R06AX32",
            "display" : "sequifenadine"
          },
          {
            "code" : "R06AX53",
            "display" : "thenalidine, combinations"
          },
          {
            "code" : "R06AX58",
            "display" : "pyrrobutamine, combinations"
          },
          {
            "code" : "R07",
            "display" : "OTHER RESPIRATORY SYSTEM PRODUCTS"
          },
          {
            "code" : "R07A",
            "display" : "OTHER RESPIRATORY SYSTEM PRODUCTS"
          },
          {
            "code" : "R07AA",
            "display" : "Lung surfactants"
          },
          {
            "code" : "R07AA01",
            "display" : "colfosceril palmitate"
          },
          {
            "code" : "R07AA02",
            "display" : "natural phospholipids"
          },
          {
            "code" : "R07AA30",
            "display" : "combinations"
          },
          {
            "code" : "R07AB",
            "display" : "Respiratory stimulants"
          },
          {
            "code" : "R07AB01",
            "display" : "doxapram"
          },
          {
            "code" : "R07AB02",
            "display" : "nikethamide"
          },
          {
            "code" : "R07AB03",
            "display" : "pentetrazol"
          },
          {
            "code" : "R07AB04",
            "display" : "etamivan"
          },
          {
            "code" : "R07AB05",
            "display" : "bemegride"
          },
          {
            "code" : "R07AB06",
            "display" : "prethcamide"
          },
          {
            "code" : "R07AB07",
            "display" : "almitrine"
          },
          {
            "code" : "R07AB08",
            "display" : "dimefline"
          },
          {
            "code" : "R07AB09",
            "display" : "mepixanox"
          },
          {
            "code" : "R07AB52",
            "display" : "nikethamide, combinations"
          },
          {
            "code" : "R07AB53",
            "display" : "pentetrazol, combinations"
          },
          {
            "code" : "R07AX",
            "display" : "Other respiratory system products"
          },
          {
            "code" : "R07AX01",
            "display" : "nitric oxide"
          },
          {
            "code" : "R07AX02",
            "display" : "ivacaftor"
          },
          {
            "code" : "R07AX30",
            "display" : "ivacaftor and lumacaftor"
          },
          {
            "code" : "R07AX31",
            "display" : "ivacaftor and tezacaftor"
          },
          {
            "code" : "R07AX32",
            "display" : "ivacaftor, tezacaftor and elexacaftor"
          },
          {
            "code" : "R07AX33",
            "display" : "deutivacaftor, tezacaftor and vanzacaftor"
          },
          {
            "code" : "S",
            "display" : "SENSORY ORGANS"
          },
          {
            "code" : "S01",
            "display" : "OPHTHALMOLOGICALS"
          },
          {
            "code" : "S01A",
            "display" : "ANTIINFECTIVES"
          },
          {
            "code" : "S01AA",
            "display" : "Antibiotics"
          },
          {
            "code" : "S01AA01",
            "display" : "chloramphenicol"
          },
          {
            "code" : "S01AA02",
            "display" : "chlortetracycline"
          },
          {
            "code" : "S01AA03",
            "display" : "neomycin"
          },
          {
            "code" : "S01AA04",
            "display" : "oxytetracycline"
          },
          {
            "code" : "S01AA05",
            "display" : "tyrothricin"
          },
          {
            "code" : "S01AA07",
            "display" : "framycetin"
          },
          {
            "code" : "S01AA09",
            "display" : "tetracycline"
          },
          {
            "code" : "S01AA10",
            "display" : "natamycin"
          },
          {
            "code" : "S01AA11",
            "display" : "gentamicin"
          },
          {
            "code" : "S01AA12",
            "display" : "tobramycin"
          },
          {
            "code" : "S01AA13",
            "display" : "fusidic acid"
          },
          {
            "code" : "S01AA14",
            "display" : "benzylpenicillin"
          },
          {
            "code" : "S01AA15",
            "display" : "dihydrostreptomycin"
          },
          {
            "code" : "S01AA16",
            "display" : "rifamycin"
          },
          {
            "code" : "S01AA17",
            "display" : "erythromycin"
          },
          {
            "code" : "S01AA18",
            "display" : "polymyxin B"
          },
          {
            "code" : "S01AA19",
            "display" : "ampicillin"
          },
          {
            "code" : "S01AA20",
            "display" : "antibiotics in combination with other drugs"
          },
          {
            "code" : "S01AA21",
            "display" : "amikacin"
          },
          {
            "code" : "S01AA22",
            "display" : "micronomicin"
          },
          {
            "code" : "S01AA23",
            "display" : "netilmicin"
          },
          {
            "code" : "S01AA24",
            "display" : "kanamycin"
          },
          {
            "code" : "S01AA25",
            "display" : "azidamfenicol"
          },
          {
            "code" : "S01AA26",
            "display" : "azithromycin"
          },
          {
            "code" : "S01AA27",
            "display" : "cefuroxime"
          },
          {
            "code" : "S01AA28",
            "display" : "vancomycin"
          },
          {
            "code" : "S01AA29",
            "display" : "dibekacin"
          },
          {
            "code" : "S01AA30",
            "display" : "combinations of different antibiotics"
          },
          {
            "code" : "S01AA31",
            "display" : "cefmenoxime"
          },
          {
            "code" : "S01AA32",
            "display" : "bacitracin"
          },
          {
            "code" : "S01AB",
            "display" : "Sulfonamides"
          },
          {
            "code" : "S01AB01",
            "display" : "sulfamethizole"
          },
          {
            "code" : "S01AB02",
            "display" : "sulfafurazole"
          },
          {
            "code" : "S01AB03",
            "display" : "sulfadicramide"
          },
          {
            "code" : "S01AB04",
            "display" : "sulfacetamide"
          },
          {
            "code" : "S01AB05",
            "display" : "sulfafenazol"
          },
          {
            "code" : "S01AD",
            "display" : "Antivirals"
          },
          {
            "code" : "S01AD01",
            "display" : "idoxuridine"
          },
          {
            "code" : "S01AD02",
            "display" : "trifluridine"
          },
          {
            "code" : "S01AD03",
            "display" : "aciclovir"
          },
          {
            "code" : "S01AD05",
            "display" : "interferon"
          },
          {
            "code" : "S01AD06",
            "display" : "vidarabine"
          },
          {
            "code" : "S01AD07",
            "display" : "famciclovir"
          },
          {
            "code" : "S01AD08",
            "display" : "fomivirsen"
          },
          {
            "code" : "S01AD09",
            "display" : "ganciclovir"
          },
          {
            "code" : "S01AE",
            "display" : "Fluoroquinolones"
          },
          {
            "code" : "S01AE01",
            "display" : "ofloxacin"
          },
          {
            "code" : "S01AE02",
            "display" : "norfloxacin"
          },
          {
            "code" : "S01AE03",
            "display" : "ciprofloxacin"
          },
          {
            "code" : "S01AE04",
            "display" : "lomefloxacin"
          },
          {
            "code" : "S01AE05",
            "display" : "levofloxacin"
          },
          {
            "code" : "S01AE06",
            "display" : "gatifloxacin"
          },
          {
            "code" : "S01AE07",
            "display" : "moxifloxacin"
          },
          {
            "code" : "S01AE08",
            "display" : "besifloxacin"
          },
          {
            "code" : "S01AE09",
            "display" : "tosufloxacin"
          },
          {
            "code" : "S01AX",
            "display" : "Other antiinfectives"
          },
          {
            "code" : "S01AX01",
            "display" : "mercury compounds"
          },
          {
            "code" : "S01AX02",
            "display" : "silver compounds"
          },
          {
            "code" : "S01AX03",
            "display" : "zinc compounds"
          },
          {
            "code" : "S01AX04",
            "display" : "nitrofural"
          },
          {
            "code" : "S01AX05",
            "display" : "bibrocathol"
          },
          {
            "code" : "S01AX06",
            "display" : "resorcinol"
          },
          {
            "code" : "S01AX07",
            "display" : "sodium borate"
          },
          {
            "code" : "S01AX08",
            "display" : "hexamidine"
          },
          {
            "code" : "S01AX09",
            "display" : "chlorhexidine"
          },
          {
            "code" : "S01AX10",
            "display" : "sodium propionate"
          },
          {
            "code" : "S01AX14",
            "display" : "dibrompropamidine"
          },
          {
            "code" : "S01AX15",
            "display" : "propamidine"
          },
          {
            "code" : "S01AX16",
            "display" : "picloxydine"
          },
          {
            "code" : "S01AX18",
            "display" : "povidone-iodine"
          },
          {
            "code" : "S01AX24",
            "display" : "polihexanide"
          },
          {
            "code" : "S01AX25",
            "display" : "lotilaner"
          },
          {
            "code" : "S01B",
            "display" : "ANTIINFLAMMATORY AGENTS"
          },
          {
            "code" : "S01BA",
            "display" : "Corticosteroids, plain"
          },
          {
            "code" : "S01BA01",
            "display" : "dexamethasone"
          },
          {
            "code" : "S01BA02",
            "display" : "hydrocortisone"
          },
          {
            "code" : "S01BA03",
            "display" : "cortisone"
          },
          {
            "code" : "S01BA04",
            "display" : "prednisolone"
          },
          {
            "code" : "S01BA05",
            "display" : "triamcinolone"
          },
          {
            "code" : "S01BA06",
            "display" : "betamethasone"
          },
          {
            "code" : "S01BA07",
            "display" : "fluorometholone"
          },
          {
            "code" : "S01BA08",
            "display" : "medrysone"
          },
          {
            "code" : "S01BA09",
            "display" : "clobetasone"
          },
          {
            "code" : "S01BA10",
            "display" : "alclometasone"
          },
          {
            "code" : "S01BA11",
            "display" : "desonide"
          },
          {
            "code" : "S01BA12",
            "display" : "formocortal"
          },
          {
            "code" : "S01BA13",
            "display" : "rimexolone"
          },
          {
            "code" : "S01BA14",
            "display" : "loteprednol"
          },
          {
            "code" : "S01BA15",
            "display" : "fluocinolone acetonide"
          },
          {
            "code" : "S01BA16",
            "display" : "difluprednate"
          },
          {
            "code" : "S01BB",
            "display" : "Corticosteroids and mydriatics in combination"
          },
          {
            "code" : "S01BB01",
            "display" : "hydrocortisone and mydriatics"
          },
          {
            "code" : "S01BB02",
            "display" : "prednisolone and mydriatics"
          },
          {
            "code" : "S01BB03",
            "display" : "fluorometholone and mydriatics"
          },
          {
            "code" : "S01BB04",
            "display" : "betamethasone and mydriatics"
          },
          {
            "code" : "S01BC",
            "display" : "Antiinflammatory agents, non-steroids"
          },
          {
            "code" : "S01BC01",
            "display" : "indometacin"
          },
          {
            "code" : "S01BC02",
            "display" : "oxyphenbutazone"
          },
          {
            "code" : "S01BC03",
            "display" : "diclofenac"
          },
          {
            "code" : "S01BC04",
            "display" : "flurbiprofen"
          },
          {
            "code" : "S01BC05",
            "display" : "ketorolac"
          },
          {
            "code" : "S01BC06",
            "display" : "piroxicam"
          },
          {
            "code" : "S01BC07",
            "display" : "bendazac"
          },
          {
            "code" : "S01BC08",
            "display" : "salicylic acid"
          },
          {
            "code" : "S01BC09",
            "display" : "pranoprofen"
          },
          {
            "code" : "S01BC10",
            "display" : "nepafenac"
          },
          {
            "code" : "S01BC11",
            "display" : "bromfenac"
          },
          {
            "code" : "S01C",
            "display" : "ANTIINFLAMMATORY AGENTS AND ANTIINFECTIVES IN COMBINATION"
          },
          {
            "code" : "S01CA",
            "display" : "Corticosteroids and antiinfectives in combination"
          },
          {
            "code" : "S01CA01",
            "display" : "dexamethasone and antiinfectives"
          },
          {
            "code" : "S01CA02",
            "display" : "prednisolone and antiinfectives"
          },
          {
            "code" : "S01CA03",
            "display" : "hydrocortisone and antiinfectives"
          },
          {
            "code" : "S01CA04",
            "display" : "fluocortolone and antiinfectives"
          },
          {
            "code" : "S01CA05",
            "display" : "betamethasone and antiinfectives"
          },
          {
            "code" : "S01CA06",
            "display" : "fludrocortisone and antiinfectives"
          },
          {
            "code" : "S01CA07",
            "display" : "fluorometholone and antiinfectives"
          },
          {
            "code" : "S01CA08",
            "display" : "methylprednisolone and antiinfectives"
          },
          {
            "code" : "S01CA09",
            "display" : "chloroprednisone and antiinfectives"
          },
          {
            "code" : "S01CA10",
            "display" : "fluocinolone acetonide and antiinfectives"
          },
          {
            "code" : "S01CA11",
            "display" : "clobetasone and antiinfectives"
          },
          {
            "code" : "S01CA12",
            "display" : "loteprednol and antiinfectives"
          },
          {
            "code" : "S01CB",
            "display" : "Corticosteroids/antiinfectives/mydriatics in combination"
          },
          {
            "code" : "S01CB01",
            "display" : "dexamethasone"
          },
          {
            "code" : "S01CB02",
            "display" : "prednisolone"
          },
          {
            "code" : "S01CB03",
            "display" : "hydrocortisone"
          },
          {
            "code" : "S01CB04",
            "display" : "betamethasone"
          },
          {
            "code" : "S01CB05",
            "display" : "fluorometholone"
          },
          {
            "code" : "S01CC",
            "display" : "Antiinflammatory agents, non-steroids and antiinfectives in combination"
          },
          {
            "code" : "S01CC01",
            "display" : "diclofenac and antiinfectives"
          },
          {
            "code" : "S01CC02",
            "display" : "indometacin and antiinfectives"
          },
          {
            "code" : "S01E",
            "display" : "ANTIGLAUCOMA PREPARATIONS AND MIOTICS"
          },
          {
            "code" : "S01EA",
            "display" : "Sympathomimetics in glaucoma therapy"
          },
          {
            "code" : "S01EA01",
            "display" : "epinephrine"
          },
          {
            "code" : "S01EA02",
            "display" : "dipivefrine"
          },
          {
            "code" : "S01EA03",
            "display" : "apraclonidine"
          },
          {
            "code" : "S01EA04",
            "display" : "clonidine"
          },
          {
            "code" : "S01EA05",
            "display" : "brimonidine"
          },
          {
            "code" : "S01EA51",
            "display" : "epinephrine, combinations"
          },
          {
            "code" : "S01EA55",
            "display" : "brimonidine and ripasudil"
          },
          {
            "code" : "S01EB",
            "display" : "Parasympathomimetics"
          },
          {
            "code" : "S01EB01",
            "display" : "pilocarpine"
          },
          {
            "code" : "S01EB02",
            "display" : "carbachol"
          },
          {
            "code" : "S01EB03",
            "display" : "ecothiopate"
          },
          {
            "code" : "S01EB04",
            "display" : "demecarium"
          },
          {
            "code" : "S01EB05",
            "display" : "physostigmine"
          },
          {
            "code" : "S01EB06",
            "display" : "neostigmine"
          },
          {
            "code" : "S01EB07",
            "display" : "fluostigmine"
          },
          {
            "code" : "S01EB08",
            "display" : "aceclidine"
          },
          {
            "code" : "S01EB09",
            "display" : "acetylcholine"
          },
          {
            "code" : "S01EB10",
            "display" : "paraoxon"
          },
          {
            "code" : "S01EB51",
            "display" : "pilocarpine, combinations"
          },
          {
            "code" : "S01EB58",
            "display" : "aceclidine, combinations"
          },
          {
            "code" : "S01EC",
            "display" : "Carbonic anhydrase inhibitors"
          },
          {
            "code" : "S01EC01",
            "display" : "acetazolamide"
          },
          {
            "code" : "S01EC02",
            "display" : "diclofenamide"
          },
          {
            "code" : "S01EC03",
            "display" : "dorzolamide"
          },
          {
            "code" : "S01EC04",
            "display" : "brinzolamide"
          },
          {
            "code" : "S01EC05",
            "display" : "methazolamide"
          },
          {
            "code" : "S01EC54",
            "display" : "brinzolamide, combinations"
          },
          {
            "code" : "S01ED",
            "display" : "Beta blocking agents"
          },
          {
            "code" : "S01ED01",
            "display" : "timolol"
          },
          {
            "code" : "S01ED02",
            "display" : "betaxolol"
          },
          {
            "code" : "S01ED03",
            "display" : "levobunolol"
          },
          {
            "code" : "S01ED04",
            "display" : "metipranolol"
          },
          {
            "code" : "S01ED05",
            "display" : "carteolol"
          },
          {
            "code" : "S01ED06",
            "display" : "befunolol"
          },
          {
            "code" : "S01ED51",
            "display" : "timolol, combinations"
          },
          {
            "code" : "S01ED52",
            "display" : "betaxolol, combinations"
          },
          {
            "code" : "S01ED54",
            "display" : "metipranolol, combinations"
          },
          {
            "code" : "S01ED55",
            "display" : "carteolol, combinations"
          },
          {
            "code" : "S01EE",
            "display" : "Prostaglandin analogues"
          },
          {
            "code" : "S01EE01",
            "display" : "latanoprost"
          },
          {
            "code" : "S01EE02",
            "display" : "unoprostone"
          },
          {
            "code" : "S01EE03",
            "display" : "bimatoprost"
          },
          {
            "code" : "S01EE04",
            "display" : "travoprost"
          },
          {
            "code" : "S01EE05",
            "display" : "tafluprost"
          },
          {
            "code" : "S01EE06",
            "display" : "latanoprostene bunod"
          },
          {
            "code" : "S01EE51",
            "display" : "latanoprost and netarsudil"
          },
          {
            "code" : "S01EE52",
            "display" : "latanoprost and dorzolamide"
          },
          {
            "code" : "S01EX",
            "display" : "Other antiglaucoma preparations"
          },
          {
            "code" : "S01EX01",
            "display" : "guanethidine"
          },
          {
            "code" : "S01EX02",
            "display" : "dapiprazole"
          },
          {
            "code" : "S01EX05",
            "display" : "netarsudil"
          },
          {
            "code" : "S01EX06",
            "display" : "omidenepag"
          },
          {
            "code" : "S01EX07",
            "display" : "ripasudil"
          },
          {
            "code" : "S01F",
            "display" : "MYDRIATICS AND CYCLOPLEGICS"
          },
          {
            "code" : "S01FA",
            "display" : "Anticholinergics"
          },
          {
            "code" : "S01FA01",
            "display" : "atropine"
          },
          {
            "code" : "S01FA02",
            "display" : "scopolamine"
          },
          {
            "code" : "S01FA03",
            "display" : "methylscopolamine"
          },
          {
            "code" : "S01FA04",
            "display" : "cyclopentolate"
          },
          {
            "code" : "S01FA05",
            "display" : "homatropine"
          },
          {
            "code" : "S01FA06",
            "display" : "tropicamide"
          },
          {
            "code" : "S01FA54",
            "display" : "cyclopentolate, combinations"
          },
          {
            "code" : "S01FA56",
            "display" : "tropicamide, combinations"
          },
          {
            "code" : "S01FB",
            "display" : "Sympathomimetics excl. antiglaucoma preparations"
          },
          {
            "code" : "S01FB01",
            "display" : "phenylephrine"
          },
          {
            "code" : "S01FB02",
            "display" : "ephedrine"
          },
          {
            "code" : "S01FB03",
            "display" : "ibopamine"
          },
          {
            "code" : "S01FB51",
            "display" : "phenylephrine and ketorolac"
          },
          {
            "code" : "S01G",
            "display" : "DECONGESTANTS AND ANTIALLERGICS"
          },
          {
            "code" : "S01GA",
            "display" : "Sympathomimetics used as decongestants"
          },
          {
            "code" : "S01GA01",
            "display" : "naphazoline"
          },
          {
            "code" : "S01GA02",
            "display" : "tetryzoline"
          },
          {
            "code" : "S01GA03",
            "display" : "xylometazoline"
          },
          {
            "code" : "S01GA04",
            "display" : "oxymetazoline"
          },
          {
            "code" : "S01GA05",
            "display" : "phenylephrine"
          },
          {
            "code" : "S01GA06",
            "display" : "oxedrine"
          },
          {
            "code" : "S01GA07",
            "display" : "brimonidine"
          },
          {
            "code" : "S01GA51",
            "display" : "naphazoline, combinations"
          },
          {
            "code" : "S01GA52",
            "display" : "tetryzoline, combinations"
          },
          {
            "code" : "S01GA53",
            "display" : "xylometazoline, combinations"
          },
          {
            "code" : "S01GA55",
            "display" : "phenylephrine, combinations"
          },
          {
            "code" : "S01GA56",
            "display" : "oxedrine, combinations"
          },
          {
            "code" : "S01GX",
            "display" : "Other antiallergics"
          },
          {
            "code" : "S01GX01",
            "display" : "cromoglicic acid"
          },
          {
            "code" : "S01GX02",
            "display" : "levocabastine"
          },
          {
            "code" : "S01GX03",
            "display" : "spaglumic acid"
          },
          {
            "code" : "S01GX04",
            "display" : "nedocromil"
          },
          {
            "code" : "S01GX05",
            "display" : "lodoxamide"
          },
          {
            "code" : "S01GX06",
            "display" : "emedastine"
          },
          {
            "code" : "S01GX07",
            "display" : "azelastine"
          },
          {
            "code" : "S01GX08",
            "display" : "ketotifen"
          },
          {
            "code" : "S01GX09",
            "display" : "olopatadine"
          },
          {
            "code" : "S01GX10",
            "display" : "epinastine"
          },
          {
            "code" : "S01GX11",
            "display" : "alcaftadine"
          },
          {
            "code" : "S01GX12",
            "display" : "cetirizine"
          },
          {
            "code" : "S01GX13",
            "display" : "bilastine"
          },
          {
            "code" : "S01GX51",
            "display" : "cromoglicic acid, combinations"
          },
          {
            "code" : "S01H",
            "display" : "LOCAL ANESTHETICS"
          },
          {
            "code" : "S01HA",
            "display" : "Local anesthetics"
          },
          {
            "code" : "S01HA01",
            "display" : "cocaine"
          },
          {
            "code" : "S01HA02",
            "display" : "oxybuprocaine"
          },
          {
            "code" : "S01HA03",
            "display" : "tetracaine"
          },
          {
            "code" : "S01HA04",
            "display" : "proxymetacaine"
          },
          {
            "code" : "S01HA05",
            "display" : "procaine"
          },
          {
            "code" : "S01HA06",
            "display" : "cinchocaine"
          },
          {
            "code" : "S01HA07",
            "display" : "lidocaine"
          },
          {
            "code" : "S01HA08",
            "display" : "chloroprocaine"
          },
          {
            "code" : "S01HA30",
            "display" : "combinations"
          },
          {
            "code" : "S01J",
            "display" : "DIAGNOSTIC AGENTS"
          },
          {
            "code" : "S01JA",
            "display" : "Colouring agents"
          },
          {
            "code" : "S01JA01",
            "display" : "fluorescein"
          },
          {
            "code" : "S01JA02",
            "display" : "rose bengal sodium"
          },
          {
            "code" : "S01JA51",
            "display" : "fluorescein, combinations"
          },
          {
            "code" : "S01JX",
            "display" : "Other ophthalmological diagnostic agents"
          },
          {
            "code" : "S01K",
            "display" : "SURGICAL AIDS"
          },
          {
            "code" : "S01KA",
            "display" : "Viscoelastic substances"
          },
          {
            "code" : "S01KA01",
            "display" : "hyaluronic acid"
          },
          {
            "code" : "S01KA02",
            "display" : "hypromellose"
          },
          {
            "code" : "S01KA51",
            "display" : "hyaluronic acid, combinations"
          },
          {
            "code" : "S01KX",
            "display" : "Other surgical aids"
          },
          {
            "code" : "S01KX01",
            "display" : "chymotrypsin"
          },
          {
            "code" : "S01KX02",
            "display" : "trypan blue"
          },
          {
            "code" : "S01L",
            "display" : "OCULAR VASCULAR DISORDER AGENTS"
          },
          {
            "code" : "S01LA",
            "display" : "Antineovascularisation agents"
          },
          {
            "code" : "S01LA01",
            "display" : "verteporfin"
          },
          {
            "code" : "S01LA02",
            "display" : "anecortave"
          },
          {
            "code" : "S01LA03",
            "display" : "pegaptanib"
          },
          {
            "code" : "S01LA04",
            "display" : "ranibizumab"
          },
          {
            "code" : "S01LA05",
            "display" : "aflibercept"
          },
          {
            "code" : "S01LA06",
            "display" : "brolucizumab"
          },
          {
            "code" : "S01LA07",
            "display" : "abicipar pegol"
          },
          {
            "code" : "S01LA08",
            "display" : "bevacizumab"
          },
          {
            "code" : "S01LA09",
            "display" : "faricimab"
          },
          {
            "code" : "S01X",
            "display" : "OTHER OPHTHALMOLOGICALS"
          },
          {
            "code" : "S01XA",
            "display" : "Other ophthalmologicals"
          },
          {
            "code" : "S01XA01",
            "display" : "guaiazulen"
          },
          {
            "code" : "S01XA02",
            "display" : "retinol"
          },
          {
            "code" : "S01XA03",
            "display" : "sodium chloride, hypertonic"
          },
          {
            "code" : "S01XA04",
            "display" : "potassium iodide"
          },
          {
            "code" : "S01XA05",
            "display" : "sodium edetate"
          },
          {
            "code" : "S01XA06",
            "display" : "ethylmorphine"
          },
          {
            "code" : "S01XA07",
            "display" : "alum"
          },
          {
            "code" : "S01XA08",
            "display" : "acetylcysteine"
          },
          {
            "code" : "S01XA09",
            "display" : "iodoheparinate"
          },
          {
            "code" : "S01XA10",
            "display" : "inosine"
          },
          {
            "code" : "S01XA11",
            "display" : "nandrolone"
          },
          {
            "code" : "S01XA12",
            "display" : "dexpanthenol"
          },
          {
            "code" : "S01XA13",
            "display" : "alteplase"
          },
          {
            "code" : "S01XA14",
            "display" : "heparin"
          },
          {
            "code" : "S01XA15",
            "display" : "ascorbic acid"
          },
          {
            "code" : "S01XA18",
            "display" : "ciclosporin"
          },
          {
            "code" : "S01XA19",
            "display" : "limbal stem cells, autologous"
          },
          {
            "code" : "S01XA20",
            "display" : "artificial tears and other indifferent preparations"
          },
          {
            "code" : "S01XA21",
            "display" : "mercaptamine"
          },
          {
            "code" : "S01XA22",
            "display" : "ocriplasmin"
          },
          {
            "code" : "S01XA23",
            "display" : "sirolimus"
          },
          {
            "code" : "S01XA24",
            "display" : "cenegermin"
          },
          {
            "code" : "S01XA25",
            "display" : "lifitegrast"
          },
          {
            "code" : "S01XA26",
            "display" : "riboflavin"
          },
          {
            "code" : "S01XA27",
            "display" : "voretigene neparvovec"
          },
          {
            "code" : "S01XA28",
            "display" : "varenicline"
          },
          {
            "code" : "S01XA29",
            "display" : "sepofarsen"
          },
          {
            "code" : "S01XA31",
            "display" : "pegcetacoplan"
          },
          {
            "code" : "S01XA32",
            "display" : "avacincaptad pegol"
          },
          {
            "code" : "S01XA33",
            "display" : "diquafosol"
          },
          {
            "code" : "S02",
            "display" : "OTOLOGICALS"
          },
          {
            "code" : "S02A",
            "display" : "ANTIINFECTIVES"
          },
          {
            "code" : "S02AA",
            "display" : "Antiinfectives"
          },
          {
            "code" : "S02AA01",
            "display" : "chloramphenicol"
          },
          {
            "code" : "S02AA02",
            "display" : "nitrofural"
          },
          {
            "code" : "S02AA03",
            "display" : "boric acid"
          },
          {
            "code" : "S02AA04",
            "display" : "aluminium acetotartrate"
          },
          {
            "code" : "S02AA05",
            "display" : "clioquinol"
          },
          {
            "code" : "S02AA06",
            "display" : "hydrogen peroxide"
          },
          {
            "code" : "S02AA07",
            "display" : "neomycin"
          },
          {
            "code" : "S02AA08",
            "display" : "tetracycline"
          },
          {
            "code" : "S02AA09",
            "display" : "chlorhexidine"
          },
          {
            "code" : "S02AA10",
            "display" : "acetic acid"
          },
          {
            "code" : "S02AA11",
            "display" : "polymyxin B"
          },
          {
            "code" : "S02AA12",
            "display" : "rifamycin"
          },
          {
            "code" : "S02AA13",
            "display" : "miconazole"
          },
          {
            "code" : "S02AA14",
            "display" : "gentamicin"
          },
          {
            "code" : "S02AA15",
            "display" : "ciprofloxacin"
          },
          {
            "code" : "S02AA16",
            "display" : "ofloxacin"
          },
          {
            "code" : "S02AA17",
            "display" : "fosfomycin"
          },
          {
            "code" : "S02AA18",
            "display" : "cefmenoxime"
          },
          {
            "code" : "S02AA30",
            "display" : "antiinfectives, combinations"
          },
          {
            "code" : "S02B",
            "display" : "CORTICOSTEROIDS"
          },
          {
            "code" : "S02BA",
            "display" : "Corticosteroids"
          },
          {
            "code" : "S02BA01",
            "display" : "hydrocortisone"
          },
          {
            "code" : "S02BA03",
            "display" : "prednisolone"
          },
          {
            "code" : "S02BA06",
            "display" : "dexamethasone"
          },
          {
            "code" : "S02BA07",
            "display" : "betamethasone"
          },
          {
            "code" : "S02BA08",
            "display" : "fluocinolone acetonide"
          },
          {
            "code" : "S02C",
            "display" : "CORTICOSTEROIDS AND ANTIINFECTIVES IN COMBINATION"
          },
          {
            "code" : "S02CA",
            "display" : "Corticosteroids and antiinfectives in combination"
          },
          {
            "code" : "S02CA01",
            "display" : "prednisolone and antiinfectives"
          },
          {
            "code" : "S02CA02",
            "display" : "flumetasone and antiinfectives"
          },
          {
            "code" : "S02CA03",
            "display" : "hydrocortisone and antiinfectives"
          },
          {
            "code" : "S02CA04",
            "display" : "triamcinolone and antiinfectives"
          },
          {
            "code" : "S02CA05",
            "display" : "fluocinolone acetonide and antiinfectives"
          },
          {
            "code" : "S02CA06",
            "display" : "dexamethasone and antiinfectives"
          },
          {
            "code" : "S02CA07",
            "display" : "fludrocortisone and antiinfectives"
          },
          {
            "code" : "S02D",
            "display" : "OTHER OTOLOGICALS"
          },
          {
            "code" : "S02DA",
            "display" : "Analgesics and anesthetics"
          },
          {
            "code" : "S02DA01",
            "display" : "lidocaine"
          },
          {
            "code" : "S02DA02",
            "display" : "cocaine"
          },
          {
            "code" : "S02DA03",
            "display" : "phenazone"
          },
          {
            "code" : "S02DA04",
            "display" : "cinchocaine"
          },
          {
            "code" : "S02DA30",
            "display" : "combinations"
          },
          {
            "code" : "S02DC",
            "display" : "Indifferent preparations"
          },
          {
            "code" : "S03",
            "display" : "OPHTHALMOLOGICAL AND OTOLOGICAL PREPARATIONS"
          },
          {
            "code" : "S03A",
            "display" : "ANTIINFECTIVES"
          },
          {
            "code" : "S03AA",
            "display" : "Antiinfectives"
          },
          {
            "code" : "S03AA01",
            "display" : "neomycin"
          },
          {
            "code" : "S03AA02",
            "display" : "tetracycline"
          },
          {
            "code" : "S03AA03",
            "display" : "polymyxin B"
          },
          {
            "code" : "S03AA04",
            "display" : "chlorhexidine"
          },
          {
            "code" : "S03AA05",
            "display" : "hexamidine"
          },
          {
            "code" : "S03AA06",
            "display" : "gentamicin"
          },
          {
            "code" : "S03AA07",
            "display" : "ciprofloxacin"
          },
          {
            "code" : "S03AA08",
            "display" : "chloramphenicol"
          },
          {
            "code" : "S03AA30",
            "display" : "antiinfectives, combinations"
          },
          {
            "code" : "S03B",
            "display" : "CORTICOSTEROIDS"
          },
          {
            "code" : "S03BA",
            "display" : "Corticosteroids"
          },
          {
            "code" : "S03BA01",
            "display" : "dexamethasone"
          },
          {
            "code" : "S03BA02",
            "display" : "prednisolone"
          },
          {
            "code" : "S03BA03",
            "display" : "betamethasone"
          },
          {
            "code" : "S03C",
            "display" : "CORTICOSTEROIDS AND ANTIINFECTIVES IN COMBINATION"
          },
          {
            "code" : "S03CA",
            "display" : "Corticosteroids and antiinfectives in combination"
          },
          {
            "code" : "S03CA01",
            "display" : "dexamethasone and antiinfectives"
          },
          {
            "code" : "S03CA02",
            "display" : "prednisolone and antiinfectives"
          },
          {
            "code" : "S03CA04",
            "display" : "hydrocortisone and antiinfectives"
          },
          {
            "code" : "S03CA05",
            "display" : "fludrocortisone and antiinfectives"
          },
          {
            "code" : "S03CA06",
            "display" : "betamethasone and antiinfectives"
          },
          {
            "code" : "S03CA07",
            "display" : "methylprednisolone and antiinfectives"
          },
          {
            "code" : "S03D",
            "display" : "OTHER OPHTHALMOLOGICAL AND OTOLOGICAL PREPARATIONS"
          },
          {
            "code" : "V",
            "display" : "VARIOUS"
          },
          {
            "code" : "V01",
            "display" : "ALLERGENS"
          },
          {
            "code" : "V01A",
            "display" : "ALLERGENS"
          },
          {
            "code" : "V01AA",
            "display" : "Allergen extracts"
          },
          {
            "code" : "V01AA01",
            "display" : "feather"
          },
          {
            "code" : "V01AA02",
            "display" : "grass pollen"
          },
          {
            "code" : "V01AA03",
            "display" : "house dust mites"
          },
          {
            "code" : "V01AA04",
            "display" : "mould fungus and yeast fungus"
          },
          {
            "code" : "V01AA05",
            "display" : "tree pollen"
          },
          {
            "code" : "V01AA07",
            "display" : "insects"
          },
          {
            "code" : "V01AA08",
            "display" : "food"
          },
          {
            "code" : "V01AA09",
            "display" : "textiles"
          },
          {
            "code" : "V01AA10",
            "display" : "flowers"
          },
          {
            "code" : "V01AA11",
            "display" : "animals"
          },
          {
            "code" : "V01AA20",
            "display" : "various"
          },
          {
            "code" : "V03",
            "display" : "ALL OTHER THERAPEUTIC PRODUCTS"
          },
          {
            "code" : "V03A",
            "display" : "ALL OTHER THERAPEUTIC PRODUCTS"
          },
          {
            "code" : "V03AB",
            "display" : "Antidotes"
          },
          {
            "code" : "V03AB01",
            "display" : "ipecacuanha"
          },
          {
            "code" : "V03AB02",
            "display" : "nalorphine"
          },
          {
            "code" : "V03AB03",
            "display" : "edetates"
          },
          {
            "code" : "V03AB04",
            "display" : "pralidoxime"
          },
          {
            "code" : "V03AB05",
            "display" : "prednisolone and promethazine"
          },
          {
            "code" : "V03AB06",
            "display" : "thiosulfate"
          },
          {
            "code" : "V03AB08",
            "display" : "sodium nitrite"
          },
          {
            "code" : "V03AB09",
            "display" : "dimercaprol"
          },
          {
            "code" : "V03AB13",
            "display" : "obidoxime"
          },
          {
            "code" : "V03AB14",
            "display" : "protamine"
          },
          {
            "code" : "V03AB15",
            "display" : "naloxone"
          },
          {
            "code" : "V03AB16",
            "display" : "ethanol"
          },
          {
            "code" : "V03AB17",
            "display" : "methylthioninium chloride"
          },
          {
            "code" : "V03AB18",
            "display" : "potassium permanganate"
          },
          {
            "code" : "V03AB19",
            "display" : "physostigmine"
          },
          {
            "code" : "V03AB20",
            "display" : "copper sulfate"
          },
          {
            "code" : "V03AB21",
            "display" : "potassium iodide"
          },
          {
            "code" : "V03AB22",
            "display" : "amyl nitrite"
          },
          {
            "code" : "V03AB23",
            "display" : "acetylcysteine"
          },
          {
            "code" : "V03AB24",
            "display" : "digitalis antitoxin"
          },
          {
            "code" : "V03AB25",
            "display" : "flumazenil"
          },
          {
            "code" : "V03AB26",
            "display" : "methionine"
          },
          {
            "code" : "V03AB27",
            "display" : "4-dimethylaminophenol"
          },
          {
            "code" : "V03AB29",
            "display" : "cholinesterase"
          },
          {
            "code" : "V03AB31",
            "display" : "prussian blue"
          },
          {
            "code" : "V03AB32",
            "display" : "glutathione"
          },
          {
            "code" : "V03AB33",
            "display" : "hydroxocobalamin"
          },
          {
            "code" : "V03AB34",
            "display" : "fomepizole"
          },
          {
            "code" : "V03AB35",
            "display" : "sugammadex"
          },
          {
            "code" : "V03AB36",
            "display" : "phentolamine"
          },
          {
            "code" : "V03AB37",
            "display" : "idarucizumab"
          },
          {
            "code" : "V03AB38",
            "display" : "andexanet alfa"
          },
          {
            "code" : "V03AB54",
            "display" : "pralidoxime and atropine"
          },
          {
            "code" : "V03AC",
            "display" : "Iron chelating agents"
          },
          {
            "code" : "V03AC01",
            "display" : "deferoxamine"
          },
          {
            "code" : "V03AC02",
            "display" : "deferiprone"
          },
          {
            "code" : "V03AC03",
            "display" : "deferasirox"
          },
          {
            "code" : "V03AE",
            "display" : "Drugs for treatment of hyperkalemia and hyperphosphatemia"
          },
          {
            "code" : "V03AE01",
            "display" : "polystyrene sulfonate"
          },
          {
            "code" : "V03AE02",
            "display" : "sevelamer"
          },
          {
            "code" : "V03AE03",
            "display" : "lanthanum carbonate"
          },
          {
            "code" : "V03AE04",
            "display" : "calcium acetate and magnesium carbonate"
          },
          {
            "code" : "V03AE05",
            "display" : "sucroferric oxyhydroxide"
          },
          {
            "code" : "V03AE06",
            "display" : "colestilan"
          },
          {
            "code" : "V03AE07",
            "display" : "calcium acetate"
          },
          {
            "code" : "V03AE08",
            "display" : "ferric citrate"
          },
          {
            "code" : "V03AE09",
            "display" : "patiromer calcium"
          },
          {
            "code" : "V03AE10",
            "display" : "sodium zirconium cyclosilicate"
          },
          {
            "code" : "V03AF",
            "display" : "Detoxifying agents for antineoplastic treatment"
          },
          {
            "code" : "V03AF01",
            "display" : "mesna"
          },
          {
            "code" : "V03AF02",
            "display" : "dexrazoxane"
          },
          {
            "code" : "V03AF03",
            "display" : "calcium folinate"
          },
          {
            "code" : "V03AF04",
            "display" : "calcium levofolinate"
          },
          {
            "code" : "V03AF05",
            "display" : "amifostine"
          },
          {
            "code" : "V03AF06",
            "display" : "sodium folinate"
          },
          {
            "code" : "V03AF07",
            "display" : "rasburicase"
          },
          {
            "code" : "V03AF08",
            "display" : "palifermin"
          },
          {
            "code" : "V03AF09",
            "display" : "glucarpidase"
          },
          {
            "code" : "V03AF10",
            "display" : "sodium levofolinate"
          },
          {
            "code" : "V03AF11",
            "display" : "arginine and lysine"
          },
          {
            "code" : "V03AF12",
            "display" : "trilaciclib"
          },
          {
            "code" : "V03AG",
            "display" : "Drugs for treatment of hypercalcemia"
          },
          {
            "code" : "V03AG01",
            "display" : "sodium cellulose phosphate"
          },
          {
            "code" : "V03AG05",
            "display" : "sodium phosphate"
          },
          {
            "code" : "V03AH",
            "display" : "Drugs for treatment of hypoglycemia"
          },
          {
            "code" : "V03AH01",
            "display" : "diazoxide"
          },
          {
            "code" : "V03AK",
            "display" : "Tissue adhesives"
          },
          {
            "code" : "V03AM",
            "display" : "Drugs for embolisation"
          },
          {
            "code" : "V03AN",
            "display" : "Medical gases"
          },
          {
            "code" : "V03AN01",
            "display" : "oxygen"
          },
          {
            "code" : "V03AN02",
            "display" : "carbon dioxide"
          },
          {
            "code" : "V03AN03",
            "display" : "helium"
          },
          {
            "code" : "V03AN04",
            "display" : "nitrogen"
          },
          {
            "code" : "V03AN05",
            "display" : "medical air"
          },
          {
            "code" : "V03AX",
            "display" : "Other therapeutic products"
          },
          {
            "code" : "V03AX02",
            "display" : "nalfurafine"
          },
          {
            "code" : "V03AX03",
            "display" : "cobicistat"
          },
          {
            "code" : "V03AX04",
            "display" : "difelikefalin"
          },
          {
            "code" : "V03AZ",
            "display" : "Nerve depressants"
          },
          {
            "code" : "V03AZ01",
            "display" : "ethanol"
          },
          {
            "code" : "V04",
            "display" : "DIAGNOSTIC AGENTS"
          },
          {
            "code" : "V04B",
            "display" : "URINE TESTS"
          },
          {
            "code" : "V04C",
            "display" : "OTHER DIAGNOSTIC AGENTS"
          },
          {
            "code" : "V04CA",
            "display" : "Tests for diabetes"
          },
          {
            "code" : "V04CA01",
            "display" : "tolbutamide"
          },
          {
            "code" : "V04CA02",
            "display" : "glucose"
          },
          {
            "code" : "V04CB",
            "display" : "Tests for fat absorption"
          },
          {
            "code" : "V04CB01",
            "display" : "vitamin A concentrates"
          },
          {
            "code" : "V04CC",
            "display" : "Tests for bile duct patency"
          },
          {
            "code" : "V04CC01",
            "display" : "sorbitol"
          },
          {
            "code" : "V04CC02",
            "display" : "magnesium sulfate"
          },
          {
            "code" : "V04CC03",
            "display" : "sincalide"
          },
          {
            "code" : "V04CC04",
            "display" : "ceruletide"
          },
          {
            "code" : "V04CD",
            "display" : "Tests for pituitary function"
          },
          {
            "code" : "V04CD01",
            "display" : "metyrapone"
          },
          {
            "code" : "V04CD03",
            "display" : "sermorelin"
          },
          {
            "code" : "V04CD04",
            "display" : "corticorelin"
          },
          {
            "code" : "V04CD05",
            "display" : "somatorelin"
          },
          {
            "code" : "V04CD06",
            "display" : "macimorelin"
          },
          {
            "code" : "V04CE",
            "display" : "Tests for liver functional capacity"
          },
          {
            "code" : "V04CE01",
            "display" : "galactose"
          },
          {
            "code" : "V04CE02",
            "display" : "sulfobromophthalein"
          },
          {
            "code" : "V04CE03",
            "display" : "methacetin (13C)"
          },
          {
            "code" : "V04CF",
            "display" : "Tuberculosis diagnostics"
          },
          {
            "code" : "V04CF01",
            "display" : "tuberculin"
          },
          {
            "code" : "V04CG",
            "display" : "Tests for gastric secretion"
          },
          {
            "code" : "V04CG01",
            "display" : "cation exchange resins"
          },
          {
            "code" : "V04CG02",
            "display" : "betazole"
          },
          {
            "code" : "V04CG03",
            "display" : "histamine phosphate"
          },
          {
            "code" : "V04CG04",
            "display" : "pentagastrin"
          },
          {
            "code" : "V04CG05",
            "display" : "methylthioninium chloride"
          },
          {
            "code" : "V04CG30",
            "display" : "caffeine and sodium benzoate"
          },
          {
            "code" : "V04CH",
            "display" : "Tests for renal function and ureteral injuries"
          },
          {
            "code" : "V04CH01",
            "display" : "inulin and other polyfructosans"
          },
          {
            "code" : "V04CH02",
            "display" : "indigo carmine"
          },
          {
            "code" : "V04CH03",
            "display" : "phenolsulfonphthalein"
          },
          {
            "code" : "V04CH04",
            "display" : "alsactide"
          },
          {
            "code" : "V04CH30",
            "display" : "aminohippuric acid"
          },
          {
            "code" : "V04CJ",
            "display" : "Tests for thyreoidea function"
          },
          {
            "code" : "V04CJ01",
            "display" : "thyrotropin"
          },
          {
            "code" : "V04CJ02",
            "display" : "protirelin"
          },
          {
            "code" : "V04CK",
            "display" : "Tests for pancreatic function"
          },
          {
            "code" : "V04CK01",
            "display" : "secretin"
          },
          {
            "code" : "V04CK02",
            "display" : "pancreozymin (cholecystokinin)"
          },
          {
            "code" : "V04CK03",
            "display" : "bentiromide"
          },
          {
            "code" : "V04CL",
            "display" : "Tests for allergic diseases"
          },
          {
            "code" : "V04CM",
            "display" : "Tests for fertility disturbances"
          },
          {
            "code" : "V04CM01",
            "display" : "gonadorelin"
          },
          {
            "code" : "V04CX",
            "display" : "Other diagnostic agents"
          },
          {
            "code" : "V04CX01",
            "display" : "indocyanine green"
          },
          {
            "code" : "V04CX02",
            "display" : "folic acid"
          },
          {
            "code" : "V04CX03",
            "display" : "methacholine"
          },
          {
            "code" : "V04CX04",
            "display" : "mannitol"
          },
          {
            "code" : "V04CX05",
            "display" : "13C-urea"
          },
          {
            "code" : "V04CX06",
            "display" : "hexaminolevulinate"
          },
          {
            "code" : "V04CX07",
            "display" : "edrophonium"
          },
          {
            "code" : "V04CX08",
            "display" : "carbon monoxide"
          },
          {
            "code" : "V04CX09",
            "display" : "patent blue"
          },
          {
            "code" : "V04CX10",
            "display" : "pafolacianine"
          },
          {
            "code" : "V04CX11",
            "display" : "lithium chloride"
          },
          {
            "code" : "V04CX12",
            "display" : "xenon"
          },
          {
            "code" : "V06",
            "display" : "GENERAL NUTRIENTS"
          },
          {
            "code" : "V06A",
            "display" : "DIET FORMULATIONS FOR TREATMENT OF OBESITY"
          },
          {
            "code" : "V06AA",
            "display" : "Low-energy diets"
          },
          {
            "code" : "V06B",
            "display" : "PROTEIN SUPPLEMENTS"
          },
          {
            "code" : "V06C",
            "display" : "INFANT FORMULAS"
          },
          {
            "code" : "V06CA",
            "display" : "Nutrients without phenylalanine"
          },
          {
            "code" : "V06D",
            "display" : "OTHER NUTRIENTS"
          },
          {
            "code" : "V06DA",
            "display" : "Carbohydrates/proteins/minerals/vitamins, combinations"
          },
          {
            "code" : "V06DB",
            "display" : "Fat/carbohydrates/proteins/minerals/vitamins, combinations"
          },
          {
            "code" : "V06DC",
            "display" : "Carbohydrates"
          },
          {
            "code" : "V06DC01",
            "display" : "glucose"
          },
          {
            "code" : "V06DC02",
            "display" : "fructose"
          },
          {
            "code" : "V06DD",
            "display" : "Amino acids, incl. combinations with polypeptides"
          },
          {
            "code" : "V06DE",
            "display" : "Amino acids/carbohydrates/minerals/vitamins, combinations"
          },
          {
            "code" : "V06DF",
            "display" : "Milk substitutes"
          },
          {
            "code" : "V06DX",
            "display" : "Other combinations of nutrients"
          },
          {
            "code" : "V07",
            "display" : "ALL OTHER NON-THERAPEUTIC PRODUCTS"
          },
          {
            "code" : "V07A",
            "display" : "ALL OTHER NON-THERAPEUTIC PRODUCTS"
          },
          {
            "code" : "V07AA",
            "display" : "Plasters"
          },
          {
            "code" : "V07AB",
            "display" : "Solvents and diluting agents, incl. irrigating solutions"
          },
          {
            "code" : "V07AC",
            "display" : "Blood transfusion, auxiliary products"
          },
          {
            "code" : "V07AD",
            "display" : "Blood tests, auxiliary products"
          },
          {
            "code" : "V07AN",
            "display" : "Incontinence equipment"
          },
          {
            "code" : "V07AR",
            "display" : "Sensitivity tests, discs and tablets"
          },
          {
            "code" : "V07AS",
            "display" : "Stomi equipment"
          },
          {
            "code" : "V07AT",
            "display" : "Cosmetics"
          },
          {
            "code" : "V07AV",
            "display" : "Technical disinfectants"
          },
          {
            "code" : "V07AX",
            "display" : "Washing agents etc."
          },
          {
            "code" : "V07AY",
            "display" : "Other non-therapeutic auxiliary products"
          },
          {
            "code" : "V07AZ",
            "display" : "Chemicals and reagents for analysis"
          },
          {
            "code" : "V08",
            "display" : "CONTRAST MEDIA"
          },
          {
            "code" : "V08A",
            "display" : "X-RAY CONTRAST MEDIA, IODINATED"
          },
          {
            "code" : "V08AA",
            "display" : "Watersoluble, nephrotropic, high osmolar X-ray contrast media"
          },
          {
            "code" : "V08AA01",
            "display" : "diatrizoic acid"
          },
          {
            "code" : "V08AA02",
            "display" : "metrizoic acid"
          },
          {
            "code" : "V08AA03",
            "display" : "iodamide"
          },
          {
            "code" : "V08AA04",
            "display" : "iotalamic acid"
          },
          {
            "code" : "V08AA05",
            "display" : "ioxitalamic acid"
          },
          {
            "code" : "V08AA06",
            "display" : "ioglicic acid"
          },
          {
            "code" : "V08AA07",
            "display" : "acetrizoic acid"
          },
          {
            "code" : "V08AA08",
            "display" : "iocarmic acid"
          },
          {
            "code" : "V08AA09",
            "display" : "methiodal"
          },
          {
            "code" : "V08AA10",
            "display" : "diodone"
          },
          {
            "code" : "V08AB",
            "display" : "Watersoluble, nephrotropic, low osmolar X-ray contrast media"
          },
          {
            "code" : "V08AB01",
            "display" : "metrizamide"
          },
          {
            "code" : "V08AB02",
            "display" : "iohexol"
          },
          {
            "code" : "V08AB03",
            "display" : "ioxaglic acid"
          },
          {
            "code" : "V08AB04",
            "display" : "iopamidol"
          },
          {
            "code" : "V08AB05",
            "display" : "iopromide"
          },
          {
            "code" : "V08AB06",
            "display" : "iotrolan"
          },
          {
            "code" : "V08AB07",
            "display" : "ioversol"
          },
          {
            "code" : "V08AB08",
            "display" : "iopentol"
          },
          {
            "code" : "V08AB09",
            "display" : "iodixanol"
          },
          {
            "code" : "V08AB10",
            "display" : "iomeprol"
          },
          {
            "code" : "V08AB11",
            "display" : "iobitridol"
          },
          {
            "code" : "V08AB12",
            "display" : "ioxilan"
          },
          {
            "code" : "V08AC",
            "display" : "Watersoluble, hepatotropic X-ray contrast media"
          },
          {
            "code" : "V08AC01",
            "display" : "iodoxamic acid"
          },
          {
            "code" : "V08AC02",
            "display" : "iotroxic acid"
          },
          {
            "code" : "V08AC03",
            "display" : "ioglycamic acid"
          },
          {
            "code" : "V08AC04",
            "display" : "adipiodone"
          },
          {
            "code" : "V08AC05",
            "display" : "iobenzamic acid"
          },
          {
            "code" : "V08AC06",
            "display" : "iopanoic acid"
          },
          {
            "code" : "V08AC07",
            "display" : "iocetamic acid"
          },
          {
            "code" : "V08AC08",
            "display" : "sodium iopodate"
          },
          {
            "code" : "V08AC09",
            "display" : "tyropanoic acid"
          },
          {
            "code" : "V08AC10",
            "display" : "calcium iopodate"
          },
          {
            "code" : "V08AD",
            "display" : "Non-watersoluble X-ray contrast media"
          },
          {
            "code" : "V08AD01",
            "display" : "ethyl esters of iodised fatty acids"
          },
          {
            "code" : "V08AD02",
            "display" : "iopydol"
          },
          {
            "code" : "V08AD03",
            "display" : "propyliodone"
          },
          {
            "code" : "V08AD04",
            "display" : "iofendylate"
          },
          {
            "code" : "V08B",
            "display" : "X-RAY CONTRAST MEDIA, NON-IODINATED"
          },
          {
            "code" : "V08BA",
            "display" : "Barium sulfate containing X-ray contrast media"
          },
          {
            "code" : "V08BA01",
            "display" : "barium sulfate with suspending agents"
          },
          {
            "code" : "V08BA02",
            "display" : "barium sulfate without suspending agents"
          },
          {
            "code" : "V08C",
            "display" : "MAGNETIC RESONANCE IMAGING CONTRAST MEDIA"
          },
          {
            "code" : "V08CA",
            "display" : "Paramagnetic contrast media"
          },
          {
            "code" : "V08CA01",
            "display" : "gadopentetic acid"
          },
          {
            "code" : "V08CA02",
            "display" : "gadoteric acid"
          },
          {
            "code" : "V08CA03",
            "display" : "gadodiamide"
          },
          {
            "code" : "V08CA04",
            "display" : "gadoteridol"
          },
          {
            "code" : "V08CA05",
            "display" : "mangafodipir"
          },
          {
            "code" : "V08CA06",
            "display" : "gadoversetamide"
          },
          {
            "code" : "V08CA07",
            "display" : "ferric ammonium citrate"
          },
          {
            "code" : "V08CA08",
            "display" : "gadobenic acid"
          },
          {
            "code" : "V08CA09",
            "display" : "gadobutrol"
          },
          {
            "code" : "V08CA10",
            "display" : "gadoxetic acid"
          },
          {
            "code" : "V08CA11",
            "display" : "gadofosveset"
          },
          {
            "code" : "V08CA12",
            "display" : "gadopiclenol"
          },
          {
            "code" : "V08CB",
            "display" : "Superparamagnetic contrast media"
          },
          {
            "code" : "V08CB01",
            "display" : "ferumoxsil"
          },
          {
            "code" : "V08CB02",
            "display" : "ferristene"
          },
          {
            "code" : "V08CB03",
            "display" : "iron oxide, nanoparticles"
          },
          {
            "code" : "V08CX",
            "display" : "Other magnetic resonance imaging contrast media"
          },
          {
            "code" : "V08CX01",
            "display" : "perflubron"
          },
          {
            "code" : "V08D",
            "display" : "ULTRASOUND CONTRAST MEDIA"
          },
          {
            "code" : "V08DA",
            "display" : "Ultrasound contrast media"
          },
          {
            "code" : "V08DA01",
            "display" : "perflutren, human albumin microspheres"
          },
          {
            "code" : "V08DA02",
            "display" : "microparticles of galactose"
          },
          {
            "code" : "V08DA03",
            "display" : "perflenapent"
          },
          {
            "code" : "V08DA04",
            "display" : "perflutren, phospholipid microspheres"
          },
          {
            "code" : "V08DA05",
            "display" : "sulfur hexafluoride, phospholipid microspheres"
          },
          {
            "code" : "V08DA06",
            "display" : "perflubutane, phospholipid microspheres"
          },
          {
            "code" : "V09",
            "display" : "DIAGNOSTIC RADIOPHARMACEUTICALS"
          },
          {
            "code" : "V09A",
            "display" : "CENTRAL NERVOUS SYSTEM"
          },
          {
            "code" : "V09AA",
            "display" : "Technetium (99mTc) compounds"
          },
          {
            "code" : "V09AA01",
            "display" : "technetium (99mTc) exametazime"
          },
          {
            "code" : "V09AA02",
            "display" : "technetium (99mTc) bicisate"
          },
          {
            "code" : "V09AB",
            "display" : "Iodine (123I) compounds"
          },
          {
            "code" : "V09AB01",
            "display" : "iodine iofetamine (123I)"
          },
          {
            "code" : "V09AB02",
            "display" : "iodine iolopride (123I)"
          },
          {
            "code" : "V09AB03",
            "display" : "iodine ioflupane (123I)"
          },
          {
            "code" : "V09AX",
            "display" : "Other central nervous system diagnostic radiopharmaceuticals"
          },
          {
            "code" : "V09AX01",
            "display" : "indium (111In) pentetic acid"
          },
          {
            "code" : "V09AX03",
            "display" : "iodine (124I) 2beta-carbomethoxy-3beta-(4 iodophenyl)-tropane"
          },
          {
            "code" : "V09AX04",
            "display" : "flutemetamol (18F)"
          },
          {
            "code" : "V09AX05",
            "display" : "florbetapir (18F)"
          },
          {
            "code" : "V09AX06",
            "display" : "florbetaben (18F)"
          },
          {
            "code" : "V09AX07",
            "display" : "flortaucipir (18F)"
          },
          {
            "code" : "V09B",
            "display" : "SKELETON"
          },
          {
            "code" : "V09BA",
            "display" : "Technetium (99mTc) compounds"
          },
          {
            "code" : "V09BA01",
            "display" : "technetium (99mTc) oxidronic acid"
          },
          {
            "code" : "V09BA02",
            "display" : "technetium (99mTc) medronic acid"
          },
          {
            "code" : "V09BA03",
            "display" : "technetium (99mTc) pyrophosphate"
          },
          {
            "code" : "V09BA04",
            "display" : "technetium (99mTc) butedronic acid"
          },
          {
            "code" : "V09C",
            "display" : "RENAL SYSTEM"
          },
          {
            "code" : "V09CA",
            "display" : "Technetium (99mTc) compounds"
          },
          {
            "code" : "V09CA01",
            "display" : "technetium (99mTc) pentetic acid"
          },
          {
            "code" : "V09CA02",
            "display" : "technetium (99mTc) succimer"
          },
          {
            "code" : "V09CA03",
            "display" : "technetium (99mTc) mertiatide"
          },
          {
            "code" : "V09CA04",
            "display" : "technetium (99mTc) gluceptate"
          },
          {
            "code" : "V09CA05",
            "display" : "technetium (99mTc) gluconate"
          },
          {
            "code" : "V09CA06",
            "display" : "technetium (99mTc) ethylenedicysteine"
          },
          {
            "code" : "V09CX",
            "display" : "Other renal system diagnostic radiopharmaceuticals"
          },
          {
            "code" : "V09CX01",
            "display" : "sodium iodohippurate (123I)"
          },
          {
            "code" : "V09CX02",
            "display" : "sodium iodohippurate (131I)"
          },
          {
            "code" : "V09CX03",
            "display" : "sodium iothalamate (125I)"
          },
          {
            "code" : "V09CX04",
            "display" : "chromium (51Cr) edetate"
          },
          {
            "code" : "V09D",
            "display" : "HEPATIC AND RETICULO ENDOTHELIAL SYSTEM"
          },
          {
            "code" : "V09DA",
            "display" : "Technetium (99mTc) compounds"
          },
          {
            "code" : "V09DA01",
            "display" : "technetium (99mTc) disofenin"
          },
          {
            "code" : "V09DA02",
            "display" : "technetium (99mTc) etifenin"
          },
          {
            "code" : "V09DA03",
            "display" : "technetium (99mTc) lidofenin"
          },
          {
            "code" : "V09DA04",
            "display" : "technetium (99mTc) mebrofenin"
          },
          {
            "code" : "V09DA05",
            "display" : "technetium (99mTc) galtifenin"
          },
          {
            "code" : "V09DB",
            "display" : "Technetium (99mTc), particles and colloids"
          },
          {
            "code" : "V09DB01",
            "display" : "technetium (99mTc) nanocolloid"
          },
          {
            "code" : "V09DB02",
            "display" : "technetium (99mTc) microcolloid"
          },
          {
            "code" : "V09DB03",
            "display" : "technetium (99mTc) millimicrospheres"
          },
          {
            "code" : "V09DB04",
            "display" : "technetium (99mTc) tin colloid"
          },
          {
            "code" : "V09DB05",
            "display" : "technetium (99mTc) sulfur colloid"
          },
          {
            "code" : "V09DB06",
            "display" : "technetium (99mTc) rheniumsulfide colloid"
          },
          {
            "code" : "V09DB07",
            "display" : "technetium (99mTc) phytate"
          },
          {
            "code" : "V09DX",
            "display" : "Other hepatic and reticulo endothelial system diagnostic radiopharmaceuticals"
          },
          {
            "code" : "V09DX01",
            "display" : "selenium (75Se) tauroselcholic acid"
          },
          {
            "code" : "V09E",
            "display" : "RESPIRATORY SYSTEM"
          },
          {
            "code" : "V09EA",
            "display" : "Technetium (99mTc), inhalants"
          },
          {
            "code" : "V09EA01",
            "display" : "technetium (99mTc) pentetic acid"
          },
          {
            "code" : "V09EA02",
            "display" : "technetium (99mTc) technegas"
          },
          {
            "code" : "V09EA03",
            "display" : "technetium (99mTc) nanocolloid"
          },
          {
            "code" : "V09EB",
            "display" : "Technetium (99mTc), particles for injection"
          },
          {
            "code" : "V09EB01",
            "display" : "technetium (99mTc) macrosalb"
          },
          {
            "code" : "V09EB02",
            "display" : "technetium (99mTc) microspheres"
          },
          {
            "code" : "V09EX",
            "display" : "Other respiratory system diagnostic radiopharmaceuticals"
          },
          {
            "code" : "V09EX01",
            "display" : "krypton (81mKr) gas"
          },
          {
            "code" : "V09EX02",
            "display" : "xenon (127Xe) gas"
          },
          {
            "code" : "V09EX03",
            "display" : "xenon (133Xe) gas"
          },
          {
            "code" : "V09F",
            "display" : "THYROID"
          },
          {
            "code" : "V09FX",
            "display" : "Various thyroid diagnostic radiopharmaceuticals"
          },
          {
            "code" : "V09FX01",
            "display" : "technetium (99mTc) pertechnetate"
          },
          {
            "code" : "V09FX02",
            "display" : "sodium iodide (123I)"
          },
          {
            "code" : "V09FX03",
            "display" : "sodium iodide (131I)"
          },
          {
            "code" : "V09FX04",
            "display" : "sodium iodide (124I)"
          },
          {
            "code" : "V09G",
            "display" : "CARDIOVASCULAR SYSTEM"
          },
          {
            "code" : "V09GA",
            "display" : "Technetium (99mTc) compounds"
          },
          {
            "code" : "V09GA01",
            "display" : "technetium (99mTc) sestamibi"
          },
          {
            "code" : "V09GA02",
            "display" : "technetium (99mTc) tetrofosmin"
          },
          {
            "code" : "V09GA03",
            "display" : "technetium (99mTc) teboroxime"
          },
          {
            "code" : "V09GA04",
            "display" : "technetium (99mTc) human albumin"
          },
          {
            "code" : "V09GA05",
            "display" : "technetium (99mTc) furifosmin"
          },
          {
            "code" : "V09GA06",
            "display" : "technetium (99mTc) stannous agent labelled cells"
          },
          {
            "code" : "V09GA07",
            "display" : "technetium (99mTc) apcitide"
          },
          {
            "code" : "V09GB",
            "display" : "Iodine (125I) compounds"
          },
          {
            "code" : "V09GB01",
            "display" : "fibrinogen (125I)"
          },
          {
            "code" : "V09GB02",
            "display" : "iodine (125I) human albumin"
          },
          {
            "code" : "V09GX",
            "display" : "Other cardiovascular system diagnostic radiopharmaceuticals"
          },
          {
            "code" : "V09GX01",
            "display" : "thallium (201Tl) chloride"
          },
          {
            "code" : "V09GX02",
            "display" : "indium (111In) imciromab"
          },
          {
            "code" : "V09GX03",
            "display" : "chromium (51Cr) chromate labelled cells"
          },
          {
            "code" : "V09GX04",
            "display" : "rubidium (82Rb) chloride"
          },
          {
            "code" : "V09GX05",
            "display" : "ammonia (13N)"
          },
          {
            "code" : "V09H",
            "display" : "INFLAMMATION AND INFECTION DETECTION"
          },
          {
            "code" : "V09HA",
            "display" : "Technetium (99mTc) compounds"
          },
          {
            "code" : "V09HA01",
            "display" : "technetium (99mTc) human immunoglobulin"
          },
          {
            "code" : "V09HA02",
            "display" : "technetium (99mTc) exametazime labelled cells"
          },
          {
            "code" : "V09HA03",
            "display" : "technetium (99mTc) antigranulocyte antibody"
          },
          {
            "code" : "V09HA04",
            "display" : "technetium (99mTc) sulesomab"
          },
          {
            "code" : "V09HB",
            "display" : "Indium (111In) compounds"
          },
          {
            "code" : "V09HB01",
            "display" : "indium (111In) oxinate labelled cells"
          },
          {
            "code" : "V09HB02",
            "display" : "indium (111In) tropolonate labelled cells"
          },
          {
            "code" : "V09HX",
            "display" : "Other diagnostic radiopharmaceuticals for inflammation and infection detection"
          },
          {
            "code" : "V09HX01",
            "display" : "gallium (67Ga) citrate"
          },
          {
            "code" : "V09I",
            "display" : "TUMOUR DETECTION"
          },
          {
            "code" : "V09IA",
            "display" : "Technetium (99mTc) compounds"
          },
          {
            "code" : "V09IA01",
            "display" : "technetium (99mTc) antiCarcinoEmbryonicAntigen antibody"
          },
          {
            "code" : "V09IA02",
            "display" : "technetium (99mTc) antimelanoma antibody"
          },
          {
            "code" : "V09IA03",
            "display" : "technetium (99mTc) pentavalent succimer"
          },
          {
            "code" : "V09IA04",
            "display" : "technetium (99mTc) votumumab"
          },
          {
            "code" : "V09IA05",
            "display" : "technetium (99mTc) depreotide"
          },
          {
            "code" : "V09IA06",
            "display" : "technetium (99mTc) arcitumomab"
          },
          {
            "code" : "V09IA07",
            "display" : "technetium (99mTc) hynic-octreotide"
          },
          {
            "code" : "V09IA08",
            "display" : "technetium (99mTc) etarfolatide"
          },
          {
            "code" : "V09IA09",
            "display" : "technetium (99mTc) tilmanocept"
          },
          {
            "code" : "V09IA10",
            "display" : "technetium (99mTc) trofolastat chloride"
          },
          {
            "code" : "V09IB",
            "display" : "Indium (111In) compounds"
          },
          {
            "code" : "V09IB01",
            "display" : "indium (111In) pentetreotide"
          },
          {
            "code" : "V09IB02",
            "display" : "indium (111In) satumomab pendetide"
          },
          {
            "code" : "V09IB03",
            "display" : "indium (111In) antiovariumcarcinoma antibody"
          },
          {
            "code" : "V09IB04",
            "display" : "indium (111In) capromab pendetide"
          },
          {
            "code" : "V09IX",
            "display" : "Other diagnostic radiopharmaceuticals for tumour detection"
          },
          {
            "code" : "V09IX01",
            "display" : "iobenguane (123I)"
          },
          {
            "code" : "V09IX02",
            "display" : "iobenguane (131I)"
          },
          {
            "code" : "V09IX03",
            "display" : "iodine (125I) CC49-monoclonal antibody"
          },
          {
            "code" : "V09IX04",
            "display" : "fludeoxyglucose (18F)"
          },
          {
            "code" : "V09IX05",
            "display" : "fluorodopa (18F)"
          },
          {
            "code" : "V09IX06",
            "display" : "sodium fluoride (18F)"
          },
          {
            "code" : "V09IX07",
            "display" : "fluorocholine (18F)"
          },
          {
            "code" : "V09IX08",
            "display" : "fluoroethylcholine (18F)"
          },
          {
            "code" : "V09IX09",
            "display" : "gallium (68Ga) edotreotide"
          },
          {
            "code" : "V09IX10",
            "display" : "fluoroethyl-L-tyrosine (18F)"
          },
          {
            "code" : "V09IX11",
            "display" : "fluoroestradiol (18F)"
          },
          {
            "code" : "V09IX12",
            "display" : "fluciclovine (18F)"
          },
          {
            "code" : "V09IX13",
            "display" : "methionine (11C)"
          },
          {
            "code" : "V09IX14",
            "display" : "gallium (68Ga) gozetotide"
          },
          {
            "code" : "V09IX15",
            "display" : "copper (64Cu) dotatate"
          },
          {
            "code" : "V09IX16",
            "display" : "piflufolastat (18F)"
          },
          {
            "code" : "V09IX17",
            "display" : "PSMA-1007 (18F)"
          },
          {
            "code" : "V09IX18",
            "display" : "flotufolastat (18F)"
          },
          {
            "code" : "V09X",
            "display" : "OTHER DIAGNOSTIC RADIOPHARMACEUTICALS"
          },
          {
            "code" : "V09XA",
            "display" : "Iodine (131I) compounds"
          },
          {
            "code" : "V09XA01",
            "display" : "iodine (131I) norcholesterol"
          },
          {
            "code" : "V09XA02",
            "display" : "iodocholesterol (131I)"
          },
          {
            "code" : "V09XA03",
            "display" : "iodine (131I) human albumin"
          },
          {
            "code" : "V09XX",
            "display" : "Various diagnostic radiopharmaceuticals"
          },
          {
            "code" : "V09XX01",
            "display" : "cobalt (57Co) cyanocobalamine"
          },
          {
            "code" : "V09XX02",
            "display" : "cobalt (58Co) cyanocobalamine"
          },
          {
            "code" : "V09XX03",
            "display" : "selenium (75Se) norcholesterol"
          },
          {
            "code" : "V09XX04",
            "display" : "ferric (59Fe) citrate"
          },
          {
            "code" : "V10",
            "display" : "THERAPEUTIC RADIOPHARMACEUTICALS"
          },
          {
            "code" : "V10A",
            "display" : "ANTIINFLAMMATORY AGENTS"
          },
          {
            "code" : "V10AA",
            "display" : "Yttrium (90Y) compounds"
          },
          {
            "code" : "V10AA01",
            "display" : "yttrium (90Y) citrate colloid"
          },
          {
            "code" : "V10AA02",
            "display" : "yttrium (90Y) ferrihydroxide colloid"
          },
          {
            "code" : "V10AA03",
            "display" : "yttrium (90Y) silicate colloid"
          },
          {
            "code" : "V10AX",
            "display" : "Other antiinflammatory therapeutic radiopharmaceuticals"
          },
          {
            "code" : "V10AX01",
            "display" : "phosphorous (32P) chromicphosphate colloid"
          },
          {
            "code" : "V10AX02",
            "display" : "samarium (153Sm) hydroxyapatite colloid"
          },
          {
            "code" : "V10AX03",
            "display" : "dysprosium (165Dy) colloid"
          },
          {
            "code" : "V10AX04",
            "display" : "erbium (169Er) citrate colloid"
          },
          {
            "code" : "V10AX05",
            "display" : "rhenium (186Re) sulfide colloid"
          },
          {
            "code" : "V10AX06",
            "display" : "gold (198Au) colloidal"
          },
          {
            "code" : "V10B",
            "display" : "PAIN PALLIATION (BONE SEEKING AGENTS)"
          },
          {
            "code" : "V10BX",
            "display" : "Various pain palliation radiopharmaceuticals"
          },
          {
            "code" : "V10BX01",
            "display" : "strontium (89Sr) chloride"
          },
          {
            "code" : "V10BX02",
            "display" : "samarium (153Sm) lexidronam"
          },
          {
            "code" : "V10BX03",
            "display" : "rhenium (186Re) etidronic acid"
          },
          {
            "code" : "V10X",
            "display" : "OTHER THERAPEUTIC RADIOPHARMACEUTICALS"
          },
          {
            "code" : "V10XA",
            "display" : "Iodine (131I) compounds"
          },
          {
            "code" : "V10XA01",
            "display" : "sodium iodide (131I)"
          },
          {
            "code" : "V10XA02",
            "display" : "iobenguane (131I)"
          },
          {
            "code" : "V10XA03",
            "display" : "iodine (131I) omburtamab"
          },
          {
            "code" : "V10XA04",
            "display" : "iodine (131I) apamistamab"
          },
          {
            "code" : "V10XA53",
            "display" : "tositumomab/iodine (131I) tositumomab"
          },
          {
            "code" : "V10XX",
            "display" : "Various therapeutic radiopharmaceuticals"
          },
          {
            "code" : "V10XX01",
            "display" : "sodium phosphate (32P)"
          },
          {
            "code" : "V10XX02",
            "display" : "ibritumomab tiuxetan (90Y)"
          },
          {
            "code" : "V10XX03",
            "display" : "radium (223Ra) dichloride"
          },
          {
            "code" : "V10XX04",
            "display" : "lutetium (177Lu) oxodotreotide"
          },
          {
            "code" : "V10XX05",
            "display" : "lutetium (177Lu) vipivotide tetraxetan"
          },
          {
            "code" : "V20",
            "display" : "SURGICAL DRESSINGS"
          }
        ]
      }
    ]
  }
}

```
